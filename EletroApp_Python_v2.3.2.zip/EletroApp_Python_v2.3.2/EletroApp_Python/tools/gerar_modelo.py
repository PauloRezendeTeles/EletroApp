#!/usr/bin/env python3
"""Gera o modelo nativo do EletroApp a partir da planilha r42 (ferramenta de desenvolvimento, v2.0).

Executada uma única vez na migração. Lê a r42 já com as adaptações do
EletroApp 1.12 (instalação, trecho, motores, DPS, Nc...) e grava:

* ``data/modelo/circuito.json`` — variáveis do circuito com nome, rótulo, unidade,
  expressão nomeada, variante para circuitos ligados à fonte e listas de opções;
* ``data/modelo/fonte.json``    — dados e cálculos da fonte (entrada de energia);
* ``data/modelo/projeto.json``  — verificações do projeto inteiro;
* ``data/modelo/nomes.json``    — nomes definidos (intervalos das tabelas técnicas);
* ``data/tabelas/*.json``       — tabelas técnicas e catálogos, com metadados;
* ``data/exemplos/exemplo.json`` — o projeto de exemplo, só com dados de entrada;
* ``docs/MIGRACAO_MODELO.md``    — decisões de unificação das fórmulas.

Uso: python tools/gerar_modelo.py <r42.json.gz>
"""
from __future__ import annotations

import collections
import gzip
import json
import re
import sys
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from core.formula import address, col_name, col_number, parse  # noqa: E402
from core.expressao import text, transform, walk  # noqa: E402

CIRCUIT_SHEETS = {
    'Identificação dos circuitos': ('ident', 'Identificação'),
    'Maneira de instalar': ('instalacao', 'Maneira de instalar'),
    'Identificação-Método_Instal ': ('metodo', 'Método de instalação'),
    'Dados dos condutores ': ('condutores', 'Dados dos condutores'),
    'Corrente-Calc_Ampacidade ': ('amp_corrente', 'Correntes corrigidas para ampacidade'),
    'Cálc_Seç-Ampacidade': ('amp_secao', 'Seção pelo critério de ampacidade'),
    'Dados dos circuitos': ('dados', 'Condições do circuito'),
    'Levantamento de carga': ('cargas', 'Levantamento de cargas'),
    'Cálc_Icc-Motores': ('motores', 'Motores'),
    'Carga nos circuitos': ('carga', 'Carga nos circuitos'),
    'Corrente nominal': ('corrente', 'Corrente nominal'),
    'Cálc_Seç-Seç_Min': ('secao_min', 'Seção mínima'),
    'Cálc_Seç-Queda de tensão': ('secao_queda', 'Seção pela queda de tensão'),
    'Cálc_Seç_Red_N-T-Cond Sugerido': ('sug_reducao', 'Redução de neutro e PE (condutor sugerido)'),
    'Corrente_Max-Cond_Sugerido': ('sug_iz', 'Iz do condutor sugerido'),
    'Cálc_Imp-Cond_Sugerido': ('sug_imp', 'Impedâncias do condutor sugerido'),
    'Cálc_Icc-Cond_Sugerido': ('sug_icc', 'Curto-circuito com o condutor sugerido'),
    'Cálc-Prot_Cond_Sugerido': ('sug_prot', 'Proteção do condutor sugerido'),
    'Cálc_Seç-Icc_Cond_Sugerido': ('secao_icc', 'Seção pelo curto-circuito'),
    'Cálc-Condutor_Terra_Sugerido': ('sug_pe', 'Condutor de proteção (sugerido)'),
    'Seleção-Seção_Condutor': ('secoes', 'Seleção das seções'),
    'Cálc_Imp-Cond_Escolhido': ('imp', 'Impedâncias do condutor escolhido'),
    'Cálc_Icc-Cond_Escolhido': ('icc', 'Curto-circuito com o condutor escolhido'),
    'Temp_Operacional': ('temperatura', 'Temperatura de operação'),
    'Cálc_Seç_Red_N_PE-Cond escolhid': ('reducao', 'Redução de neutro e PE (condutor escolhido)'),
    'Corrente_Max-Cond_Escolhido': ('iz', 'Iz do condutor escolhido'),
    'Queda_Tens-Cond_Escolhido': ('queda', 'Queda de tensão'),
    'ΔV_Partida_Motores': ('partida', 'Partida de motores'),
    'Cálc-Prot_Cabos': ('protecao', 'Proteção dos cabos'),
    'Seletividade': ('seletividade', 'Seletividade'),
    'Cálc-Prot_Choque': ('choque', 'Proteção contra choques'),
    'Cálc_Comp_Max-Icc': ('comp_max', 'Comprimento máximo'),
    'DPS': ('dps', 'DPS'),
    'Auditoria_Checklist': ('auditoria', 'Auditoria do circuito'),
    'Dispositivos_Trecho': ('trecho', 'Dispositivos do trecho'),
}
FONTE = 'Padrão de entrada'
TABLES = {
    'sist-Nomes': 'tab_listas', 'Metodos_Inst_Ajuda': 'tab_metodos', 'Tabelas_33_NBR': 'tab_nbr5410_t33',
    'Tabela - Motores': 'tab_motores', 'Tabela_Concess': 'tab_concessionaria', 'Tab_Imped-Cabos': 'tab_impedancias',
    'Tabelas_Correção-In': 'tab_fatores_correcao', 'Tabela-Seção_Neutro': 'tab_secao_neutro', 'Tabela-Seção_PE': 'tab_secao_pe',
    'Tabelas_Ampacidade_2cond': 'tab_ampacidade_2c', 'Tabelas_Ampacidade_3cond': 'tab_ampacidade_3c',
    'Tabela_Disjuntores': 'tab_disjuntores_ref', 'Tabela_Transformadores': 'tab_transformadores',
    'Tabela_In_Comercial': 'tab_in_comercial', 'Biblioteca_Proteções_WEG': 'tab_weg_protecoes',
    'Biblioteca_DPS_Siemens': 'tab_dps_siemens', 'Biblioteca_DPS_Clamper': 'tab_dps_clamper', 'Biblioteca_Fusiveis_NH': 'tab_fusiveis_nh',
}
DROPPED = {'Memorial-1', 'Memorial-2', 'Memorial-3', 'Memorial-4', 'Memorial-5', 'Auditoria_Seleção_Disjuntores'}
# Colunas cuja fórmula da linha 2 (primeiro circuito, ligado à fonte) é semântica: impedância a montante = fonte.
ROOT_VARIANT = {(s, c) for s in ('Cálc_Imp-Cond_Sugerido', 'Cálc_Imp-Cond_Escolhido')
                for c in ('W', 'X', 'AD', 'AE', 'AK', 'AL', 'AR', 'AV', 'AW', 'AX', 'AY')}
PROJECT_LEVEL = {('Auditoria_Checklist', 'R'), ('Auditoria_Checklist', 'S'), ('Auditoria_Checklist', 'T')}
# Identificadores escolhidos à mão para as variáveis mais usadas (o restante vem do cabeçalho).
OVERRIDE_IDS = {
    ('Identificação dos circuitos', 'A'): 'ident.posicao', ('Identificação dos circuitos', 'B'): 'ident.nome',
    ('Identificação dos circuitos', 'C'): 'ident.descricao', ('Identificação dos circuitos', 'D'): 'ident.montante',
    ('Identificação dos circuitos', 'E'): 'ident.ligacao', ('Identificação dos circuitos', 'F'): 'ident.aterramento',
    ('Identificação dos circuitos', 'G'): 'ident.tipo_calculo', ('Identificação dos circuitos', 'K'): 'ident.status_topologia',
    ('Identificação dos circuitos', 'M'): 'ident.natureza',
    ('Levantamento de carga', 'D'): 'cargas.p_r_w', ('Levantamento de carga', 'E'): 'cargas.fp_r',
    ('Levantamento de carga', 'H'): 'cargas.p_s_w', ('Levantamento de carga', 'I'): 'cargas.fp_s',
    ('Levantamento de carga', 'L'): 'cargas.p_t_w', ('Levantamento de carga', 'M'): 'cargas.fp_t',
    ('Carga nos circuitos', 'Y'): 'carga.p_total_w', ('Carga nos circuitos', 'Z'): 'carga.s_total_va',
    ('Carga nos circuitos', 'AA'): 'carga.q_total_var', ('Carga nos circuitos', 'F'): 'carga.fp',
    ('Corrente nominal', 'P'): 'corrente.i_r_a', ('Corrente nominal', 'R'): 'corrente.i_s_a',
    ('Corrente nominal', 'T'): 'corrente.i_t_a', ('Corrente nominal', 'V'): 'corrente.i_neutro_a',
    ('Seleção-Seção_Condutor', 'T'): 'secoes.fase_mm2', ('Seleção-Seção_Condutor', 'W'): 'secoes.neutro_mm2',
    ('Seleção-Seção_Condutor', 'Z'): 'secoes.pe_mm2', ('Seleção-Seção_Condutor', 'S'): 'secoes.fase_sugerida_mm2',
    ('Cálc-Prot_Cabos', 'D'): 'protecao.ib_a', ('Cálc-Prot_Cabos', 'F'): 'protecao.iz_a',
    ('Cálc-Prot_Cabos', 'Y'): 'protecao.ir_a', ('Cálc-Prot_Cabos', 'Z'): 'protecao.ii_a',
    ('Cálc-Prot_Cabos', 'BX'): 'protecao.isd_a', ('Cálc-Prot_Cabos', 'BZ'): 'protecao.tsd_ms',
    ('Cálc-Prot_Cabos', 'AL'): 'protecao.familia', ('Cálc-Prot_Cabos', 'AM'): 'protecao.modelo',
    ('Cálc-Prot_Cabos', 'DN'): 'protecao.modelo_em_uso', ('Cálc-Prot_Cabos', 'BJ'): 'protecao.status_final',
    ('Cálc-Prot_Cabos', 'AA'): 'protecao.icu_ka', ('Cálc-Prot_Cabos', 'K'): 'protecao.in_a',
    ('Queda_Tens-Cond_Escolhido', 'U'): 'queda.trecho_pct', ('Queda_Tens-Cond_Escolhido', 'W'): 'queda.acumulada_pct',
    ('Cálc_Icc-Cond_Escolhido', 'S'): 'icc.ik_max_ka', ('Cálc_Icc-Cond_Escolhido', 'K'): 'icc.ik_min_1f_ka',
    ('DPS', 'AV'): 'dps.modelo_ativo', ('DPS', 'AS'): 'dps.status',
    ('Dados dos circuitos', 'F'): 'dados.comprimento_m', ('Dados dos circuitos', 'H'): 'dados.simultaneidade',
    ('Dados dos condutores ', 'D'): 'condutores.por_polo',
}
FONTE_IDS = {'B2': 'fonte.tipo_atendimento', 'B135': 'fonte.tensao_linha_v', 'B136': 'fonte.potencia_referencia',
             'B137': 'fonte.r1_sistema', 'B138': 'fonte.x1_sistema', 'B140': 'fonte.r0_sistema', 'B141': 'fonte.x0_sistema',
             'B147': 'fonte.cmax', 'B148': 'fonte.cmin', 'B78': 'fonte.esquema_aterramento', 'B75': 'fonte.trafo_kva',
             'B80': 'fonte.trafo_tensao_secundario_v', 'B81': 'fonte.trafo_grupo_ligacao', 'B9': 'fonte.tensao_mt_kv',
             'B11': 'fonte.modo_entrada_mt', 'B31': 'fonte.tensao_bt_v', 'B45': 'fonte.gerador_tensao_v',
             'B46': 'fonte.gerador_kva', 'B47': 'fonte.gerador_fp'}
LOG = []


def slug(textv, maxlen=44):
    t = str(textv or '')
    t = re.sub(r'\[.*?\]', ' ', t, flags=re.S)
    for k, v in {'φ': ' phi ', 'θ': ' theta ', 'Δ': ' dv ', 'Σ': ' soma ', '∑': ' soma ', 'Ω': ' ohm ', 'µ': 'u', 'μ': 'u',
                 '²': '2', '³': '3', '√': ' raiz ', '%': ' pct ', '≤': ' le ', '≥': ' ge ', '×': ' x ', 'ₙ': 'n', '₀': '0', '₁': '1',
                 '₂': '2', '₃': '3', 'ᵢ': 'i'}.items():
        t = t.replace(k, v)
    t = unicodedata.normalize('NFKD', t).encode('ascii', 'ignore').decode().casefold()
    t = re.sub(r'[^0-9a-z]+', '_', t).strip('_')
    t = re.sub(r'_+', '_', t)
    if len(t) > maxlen:
        cut = t[:maxlen]
        t = cut.rsplit('_', 1)[0] if '_' in cut[10:] else cut
    if not t or t[0].isdigit():
        t = 'v_' + t
    return t


def unit_of(header):
    h = str(header or '')
    for m in re.finditer(r'\(([^()]{1,14})\)', h):
        u = m.group(1).strip()
        if re.fullmatch(r'[A-Za-zΩµμ°²³%/·\.\-\s0-9º]+', u) and not re.fullmatch(r'\d+', u):
            return u
    return ''


def label_of(header):
    h = re.sub(r'\[.*?\]', '', str(header or ''), flags=re.S)
    return ' '.join(h.split()).strip()


def lit_norm(t, r):
    return re.sub(r'(?<![\w$.:])%d(?![\w.])' % r, '{ROW}', t)


class Model:
    def __init__(self, data):
        from core.catalog import normalize
        self.normalize = normalize
        self.data = data
        self.sheets = data['sheets']
        self.var_of = {}        # (aba, coluna) -> id
        self.fixed = {}         # (aba, endereço) -> id   (fonte e verificações do projeto)
        self.circuit_vars = []
        self.fonte_vars = []
        self.project_vars = []

    # ------------------------------------------------------------ inventário
    def scan_references(self, extra):
        """Colunas de circuito referenciadas por alguma fórmula ou editáveis no aplicativo."""
        ref = collections.defaultdict(set)
        for sheet, body in self.sheets.items():
            for a, c in body['cells'].items():
                if not c.get('formula'):
                    continue
                for n in walk(parse(c['value'])):
                    if n[0] == 'ref':
                        ts = n[1] or sheet
                        if ts in CIRCUIT_SHEETS:
                            c1, c2 = address(n[2])[1], address(n[3])[1]
                            for cc in range(c1, c2 + 1):
                                ref[ts].add(col_name(cc))
        for sheet, cols in extra.items():
            if sheet in CIRCUIT_SHEETS:
                ref[sheet] |= set(cols)
        self.referenced = ref

    def build_ids(self):
        used = set()
        for sheet, (group, _) in CIRCUIT_SHEETS.items():
            cells = self.sheets[sheet]['cells']
            cols = sorted({re.match(r'[A-Z]+', a)[0] for a in cells if 1 <= address(a)[0] <= 101} | self.referenced.get(sheet, set()), key=col_number)
            for col in cols:
                if (sheet, col) in PROJECT_LEVEL:
                    continue
                if not any(f'{col}{r}' in cells for r in range(2, 102)) and col not in self.referenced.get(sheet, set()):
                    continue
                if (sheet, col) in OVERRIDE_IDS:
                    vid = OVERRIDE_IDS[(sheet, col)]
                elif sheet == 'Dispositivos_Trecho':
                    from core import trecho
                    inv = {v: k for k, v in trecho.COL.items()}
                    vid = 'trecho.' + inv[col]
                else:
                    header = cells.get(col + '1', {}).get('value')
                    vid = f'{group}.{slug(header) if header else "col_" + col.lower()}'
                base, n = vid, 2
                while vid in used:
                    vid = f'{base}_{col.lower()}' if n == 2 else f'{base}_{n}'
                    n += 1
                used.add(vid)
                self.var_of[(sheet, col)] = vid
        cells = self.sheets[FONTE]['cells']
        for a, c in sorted(cells.items(), key=lambda kv: address(kv[0])):
            r, cn = address(a)
            if cn not in (2, 4) or c.get('value') in (None, '') and not c.get('formula'):
                continue
            if a in FONTE_IDS:
                vid = FONTE_IDS[a]
            else:
                label = cells.get(f'A{r}', {}).get('value')
                core_label = str(label or '')
                if ' — ' in core_label and len(core_label.split(' — ')[-1]) <= 18:
                    core_label = core_label.split(' — ')[0] + ' ' + core_label.split(' — ')[-1]
                vid = 'fonte.' + (slug(core_label, 40) if label else f'b{r}') + ('_imag' if cn == 4 else '')
            base, n = vid, 2
            while vid in used:
                vid = f'{base}_{n}'
                n += 1
            used.add(vid)
            self.fixed[(FONTE, a)] = vid
        au = self.sheets['Auditoria_Checklist']['cells']
        for r in range(2, 8):
            lab = au.get(f'R{r}', {}).get('value')
            if not lab:
                continue
            vid = 'verificacao.' + slug(lab, 36)
            used.add(vid)
            self.fixed[('Auditoria_Checklist', f'S{r}')] = vid
            self.fixed[('Auditoria_Checklist', f'R{r}')] = vid + '__rotulo'

    # ------------------------------------------------------------ reescrita
    def rewrite(self, node, sheet, row, where):
        """Troca referências de célula por nomes. ``row`` é a linha de contexto (circuito)."""
        def fn(n):
            if n[0] == 'ref':
                return self._ref(n, sheet, row, where)
            if n[0] == 'columns':
                LOG.append(f'{where}: referência de colunas inteiras mantida: {text(n)}')
            return n
        return transform(node, fn)

    def _ref(self, n, sheet, row, where):
        ts = n[1] or sheet
        a, b = n[2].replace('$', ''), n[3].replace('$', '')
        r1, c1 = address(a)
        r2, c2 = address(b)
        if ts in CIRCUIT_SHEETS:
            if (ts, f'S{r1}') in self.fixed and c1 == c2 == col_number('S') and r1 == r2:
                return ('name', self.fixed[(ts, f'S{r1}')])
            if r1 == r2 and c1 == c2:
                col = col_name(c1)
                vid = self.var_of.get((ts, col))
                if vid is None:
                    if r1 == 1:
                        return ('lit', self.sheets[ts]['cells'].get(a, {}).get('value'))
                    raise ValueError(f'{where}: coluna sem variável {ts}!{a}')
                if r1 == row:
                    return ('name', vid)
                if r1 == row - 1:
                    return ('call', 'ANTERIOR', (('name', vid),))
                if r1 == 2 and row == 2:
                    return ('name', vid)
                raise ValueError(f'{where}: referência fixa a outra linha {ts}!{a}')
            if r1 == r2:
                if r1 != row:
                    raise ValueError(f'{where}: faixa em outra linha {ts}!{a}:{b}')
                return ('call', 'FAIXA', (('name', self.var_of[(ts, col_name(c1))]), ('name', self.var_of[(ts, col_name(c2))])))
            if r1 <= 3 and r2 >= 100:
                for c in range(c1, c2 + 1):
                    if (ts, col_name(c)) not in self.var_of:
                        raise ValueError(f'{where}: bloco com coluna sem variável {ts}!{col_name(c)}')
                if r1 == 3 or r2 not in (101,):
                    LOG.append(f'{where}: intervalo {ts}!{a}:{b} tratado como todos os circuitos')
                args = (('name', self.var_of[(ts, col_name(c1))]),)
                if c2 != c1:
                    args += (('name', self.var_of[(ts, col_name(c2))]),)
                return ('call', 'CIRCUITOS', args)
            raise ValueError(f'{where}: intervalo não reconhecido {ts}!{a}:{b}')
        if ts == FONTE:
            if (r1, c1) == (r2, c2):
                vid = self.fixed.get((FONTE, a))
                if vid:
                    return ('name', vid)
                return ('lit', None) if not self.sheets[FONTE]['cells'].get(a) else ('lit', self.sheets[FONTE]['cells'][a].get('value'))
            raise ValueError(f'{where}: intervalo na fonte {a}:{b}')
        if ts in TABLES:
            return ('ref', TABLES[ts], n[2], n[3])
        if ts in DROPPED:
            return ('lit', None)
        raise ValueError(f'{where}: aba desconhecida {ts}')

    # ------------------------------------------------------------ circuito
    def circuit(self):
        normalize = self.normalize
        decisions = collections.defaultdict(list)
        for sheet, (group, gname) in CIRCUIT_SHEETS.items():
            cells = self.sheets[sheet]['cells']
            validations = self._validations(sheet)
            for (s, col), vid in [(k, v) for k, v in self.var_of.items() if k[0] == sheet]:
                header = cells.get(col + '1', {}).get('value')
                rows = {r: cells.get(f'{col}{r}') for r in range(2, 102)}
                formulas = {r: c for r, c in rows.items() if c and c.get('formula')}
                var = {'id': vid, 'grupo': group, 'rotulo': label_of(header) or vid, 'unidade': unit_of(header),
                       'legado': [sheet, col]}
                if header not in (None, '') and str(header) != var['rotulo']:
                    var['cabecalho'] = header
                fmt = next((c.get('format') for c in rows.values() if c and c.get('format') not in (None, 'General')), None)
                if fmt:
                    var['formato'] = fmt
                if formulas:
                    ref_row = 4 if 4 in formulas else min(r for r in formulas if r >= 2)
                    canon = formulas[ref_row]['value']
                    t_canon = normalize(canon, ref_row)
                    tree = self.rewrite(parse(self._row_literal(canon, ref_row, vid)), sheet, ref_row, vid)
                    var['tipo'] = 'formula'
                    var['expressao'] = text(tree)
                    # diferenças por linha
                    diffs = collections.defaultdict(list)
                    for r, c in formulas.items():
                        t = normalize(c['value'], r)
                        if t != t_canon and lit_norm(t, r) != lit_norm(t_canon, ref_row):
                            diffs[t].append(r)
                    if (sheet, col) in ROOT_VARIANT and 2 in formulas:
                        root_tree = self.rewrite(parse(formulas[2]['value']), sheet, 2, vid + '[raiz]')
                        var['variantes'] = {'raiz': text(root_tree)}
                        decisions['raiz'].append(vid)
                    for t, rs in diffs.items():
                        if (sheet, col) in ROOT_VARIANT and rs == [2]:
                            continue
                        decisions['unificada'].append((vid, rs, t[:400], t_canon[:400]))
                    non_formula = [r for r, c in rows.items() if c and not c.get('formula') and c.get('value') not in (None, '')]
                    if non_formula:
                        decisions['constantes_ignoradas'].append((vid, non_formula, [rows[r]['value'] for r in non_formula][:3]))
                else:
                    var['tipo'] = 'entrada'
                if col in validations:
                    var['opcoes'] = validations[col]
                self.circuit_vars.append(var)
        # Posição: a fórmula r42 do ID é a própria linha.
        for v in self.circuit_vars:
            if v['id'] == 'ident.posicao':
                v['expressao'] = '=IF(ident.nome="","",ROW())'
                decisions['posicao'].append(v['id'])
            if v['legado'] == ['Cálc_Icc-Cond_Sugerido', 'A'] or v['legado'] == ['Cálc_Icc-Cond_Escolhido', 'A']:
                b = self.var_of[(v['legado'][0], 'B')]
                v['expressao'] = f'=IF({b}="","",ROW())'
                decisions['posicao'].append(v['id'])
        return decisions

    def _row_literal(self, formula, row, where):
        """Funções do aplicativo que recebem a linha (INSTALLREF(5)) passam a usar ROW()."""
        def rep(m):
            return m.group(1) + '(ROW())'
        out = re.sub(r'\b(INSTALLREF|INSTALLTABLE|INSTALLARRANGEMENT|INSTALLSOIL|INSTALLGROUP|GROUPTRACE|GROUPTEMPERATURE|'
                     r'NEUTRALHEATING|NEUTRALCURRENT)\(%d\)' % row, rep, formula)
        out = re.sub(r'\bNEUTRALMIN\(%d,' % row, 'NEUTRALMIN(ROW(),', out)
        if re.search(r'\b[A-Z]+\(%d[,)]' % row, out):
            LOG.append(f'{where}: literal igual à linha em chamada de função: {out[:160]}')
        return out

    def _validations(self, sheet):
        from core.xlsx_reader import translate
        out = {}
        for dv in self.sheets[sheet].get('validations', []):
            if dv.get('type') != 'list' or not dv.get('f1'):
                continue
            for area in dv['range'].split():
                parts = area.split(':')
                r1, c1 = address(parts[0])
                r2, c2 = address(parts[-1])
                if r2 < 4 or r1 > 101:
                    continue
                for c in range(c1, c2 + 1):
                    col = col_name(c)
                    if col in out:
                        continue
                    f = dv['f1'].lstrip('=')
                    if f.startswith('"'):
                        out[col] = {'lista': [x.strip() for x in f[1:-1].split(',')]}
                    else:
                        try:
                            f4 = translate(f, max(4, r1) - r1, c - c1)
                            tree = self.rewrite(parse(f4), sheet, max(4, r1), f'validação {sheet}!{col}')
                            out[col] = {'formula': text(tree)}
                        except ValueError as e:
                            LOG.append(f'validação ignorada {sheet}!{col}: {e}')
        return out

    # ------------------------------------------------------------ fonte e projeto
    def fonte(self):
        cells = self.sheets[FONTE]['cells']
        val = {}
        for dv in self.sheets[FONTE].get('validations', []):
            if dv.get('type') == 'list' and dv.get('f1'):
                for area in dv['range'].split():
                    parts = area.split(':')
                    r1, c1 = address(parts[0])
                    r2, c2 = address(parts[-1])
                    for r in range(r1, r2 + 1):
                        for c in range(c1, c2 + 1):
                            f = dv['f1'].lstrip('=')
                            a = f'{col_name(c)}{r}'
                            if f.startswith('"'):
                                val[a] = {'lista': [x.strip() for x in f[1:-1].split(',')]}
                            else:
                                try:
                                    val[a] = {'formula': text(self.rewrite(parse(f), FONTE, r, 'validação fonte ' + a))}
                                except ValueError as e:
                                    LOG.append(str(e))
        for (s, a), vid in self.fixed.items():
            if s != FONTE:
                continue
            c = cells[a]
            r, cn = address(a)
            label = cells.get(f'A{r}', {}).get('value')
            var = {'id': vid, 'rotulo': label_of(label) + (' — componente imaginária' if cn == 4 else '') if label else a,
                   'unidade': unit_of(label), 'legado': [FONTE, a]}
            if c.get('formula'):
                var['tipo'] = 'formula'
                var['expressao'] = text(self.rewrite(parse(c['value']), FONTE, r, vid))
            else:
                var['tipo'] = 'entrada'
                var['padrao'] = c.get('value')
            if a in val:
                var['opcoes'] = val[a]
            self.fonte_vars.append(var)
        # títulos de seção (coluna A sem valor) — usados para agrupar o formulário
        sections = []
        for r in range(1, 160):
            lab = cells.get(f'A{r}', {}).get('value')
            if lab and not cells.get(f'B{r}') and not cells.get(f'D{r}'):
                sections.append({'linha': r, 'titulo': str(lab)})
        return sections

    def project(self):
        au = self.sheets['Auditoria_Checklist']['cells']
        for (s, a), vid in self.fixed.items():
            if s != 'Auditoria_Checklist' or not a.startswith('S'):
                continue
            r = address(a)[0]
            c = au.get(a, {})
            var = {'id': vid, 'rotulo': au.get(f'R{r}', {}).get('value'), 'legado': ['Auditoria_Checklist', a]}
            if c.get('formula') and 'Memorial' not in c['value']:
                var['tipo'] = 'formula'
                var['expressao'] = text(self.rewrite(parse(c['value']), 'Auditoria_Checklist', r, vid))
            elif c.get('formula'):
                var['tipo'] = 'formula'
                var['expressao'] = '="N/A — os memoriais da planilha foram substituídos pelo relatório do aplicativo"'
                LOG.append(f'{vid}: verificação dos memoriais da r42 substituída (memoriais removidos)')
            else:
                var['tipo'] = 'formula'
                var['expressao'] = '="N/A — verificação externa da planilha r42, não aplicável ao motor nativo"'
                LOG.append(f'{vid}: texto fixo da entrega r38 substituído')
            self.project_vars.append(var)

    # ------------------------------------------------------------ tabelas
    def tables(self):
        out = {}
        for sheet, tid in TABLES.items():
            body = self.sheets[sheet]
            cells = {}
            for a, c in body['cells'].items():
                if c.get('formula'):
                    r = address(a)[0]
                    try:
                        tree = self.rewrite(parse(c['value']), sheet, r, f'{tid}!{a}')
                    except ValueError as e:
                        raise ValueError(f'tabela {sheet}!{a}: {e}')
                    cells[a] = {'f': text(tree)}
                    if c.get('cache') is not None and not isinstance(c.get('cache'), dict):
                        cells[a]['cache'] = c['cache']
                else:
                    if c.get('value') is None:
                        continue
                    cells[a] = {'v': c['value']}
                    if c.get('error'):
                        cells[a]['erro'] = True
            maxc = max((address(a)[1] for a in cells), default=1)
            columns = [{'letra': col_name(i), 'nome': label_of(body['cells'].get(col_name(i) + '1', {}).get('value'))}
                       for i in range(1, maxc + 1)]
            out[tid] = {'id': tid, 'nome': sheet.replace('_', ' '), 'legado': sheet, 'colunas': columns, 'celulas': cells}
        return out

    def names(self):
        out = {}
        for name, target in self.data.get('names', {}).items():
            try:
                tree = parse(target)
            except Exception as e:  # noqa: BLE001
                LOG.append(f'nome {name} ignorado: {e}')
                continue
            m = re.match(r"'?(.*?)'?!", target)
            ts = m.group(1) if m else None
            if ts in DROPPED:
                continue
            try:
                out[name] = text(self.rewrite(tree, ts or FONTE, 4, 'nome ' + name))[1:]
            except ValueError as e:
                LOG.append(f'nome {name}: {e}')
        return out

    # ------------------------------------------------------------ exemplo
    def example(self, project):
        circuits = []
        inputs = [v for v in self.circuit_vars if v['tipo'] == 'entrada']
        for r in project.active_rows():
            entradas = {}
            for v in inputs:
                sheet, col = v['legado']
                if sheet == 'Levantamento de carga' and r < 4:
                    continue  # linhas 2 e 3 da r42 guardam subtítulos, não dados
                val = self.sheets[sheet]['cells'].get(f'{col}{r}', {}).get('value')
                if val not in (None, ''):
                    entradas[v['id']] = val
            circuits.append({'id': project.meta['ids'][str(r)], 'entradas': entradas})
        fonte = {v['id']: v.get('padrao') for v in self.fonte_vars if v['tipo'] == 'entrada' and v.get('padrao') not in (None, '')}
        return {'formato': 'eletroapp-projeto', 'versao': 2, 'meta': {'title': 'Exemplo — instalação de referência (r42)'},
                'fonte': fonte, 'circuitos': circuits}


def main(src):
    with gzip.open(src, 'rt', encoding='utf-8') as f:
        raw = json.load(f)
    # Mesmas adaptações que a v1.12 aplicava ao abrir a planilha (ver core/migracao.py).
    from core.migracao import _patch
    from core.project import GROUPS
    _patch(raw)
    for row in range(2, 102):
        raw['sheets']['Identificação dos circuitos']['cells'][f'A{row}'] = {'value': f'=IF(B{row}="","",{row})', 'formula': True}
    input_cols = collections.defaultdict(set)
    for _, _, sheet, cols in GROUPS:
        input_cols[sheet].update(cols)
    for sheet in list(raw['sheets'])[1:34]:
        for a, c in raw['sheets'][sheet]['cells'].items():
            r, cn = address(a)
            if 4 <= r <= 101 and cn > 1 and not c.get('formula'):
                input_cols[sheet].add(col_name(cn))
    m = Model(raw)
    m.scan_references(input_cols)
    m.build_ids()
    decisions = m.circuit()
    sections = m.fonte()
    m.project()
    tables = m.tables()
    names = m.names()
    out = ROOT / 'data' / 'modelo'
    out.mkdir(parents=True, exist_ok=True)
    groups = [{'id': g, 'nome': n, 'legado': s} for s, (g, n) in CIRCUIT_SHEETS.items()]
    dump = lambda path, obj: path.write_text(json.dumps(obj, ensure_ascii=False, indent=0, separators=(',', ':')), encoding='utf-8')
    dump(out / 'circuito.json', {'versao': 1, 'grupos': groups, 'variaveis': m.circuit_vars})
    dump(out / 'fonte.json', {'versao': 1, 'secoes': sections, 'variaveis': m.fonte_vars})
    dump(out / 'projeto.json', {'versao': 1, 'variaveis': m.project_vars})
    dump(out / 'nomes.json', names)
    tdir = ROOT / 'data' / 'tabelas'
    tdir.mkdir(parents=True, exist_ok=True)
    for tid, t in tables.items():
        dump(tdir / f'{tid}.json', t)
    edir = ROOT / 'data' / 'exemplos'
    edir.mkdir(parents=True, exist_ok=True)
    # O exemplo é o próprio projeto r42 convertido pelo mesmo caminho dos projetos antigos.
    from core import motor
    from core.migracao import from_workbook
    motor.model.cache_clear()
    with gzip.open(src, 'rt', encoding='utf-8') as f:
        doc = from_workbook(json.load(f))
    doc['meta']['title'] = 'Exemplo — instalação de referência'
    doc['meta'].pop('migracao', None)
    doc['meta'].pop('source', None)
    dump(edir / 'exemplo.json', doc)
    lines = ['# Migração do modelo r42 para o motor nativo', '',
             f'Variáveis por circuito: {len(m.circuit_vars)} · fonte: {len(m.fonte_vars)} · projeto: {len(m.project_vars)} · '
             f'tabelas: {len(tables)} · nomes definidos: {len(names)}.', '',
             '## Variantes para circuitos ligados diretamente à fonte', '',
             'Na r42 a linha 2 usava a impedância da fonte como impedância a montante. No motor nativo isso vale para '
             'qualquer circuito cujo montante seja a fonte ou o transformador:', '']
    lines += [f'- `{v}`' for v in decisions['raiz']]
    lines += ['', '## Fórmulas unificadas', '',
              'A r42 tinha linhas com fórmulas diferentes da coluna (linha 2 = entrada, linha 3 = medição, linhas 2–33 x 34–101 '
              'e erros pontuais). O motor nativo usa uma única fórmula por variável — a da linha 4 da r42, primeira linha de '
              'circuito comum. Linhas afetadas:', '']
    for vid, rs, t, canon in decisions['unificada']:
        lines.append(f'- `{vid}` — linhas {", ".join(map(str, rs[:12]))}{"…" if len(rs) > 12 else ""}')
    lines += ['', '## Registro técnico', ''] + [f'- {x}' for x in LOG]
    (ROOT / 'docs' / 'MIGRACAO_MODELO.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(len(m.circuit_vars), 'variáveis de circuito;', len(m.fonte_vars), 'da fonte;', len(m.project_vars), 'do projeto;',
          len(tables), 'tabelas;', len(names), 'nomes;', len(LOG), 'registros')


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else str(ROOT / 'data' / 'r42.json.gz'))

#!/usr/bin/env python3
"""Paridade entre o motor da v1.12 (planilha r42 interpretada) e o motor nativo (v2.0).

Ferramenta de desenvolvimento. Executa o mesmo cenário nos dois aplicativos e compara
todas as variáveis de todos os circuitos, da fonte e das verificações do projeto.

Uso: python tools/paridade.py <pasta da v1.12> <r42.json.gz> [cenário...]
"""
from __future__ import annotations

import json
import math
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

SCENARIOS = {
    'exemplo': [],
    'cargas': [('update', [['Levantamento de carga', 'D5', 12000], ['Levantamento de carga', 'H6', 4500], ['Dados dos circuitos', 'F7', 55]])],
    'novos': [('add', 'QD-NOVO', 'QGBT-01'), ('add', 'C-TOM', 'QD-NOVO'),
              ('update_named', 'C-TOM', [['Levantamento de carga', 'D', 1800], ['Dados dos circuitos', 'F', 25]])],
    'trecho': [('preset_entrada',)],
    'fonte_bt': [('update', [['Padrão de entrada', 'B2', 'Rede BT Direta']])],
    'motor': [('update', [['Levantamento de carga', 'V6', 10], ['Levantamento de carga', 'T6', 4], ['Levantamento de carga', 'AN6', 'Somar automaticamente às cargas gerais']])],
    'secoes': [('update', [['Seleção-Seção_Condutor', 'T5', 120], ['Seleção-Seção_Condutor', 'W5', 120], ['Seleção-Seção_Condutor', 'Z5', 70]])],
}

RUNNER = r'''
import sys, json, gzip, copy
sys.path.insert(0, sys.argv[1])
from core.project import Project
from core import trecho
mode, src, scen, keys_path = sys.argv[2], sys.argv[3], json.loads(sys.argv[4]), sys.argv[5]
if mode == 'old':
    p = Project(json.load(gzip.open(src, 'rt', encoding='utf-8')))
else:
    p = Project(json.load(open(src, encoding='utf-8')))
for step in scen:
    kind = step[0]
    if kind == 'update':
        p.update([{'sheet': s, 'address': a, 'value': v} for s, a, v in step[1]], validate_installation=False)
    elif kind == 'add':
        p.add(step[1], step[2])
    elif kind == 'update_named':
        r = next(r for r in p.active_rows() if p.raw('Identificação dos circuitos', f'B{r}') == step[1])
        p.update([{'sheet': s, 'address': f'{c}{r}', 'value': v} for s, c, v in step[2]], validate_installation=False)
    elif kind == 'preset_entrada':
        p.update(trecho.exemplo_entrada(p), validate_installation=False)
keys = json.load(open(keys_path))
out = {}
def plain(v):
    if isinstance(v, dict): return {'error': v.get('error')}
    if isinstance(v, list): return str(v)
    return v
rows = p.active_rows()
names = {r: p.raw('Identificação dos circuitos', f'B{r}') for r in rows}
for sheet, col, vid in keys['circuito']:
    for r in rows:
        out[f'{vid}@{names[r]}'] = plain(p.get(sheet, f'{col}{r}'))
for sheet, addr, vid in keys['fixos']:
    out[vid] = plain(p.get(sheet, addr))
json.dump(out, sys.stdout, ensure_ascii=False, default=str)
'''


def same(a, b):
    if isinstance(a, dict) or isinstance(b, dict):
        return isinstance(a, dict) and isinstance(b, dict) and a.get('error') == b.get('error')
    if isinstance(a, bool) or isinstance(b, bool):
        return a == b
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-12)
    return (a if a is not None else '') == (b if b is not None else '')


def run(old_dir, r42, scenario):
    model = json.loads((ROOT / 'data/modelo/circuito.json').read_text(encoding='utf-8'))
    fixed = json.loads((ROOT / 'data/modelo/fonte.json').read_text(encoding='utf-8'))['variaveis'] + \
        json.loads((ROOT / 'data/modelo/projeto.json').read_text(encoding='utf-8'))['variaveis']
    keys = {'circuito': [[v['legado'][0], v['legado'][1], v['id']] for v in model['variaveis']],
            'fixos': [[v['legado'][0], v['legado'][1], v['id']] for v in fixed]}
    kp = ROOT / 'tools' / '.paridade_chaves.json'
    kp.write_text(json.dumps(keys), encoding='utf-8')
    steps = json.dumps(SCENARIOS[scenario])
    res = {}
    for mode, code, src in (('old', old_dir, r42), ('new', str(ROOT), str(ROOT / 'data/exemplos/exemplo.json'))):
        proc = subprocess.run([sys.executable, '-c', RUNNER, code, mode, src, steps, str(kp)], capture_output=True, text=True, cwd=code)
        if proc.returncode:
            raise SystemExit(f'{mode} falhou:\n{proc.stderr[-3000:]}')
        res[mode] = json.loads(proc.stdout)
    diffs = [(k, res['old'].get(k), res['new'].get(k)) for k in res['old'] if not same(res['old'].get(k), res['new'].get(k))]
    missing = [k for k in res['old'] if k not in res['new']]
    return len(res['old']), diffs, missing


if __name__ == '__main__':
    old_dir, r42 = sys.argv[1], sys.argv[2]
    names = sys.argv[3:] or list(SCENARIOS)
    total = 0
    for name in names:
        n, diffs, missing = run(old_dir, r42, name)
        total += len(diffs)
        print(f'== {name}: {n} valores comparados, {len(diffs)} diferenças, {len(missing)} ausentes')
        for k, a, b in diffs[:25]:
            print(f'   {k}: v1.12={str(a)[:90]!r} | nativo={str(b)[:90]!r}')
    sys.exit(1 if total else 0)

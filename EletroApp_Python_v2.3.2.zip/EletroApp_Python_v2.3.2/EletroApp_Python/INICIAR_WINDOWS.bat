@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  py -3 app.py
  goto fim
)
where python >nul 2>&1
if not errorlevel 1 (
  python app.py
  goto fim
)
echo.
echo Python nao encontrado.
echo Instale Python 3.10 ou superior: https://www.python.org/downloads/
echo Marque a opcao Add Python to PATH e abra este arquivo novamente.
:fim
echo.
pause

// Entrada (origem) editável a partir do diagrama: painel lateral, troca rápida do tipo de atendimento
// e atalho no modo Cartões. Os dados continuam sendo os da aba "Entrada e fontes" (/api/source).
function origemTexto(o){
  if(!o)return 'Entrada';
  if(o.tipo==='Gerador BT')return `Gerador BT · ${o.gerador_kva??'—'} kVA`;
  if(o.tipo==='Rede BT Direta')return `Rede BT · ${o.tensao_ff??'—'} V`;
  return `Rede MT ${o.tensao_mt??'—'} kV · Trafo ${o.trafo_kva??'—'} kVA`;
}
function originChipHTML(){
  const o=state.origem||{};const st=o.status||'ok';
  const label=st==='ok'?'':st==='error'?'Revisar':'Pendente';
  return `<div class="origin-chip-row"><button type="button" class="origin-chip" data-origin-open="1" title="${esc((o.pendencias||[]).join(' '))}"><i class="dot ${st==='error'?'red':st==='pending'?'amber':''}"></i><b>Origem</b> ${esc(origemTexto(o))}${label?` <span class="tag ${st==='error'?'red':'amber'}">${label}</span>`:''}<span class="origin-chip-edit">⚙ editar entrada</span></button></div>`;
}
function closeOrigemMenu(){const m=document.getElementById('origem-menu');if(m)m.remove();}
function origemMenu(ev){
  closeOrigemMenu();
  const tipos=(state.origem&&state.origem.tipos)||[];const atual=state.origem&&state.origem.tipo;
  const m=document.createElement('div');m.id='origem-menu';m.className='origin-menu';m.setAttribute('role','menu');
  m.innerHTML=`<div class="origin-menu-title">Tipo de atendimento</div>`+tipos.map(t=>`<button type="button" role="menuitem" data-origem-tipo="${esc(t)}" class="${t===atual?'active':''}">${t===atual?'✓ ':''}${esc(t)}</button>`).join('');
  document.body.appendChild(m);
  const r=m.getBoundingClientRect();
  m.style.left=Math.max(8,Math.min(ev.clientX+8,innerWidth-r.width-8))+'px';
  m.style.top=Math.max(8,Math.min(ev.clientY+8,innerHeight-r.height-8))+'px';
  m.querySelectorAll('[data-origem-tipo]').forEach(b=>b.onclick=async()=>{
    const novo=b.dataset.origemTipo;closeOrigemMenu();
    if(novo===atual)return;
    if(!confirm(`Mudar o tipo de atendimento para "${novo}"?\nOs dados dos outros tipos continuam guardados, mas os cálculos passam a usar os dados deste tipo.`))return;
    await action(async()=>{await api('/api/changes',{changes:[{sheet:'Padrão de entrada',address:'B2',value:novo}]});await refresh();},`Entrada alterada para "${novo}".`);
    if(state.origem&&state.origem.status!=='ok')openOrigemPanel();
  });
}
async function openOrigemPanel(){
  if(dirty&&!confirm('Descartar as alterações ainda não salvas?'))return;
  closeOrigemMenu();
  busy(true,'Abrindo a entrada…');
  try{
    const fields=await api('/api/source');
    drawerData=null;dirty=false;
    const o=state.origem||{};
    const pend=(o.pendencias||[]).length?`<div class="notice amber"><b>Pendências da entrada</b><ul>${o.pendencias.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>`:'';
    $('#drawer').innerHTML=`<div class="drawer-header"><div><div class="eyebrow">ENTRADA E FONTES</div><h2 id="drawer-title">${esc(origemTexto(o))}</h2><p>Edite a fonte sem sair do diagrama. Só aparecem os blocos que valem para o tipo de atendimento escolhido.</p></div><button class="icon-btn" id="close-drawer" aria-label="Fechar">×</button></div><div class="drawer-body origem-panel">${pend}${sourceBlocksHTML(fields)}</div><div class="drawer-footer"><a class="btn small" href="#source">Abrir em tela cheia</a><button class="btn primary" id="save-origem">Salvar e recalcular</button></div>`;
    $('#drawer').hidden=false;$('#drawer-shade').hidden=false;document.body.classList.add('no-scroll');
    refreshSourceHierarchy(fields,{forceToggle:true});
    $('#drawer').oninput=e=>{dirty=true;$('#save-origem').textContent='Salvar alterações';const idx=indexFromElId(e.target.id,'source-');const f=idx>=0?fields[idx]:null;if(f&&f.block==='tipo')refreshSourceHierarchy(fields,{forceToggle:true});else if(f&&f.sheet==='Padrão de entrada'&&f.address==='B11')refreshSourceHierarchy(fields);};
    $('#close-drawer').onclick=()=>closeDrawer();
    $('#save-origem').onclick=()=>action(async()=>{await api('/api/changes',{changes:collect(fields,'source-')});dirty=false;closeDrawer(true);await refresh();},'Entrada salva e cálculos atualizados.');
    $('#close-drawer').focus();
  }catch(e){toast(e.message,true);}finally{busy(false);}
}
document.addEventListener('click',e=>{
  const sw=e.target.closest('[data-origin-swap]');
  if(sw){e.preventDefault();e.stopPropagation();origemMenu(e);return;}
  if(e.target.closest('#origem-menu'))return;
  const op=e.target.closest('[data-origin-open],[data-origin]');
  if(op){e.preventDefault();openOrigemPanel();return;}
  closeOrigemMenu();
},true);
document.addEventListener('keydown',e=>{
  if(e.key==='Enter'&&e.target.matches&&e.target.matches('[data-origin]')){openOrigemPanel();}
  if(e.key==='Escape')closeOrigemMenu();
});

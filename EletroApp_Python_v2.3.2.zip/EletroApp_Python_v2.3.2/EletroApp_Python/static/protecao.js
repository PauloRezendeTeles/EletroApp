// Aba Proteções: seleção em cascata (Classe > Família > Modelo), parâmetros condicionais ao tipo de
// disjuntor, listas de ajuste vindas do catálogo (sem digitação de valores que o dial não tem),
// In automático e organização em blocos. Todos os campos continuam no DOM (collect() os lê); a
// interface só os mostra, bloqueia ou preenche. Nada aqui recalcula resultados.
const PROTECAO_CLASSES=['fixo','termomagnetico','eletronico','fusivel'];
const PROTECAO_CLASSE_LABEL={fixo:'Disjuntor fixo',termomagnetico:'Ajustável termomagnético',eletronico:'Ajustável eletrônico (LSI)',fusivel:'Fusível'};
const PROTECAO_CLASSE_ICONS={
  fixo:'<svg viewBox="0 0 64 34" aria-hidden="true"><rect x="20" y="4" width="24" height="26" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><rect x="29" y="9" width="6" height="10" rx="1.5" fill="currentColor"/><line x1="32" y1="22" x2="32" y2="26" stroke="currentColor" stroke-width="2"/></svg>',
  termomagnetico:'<svg viewBox="0 0 64 34" aria-hidden="true"><rect x="20" y="4" width="24" height="26" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="32" cy="15" r="6" fill="none" stroke="currentColor" stroke-width="2"/><line x1="32" y1="15" x2="36" y2="11" stroke="currentColor" stroke-width="2"/><line x1="26" y1="26" x2="38" y2="26" stroke="currentColor" stroke-width="2"/></svg>',
  eletronico:'<svg viewBox="0 0 64 34" aria-hidden="true"><rect x="14" y="4" width="36" height="26" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><rect x="19" y="8" width="26" height="9" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M22 14 L27 10 L32 14 L37 10 L42 14" fill="none" stroke="currentColor" stroke-width="1.3"/><circle cx="24" cy="24" r="2.2" fill="currentColor"/><circle cx="32" cy="24" r="2.2" fill="currentColor"/><circle cx="40" cy="24" r="2.2" fill="currentColor"/></svg>',
  fusivel:'<svg viewBox="0 0 64 34" aria-hidden="true"><rect x="14" y="13" width="36" height="8" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><line x1="8" y1="17" x2="14" y2="17" stroke="currentColor" stroke-width="2"/><line x1="50" y1="17" x2="56" y2="17" stroke="currentColor" stroke-width="2"/><line x1="22" y1="13" x2="22" y2="21" stroke="currentColor" stroke-width="1.2"/><line x1="42" y1="13" x2="42" y2="21" stroke="currentColor" stroke-width="1.2"/></svg>',
};
const PROT_BLOCO1=['J','AL','AM','K','BG','BO','BQ'];
const PROT_BLOCO2=['Y','Z','BX','BZ','CA'];
const protCol=a=>/^[A-Z]+/.exec(a)[0];

function protecaoClasseGalleryHTML(classe){
  const tiles=PROTECAO_CLASSES.map(c=>`<button type="button" class="method-tile protecao-classe-tile ${c===classe?'active':''}" data-classe="${c}" aria-pressed="${c===classe}">${PROTECAO_CLASSE_ICONS[c]}<span>${PROTECAO_CLASSE_LABEL[c]}</span></button>`).join('');
  return `<div class="method-cascade" id="protecao-classe-cascade"><div class="cascade-label">Passo 1 · classe do dispositivo</div><div class="method-gallery clickable prot-4">${tiles}</div></div>`;
}
// h: {coluna: html do campo}; resumo: html do status final.
function protecaoBlocosHTML(h,g,classe){
  const pick=cols=>cols.map(c=>h[c]||'').join('');
  const resto=Object.keys(h).filter(c=>!PROT_BLOCO1.includes(c)&&!PROT_BLOCO2.includes(c)).map(c=>h[c]).join('');
  return `<div class="prot-bloco" id="prot-bloco-1"><h4><span>1</span>Especificação do hardware</h4>${protecaoClasseGalleryHTML(classe)}<div class="cascade-label prot-step-label">Passo 2 e 3 · família e modelo (só aparecem opções compatíveis com a classe)</div><div class="fields">${pick(PROT_BLOCO1)}</div><div class="field-note" id="prot-sem-ajuste" hidden></div></div>`+
    `<div class="prot-bloco" id="prot-bloco-2"><h4><span>2</span>Parametrização da unidade de trip</h4><div class="field-note" id="prot-faixa-hint"></div><div class="fields">${pick(PROT_BLOCO2)}</div></div>`+
    `<div class="prot-bloco" id="prot-bloco-3"><h4><span>3</span>Resultados e status</h4>${protecaoResumoHTML(g)}<div class="fields">${resto}</div></div>`;
}
function protAjustes(classe,m){
  const nada={ir:false,im:false,isd:false,tsd:false,i2t:false,rotuloIm:'Ii/Im adotado (A)'};
  if(!classe||classe==='fusivel'||classe==='fixo')return nada;
  if(classe==='eletronico')return{...nada,ir:true,im:true,isd:true,tsd:true,i2t:true,rotuloIm:'Ii adotado (A) · instantâneo'};
  let ir=true,im=true;
  if(m){ir=m.ir_ajuste?m.ir_ajuste.tipo!=='nenhum':true;im=m.im_ajuste?m.im_ajuste.tipo!=='nenhum':true;}
  return{...nada,ir,im};
}
function protFieldIdx(fields,col){return fields.findIndex(f=>f.sheet==='Cálc-Prot_Cabos'&&protCol(f.address)===col);}
function protEl(fields,col){const i=protFieldIdx(fields,col);return i<0?null:document.getElementById('field-'+i);}
function protWrap(fields,col){const el=protEl(fields,col);return el?el.closest('.field'):null;}
// Garante <select> (ou <input>) com o mesmo id, descartando o controle "Outro (digitar)" quando strict.
function protAsSelect(el,numeric){
  if(!el)return null;
  if(el.tagName==='SELECT'){delete el.dataset.hasCustom;const c=document.getElementById(el.id+'-custom');if(c)c.remove();return el;}
  const s=document.createElement('select');s.id=el.id;s.dataset.type=numeric?'number':'text';s.dataset.prev=el.value||'';el.replaceWith(s);return s;
}
function protAsInput(el){
  if(!el||el.tagName==='INPUT')return el;
  const i=document.createElement('input');i.id=el.id;i.dataset.type='number';i.setAttribute('inputmode','decimal');i.autocomplete='off';
  i.value=el.value&&el.value!=='__custom__'?el.value:'';el.replaceWith(i);const c=document.getElementById(el.id+'-custom');if(c)c.remove();return i;
}
function protFillSelect(el,options,placeholder,current){
  const cur=current!=null&&current!==''?String(current):(el.dataset.prev||'');delete el.dataset.prev;
  const set=new Set(options.map(String));
  const incompat=cur!==''&&!set.has(cur);
  el.innerHTML=`<option value="">${esc(placeholder)}</option>`+options.map(x=>`<option value="${esc(x)}" ${String(x)===cur?'selected':''}>${esc(x)}</option>`).join('')+(incompat?`<option value="${esc(cur)}" selected data-incompat="1">${esc(cur)} (incompatível com as escolhas atuais)</option>`:'');
  el.classList.toggle('incompat',incompat);
}
function protHint(el,text){
  if(!el)return;const id=el.id+'-prot-hint';let h=document.getElementById(id);
  if(!h){h=document.createElement('div');h.className='field-note';h.id=id;el.insertAdjacentElement('afterend',h);}
  h.textContent=text||'';h.hidden=!text;
}
function protSetDisabled(el,off){if(el)el.disabled=!!off;}
const protNum=v=>{if(v==null||v==='')return null;const n=Number(String(v).replace(',','.'));return Number.isFinite(n)?n:null;};

function refreshProtecaoCascade(fields){
  if(typeof workflowMode==='function'&&workflowMode('protecao')==='Automático')return;
  const g=drawerData?.groups?.find(x=>x.key==='protecao');
  if(!g||!protecaoCatalog)return;
  const classe=protecaoClasseEscolhida||g.classe_atual||null;
  const ehFusivel=classe==='fusivel',ehDisj=['fixo','termomagnetico','eletronico'].includes(classe);
  // Passo 1: galeria
  const galeria=$('#protecao-classe-cascade');
  if(galeria)galeria.outerHTML=protecaoClasseGalleryHTML(classe);
  $$('.protecao-classe-tile[data-classe]').forEach(t=>t.onclick=()=>{
    const nova=t.dataset.classe;if(nova===(protecaoClasseEscolhida||g.classe_atual||null))return;
    protecaoClasseEscolhida=nova;
    // Troca de classe invalida família/modelo incompatíveis (seleção estritamente sequencial).
    const alEl=protEl(fields,'AL'),amEl=protEl(fields,'AM');
    if(nova==='fusivel'){if(alEl)alEl.value='';if(amEl)amEl.value='';}
    else{
      const okFam=new Set((protecaoFamiliasPorClasse||{})[nova]||[]);
      if(alEl&&alEl.value&&!okFam.has(alEl.value)){alEl.value='';if(amEl)amEl.value='';}
      else if(amEl&&amEl.value){const mi=protecaoCatalogByModelo[amEl.value];if(!mi||mi.subclasse!==nova)amEl.value='';}
    }
    dirty=true;$('#save-circuit').textContent='Salvar alterações';refreshProtecaoCascade(fields);
  });
  // Visibilidade: fusível usa J; disjuntores usam família/modelo.
  const W=c=>protWrap(fields,c);
  if(W('J'))W('J').hidden=!ehFusivel;
  if(W('AL'))W('AL').hidden=ehFusivel;
  if(W('AM'))W('AM').hidden=ehFusivel;
  // Passo 2: família
  const curAL=liveValue(protFieldIdx(fields,'AL'),'field-');
  const curAM0=liveValue(protFieldIdx(fields,'AM'),'field-');
  const alEl=protAsSelect(protEl(fields,'AL'),false);
  if(alEl){
    const familias=ehDisj?((protecaoFamiliasPorClasse||{})[classe]||[]):[];
    protFillSelect(alEl,familias,ehDisj?'Selecione a família':'Escolha primeiro a classe',curAL);
    protSetDisabled(alEl,!ehDisj);
    protHint(alEl,!ehDisj&&!ehFusivel?'Escolha a classe acima para listar as famílias.':'');
  }
  // Passo 3: modelo
  const amEl=protAsSelect(protEl(fields,'AM'),false);
  const famAtual=alEl&&alEl.value?alEl.value:null;
  if(amEl){
    const modelos=ehDisj&&famAtual?protecaoCatalog.filter(m=>m.familia===famAtual&&m.subclasse===classe).map(m=>m.modelo):[];
    let curAM=curAM0;const mi0=curAM?protecaoCatalogByModelo[curAM]:null;
    if(mi0&&(mi0.familia!==famAtual||mi0.subclasse!==classe))curAM=null; // trocar a família descarta o modelo da família anterior
    protFillSelect(amEl,modelos,famAtual?'Selecione o modelo':'Escolha primeiro a família',curAM);
    protSetDisabled(amEl,!(ehDisj&&famAtual));
    protHint(amEl,ehDisj&&!famAtual?'Escolha a família acima para listar os modelos.':'');
  }
  const modelo=amEl&&amEl.value?protecaoCatalogByModelo[amEl.value]:null;
  const aj=protAjustes(classe,modelo);
  // In nominal: preenchido e bloqueado pelo catálogo.
  const kEl=protEl(fields,'K');
  if(kEl){
    const inCat=ehDisj&&modelo&&modelo.in_nominal!=null?modelo.in_nominal:null;
    if(inCat!=null){
      const k=protAsSelect(kEl,true);
      const opts=[...k.options].map(o=>o.value);
      if(!opts.includes(String(inCat))){const o=document.createElement('option');o.value=String(inCat);o.textContent=String(inCat);k.appendChild(o);}
      k.value=String(inCat);k.disabled=true;
      protHint(k,`Definido pelo catálogo (${modelo.modelo}): In = ${inCat} A. Só os ajustes abaixo são editáveis.`);
    }else{
      kEl.disabled=false;protHint(kEl,ehDisj&&modelo?'Modelo sem In único no catálogo: escolha o In do sensor.':'');
    }
  }
  // Bloco 2: parâmetros existentes para esta classe/modelo.
  const show=(c,on)=>{const w=W(c);if(w)w.hidden=!on;};
  show('Y',aj.ir);show('Z',aj.im);show('BX',aj.isd);show('BZ',aj.tsd);show('CA',aj.i2t);
  const bloco2=$('#prot-bloco-2');
  const algum=aj.ir||aj.im||aj.isd||aj.tsd||aj.i2t;
  if(bloco2)bloco2.hidden=!algum;
  const sem=$('#prot-sem-ajuste');
  if(sem){
    sem.hidden=algum||!classe;
    sem.textContent=classe==='fixo'?'Disjuntor fixo: não há ajuste de Ir, Im, Isd, tsd ou I²t — o disparo é definido pelo fabricante (Ir = In).':classe==='fusivel'?'Fusível: não há ajuste na unidade de proteção; só a corrente nominal e a classe de operação.':classe==='termomagnetico'?'Este modelo não tem parâmetros ajustáveis.':'';
  }
  const zLabel=W('Z')?.querySelector('label');if(zLabel&&aj.im)zLabel.textContent=aj.rotuloIm;
  // Ajuste de Ir (Y): lista discreta do catálogo; contínuo ou faixa -> numérico dentro de [min,max].
  const ib=protNum(state.circuits.find(c=>c.id===drawerData.id)?.ib)??protNum(drawerData.ib);
  const hintBox=$('#prot-faixa-hint');let faixaTxt=[];
  const yEl=protEl(fields,'Y');
  if(yEl&&aj.ir&&modelo){
    const a=modelo.ir_ajuste||{tipo:'faixa',valores:[]};
    if(a.tipo==='discreto'&&a.valores.length){
      const y=protAsSelect(yEl,true);const cur=y.value;
      let alvo=a.valores.includes(Number(cur))?cur:'';
      if(!alvo&&ib!=null){const v=a.valores.find(x=>x>=ib);alvo=String(v!=null?v:a.valores[a.valores.length-1]);}
      protFillSelect(y,a.valores,'Selecione o ajuste',alvo||cur);protHint(y,`Posições do dial (${modelo.modelo}): ${a.valores.join(' · ')} A. Valores intermediários não existem no equipamento.`);
    }else{
      const y=protAsInput(yEl);const lo=protNum(modelo.ir_min),hi=protNum(modelo.ir_max);
      protHint(y,lo!=null&&hi!=null?`Ajuste ${a.tipo==='continuo'?'contínuo':'permitido'}: ${lo} a ${hi} A.`:'');
    }
    if(modelo.ir_min!=null)faixaTxt.push(`Ir: ${modelo.ir_min}–${modelo.ir_max} A`);
  }
  const yVal=protNum(protEl(fields,'Y')?.value);
  const lista=(a)=>{if(a.tipo==='discreto'&&a.valores.length)return a.valores;if(a.tipo==='discreto_ir'&&yVal!=null)return a.mult_ir.map(m=>Math.round(m*yVal*100)/100);return null;};
  const hintAj=(a,vals,lo,hi,eletro)=>vals?(a.tipo==='discreto_ir'?`Posições ${a.mult_ir.join(' · ')} × Ir (Ir = ${yVal} A): ${vals.join(' · ')} A.`:`Posições do dial: ${vals.join(' · ')} A.`):(lo!=null&&hi!=null?`Faixa do catálogo: ${lo} a ${hi} A (${a.tipo==='continuo'?'ajuste contínuo':'posições não detalhadas no catálogo'}).`:'');
  const zEl=protEl(fields,'Z');
  if(zEl&&aj.im&&modelo){
    if(classe==='eletronico'){
      // Z = Ii (instantâneo). Em ETS é fixo (11×In): vem do catálogo e fica bloqueado.
      if(modelo.ii_fixo!=null){
        const z=protAsSelect(zEl,true);protFillSelect(z,[modelo.ii_fixo],'—',modelo.ii_fixo);z.value=String(modelo.ii_fixo);z.disabled=true;
        protHint(z,`Ii fixo do modelo (catálogo): ${modelo.ii_fixo} A. Não ajustável.`);
      }else{
        const z=protAsInput(zEl);z.disabled=false;protHint(z,'Ii instantâneo: consulte o catálogo do modelo (ajuste ou OFF conforme o relé).');
      }
    }else{
      const a=modelo.im_ajuste||{tipo:'faixa',valores:[]};const vals=lista(a);
      if(vals){const z=protAsSelect(zEl,true);const zc=z.dataset.prev||z.value;protFillSelect(z,vals,'Selecione o ajuste',vals.map(String).includes(String(zc))?zc:'');z.disabled=false;protHint(z,hintAj(a,vals));}
      else{const z=protAsInput(zEl);z.disabled=false;protHint(z,hintAj(a,null,protNum(modelo.im_min),protNum(modelo.im_max)));}
      if(modelo.im_min!=null)faixaTxt.push(`Im: ${modelo.im_min}–${modelo.im_max} A`);
    }
  }
  // Isd (BX), tsd (BZ) e I²t (CA): só existem em relé eletrônico; sem "Outro (digitar)" nos passos.
  if(aj.isd&&modelo){
    const bxEl=protEl(fields,'BX');
    if(bxEl){
      const a=modelo.im_ajuste||{tipo:'faixa',valores:[]};const vals=lista(a);
      if(vals){const bx=protAsSelect(bxEl,true);const cur=bx.dataset.prev||bx.value;protFillSelect(bx,vals,'Selecione o ajuste',vals.map(String).includes(String(cur))?cur:'');protHint(bx,hintAj(a,vals));}
      else{const bx=protAsInput(bxEl);protHint(bx,hintAj(a,null,protNum(modelo.im_min),protNum(modelo.im_max)));}
      if(modelo.im_min!=null)faixaTxt.push(`Isd: ${modelo.im_min}–${modelo.im_max} A`);
    }
    ['BZ','CA'].forEach(c=>{
      const el=protEl(fields,c);if(!el||el.tagName!=='SELECT')return;
      const cur=liveValue(protFieldIdx(fields,c),'field-');
      const opts=[...el.options].map(o=>o.value).filter(v=>v&&v!=='__custom__'&&!o_incompat(el,v));
      delete el.dataset.hasCustom;const cu=document.getElementById(el.id+'-custom');if(cu)cu.remove();
      protFillSelect(el,opts,'Selecione',cur);
    });
  }
  if(hintBox)hintBox.textContent=algum&&modelo?`Faixas permitidas pelo catálogo — ${faixaTxt.join(' · ')}.`:'';
  if(hintBox)hintBox.hidden=!(algum&&modelo);
  // Troca de modelo: os ajustes do modelo anterior deixam de valer → carrega valores válidos do novo modelo.
  const ant=protecaoModeloAnterior;
  const atual=modelo?modelo.modelo:null;
  if(!ant||ant.id!==drawerData.id){protecaoModeloAnterior={id:drawerData.id,modelo:atual};return;}
  if(atual&&atual!==ant.modelo){
    protecaoModeloAnterior={id:drawerData.id,modelo:atual};
    protAplicarPadroes(fields,modelo,classe,ib);
    refreshProtecaoCascade(fields);
    protAplicarPadroes(fields,modelo,classe,ib,true);
  }else if(atual!==ant.modelo){protecaoModeloAnterior={id:drawerData.id,modelo:atual};}
}
let protecaoModeloAnterior=null;
// Valores válidos de ajuste para um modelo (mesma regra de Project.protecao_padroes no servidor).
function protAplicarPadroes(fields,modelo,classe,ib,segundaPassada){
  const set=(c,v)=>{const el=protEl(fields,c);if(!el||v==null)return;
    if(el.tagName==='SELECT'&&![...el.options].some(o=>o.value===String(v))){const o=document.createElement('option');o.value=String(v);o.textContent=String(v);el.appendChild(o);}
    el.value=String(v);el.dataset.prev=String(v);};
  const num=x=>typeof x==='number'?x:null;
  const ia=modelo.ir_ajuste||{},ma=modelo.im_ajuste||{};
  const lo=num(modelo.ir_min),hi=num(modelo.ir_max);
  let y=null;
  if(ia.tipo==='discreto'&&ia.valores?.length){const v=[...ia.valores].sort((a,b)=>a-b);y=v.find(x=>ib==null||x>=ib)??v[v.length-1];}
  else if(lo!=null&&hi!=null){const alvo=ib!=null?Math.ceil(ib):lo;y=Math.min(Math.max(alvo,lo),hi);}
  else if(modelo.in_nominal!=null)y=modelo.in_nominal;
  if(!segundaPassada){if(modelo.in_nominal!=null)set('K',modelo.in_nominal);set('Y',y);return;}
  const primeira=()=>{
    if(ma.tipo==='discreto'&&ma.valores?.length)return Math.min(...ma.valores);
    if(ma.tipo==='discreto_ir'&&y!=null&&ma.mult_ir?.length)return Math.round(Math.min(...ma.mult_ir)*y*100)/100;
    return num(modelo.im_min);
  };
  const eletro=classe==='eletronico';
  set('Z',eletro?modelo.ii_fixo:primeira());
  set('BX',eletro?primeira():'N/A');
  set('BZ',eletro?'100':'N/A');
  set('CA',eletro?'OFF':'N/A');
}
function o_incompat(el,v){const o=[...el.options].find(x=>x.value===v);return !!(o&&o.dataset.incompat);}

'use strict';
/* v2.0 — Base técnica versionada (tabelas com fonte, edição, revisão e condições) e
 * coordenação das proteções em três níveis. Usa as funções globais de app.js e catalogo.js. */
(function () {
  const fv = (v) => {
    if (v === null || v === undefined || v === '') return '';
    if (typeof v === 'object' && v.error) return v.error;
    if (typeof v === 'number') return formatBR(v);
    return String(v);
  };
  const fmtTs = (ts) => { try { return new Date(ts).toLocaleString('pt-BR'); } catch { return ts || ''; } };
  const tb = { list: null, row: 1, q: '' };
  window.tablesSelected = window.tablesSelected || null;

  async function reviewerBar(after) {
    await window.loadReviewer();
    const el = $('#rev-bar'); if (!el) return;
    el.innerHTML = window.reviewerBarHTML();
    window.bindReviewerBar(() => reviewerBar(after).then(after));
  }

  /* ---------------- base técnica ---------------- */
  window.renderTablesView = async function (main) {
    if (window.tablesSelected) return renderTable(main, window.tablesSelected);
    const nv = window.normView || { mode: 'arquivos' };
    main.innerHTML = heading('Base técnica', 'Tabelas e regras usadas nos cálculos, na forma da norma: localizador, conferência, o que mudou nesta revisão e quem usa cada valor. Edições no projeto são feitas pelo revisor, com fonte e justificativa, e ficam versionadas.', '', 'REFERÊNCIA')
      + '<div id="rev-bar"></div>' + (window.renderNormNav ? window.renderNormNav() : '') + '<div id="tables-body"><div class="loading-card">Carregando…</div></div>';
    await reviewerBar(() => render());
    if (window.bindNormNav) window.bindNormNav(main);
    if (nv.mode !== 'arquivos' && window.renderNormMode) { await window.renderNormMode($('#tables-body')); return; }
    const d = await api('/api/tables'); tb.list = d;
    const groups = Object.entries(d.categorias).map(([k, label]) => {
      const items = d.tabelas.filter((t) => t.categoria === k);
      if (!items.length) return '';
      return `<h3>${esc(label)}</h3><div class="reference-grid">${items.map((t) => `<button class="ref-card table-card" data-table-open="${esc(t.id)}">
        <h3>${esc(t.nome)}</h3>
        <p>${esc(t.fonte || '—')}${t.edicao ? ' · ' + esc(t.edicao) : ''}</p>
        <p><span class="tag">revisão ${esc(t.revisao_base)} da base</span> <span class="tag ${t.situacao_fonte === 'a_confirmar' ? 'amber' : 'green'}">${esc(t.situacao_fonte_rotulo)}</span>
        ${t.celulas_editadas ? `<span class="tag ${t.integridade === 'tabela_alterada' ? 'red' : 'amber'}">${t.celulas_editadas} célula(s) editada(s) no projeto</span>` : ''}</p>
        <p class="subtitle">${t.linhas} linhas × ${t.colunas} colunas · ${t.uso.operacional ? 'alimenta cálculos' : '<b>apenas consulta</b>'}</p></button>`).join('')}</div>`;
    }).join('');
    const rules = (d.regras_operacionais || []).map((r) => `<tr><td class="mono">${esc(r.arquivo)}</td><td class="wrap-cell">${esc(r.uso)}</td><td class="mono">${esc((r.resumo || '').slice(0, 12))}</td></tr>`).join('');
    $('#tables-body').innerHTML = groups + (rules ? `<h3>Regras operacionais (não editáveis)</h3><section class="panel"><div class="table-wrap"><table class="data-table"><thead><tr><th>Arquivo</th><th>Uso no cálculo</th><th>Resumo</th></tr></thead><tbody>${rules}</tbody></table></div></section>
      <p class="subtitle">Estas regras entram no registro da base de cálculo de cada projeto e só mudam com uma nova versão do aplicativo. As tabelas de consulta geradas delas (matriz de métodos e Tabelas 41 a 45) ficam em <a href="#installtables">Tabelas de instalação</a>.</p>` : '') + '<div class="notice blue">As tabelas de norma trazem localizadores (tabela, item e página) e não o texto da norma. Tabelas de fabricante indicam o documento de origem por linha quando disponível.</div>';
    $('#tables-body').onclick = (e) => { const b = e.target.closest('[data-table-open]'); if (b) { window.tablesSelected = b.dataset.tableOpen; tb.row = 1; tb.q = ''; render(); } };
  };

  const fmtList = (vals) => (vals || []).map((v) => fv(v) || 'vazio').join(' / ');
  async function renderTable(main, id) {
    const isAmp = id === 'tab_ampacidade_2c' || id === 'tab_ampacidade_3c';
    main.innerHTML = heading('Base técnica', 'Consulta e edição versionada de tabela técnica.', `${isAmp ? '<button class="btn" id="tables-norm">Ver na forma da norma</button> ' : ''}<button class="btn" id="tables-back">← Todas as tabelas</button>`, 'REFERÊNCIA')
      + '<div id="rev-bar"></div><div id="table-body"><div class="loading-card">Carregando tabela…</div></div>';
    $('#tables-back').onclick = () => { window.tablesSelected = null; render(); };
    const tn = $('#tables-norm'); if (tn) tn.onclick = () => window.openNormAmpacity && window.openNormAmpacity();
    await reviewerBar(() => render());
    const rv = window.reviewerState();
    let d;
    try { d = await api('/api/table?' + new URLSearchParams({ id, row: tb.row, count: 50, q: tb.q })); } catch (e) { toast(e.message, true); window.tablesSelected = null; return; }
    const usage = window.tableUsage && window.tableUsage.tabela === id ? window.tableUsage : null;
    const usedCells = usage ? usage.celulas || {} : {};
    const usedRows = new Set(usage ? usage.linhas || [] : []);
    const head = `<tr><th></th>${d.colunas_def.map((c) => `<th title="${esc(c.nome)}">${esc(c.letra)}${c.nome ? `<small class="cell-sub">${esc(c.nome.slice(0, 40))}</small>` : ''}</th>`).join('')}</tr>`;
    const body = d.linhas_def.map((r) => `<tr class="${usedRows.has(r.linha) ? 'row-used' : ''}"><td class="row-number">${r.linha}</td>${r.celulas.map((c, i) => {
      const addr = d.colunas_def[i].letra + r.linha;
      const used = usedCells[addr];
      if (!c) return `<td class="raw ${rv.desbloqueado && d.uso.operacional && r.linha > 1 ? 'editable-cell' : ''}${used ? ' used-cell' : ''}" data-tcell="${addr}"></td>`;
      const cls = [c.calculada ? 'calc' : 'raw', c.editada ? 'edited-cell' : '', c.anterior ? 'corrected-cell' : '', used ? 'used-cell' : '', rv.desbloqueado && d.uso.operacional && !c.calculada && r.linha > 1 ? 'editable-cell' : ''].join(' ');
      const corr = c.anterior ? `${c.removida ? 'Removida' : 'Corrigida'} nesta revisão da base. Valor anterior: ${fmtList(c.anterior)}.${c.correcao ? ` ${c.correcao.achado || ''} — ${c.correcao.fonte || ''}${c.correcao.motivo ? '. ' + c.correcao.motivo : ''}` : ''}` : '';
      const title = [c.editada ? `Editada no projeto. Valor da base: ${fv(c.base)}` : c.calculada ? 'Calculada a partir de outras células' : '', corr, used ? 'Lida pelo cálculo de ' + usage.circuito + ': ' + used.map((x) => x.rotulo).join('; ') : ''].filter(Boolean).join(' · ');
      return `<td class="${cls}" data-tcell="${addr}" title="${esc(title || fv(c.v))}">${esc(fv(c.v)).slice(0, 80)}${c.anterior ? '<sup>*</sup>' : ''}</td>`;
    }).join('')}</tr>`).join('');
    const versions = d.versoes.length ? `<h3>Edições desta tabela no projeto</h3><div class="table-wrap"><table class="data-table compact"><thead><tr><th>Versão</th><th>Tipo</th><th>Autor</th><th>Quando</th><th>Fonte do valor</th><th>Justificativa</th><th>Células</th></tr></thead><tbody>${d.versoes.map((v) => `<tr><td>v${v.versao}</td><td>${esc(v.tipo)}</td><td>${esc(v.autor || '—')}</td><td>${esc(fmtTs(v.ts))}</td><td class="wrap-cell">${esc(v.fonte || '—')}</td><td class="wrap-cell">${esc(v.justificativa || '')}</td><td>${v.n_celulas}</td></tr>`).join('')}</tbody></table></div>` : '';
    const corrections = (d.correcoes || []).length ? `<details class="norm-corr"><summary>${d.corrigidas} célula(s) diferentes da revisão anterior da base — ver as correções</summary><ul>${d.correcoes.map((x) => `<li><b>${esc(x.achado || '')}</b> ${esc((x.celulas || []).join(', '))}: ${esc(x.de ?? '')} → ${esc(x.para ?? '')}. ${esc(x.fonte || '')}${x.motivo ? ` <span class="muted">${esc(x.motivo)}</span>` : ''}</li>`).join('')}</ul></details>` : (d.corrigidas ? `<p><span class="tag red">${d.corrigidas} célula(s) corrigida(s) nesta revisão</span> marcadas com * na grade.</p>` : '');
    const usageList = usage ? `<div class="notice blue"><b>Lidas pelo cálculo de ${esc(usage.circuito || '')}:</b> ${Object.keys(usedCells).length ? Object.entries(usedCells).map(([a, us]) => `<span class="mono">${esc(a)}</span> (${esc([...new Set(us.map((x) => x.rotulo))].join('; '))})`).join(' · ') : usedRows.size ? '' : 'nenhuma célula desta tabela.'}${usedRows.size ? ` Linha(s) do modelo escolhido: ${[...usedRows].join(', ')}.` : ''}<br><small>${esc(usage.nota || '')}</small></div>` : '';
    $('#table-body').innerHTML = `<section class="panel table-meta"><h2>${esc(d.nome)}</h2>
      <div class="meta-grid"><div><label>Categoria</label><span>${esc(d.categoria_rotulo)}</span></div><div><label>Fonte</label><span>${esc(d.fonte || '—')}</span></div>
      <div><label>Edição</label><span>${esc(d.edicao || '—')}</span></div><div><label>Revisão da base</label><span>${esc(d.revisao_base)} · ${esc(d.revisao_data || '')}</span></div>
      <div><label>Situação da fonte</label><span class="tag ${d.situacao_fonte === 'a_confirmar' ? 'amber' : 'green'}">${esc(d.situacao_fonte_rotulo)}</span></div>
      <div><label>No projeto</label><span class="tag ${d.integridade === 'tabela_alterada' ? 'red' : d.integridade ? 'amber' : 'green'}">${esc(d.integridade_rotulo)}</span></div></div>
      ${d.condicoes.length ? `<p><b>Condições de uso:</b> ${esc(d.condicoes.join('; '))}</p>` : ''}
      ${d.refs.length ? `<p><b>Referências:</b> ${d.refs.map((r) => `<span class="tag">${esc(r)}</span>`).join(' ')}</p>` : ''}
      <p><b>Uso no cálculo:</b> ${d.uso.operacional ? `alimenta ${d.uso.n_variaveis} cálculo(s)${d.uso.regras_python ? ' e ' + esc(d.uso.regras_python) : ''}. Células que nenhum cálculo lê não são editáveis.` : `<b>apenas consulta.</b> ${esc(d.uso.nota || '')} A edição está bloqueada para não sugerir um efeito que não existe.`}</p>
      ${d.origem_por_linha ? `<p><b>Origem por linha:</b> coluna(s) ${esc(d.origem_por_linha.join(', '))} citam o documento de cada registro.</p>` : ''}
      ${corrections}
      <p class="subtitle">${esc(d.verificacao || '')} ${esc(d.revisao_nota || '')}</p></section>
      <div class="explorer-controls"><input id="tb-q" class="search" placeholder="Buscar texto na tabela…" value="${esc(tb.q)}" aria-label="Buscar na tabela"><button class="btn" id="tb-find">Buscar</button>
      ${d.uso.operacional && window.tableUsageHTML ? window.tableUsageHTML(id) : ''}
      ${rv.desbloqueado && d.celulas_editadas ? '<button class="btn" id="tb-restore">Restaurar a base do aplicativo</button>' : ''}</div>
      ${usageList}
      ${rv.desbloqueado && d.uso.operacional ? '<div class="notice">Modo revisor: clique em uma célula de valor para editá-la. Cabeçalhos, células calculadas e posições que nenhum cálculo lê não são editáveis.</div>' : ''}
      <section class="panel"><div class="table-wrap"><table class="data-table sheet-table" style="width:${Math.max(600, d.colunas_def.length * 150 + 50)}px"><thead>${head}</thead><tbody>${body || '<tr><td class="empty">Nenhuma linha.</td></tr>'}</tbody></table></div>
      <div class="sheet-pagination"><span>${d.total_linhas} linha(s)${tb.q ? ' encontradas' : ''} · mostrando a partir da ${d.inicio}</span><div><button class="btn small" id="tb-prev" ${tb.row <= 1 || tb.q ? 'disabled' : ''}>↑ Linhas</button><button class="btn small" id="tb-next" ${tb.q || tb.row + 50 > d.total_linhas ? 'disabled' : ''}>Linhas ↓</button></div></div></section>${versions}`;
    $('#tb-find').onclick = () => { tb.q = $('#tb-q').value.trim(); tb.row = 1; render(); };
    $('#tb-q').onkeydown = (e) => { if (e.key === 'Enter') $('#tb-find').click(); };
    $('#tb-prev').onclick = () => { tb.row = Math.max(1, tb.row - 50); render(); };
    $('#tb-next').onclick = () => { tb.row += 50; render(); };
    if (window.bindTableUsage) window.bindTableUsage(id, () => render());
    const rs = $('#tb-restore');
    if (rs) rs.onclick = () => { if (!confirm('Voltar todas as células editadas desta tabela aos valores da base do aplicativo? A edição fica no histórico.')) return; action(async () => { await api('/api/table/restore', { id }); await refresh(); render(); }, 'Tabela restaurada.'); };
    if (rv.desbloqueado) {
      $('#table-body').onclick = (e) => {
        const td = e.target.closest('.editable-cell'); if (!td) return;
        const addr = td.dataset.tcell;
        modal('Editar ' + esc(d.nome) + ' · ' + esc(addr),
          `<p class="subtitle">Valor atual: <b>${esc(td.textContent.replace(/\*$/, '') || '—')}</b>${td.classList.contains('edited-cell') ? ' (já editado no projeto)' : ''}</p>
           <div class="field wide"><label for="te-val">Novo valor (vazio apaga a célula)</label><input id="te-val" value="${esc(td.textContent.replace(/\*$/, ''))}" autocomplete="off"></div>
           <div class="field wide"><label for="te-src">Fonte do novo valor (norma e edição, catálogo e página, ensaio…)</label><input id="te-src" autocomplete="off"></div>
           <div class="field wide"><label for="te-just">Justificativa (mín. 15 caracteres)</label><textarea id="te-just" rows="3"></textarea></div>
           <div class="notice">A edição vale só para este projeto, é executada em todos os circuitos antes de gravar e é bloqueada se criar erros nos resultados obrigatórios. As confirmações de proteção são reabertas.</div>`,
          '<button class="btn primary" id="te-save">Gravar edição</button>');
        $('#te-save').onclick = () => action(async () => {
          const r = await api('/api/table/edit', { id, celulas: { [addr]: $('#te-val').value }, fonte: $('#te-src').value, justificativa: $('#te-just').value });
          $('#modal').close(); await refresh(); render();
          toast(`Tabela editada (v${r.versao}): ${r.impacto.circuitos_afetados} circuito(s) com valores alterados.`);
        });
      };
    }
  }

  /* ---------------- coordenação ---------------- */
  const LEVEL_CLS = { verificado: 'green', aproximado: 'amber', pre_verificacao: '', sem_dados: '' };
  const STATUS_CLS = { seletiva: 'green', parcial: 'amber', limitada: 'amber', nao_seletiva: 'red', indeterminada: '' };
  window.renderCoordinationView = async function (main) {
    main.innerHTML = heading('Coordenação das proteções', 'Seletividade entre cada dispositivo e o dispositivo a montante, classificada pelo nível de evidência: verificada com dados do fabricante, aproximada por faixas genéricas ou pré-verificação.', '', 'PROTEÇÕES')
      + '<div id="rev-bar"></div><div id="coord-body"><div class="loading-card">Avaliando os pares de dispositivos…</div></div>';
    await reviewerBar(() => render());
    const rv = window.reviewerState();
    const c = await api('/api/coordination');
    const rows = c.pares.filter((x) => x.aplicavel).map((x) => {
      const up = x.dispositivo_montante || {}, dn = x.dispositivo_jusante || {};
      const lim = x.limite_ka != null && ['parcial', 'limitada'].includes(x.situacao) ? ` até ≈ ${formatBR(x.limite_ka)} kA` : '';
      const conf = [...(up.conflitos || []), ...(dn.conflitos || [])].length;
      return `<tr><td><b>${esc(x.circuito)}</b>${x.par === 'origem_manutencao' ? ' <span class="tag">origem × manutenção</span>' : ''}<small class="cell-sub">${esc(dn.descricao || '')}${dn.modelo ? ' · ' + esc(dn.modelo) : ''}${dn.in ? ' · In ' + formatBR(dn.in) + ' A' : ''}</small>${conf ? '<span class="tag amber">dados do dispositivo divergentes</span>' : ''}</td>
        <td class="wrap-cell">${esc(up.descricao || '—')}${up.modelo ? `<small class="cell-sub">${esc(up.modelo)}</small>` : ''}</td>
        <td><span class="tag ${LEVEL_CLS[x.nivel]}">${esc(c.niveis[x.nivel])}</span></td>
        <td><span class="tag ${STATUS_CLS[x.situacao]}">${esc(c.situacoes[x.situacao])}${esc(lim)}</span></td>
        <td class="num">${x.ik_ka == null ? '—' : formatBR(x.ik_ka)}</td>
        <td class="wrap-cell"><details><summary>Detalhes</summary><ul>${x.detalhes.map((d) => `<li>${esc(d)}</li>`).join('')}</ul>${x.fonte ? `<p><b>Fonte:</b> ${esc(x.fonte)}</p>` : ''}${x.pre_verificacao ? `<p class="subtitle">Pré-verificação do modelo: ${esc(x.pre_verificacao)}</p>` : ''}</details></td></tr>`;
    }).join('');
    const cond = (d) => [d.tensao_v ? `${d.tensao_v[0] === d.tensao_v[1] ? formatBR(d.tensao_v[0]) : formatBR(d.tensao_v[0]) + '–' + formatBR(d.tensao_v[1])} V` : '',
      ...Object.entries(d.ajustes || {}).map(([k, v]) => `${k.replace('_a', '').replace('_ms', '')} = ${v}`)].filter(Boolean).join(' · ');
    const data = c.dados_fabricante.map((d) => `<tr><td>${esc(d.tipo === 'curva' ? 'Curva tempo × corrente' : 'Tabela de seletividade')}${d.selo_valido ? '' : ' <span class="tag red">alterado fora do aplicativo — desconsiderado</span>'}</td><td class="wrap-cell">${esc(d.descricao || '')}${cond(d) ? `<small class="cell-sub">Condições: ${esc(cond(d))}</small>` : ''}</td>
      <td class="wrap-cell">${esc([d.fabricante, d.documento, d.edicao && 'edição ' + d.edicao, d.pagina && 'p. ' + d.pagina].filter(Boolean).join(' · '))}</td><td>${esc(d.importado_por || '—')}<small class="cell-sub">${esc(fmtTs(d.ts))}</small></td>
      <td>${rv.desbloqueado ? `<button class="btn small" data-curve-del="${esc(d.id)}">Remover</button>` : ''}</td></tr>`).join('');
    $('#coord-body').innerHTML = `<div class="toolbar">${Object.entries(c.niveis).filter(([k]) => k !== 'sem_dados').map(([k, label]) => `<span class="tag ${LEVEL_CLS[k]}">${c.contagem[k]} · ${esc(label)}</span>`).join('')}</div>
      <div class="notice blue">${esc(c.nota)}</div>
      <section class="panel"><div class="table-wrap"><table class="data-table"><thead><tr><th>Circuito (jusante)</th><th>Dispositivo a montante</th><th>Nível</th><th>Resultado</th><th class="num">Ik máx no ponto (kA)</th><th>Base</th></tr></thead><tbody>${rows || '<tr><td colspan="6" class="empty">Nenhum par montante × jusante.</td></tr>'}</tbody></table></div></section>
      <section class="panel"><div class="panel-head"><div><h2>Dados de fabricante importados</h2><p>Tabelas de seletividade e curvas tempo × corrente, sempre com o documento de origem. Sem estes dados, nenhum par é marcado como verificado.</p></div>${rv.desbloqueado ? '<button class="btn primary" id="curve-import">Importar dados do fabricante</button>' : ''}</div>
      <div class="table-wrap"><table class="data-table"><thead><tr><th>Tipo</th><th>Descrição</th><th>Documento</th><th>Importado por</th><th></th></tr></thead><tbody>${data || '<tr><td colspan="5" class="empty">Nenhum dado de fabricante importado neste projeto.</td></tr>'}</tbody></table></div></section>`;
    const imp = $('#curve-import'); if (imp) imp.onclick = importModal;
    $$('[data-curve-del]').forEach((b) => { b.onclick = () => { if (!confirm('Remover estes dados do fabricante do projeto?')) return; action(async () => { await api('/api/curves/delete', { id: b.dataset.curveDel }); await refresh(); render(); }, 'Dados removidos.'); }; });
  };

  function importModal() {
    modal('Importar dados do fabricante',
      `<div class="notice">Cole os dados exatamente como constam no documento do fabricante. O aplicativo não completa nem estima valores ausentes.</div>
       <div class="field-grid"><div class="field"><label for="cv-tipo">Tipo</label><select id="cv-tipo"><option value="tabela_seletividade">Tabela de seletividade</option><option value="curva">Curva tempo × corrente</option></select></div>
       <div class="field"><label for="cv-fab">Fabricante</label><input id="cv-fab" autocomplete="off"></div>
       <div class="field"><label for="cv-doc">Documento (catálogo, guia de seletividade…)</label><input id="cv-doc" autocomplete="off"></div>
       <div class="field"><label for="cv-ed">Edição / data</label><input id="cv-ed" autocomplete="off"></div>
       <div class="field"><label for="cv-pg">Página</label><input id="cv-pg" autocomplete="off"></div>
       <div class="field"><label for="cv-tensao">Tensão para a qual o documento vale (V; ex.: 220 ou 380-415)</label><input id="cv-tensao" autocomplete="off"></div>
       <div class="field" id="cv-model-f" hidden><label for="cv-model">Modelo do dispositivo (igual ao usado no projeto)</label><input id="cv-model" autocomplete="off"></div></div>
       <div class="field-grid" id="cv-adj" hidden><div class="field"><label for="cv-ir">Ir (A) da curva</label><input id="cv-ir" inputmode="decimal"></div>
       <div class="field"><label for="cv-isd">Isd (A)</label><input id="cv-isd" inputmode="decimal"></div><div class="field"><label for="cv-tsd">tsd (ms)</label><input id="cv-tsd" inputmode="decimal"></div>
       <div class="field"><label for="cv-ii">Ii (A)</label><input id="cv-ii" inputmode="decimal"></div><div class="field"><label for="cv-i2t">I²t</label><select id="cv-i2t"><option value="">não informado</option><option>ON</option><option>OFF</option></select></div></div>
       <div class="field wide"><label for="cv-data">Dados (CSV com ; ou ,)</label><textarea id="cv-data" rows="8" class="mono" spellcheck="false"></textarea></div>
       <p class="subtitle" id="cv-help"></p>`,
      '<button class="btn primary" id="cv-save">Importar</button>');
    const help = () => {
      const curve = $('#cv-tipo').value === 'curva';
      $('#cv-model-f').hidden = !curve; $('#cv-adj').hidden = !curve;
      $('#cv-help').innerHTML = curve
        ? 'Cabeçalho: <code>corrente_a;t_min_s;t_max_s</code> (ou <code>multiplo_ir</code> / <code>multiplo_in</code>). Um ponto por linha; tempos em segundos, positivos. A curva vale só no intervalo de correntes informado (sem extrapolação); o montante precisa de tempos mínimos que cubram desde o início do envelope de tempos máximos do jusante. Ausência de pontos não comprova não atuação. Para dispositivo ajustável, informe os ajustes da curva: ela só é usada quando eles coincidem com os do projeto.'
        : 'Cabeçalho: <code>montante;jusante;limite_ka</code> (limite em kA ou <code>T</code> = seletividade total até a capacidade de interrupção do jusante). Colunas opcionais de condição: <code>tensao_v</code>, <code>icu_jusante_ka</code>, <code>ir_montante_a</code>, <code>isd_montante_a</code>, <code>tsd_montante_ms</code>, <code>ii_montante_a</code>, <code>i2t_montante</code> (e as equivalentes <code>_jusante</code>). A tensão é obrigatória; para dispositivos ajustáveis, informe todos os ajustes, incluindo I²t ON/OFF quando disponível. Ii deve corresponder ao disparo instantâneo do modelo. Icu divergente do catálogo exige reconciliação; este campo não comprova associação em cascata.';
    };
    $('#cv-tipo').onchange = help; help();
    $('#cv-save').onclick = () => action(async () => {
      const num = (id) => { const v = $(id).value.trim(); return v ? parseBR(v) : undefined; };
      await api('/api/curves/import', { tipo: $('#cv-tipo').value, fabricante: $('#cv-fab').value, documento: $('#cv-doc').value, edicao: $('#cv-ed').value,
        pagina: $('#cv-pg').value, modelo: $('#cv-model').value, conteudo: $('#cv-data').value, tensao_v: $('#cv-tensao').value,
        ajustes: { ir_a: num('#cv-ir'), isd_a: num('#cv-isd'), tsd_ms: num('#cv-tsd'), ii_a: num('#cv-ii'), i2t: $('#cv-i2t').value || undefined } });
      $('#modal').close(); await refresh(); render();
    }, 'Dados do fabricante importados.');
  }
})();

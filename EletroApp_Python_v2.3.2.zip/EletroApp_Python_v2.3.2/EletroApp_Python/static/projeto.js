'use strict';
/* EletroApp v1.5
 * - Diagrama unifilar com simbologia gráfica (IEC 60617 / ABNT NBR 12520 e 12523), em disposição vertical,
 *   horizontal ou em cartões, com seleção das informações exibidas;
 * - Quadro de cargas (P, Q, S, fp, fator de simultaneidade e potência por fase);
 * - Resumo dos circuitos da Visão geral;
 * - Abas de informações por subgrupo no formulário do circuito.
 * Usa as funções globais de app.js ($, $$, esc, num, short, isError, heading, state).
 */

const nf=(v,d=2)=>typeof v==='number'&&Number.isFinite(v)?v.toLocaleString('pt-BR',{minimumFractionDigits:d,maximumFractionDigits:d}):null;
const nv=(v,d=2,unit='')=>{const t=nf(v,d);return t===null?'—':unit?t+' '+unit:t;};
const kx=(v,d=2)=>typeof v==='number'?nf(v/1000,d):'—';
const isNum=v=>typeof v==='number'&&Number.isFinite(v);
const textOf=v=>isError(v)?'—':(v===null||v===undefined||v===''?'—':String(v));

/* ---------------------------------------------------------------- informações exibíveis no unifilar */
const UNI_INFO=[
  {id:'nome',grupo:'Identificação',label:'Nome do circuito / quadro',def:1,min:1},
  {id:'natureza',grupo:'Identificação',label:'Natureza (origem, distribuição, final)'},
  {id:'descricao',grupo:'Identificação',label:'Descrição'},
  {id:'esquema',grupo:'Ligação',label:'Esquema de ligação (3F+N+PE)',def:1},
  {id:'aterramento',grupo:'Ligação',label:'Esquema de aterramento (TN-S / TN-C)'},
  {id:'condutores',grupo:'Condutores',label:'Condutores agrupados — 1x{3#50mm²(25mm²)PE16mm²}',def:1},
  {id:'comprimento',grupo:'Condutores',label:'Comprimento do circuito'},
  {id:'metodo',grupo:'Condutores',label:'Método de instalação'},
  {id:'protecao',grupo:'Proteção',label:'Modelo do dispositivo de proteção'},
  {id:'in_ir',grupo:'Proteção',label:'Corrente nominal e de ajuste — In100A_Ir80A',def:1,min:1},
  {id:'ii',grupo:'Proteção',label:'Disparo instantâneo (Ii/Im)'},
  {id:'icu',grupo:'Proteção',label:'Capacidade de interrupção (Icu)'},
  {id:'ib',grupo:'Correntes',label:'Corrente nominal (Ib)'},
  {id:'ic',grupo:'Correntes',label:'Corrente máxima (Ic — base da proteção)'},
  {id:'iz',grupo:'Correntes',label:'Corrente máxima do cabo na instalação (Iz)'},
  {id:'dv',grupo:'Correntes',label:'Queda de tensão (trecho e total)'},
  {id:'icc',grupo:'Curto-circuito',label:'Icc máxima e mínima'},
  {id:'carga_total',grupo:'Cargas',label:'Carga total: P, Q e S (com simultaneidade)',def:1},
  {id:'carga_fase',grupo:'Cargas',label:'Carga por fase: P, Q e S'},
  {id:'carga_propria',grupo:'Cargas',label:'Carga própria (sem simultaneidade)'},
  {id:'fp_fs',grupo:'Cargas',label:'Fator de potência e fator de simultaneidade',def:1},
  {id:'dps',grupo:'Símbolos adicionais',label:'DPS nos quadros em que é recomendado'},
  {id:'status',grupo:'Símbolos adicionais',label:'Indicador de verificação (cor)',def:1,min:1},
];
const UNI_PRESETS={
  minimo:{label:'Mínimo',ids:UNI_INFO.filter(i=>i.min).map(i=>i.id)},
  padrao:{label:'Padrão',ids:UNI_INFO.filter(i=>i.def).map(i=>i.id)},
  completo:{label:'Completo',ids:UNI_INFO.map(i=>i.id)},
};
const uniState={mode:'v',sel:new Set(UNI_PRESETS.padrao.ids),zoom:'fit',focus:'',tab:'diagrama',cargaModo:'total',infoOpen:true};
function uniLoad(){
  try{
    const j=JSON.parse(localStorage.getItem('eletroapp.unifilar')||'null');
    if(!j)return;
    if(['v','h','c'].includes(j.mode))uniState.mode=j.mode;
    if(Array.isArray(j.sel))uniState.sel=new Set(j.sel.filter(id=>UNI_INFO.some(i=>i.id===id)));
    if(j.zoom==='fit'||(typeof j.zoom==='number'&&j.zoom>=.3&&j.zoom<=2.5))uniState.zoom=j.zoom;
    if(['total','propria'].includes(j.cargaModo))uniState.cargaModo=j.cargaModo;
    if(typeof j.infoOpen==='boolean')uniState.infoOpen=j.infoOpen;
  }catch(e){/* armazenamento indisponível: segue com os padrões */}
}
function uniSave(){
  try{localStorage.setItem('eletroapp.unifilar',JSON.stringify({mode:uniState.mode,sel:[...uniState.sel],zoom:uniState.zoom,cargaModo:uniState.cargaModo,infoOpen:uniState.infoOpen}));}catch(e){/* ignora */}
}
uniLoad();

/* ---------------------------------------------------------------- símbolos (coordenadas locais: o condutor corre em +y) */
const SYM={
  // disjuntor: contato aberto com a cruz de disparo (IEC 60617, dispositivo de manobra com abertura automática)
  breaker:'<path d="M0 0V9M0 27V36M0 27L-8.5 10"/><path d="M-4 5.5L4 12.5M4 5.5L-4 12.5"/>',
  // fusível: retângulo atravessado pelo condutor
  fuse:'<path d="M0 0V8M0 28V36"/><rect x="-4" y="8" width="8" height="20"/><path d="M0 8V28"/>',
  load:'<path d="M0 0V6"/><rect x="-8" y="6" width="16" height="22"/>',
  dps:'<path d="M0 0V8M0 28V33"/><rect x="-5" y="8" width="10" height="20"/><path d="M-5 25L5 11M5 11L1.4 12.6M5 11L5.6 15"/>',
};
const cText=(h,cy,s,cls='ts')=>`<text class="${cls}" x="0" y="${cy}" text-anchor="middle"${h?` transform="rotate(90 0 ${cy-3})"`:''}>${s}</text>`;
const symMeter=h=>`<path d="M0 0V7M0 29V36"/><circle cx="0" cy="18" r="11"/>${cText(h,21,'Wh')}`;
const symMotor=h=>`<path d="M0 0V7"/><circle cx="0" cy="18" r="11"/>${cText(h,21.5,'M','tb')}`;
const symSource=h=>`<circle cx="0" cy="0" r="14"/>${cText(h,3.5,'~','tb')}`;
const symGenerator=h=>`<circle cx="0" cy="0" r="14"/>${cText(h,-1,'G','tb')}${cText(h,9,'~','ts')}`;
const symTrafo='<circle cx="0" cy="11" r="11"/><circle cx="0" cy="25" r="11"/>';
const symTicks=n=>{let out='';const total=Math.max(1,n);const first=-((total-1)*3.2)/2;for(let i=0;i<total;i++){const y=first+i*3.2;out+=`M-4.5 ${(y+2.2).toFixed(1)}L4.5 ${(y-2.2).toFixed(1)}`;}return `<path d="${out}"/>`;};
const groundAt=(x,y)=>`<path class="s" d="M${x} ${y}V${y+8}M${x-9} ${y+8}H${x+9}M${x-6} ${y+12}H${x+6}M${x-3} ${y+16}H${x+3}"/>`;

function uniStatusColor(s){return s==='error'?'#c0786b':s==='pending'?'#c7a261':'#4f9b80';}
function uniCondCount(n){
  const t=n.tipo_circuito;
  if(typeof t!=='string'||!t)return 3;
  const p=t.split('+');const f=parseInt(p[0],10)||3;
  return f+(p.includes('N')?1:0)+(p.includes('T')?1:0)+(p.includes('PEN')?1:0);
}
function uniOriginInfo(o){
  const t=o&&o.tipo;
  const v=(x,d=0)=>isNum(x)?nf(x,Number.isInteger(x)?0:d||1):'—';
  if(t==='Gerador BT')return{kind:'gerador',lines:['Gerador BT',`${v(o.gerador_kva)} kVA · ${v(o.tensao_ff)} V`,o.esquema||'']};
  if(t==='Rede BT Direta')return{kind:'rede',lines:['Rede BT da concessionária',`${v(o.tensao_ff)} V`,o.esquema||'']};
  return{kind:'trafo',lines:[`Rede MT ${v(o&&o.tensao_mt)} kV`,`Transformador ${v(o&&o.trafo_kva)} kVA`,`${(o&&o.grupo_ligacao)||''} · ${v(o&&o.tensao_secundario)} V`,(o&&o.esquema)||'']};
}

/* ---------------------------------------------------------------- textos do unifilar */
function uniLines(n,sel){
  const has=id=>sel.has(id),prot=[],cable=[],load=[];
  if(n.protection_link?.vinculado){if(has('protecao'))prot.push('Vinculado ao disjuntor de '+n.protection_link.quadro);}
  else if(n.origem_ausente){if(has('protecao')||has('in_ir'))prot.push('sem dispositivo na origem');}
  else{
    if(has('protecao'))prot.push(isError(n.protecao)||!n.protecao?'Sem modelo definido':String(n.protecao));
    if(has('in_ir'))prot.push(n.protecao_ajuste||'In/Ir —');
  }
  const pp=[];
  if(has('ii'))pp.push('Ii '+nv(n.ii_prot,0,'A'));
  if(has('icu'))pp.push('Icu '+nv(n.icu,0,'kA'));
  if(pp.length&&!n.origem_ausente)prot.push(pp.join(' · '));
  const l1=[];
  if(has('esquema'))l1.push(n.esquema_ligacao||'—');
  if(has('aterramento'))l1.push(n.earthing||'—');
  if(l1.length)cable.push(l1.join(' · '));
  if(has('condutores'))cable.push(n.condutores||'condutores —');
  const l3=[];
  if(has('comprimento'))l3.push('L '+nv(n.length,0,'m'));
  if(has('metodo')){const i=n.instalacao||{};l3.push('Método '+(i.referencia||'—')+(i.metodo!=null&&i.metodo!==''?' ('+i.metodo+')':''));}
  if(l3.length)cable.push(l3.join(' · '));
  const cur=[];
  if(has('ib'))cur.push('Ib '+nv(n.ib,1));
  if(has('ic'))cur.push('Ic '+nv(n.ic,1));
  if(has('iz'))cur.push('Iz '+nv(n.iz,1));
  if(cur.length)cable.push(cur.join(' · ')+' A');
  if(has('dv'))cable.push('ΔV '+nv(n.dv,2,'%')+' · total '+(isNum(n.dv_total)?nv(n.dv_total,2,'%'):textOf(n.dv_total)));
  if(has('icc'))cable.push('Icc máx '+nv(n.icc_max,2)+' · mín '+nv(n.icc_min,2)+' kA');
  if(has('carga_total'))load.push(`P ${kx(n.p_w)} kW · Q ${kx(n.q_var)} kvar · S ${kx(n.s_va)} kVA`);
  if(has('carga_fase')){
    load.push(`R: ${kx(n.pr)} kW · ${kx(n.q_r)} kvar · ${kx(n.s_r)} kVA`);
    load.push(`S: ${kx(n.ps)} kW · ${kx(n.q_s)} kvar · ${kx(n.s_s)} kVA`);
    load.push(`T: ${kx(n.pt)} kW · ${kx(n.q_t)} kvar · ${kx(n.s_t)} kVA`);
  }
  if(has('carga_propria')){
    const s=Math.hypot(n.p_own||0,n.q_own||0);
    load.push(`Própria: P ${kx(n.p_own)} kW · Q ${kx(n.q_own)} kvar · S ${kx(s)} kVA`);
  }
  if(has('fp_fs'))load.push(`fp ${nv(n.fp,3)} · Fs ${nv(n.fs,2)}`);
  return{prot,cable,load};
}

/* ---------------------------------------------------------------- unifilar normativo (SVG) */
function unifilarSVG(circuits,origem,opt){
  const o=Object.assign({mode:'v',sel:uniState.sel,focus:'',fit:true,zoom:1,standalone:false},opt||{});
  if(!circuits.length)return '<div class="empty">Nenhum circuito cadastrado.</div>';
  const horiz=o.mode==='h',LH=12,sel=o.sel,CLIP=56;
  const clip=s=>{s=String(s??'');return s.length>CLIP?s.slice(0,CLIP-1)+'…':s;};
  const T=(x,y,s,cls='t',anchor='start')=>{const full=String(s??'');const body=esc(clip(full));const a=anchor==='start'?'':` text-anchor="${anchor}"`;return `<text class="${cls}" x="${x.toFixed(1)}" y="${y.toFixed(1)}"${a}>${body}${full.length>CLIP?`<title>${esc(full)}</title>`:''}</text>`;};
  const pt=(u,v)=>horiz?[u,v]:[v,u];
  const seg=(u1,v1,u2,v2,cls='s')=>{const[a,b]=pt(u1,v1),[c,d]=pt(u2,v2);return `<line class="${cls}" x1="${a.toFixed(1)}" y1="${b.toFixed(1)}" x2="${c.toFixed(1)}" y2="${d.toFixed(1)}"/>`;};
  const sym=(u,v,inner,cls='s')=>{const[x,y]=pt(u,v);return `<g class="${cls}" transform="translate(${x.toFixed(1)},${y.toFixed(1)})${horiz?' rotate(-90)':''}">${inner}</g>`;};

  // ---- árvore (ignora ciclos; "Desvinculado" vira raiz tracejada)
  const nodes=circuits.map(c=>Object.assign({},c,{kids:[],_seen:false}));
  const byName=new Map(nodes.map(n=>[n.name,n]));
  const parentOf=n=>{const p=byName.get(n.parent);return p&&p!==n?p:null;};
  const focused=o.focus&&byName.has(o.focus)?byName.get(o.focus):null;
  const top=focused?[focused]:nodes.filter(n=>!parentOf(n));
  const visit=(n,d)=>{if(n._seen)return;n._seen=true;n.depth=d;for(const c of nodes){if(parentOf(c)===n&&!c._seen){n.kids.push(c);visit(c,d+1);}}};
  top.forEach(n=>visit(n,0));
  if(!focused)nodes.filter(n=>!n._seen).forEach(n=>{top.push(n);visit(n,0);});
  const vis=nodes.filter(n=>n._seen);
  vis.forEach(n=>{
    const L=uniLines(n,sel);n.prot=L.prot;n.cable=L.cable;n.load=L.load;
    n.feed=n.prot.length+n.cable.length+(n.kids.length?n.load.length:0);
    n.legit=!n.parent||['Fonte','Transformador'].includes(n.parent)||!!parentOf(n);
  });
  const maxDepth=Math.max(...vis.map(n=>n.depth));
  const fLines=Math.max(...vis.map(n=>n.feed),0);
  const lLines=Math.max(...vis.map(n=>n.kids.length?0:n.load.length+1),1);

  // ---- geometria
  const SLOT=horiz?Math.max(92,48+Math.max(fLines,lLines)*LH):250;
  // Disjuntor de manutenção na extremidade: espaço extra antes do barramento do quadro.
  const anyMB=vis.some(n=>n.manutencao);
  const SEG=horiz?310:Math.max(118,48+fLines*LH)+(anyMB?52:0);
  const org=uniOriginInfo(origem);
  const sourceMT=origem?.protection&&['Chave fusível MT','Disjuntor MT com relé'].includes(origem.protection.profile);
  const ORI=(sourceMT?60:0)+(focused?46:(horiz?(org.kind==='trafo'?190:130):(org.kind==='trafo'?138:96)));
  const PAD=horiz?30:64;
  const U=d=>d<0?ORI:ORI+(d+1)*SEG;
  let leaf=0;
  const place=n=>{
    if(n.kids.length){n.kids.forEach(place);n.v=(n.kids[0].v+n.kids[n.kids.length-1].v)/2;}
    else{n.v=PAD+leaf*SLOT+(horiz?SLOT/2:46);leaf++;}
  };
  top.forEach(place);
  const vMin=Math.min(...top.map(n=>n.v)),vMax=Math.max(...top.map(n=>n.v));
  const originV=(vMin+vMax)/2;
  const W=horiz?ORI+(maxDepth+1)*SEG+270:Math.max(leaf,1)*SLOT+PAD*2;
  const H=horiz?Math.max(leaf,1)*SLOT+PAD*2:ORI+(maxDepth+1)*SEG+40+lLines*LH+30;

  let body='';
  // ---- origem
  if(focused){
    const f=focused;
    body+=seg(0,f.v,ORI,f.v)+(horiz?T(4,f.v-8,'de '+(f.parent||'—'),'tg'):T(f.v+10,16,'de '+(f.parent||'—'),'tg'));
  }else{
    const v=originV;
    let og='';
    if(org.kind==='trafo'){
      if(sourceMT){og+=sym(28,v,symSource(horiz))+seg(42,v,56,v)+sym(56,v,origem.protection.profile==='Chave fusível MT'?SYM.fuse:SYM.breaker)+seg(92,v,110,v)+sym(110,v,symTrafo)+seg(146,v,ORI,v);og+=horiz?T(56,v-25,origem.protection.description,'tg'):T(v+26,102,origem.protection.description,'tg');}else og+=sym(28,v,symSource(horiz))+seg(42,v,56,v)+sym(56,v,symTrafo)+seg(92,v,ORI,v);
    }else{
      og+=sym(28,v,org.kind==='gerador'?symGenerator(horiz):symSource(horiz))+seg(42,v,ORI,v);
    }
    // aterramento do neutro na origem (símbolo de terra)
    const gu=ORI-(org.kind==='trafo'?20:16);
    if(horiz){og+=`<path class="s" d="M${gu} ${v}V${v+14}"/>`+groundAt(gu,v+14);}
    else{og+=`<path class="s" d="M${v} ${gu}H${v+18}"/>`+groundAt(v+18,gu);}
    const lines=org.lines.filter(Boolean);
    lines.forEach((s,i)=>{
      if(horiz)og+=T(12,v+30+i*LH,s,i===0?'tb':'t');
      else og+=T(v+26,22+i*LH,s,i===0?'tb':'t');
    });
    // área de clique + ações no hover + selo de status (a origem é um elemento editável como os circuitos)
    const ost=origem&&origem.status||'ok';
    const hitV0=v-34,hitV1=horiz?v+34+LH*5:v+250;
    const hit=horiz?`<rect class="uni-origin-hit" x="0" y="${hitV0}" width="${ORI}" height="${hitV1-hitV0}"/>`:`<rect class="uni-origin-hit" x="${hitV0}" y="0" width="${hitV1-hitV0}" height="${ORI}"/>`;
    const at=(u,w)=>pt(u,w);
    const [gx,gy]=at(8,v-30),[sx,sy]=at(8,v-8);
    const actions=`<g class="uni-origin-actions"><g class="uni-act" data-origin-open="1" transform="translate(${gx},${gy})" role="button" aria-label="Editar parâmetros da entrada"><title>Editar parâmetros da entrada</title><circle r="9"/><circle r="2.6" class="ic"/><path class="ic" d="M0 -6V-4M0 4V6M-6 0H-4M4 0H6M-4.2 -4.2L-2.8 -2.8M2.8 2.8L4.2 4.2M-4.2 4.2L-2.8 2.8M2.8 -2.8L4.2 -4.2"/></g><g class="uni-act" data-origin-swap="1" transform="translate(${sx},${sy})" role="button" aria-label="Trocar o tipo de atendimento"><title>Trocar o tipo de atendimento</title><circle r="9"/><path class="ic" d="M-5 -2H4M1.5 -4.5L4 -2L1.5 0.5M5 2H-4M-1.5 -0.5L-4 2L-1.5 4.5"/></g></g>`;
    const [dx,dy]=at(40,v-22);
    const dot=(ost!=='ok'||sel.has('status'))?`<circle class="uni-origin-dot" cx="${dx}" cy="${dy}" r="5" fill="${uniStatusColor(ost)}"><title>${esc(ost==='ok'?'Entrada completa':(origem.pendencias||[]).join(' '))}</title></circle>`:'';
    body+=`<g class="uni-origin" data-origin="1" tabindex="0" role="button" aria-label="Editar a entrada (${esc(org.lines[0]||'origem')})"><title>${esc(org.lines.filter(Boolean).join(' · '))} — clique para editar</title>${o.standalone?'':hit}${og}${dot}${o.standalone?'':actions}</g>`;
    // barramento de origem
    const a=Math.min(vMin,v)-16,b=Math.max(vMax,v)+16;
    body+=seg(ORI,a,ORI,b,'bus');
  }

  // ---- circuitos
  const draw=n=>{
    const d=n.depth,u0=d===0?ORI:U(d-1),u1=U(d),v=n.v,terminal=!n.kids.length;
    const colorDot=sel.has('status')?uniStatusColor(n.status):null;
    let g='';
    // área clicável
    const hitU0=u0+6,hitU1=terminal?u1+40+n.load.length*LH:u1+6;
    if(horiz){g+=`<rect class="hit" x="${u0.toFixed(1)}" y="${(v-18).toFixed(1)}" width="${(SEG-4)}" height="${(Math.max(n.feed,1)*LH+40).toFixed(1)}" rx="5"/>`;}
    else{g+=`<rect class="hit" x="${(v-24).toFixed(1)}" y="${hitU0.toFixed(1)}" width="${SLOT-8}" height="${(hitU1-hitU0).toFixed(1)}" rx="5"/>`;}
    // condutor e dispositivo de proteção
    const brk=n.prot_classe==='fusivel'?SYM.fuse:SYM.breaker;
    // Sem dispositivo na origem: o condutor segue direto do barramento a montante.
    if(n.origem_ausente||n.protection_link?.vinculado)g+=seg(u0,v,u0+50,v,n.legit?'s':'s dash');
    else g+=seg(u0,v,u0+14,v,n.legit?'s':'s dash')+sym(u0+14,v,brk);
    let cStart=u0+50;
    if(n.row===3){g+=seg(u0+50,v,u0+54,v)+sym(u0+54,v,symMeter(horiz));cStart=u0+90;}
    const mb=n.manutencao,cEnd=mb?u1-44:u1;
    g+=seg(cStart,v,cEnd,v,n.legit?'s':'s dash');
    g+=sym((cStart+cEnd)/2,v,symTicks(uniCondCount(n)));
    if(mb){
      g+=sym(u1-44,v,SYM.breaker)+seg(u1-8,v,u1,v,n.legit?'s':'s dash');
      const ml=[['manutenção','tg'],[mb.ajuste||mb.modelo||'modelo a definir','tb']];
      ml.forEach(([s,cls],i)=>{if(horiz)g+=T(u1-8,v-22+i*LH,s,cls,'end');else g+=T(v+16,u1-58+i*LH,s,cls);});
    }
    // textos do alimentador
    const L=n.prot.map(s=>[s,n.origem_ausente?'tw':'tb']).concat(n.cable.map(s=>[s,'t']));
    if(n.kids.length)n.load.forEach(s=>L.push([s,'tl']));
    L.forEach(([s,cls],i)=>{
      if(horiz)g+=T(u0+14,v+16+i*LH,s,cls);
      else g+=T(v+16,u0+22+i*LH,s,cls);
    });
    if(!n.legit)(horiz?(g+=T(u0+14,v-8,'desvinculado','tw')):(g+=T(v+16,u0+12,'desvinculado','tw')));
    // destino: barramento do quadro ou carga
    const nameTxt=sel.has('nome')?n.name:'';
    const extra=[];
    if(sel.has('natureza')&&n.kind)extra.push(n.kind);
    if(sel.has('descricao')&&n.description)extra.push(n.description);
    if(!terminal){
      const a=Math.min(...n.kids.map(k=>k.v),v)-16,b=Math.max(...n.kids.map(k=>k.v),v)+16;
      g+=seg(u1,a,u1,b,'bus');
      if(horiz){
        if(colorDot)g+=`<circle cx="${u1+12}" cy="${a-12}" r="3.6" fill="${colorDot}"/>`;
        if(nameTxt)g+=T(u1+(colorDot?20:8),a-8,nameTxt,'tb');
        extra.forEach((s,i)=>{g+=T(u1+8,a-8-(i+1)*LH,s,'tg');});
      }else{
        if(colorDot)g+=`<circle cx="${(v+22).toFixed(1)}" cy="${(u1-10).toFixed(1)}" r="3.6" fill="${colorDot}"/>`;
        if(nameTxt)g+=T(v+(colorDot?30:16),u1-7,nameTxt,'tb');
        extra.forEach((s,i)=>{g+=T(v+16,u1-7-(i+1)*LH-(L.length?0:0),s,'tg');});
      }
      if(sel.has('dps')&&n.dps_recomendado){
        // DPS ligado ao barramento, em ramal para a terra (símbolo IEC), do lado oposto ao fluxo
        if(horiz){
          const yy=v-26;
          g+=`<path class="s" d="M${u1} ${yy}H${u1-18}"/>`
            +`<g class="s" transform="translate(${u1-18},${yy}) rotate(90)">${SYM.dps}</g>`
            +T(u1-12,yy-8,'DPS','ts','end')
            +`<path class="s" d="M${u1-18-33} ${yy}H${u1-18-39}"/>`
            +`<path class="s" d="M${u1-18-39} ${yy-9}V${yy+9}M${u1-18-43} ${yy-6}V${yy+6}M${u1-18-47} ${yy-3}V${yy+3}"/>`;
        }else{
          const xx=v-26;
          g+=`<path class="s" d="M${xx} ${u1}V${u1-18}"/>`
            +`<g class="s" transform="translate(${xx},${u1-18}) rotate(180)">${SYM.dps}</g>`
            +T(xx-8,u1-30,'DPS','ts','end')
            +groundAt(xx,u1-18-33-0).replace(/V(\S+)M/,'V$1M').replace(/class="s"/,'class="s" transform="translate(0,0)"');
        }
      }
    }else{
      const motor=false;
      g+=sym(u1,v,motor?symMotor(horiz):SYM.load);
      const lines=[];
      if(nameTxt)lines.push([nameTxt,'tb']);
      extra.forEach(s=>lines.push([s,'tg']));
      n.load.forEach(s=>lines.push([s,'tl']));
      lines.forEach(([s,cls],i)=>{
        if(horiz){
          const x=u1+40;
          const y0=v-((lines.length-1)*LH)/2+3;
          g+=(i===0&&colorDot?`<circle cx="${x-8}" cy="${(y0-3).toFixed(1)}" r="3.6" fill="${colorDot}"/>`:'')+T(x,y0+i*LH,s,cls);
        }else{
          const y=u1+46+i*LH;
          g+=(i===0&&colorDot?`<circle cx="${(v-Math.min(CLIP,String(nameTxt).length)*2.9-9).toFixed(1)}" cy="${(y-3).toFixed(1)}" r="3.6" fill="${colorDot}"/>`:'')+T(v-(i===0&&colorDot?0:0),y,s,cls,'middle');
        }
      });
    }
    return `<g class="uni-node" data-edit="${esc(n.id)}" tabindex="0" role="button" aria-label="Editar ${esc(n.name)}"><title>${esc(n.name)} — clique para editar</title>${g}</g>`;
  };
  vis.forEach(n=>{body+=draw(n);});

  const style='<style>.s{stroke:#1c2b36;stroke-width:1.4;fill:none;stroke-linecap:round;stroke-linejoin:round}.s rect,.s circle{fill:#fff}.dash{stroke-dasharray:5 4;stroke:#b0702a}.bus{stroke:#1c2b36;stroke-width:4.5;stroke-linecap:round}.t,.tb,.tg,.tl,.tw,.ts{font-family:Arial,Helvetica,sans-serif;font-size:10px;fill:#1c2b36}.tb{font-weight:700}.tg{fill:#6c7d86}.tl{fill:#0e6b66}.tw{fill:#b0702a;font-style:italic}.ts{font-size:8px;stroke:none}.hit{fill:transparent;stroke:none}.uni-node{cursor:pointer;outline:none}.uni-node:hover .hit,.uni-node:focus .hit{fill:#117b780d;stroke:#117b78;stroke-width:1;stroke-dasharray:3 3}</style>';
  const dims=o.fit?'':` width="${Math.round(W*(o.zoom||1))}" height="${Math.round(H*(o.zoom||1))}"`;
  const xmlns=o.standalone?' xmlns="http://www.w3.org/2000/svg"':'';
  return `<svg${xmlns} class="uni-svg" viewBox="0 0 ${Math.round(W)} ${Math.round(H)}"${dims} role="img" aria-label="Diagrama unifilar da instalação">${style}${body}</svg>`;
}

function uniLegendHTML(){
  const items=[
    ['Rede / fonte',`<svg viewBox="-18 -18 36 36" class="lg"><g class="s">${symSource(false)}</g></svg>`],
    ['Transformador',`<svg viewBox="-14 -2 28 40" class="lg"><g class="s">${symTrafo}</g></svg>`],
    ['Disjuntor',`<svg viewBox="-14 -2 28 40" class="lg"><g class="s">${SYM.breaker}</g></svg>`],
    ['Fusível',`<svg viewBox="-14 -2 28 40" class="lg"><g class="s">${SYM.fuse}</g></svg>`],
    ['Disjuntor de manutenção (chegada do quadro)',`<svg viewBox="-14 -2 28 48" class="lg"><g class="s">${SYM.breaker}<path d="M0 36V40"/></g><path class="bus" d="M-10 42H10"/></svg>`],
    ['Trecho sem dispositivo na origem',`<svg viewBox="-14 -2 28 40" class="lg"><g class="s"><path d="M0 0V36"/></g><text x="5" y="20" style="font:italic 8px Arial;fill:#b0702a">sem</text></svg>`],
    ['Medidor de energia',`<svg viewBox="-14 -2 28 40" class="lg"><g class="s">${symMeter(false)}</g></svg>`],
    ['Condutores (traços = nº de condutores)',`<svg viewBox="-14 -12 28 24" class="lg"><g class="s"><path d="M0 -12V12"/>${symTicks(4)}</g></svg>`],
    ['Barramento do quadro',`<svg viewBox="-20 -6 40 12" class="lg"><path class="bus" d="M-16 0H16"/></svg>`],
    ['DPS',`<svg viewBox="-14 -2 28 40" class="lg"><g class="s">${SYM.dps}</g></svg>`],
    ['Terra',`<svg viewBox="-14 -2 28 24" class="lg">${groundAt(0,0)}</svg>`],
    ['Carga',`<svg viewBox="-14 -2 28 34" class="lg"><g class="s">${SYM.load}</g></svg>`],
    ['Motor',`<svg viewBox="-16 -2 32 36" class="lg"><g class="s">${symMotor(false)}</g></svg>`],
  ];
  return `<div class="uni-legend"><div class="uni-legend-items">${items.map(([l,svg])=>`<span>${svg}${esc(l)}</span>`).join('')}</div><p>Simbologia gráfica conforme a série IEC 60617 (ABNT NBR 12520 e NBR 12523 para condutores e dispositivos de manobra e proteção). A NBR 5444 foi cancelada e remete à IEC 60617. Confira o desenho final contra a edição vigente da norma antes de emitir o projeto.</p></div>`;
}

/* ---------------------------------------------------------------- tela do diagrama unifilar */
function uniCanvasHTML(){
  if(uniState.mode==='c')return originChipHTML()+diagram(true);
  const zoom=uniState.zoom==='fit'?1:uniState.zoom;
  return unifilarSVG(state.circuits,state.origem,{mode:uniState.mode,sel:uniState.sel,focus:uniState.focus,fit:uniState.zoom==='fit',zoom});
}
function uniInfoPanelHTML(){
  const groups=[...new Set(UNI_INFO.map(i=>i.grupo))];
  return `<details class="uni-info" id="uni-info" ${uniState.infoOpen?'open':''}><summary>Informações exibidas no diagrama <span class="tag">${uniState.sel.size} de ${UNI_INFO.length}</span></summary>
    <div class="uni-presets"><span>Atalhos:</span>${Object.entries(UNI_PRESETS).map(([k,p])=>`<button type="button" class="btn small" data-uni-preset="${k}">${p.label}</button>`).join('')}</div>
    <div class="uni-groups">${groups.map(gr=>`<fieldset><legend>${esc(gr)}</legend>${UNI_INFO.filter(i=>i.grupo===gr).map(i=>`<label><input type="checkbox" data-uni-info="${i.id}" ${uniState.sel.has(i.id)?'checked':''}> ${esc(i.label)}</label>`).join('')}</fieldset>`).join('')}</div>
    ${uniState.mode==='c'?'<p class="field-hint">No modo Cartões o conteúdo de cada cartão é fixo; as informações escolhidas valem para os modos Vertical e Horizontal.</p>':''}</details>`;
}
function uniToolbarHTML(){
  const modes=[['v','Vertical'],['h','Horizontal'],['c','Cartões']];
  const zl=uniState.zoom==='fit'?'Ajustado':Math.round(uniState.zoom*100)+'%';
  const roots=state.circuits;
  return `<div class="uni-toolbar"><div class="seg" role="group" aria-label="Visualização">${modes.map(([k,l])=>`<button type="button" data-uni-mode="${k}" class="${uniState.mode===k?'active':''}" aria-pressed="${uniState.mode===k}">${l}</button>`).join('')}</div>
    <label class="uni-focus">Mostrar a partir de <select id="uni-focus" class="input"><option value="">Toda a instalação</option>${roots.map(c=>`<option value="${esc(c.name)}" ${uniState.focus===c.name?'selected':''}>${esc(c.name)}</option>`).join('')}</select></label>
    <div class="zoom" ${uniState.mode==='c'?'hidden':''}><button type="button" class="btn small" data-uni-zoom="-1" aria-label="Diminuir">−</button><span id="uni-zoom-label">${zl}</span><button type="button" class="btn small" data-uni-zoom="1" aria-label="Aumentar">+</button><button type="button" class="btn small" data-uni-zoom="0">Ajustar à tela</button></div>
    <button type="button" class="btn small" id="uni-svg" ${uniState.mode==='c'?'hidden':''}>Baixar SVG</button></div>`;
}
function uniDownloadSVG(){
  const zoom=uniState.zoom==='fit'?1:uniState.zoom;
  const svg=unifilarSVG(state.circuits,state.origem,{mode:uniState.mode,sel:uniState.sel,focus:uniState.focus,fit:false,zoom,standalone:true});
  const blob=new Blob(['<?xml version="1.0" encoding="UTF-8"?>\n'+svg.replace(/ class="uni-svg"/,'')],{type:'image/svg+xml'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='diagrama_unifilar.svg';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),2000);
}
function uniRefreshCanvas(){
  const c=$('#uni-canvas');if(!c)return;
  c.innerHTML=uniCanvasHTML();
  c.classList.toggle('fit',uniState.zoom==='fit'&&uniState.mode!=='c');
  const tb=$('.uni-toolbar');if(tb)tb.outerHTML=uniToolbarHTML();
  const pn=$('#uni-info');if(pn)pn.outerHTML=uniInfoPanelHTML();
  uniBind();
}
function uniBind(){
  $$('[data-uni-mode]').forEach(b=>b.onclick=()=>{uniState.mode=b.dataset.uniMode;uniSave();uniRefreshCanvas();});
  $$('[data-uni-zoom]').forEach(b=>b.onclick=()=>{
    const k=Number(b.dataset.uniZoom),cur=uniState.zoom==='fit'?1:uniState.zoom;
    uniState.zoom=k===0?'fit':Math.min(2.5,Math.max(.3,Math.round((cur+(k>0?.15:-.15))*100)/100));
    uniSave();uniRefreshCanvas();
  });
  const f=$('#uni-focus');if(f)f.onchange=()=>{uniState.focus=f.value;uniRefreshCanvas();};
  $$('[data-uni-info]').forEach(cb=>cb.onchange=()=>{
    if(cb.checked)uniState.sel.add(cb.dataset.uniInfo);else uniState.sel.delete(cb.dataset.uniInfo);
    uniSave();
    const c=$('#uni-canvas');if(c)c.innerHTML=uniCanvasHTML();
    const tag=$('#uni-info .tag');if(tag)tag.textContent=`${uniState.sel.size} de ${UNI_INFO.length}`;
  });
  $$('[data-uni-preset]').forEach(b=>b.onclick=()=>{uniState.sel=new Set(UNI_PRESETS[b.dataset.uniPreset].ids);uniSave();uniRefreshCanvas();});
  const d=$('#uni-info');if(d)d.ontoggle=()=>{uniState.infoOpen=d.open;uniSave();};
  const s=$('#uni-svg');if(s)s.onclick=uniDownloadSVG;
}
function unifilarCompactHTML(){
  const ids=new Set(UNI_PRESETS.minimo.ids.concat(['esquema']));
  return `<div class="diagram-canvas uni-canvas fit">${unifilarSVG(state.circuits,state.origem,{mode:'v',sel:ids,fit:true})}</div><div class="diagram-footer"><span><i class="dot"></i>Sem alertas</span><span><i class="dot amber"></i>Pendente</span><span><i class="dot red"></i>Revisar</span><span>Clique em qualquer elemento para editar · <a href="#diagram">escolher as informações exibidas</a></span></div>`;
}
async function renderUnifilarView(main,addBtn){
  const tabs=[['diagrama','Diagrama'],['cargas','Quadro de cargas']];
  const head=heading('Diagrama unifilar','Desenho segundo a simbologia de projetos elétricos. Clique em um circuito para editar seus dados e o vínculo com o quadro a montante.',addBtn);
  const notice=state.disconnected?`<div class="notice">${state.disconnected} circuito(s) desvinculado(s). Os resultados que dependem da alimentação precisam de revisão.</div>`:'';
  const tabsHTML=`<div class="view-tabs" role="tablist">${tabs.map(([k,l])=>`<button type="button" role="tab" data-uni-tab="${k}" class="${uniState.tab===k?'active':''}" aria-selected="${uniState.tab===k}">${l}</button>`).join('')}</div>`;
  let content;
  if(uniState.tab==='cargas')content=cargasViewHTML();
  else content=`${uniToolbarHTML()}${uniInfoPanelHTML()}<section class="panel"><div class="panel-head"><div><h2>Conexões do projeto</h2><p>Reorganizado automaticamente após cada alteração</p></div><span class="tag">${state.circuits.length} circuitos</span></div><div id="uni-canvas" class="diagram-canvas uni-canvas ${uniState.zoom==='fit'&&uniState.mode!=='c'?'fit':''}">${uniCanvasHTML()}</div><div class="diagram-footer"><span><i class="dot"></i>Sem alertas</span><span><i class="dot amber"></i>Pendente</span><span><i class="dot red"></i>Revisar</span><span>Clique em qualquer elemento para editar</span></div></section>${uniLegendHTML()}<div class="notice blue">Para transferir um circuito, abra-o e altere <strong>Circuito a montante</strong>. Para desvincular, selecione “Desvinculado”. O aplicativo verifica a existência de ciclos antes de salvar.</div>`;
  main.innerHTML=head+notice+tabsHTML+content;
  $$('[data-uni-tab]').forEach(b=>b.onclick=()=>{uniState.tab=b.dataset.uniTab;renderUnifilarView(main,addBtn);});
  if(uniState.tab==='cargas')cargasBind(main,addBtn);else uniBind();
}

/* ---------------------------------------------------------------- quadro de cargas */
function cargaRows(modo){
  const rows=state.circuits.map(c=>{
    let P,Q,S;
    if(modo==='propria'){
      P=[c.p_own_r,c.p_own_s,c.p_own_t];Q=[c.q_own_r,c.q_own_s,c.q_own_t];
      S=P.map((p,i)=>isNum(p)&&isNum(Q[i])?Math.hypot(p,Q[i]):null);
    }else{P=[c.pr,c.ps,c.pt];Q=[c.q_r,c.q_s,c.q_t];S=[c.s_r,c.s_s,c.s_t];}
    const sum=a=>a.some(isNum)?a.reduce((s,v)=>s+(isNum(v)?v:0),0):null;
    const P3=sum(P),Q3=sum(Q),S3=isNum(P3)&&isNum(Q3)?Math.hypot(P3,Q3):null;
    return{c,P,Q,S,P3,Q3,S3,fp:isNum(P3)&&isNum(S3)&&S3>0?P3/S3:null};
  });
  return rows;
}
function cargasViewHTML(){
  const modo=uniState.cargaModo,rows=cargaRows(modo);
  const roots=rows.filter(r=>['Fonte','Transformador'].includes(r.c.parent));
  const tot=a=>a.some(isNum)?a.reduce((s,v)=>s+(isNum(v)?v:0),0):null;
  let footer='';
  if(modo==='total'&&roots.length){
    const P=[0,1,2].map(i=>tot(roots.map(r=>r.P[i]))),Q=[0,1,2].map(i=>tot(roots.map(r=>r.Q[i])));
    const S=P.map((p,i)=>isNum(p)&&isNum(Q[i])?Math.hypot(p,Q[i]):null);
    const P3=tot(P),Q3=tot(Q),S3=isNum(P3)&&isNum(Q3)?Math.hypot(P3,Q3):null;
    footer=`<tr class="total-row"><td colspan="2"><b>Total na origem</b></td><td class="num">—</td><td class="num">${nv(isNum(P3)&&isNum(S3)&&S3>0?P3/S3:null,3)}</td>${[P,Q,S].map((a,k)=>a.map(v=>`<td class="num">${kx(v)}</td>`).join('')+`<td class="num sum">${kx([P3,Q3,S3][k])}</td>`).join('')}<td></td></tr>`;
  }else if(modo==='propria'){
    const P=[0,1,2].map(i=>tot(rows.map(r=>r.P[i]))),Q=[0,1,2].map(i=>tot(rows.map(r=>r.Q[i])));
    const S=P.map((p,i)=>isNum(p)&&isNum(Q[i])?Math.hypot(p,Q[i]):null);
    const P3=tot(P),Q3=tot(Q),S3=isNum(P3)&&isNum(Q3)?Math.hypot(P3,Q3):null;
    footer=`<tr class="total-row"><td colspan="2"><b>Soma das cargas próprias (sem simultaneidade)</b></td><td class="num">—</td><td class="num">${nv(isNum(P3)&&isNum(S3)&&S3>0?P3/S3:null,3)}</td>${[P,Q,S].map((a,k)=>a.map(v=>`<td class="num">${kx(v)}</td>`).join('')+`<td class="num sum">${kx([P3,Q3,S3][k])}</td>`).join('')}<td></td></tr>`;
  }
  const body=rows.map(r=>`<tr class="click-row" data-edit="${esc(r.c.id)}" data-group="cargas"><td><div class="circuit-name"><span class="circuit-square">${r.c.kind==='Circuito final'?'↳':'⌘'}</span>${esc(r.c.name)}</div><span class="circuit-type">${esc(r.c.kind||'Sem classificação')}</span></td><td>${esc(r.c.parent||'Desvinculado')}</td><td class="num">${nv(r.c.fs,2)}</td><td class="num">${nv(r.fp,3)}</td>${[r.P,r.Q,r.S].map((a,k)=>a.map(v=>`<td class="num">${kx(v)}</td>`).join('')+`<td class="num sum">${kx([r.P3,r.Q3,r.S3][k])}</td>`).join('')}<td><button class="row-button" aria-label="Editar ${esc(r.c.name)}">↗</button></td></tr>`).join('');
  const grp=(t,u)=>`<th colspan="4" class="grp">${t} <small>(${u})</small></th>`;
  const ph=`<th class="num">R</th><th class="num">S</th><th class="num">T</th><th class="num sum">3F</th>`;
  return `<div class="uni-toolbar"><div class="seg" role="group" aria-label="Tipo de carga"><button type="button" data-carga-modo="total" class="${modo==='total'?'active':''}">Total (com jusante e simultaneidade)</button><button type="button" data-carga-modo="propria" class="${modo==='propria'?'active':''}">Carga própria do circuito</button></div></div>
  <section class="panel"><div class="panel-head"><div><h2>Quadro de cargas</h2><p>${modo==='total'?'Cada linha soma a carga própria e a dos circuitos a jusante, multiplicada pelo fator de simultaneidade do circuito':'Carga cadastrada em cada circuito, sem fator de simultaneidade e sem as cargas a jusante'}</p></div><span class="tag">${rows.length} circuitos</span></div>
  <div class="table-wrap"><table class="data-table cargas-table"><thead><tr><th rowspan="2">Circuito / quadro</th><th rowspan="2">Montante</th><th rowspan="2" class="num">Fs</th><th rowspan="2" class="num">fp</th>${grp('Potência ativa P','kW')}${grp('Potência reativa Q','kvar')}${grp('Potência aparente S','kVA')}<th rowspan="2"></th></tr><tr>${ph}${ph}${ph}</tr></thead><tbody>${body}${footer}</tbody></table></div>
  <div class="table-bottom"><span>Fs = fator de simultaneidade · fp = fator de potência (P/S)</span><span>S = √(P² + Q²), por fase e no total</span></div></section>`;
}
function cargasBind(main,addBtn){
  $$('[data-carga-modo]').forEach(b=>b.onclick=()=>{uniState.cargaModo=b.dataset.cargaModo;uniSave();renderUnifilarView(main,addBtn);});
}

/* ---------------------------------------------------------------- resumo dos circuitos (visão geral) */
function resumoTableHTML(){
  const cs=state.circuits;
  const num2=(v,d=2)=>isError(v)?'<span class="err" title="'+esc(v.detail||v.error)+'">—</span>':nv(v,d);
  const head1=`<tr><th rowspan="2">Circuito</th><th rowspan="2">Esquema de ligação</th><th rowspan="2">Proteção<br><small>In_Ir</small></th><th rowspan="2">Condutores</th><th rowspan="2" class="num">ΔV total<br><small>(%)</small></th><th colspan="6" class="grp">Icc (kA)</th><th colspan="2" class="grp">Corrente do circuito (A)</th><th rowspan="2" class="num">Iz do cabo<br><small>(A)</small></th><th rowspan="2">Verificação</th><th rowspan="2"></th></tr>`;
  const head2=`<tr><th class="num sub">3F máx</th><th class="num sub">2F máx</th><th class="num sub">1F máx</th><th class="num sub">3F mín</th><th class="num sub">2F mín</th><th class="num sub">1F mín</th><th class="num sub">Nominal</th><th class="num sub">Máxima (Ic)</th></tr>`;
  const rows=cs.map(c=>`<tr class="click-row" data-edit="${esc(c.id)}"><td><div class="circuit-name"><span class="circuit-square">${c.kind==='Circuito final'?'↳':'⌘'}</span>${esc(c.name)}</div><span class="circuit-type">${esc(c.kind||'Sem classificação')}</span></td>
    <td class="mono">${esc(c.esquema_ligacao||'—')}</td><td class="mono">${c.origem_ausente?'<span class="muted">sem disp. na origem</span>':esc(c.protecao_ajuste||'—')}${c.manutencao?`<small class="cell-sub">Manut. ${esc(c.manutencao.ajuste||c.manutencao.modelo||'—')}</small>`:''}</td><td class="mono">${esc(c.condutores||'—')}</td>
    <td class="num">${isNum(c.dv_total)?nv(c.dv_total,2):isError(c.dv_total)?num2(c.dv_total):`<span class="muted" title="${esc(textOf(c.dv_total))}">${esc(short(textOf(c.dv_total),12))}</span>`}</td>
    <td class="num">${num2(c.icc3f_max,2)}</td><td class="num">${num2(c.icc2f_max,2)}</td><td class="num">${num2(c.icc1f_max,2)}</td><td class="num">${num2(c.icc3f_min,2)}</td><td class="num">${num2(c.icc2f_min,2)}</td><td class="num">${num2(c.icc1f_min,2)}</td>
    <td class="num">${num2(c.ib,1)}</td><td class="num">${num2(c.ic,1)}</td><td class="num">${num2(c.iz,1)}</td>
    <td>${badge(c.status)}</td><td><button class="row-button" aria-label="Editar ${esc(c.name)}">↗</button></td></tr>`).join('')||'<tr><td colspan="16" class="empty">Nenhum circuito cadastrado.</td></tr>';
  return `<div class="table-wrap"><table class="data-table resumo-table"><thead>${head1}${head2}</thead><tbody>${rows}</tbody></table></div>`;
}

/* ---------------------------------------------------------------- abas de informações no formulário do circuito */
let drawerTab=null;
function infoValueHTML(it){
  const v=it.value;
  if(isError(v))return `<span class="err" title="${esc(v.detail||v.error)}">${esc(v.error)}</span>`;
  if(typeof v==='number')return esc(nf(v,it.digits==null?2:it.digits))+(it.unit?` <small>${esc(it.unit)}</small>`:'');
  if(typeof v==='boolean')return v?'Sim':'Não';
  if(v===null||v===undefined||v==='')return '<span class="muted">—</span>';
  return esc(String(v))+(it.unit?` <small>${esc(it.unit)}</small>`:'');
}
function infoSectionHTML(sec){
  if(sec.matrix){
    const m=sec.matrix;
    return `<div class="info-card wide"><h4>${esc(sec.title)}</h4><table class="data-table compact info-matrix"><thead><tr><th></th>${m.columns.map(c=>`<th class="num">${esc(c)}</th>`).join('')}<th>un.</th></tr></thead><tbody>${m.rows.map(r=>`<tr><td>${esc(r.label)}</td>${r.values.map(v=>`<td class="num">${isNum(v)?esc(nf(v,r.digits==null?2:r.digits)):'<span class="muted">—</span>'}</td>`).join('')}<td class="unit">${esc(r.unit)}</td></tr>`).join('')}</tbody></table></div>`;
  }
  if(sec.alerts){
    return `<div class="info-card wide norm-alerts"><h4>${esc(sec.title)}</h4><ul class="norm-alert-list">${sec.alerts.map(a=>`<li class="norm-alert ${esc(a.nivel)}"><span class="norm-ref">${esc(a.ref)}</span>${esc(a.texto)}</li>`).join('')}</ul></div>`;
  }
  return `<div class="info-card"><h4>${esc(sec.title)}</h4><dl class="info-list">${sec.items.map(it=>`<div class="info-row"><dt>${esc(it.label)}${it.note?`<small>${esc(it.note)}</small>`:''}</dt><dd>${infoValueHTML(it)}${it.sheet?`<button type="button" class="trace-btn mini" data-cell="${esc(it.address)}" data-sheet="${esc(it.sheet)}" title="Ver cálculo" aria-label="Ver cálculo de ${esc(it.label)}">🔍</button>`:''}</dd></div>`).join('')}</dl></div>`;
}
function drawerTabsHTML(info,sectionMap,group){
  if(!info.length)return Object.values(sectionMap).join('');
  let active=null;
  if(group)active=(info.find(t=>t.groups.includes(group))||{}).key||null;
  if(!active&&drawerTab&&info.some(t=>t.key===drawerTab))active=drawerTab;
  if(!active)active=info[0].key;
  drawerTab=active;
  const nav=`<div class="dtabs" role="tablist" aria-label="Subgrupos do circuito">${info.map(t=>`<button type="button" role="tab" class="dtab ${t.key===active?'active':''}" data-dtab="${t.key}" aria-selected="${t.key===active}">${esc(t.label)}</button>`).join('')}</div>`;
  const panes=info.map(t=>`<section class="dpane" data-dpane="${t.key}" ${t.key===active?'':'hidden'}>${['protecoes','dps','motores','cargas'].includes(t.key)?`${t.groups.map(g=>sectionMap[g]||'').join('')}<details class="guided-more"><summary>Resultados detalhados</summary><div class="info-grid">${t.sections.map(infoSectionHTML).join('')}</div></details>`:`<div class="info-grid">${t.sections.map(infoSectionHTML).join('')}</div>${t.groups.map(g=>sectionMap[g]||'').join('')}`}${t.groups.length?'':'<p class="field-hint">Resultados calculados — somente leitura. Para alterar, edite a instalação, os condutores ou a proteção nas outras abas.</p>'}</section>`).join('');
  // grupos que não pertencem a nenhuma aba continuam acessíveis no fim
  const used=new Set(info.flatMap(t=>t.groups));
  const rest=Object.keys(sectionMap).filter(k=>!used.has(k)).map(k=>sectionMap[k]).join('');
  return nav+panes+rest;
}
function switchDrawerTab(key){
  drawerTab=key;
  $$('.dtab').forEach(b=>{const on=b.dataset.dtab===key;b.classList.toggle('active',on);b.setAttribute('aria-selected',on);});
  $$('.dpane').forEach(p=>{p.hidden=p.dataset.dpane!==key;});
  const tabs=$('.dtabs');if(tabs)tabs.scrollIntoView({block:'start'});
}
document.addEventListener('click',e=>{const b=e.target.closest('[data-dtab]');if(b)switchDrawerTab(b.dataset.dtab);});

/* Agrupamento e neutro: agrupamento.js. */

'use strict';
/* v1.10 — Dispositivos do trecho: dispositivo na origem opcional, disjuntor de manutenção na
 * extremidade (jusante) e DPS opcional por quadro. Os cálculos e as verificações pertencem ao
 * servidor (core/trecho.py); aqui ficam a montagem da tela, a cascata de catálogo do disjuntor de
 * manutenção e a atualização da prévia. Usa as funções globais de app.js, workflow.js, protecao.js
 * e projeto.js. */
const TRECHO_SHEET='Dispositivos_Trecho';
const MB_CLASSES=['fixo','termomagnetico','eletronico'];
const MB_KEYS=['mb_familia','mb_modelo','mb_ir','mb_ii','mb_isd','mb_tsd'];
let mbClasseEscolhida=null, mbModeloAnterior=null;

function tIdx(key){return drawerData?.fields?.findIndex(f=>f.trecho_key===key)??-1;}
function tEl(key){const i=tIdx(key);return i<0?null:document.getElementById('field-'+i);}
function tWrap(key){return tEl(key)?.closest('.field')||null;}
function tVal(key){const i=tIdx(key);return i<0?null:liveValue(i,'field-');}
function tField(g,data,key){const f=g.fields.find(x=>x.trecho_key===key);return f?fieldHTML(f,'field-'+data.fields.indexOf(f)):'';}
function tSet(key,value){
  const el=tEl(key);if(!el)return;const v=value===null||value===undefined?'':String(value);
  if(el.tagName==='SELECT'){if(v!==''&&![...el.options].some(o=>o.value===v))el.add(new Option(v,v));el.value=v;
    if(el.dataset.hasCustom){const c=document.getElementById(el.id+'-custom');if(c)c.hidden=true;}}
  else el.value=v.replace('.',',');
}
function trechoDirty(){dirty=true;const b=document.getElementById('save-circuit');if(b)b.textContent='Salvar alterações';}
const trechoSemOrigem=()=>String(tVal('origem')||'').startsWith('NÃO');
const trechoComMB=()=>tVal('manut')==='SIM';
function trechoState(data){return (data?.groups?.find(g=>g.key==='trecho')||{}).trecho||{};}

/* ---------------------------------------------------------------- esquema do trecho */
function trechoSchemeSVG(origem,mb,nome){
  const y=34,x0=34,x1=486;
  const style='<style>.tsx{stroke:#1c2b36;stroke-width:1.4;fill:none;stroke-linecap:round;stroke-linejoin:round}.tsx circle,.tsx rect{fill:#fff}.tsb{stroke:#1c2b36;stroke-width:4.5;stroke-linecap:round}.tst{font:10px Arial,Helvetica,sans-serif;fill:#1c2b36}.tsg{font:9px Arial,Helvetica,sans-serif;fill:#6c7d86}.tsa{font:italic 9px Arial,Helvetica,sans-serif;fill:#b0702a}</style>';
  const brk=x=>`<g class="tsx" transform="translate(${x},${y}) rotate(-90)">${SYM.breaker}</g>`;
  let g=`<line class="tsb" x1="${x0}" y1="${y-16}" x2="${x0}" y2="${y+16}"/><text class="tsg" x="${x0}" y="${y+30}" text-anchor="middle">montante</text>`;
  if(origem)g+=`<line class="tsx" x1="${x0}" y1="${y}" x2="${x0+18}" y2="${y}"/>`+brk(x0+18)+`<text class="tsg" x="${x0+36}" y="${y-14}" text-anchor="middle">origem</text>`;
  else g+=`<text class="tsa" x="${x0+9}" y="${y+15}">sem dispositivo</text>`;
  const cEnd=mb?x1-58:x1;
  g+=`<line class="tsx" x1="${origem?x0+54:x0}" y1="${y}" x2="${cEnd}" y2="${y}"/>`;
  const mid=(x0+54+cEnd)/2;
  g+=`<path class="tsx" d="M${mid-6} ${y+4.5}L${mid-1} ${y-4.5}M${mid-1} ${y+4.5}L${mid+4} ${y-4.5}M${mid+4} ${y+4.5}L${mid+9} ${y-4.5}"/><text class="tsg" x="${mid}" y="${y+18}" text-anchor="middle">cabo do circuito</text>`;
  if(mb)g+=brk(x1-58)+`<line class="tsx" x1="${x1-22}" y1="${y}" x2="${x1}" y2="${y}"/><text class="tsg" x="${x1-40}" y="${y-14}" text-anchor="middle">manutenção</text>`;
  g+=`<line class="tsb" x1="${x1}" y1="${y-16}" x2="${x1}" y2="${y+16}"/><text class="tst" x="${x1}" y="${y+30}" text-anchor="middle">${esc(short(nome||'quadro',26))}</text>`;
  if(!origem)g+=`<text class="tsa" x="${x0+8}" y="${y-10}">falta no cabo: proteção a montante</text>`;
  return `<svg viewBox="0 0 520 70" role="img" aria-label="Esquema dos dispositivos do trecho">${style}${g}</svg>`;
}

/* ---------------------------------------------------------------- textos de situação */
function trechoStatusRows(rows,st){
  return rows.map(([label,value,key])=>{
    const t=st.enderecos?.[key];
    return `<div class="ts-row"><div class="ts-head"><span>${esc(label)}</span>${statusChip(value)}${t?`<button type="button" class="trace-btn mini" data-cell="${esc(t.address)}" data-sheet="${esc(t.sheet)}" title="Ver cálculo" aria-label="Ver cálculo de ${esc(label)}">🔍</button>`:''}</div><p>${esc(issueText(value))}</p></div>`;
  }).join('');
}
function trechoOrigemStatusHTML(st){
  if(!st.sem_origem)return '<p class="field-note">Salve ou atualize a prévia para ver as verificações do trecho sem dispositivo na origem.</p>';
  return `<div class="trecho-status">${trechoStatusRows([['Curto-circuito',st.status?.curto,'trecho_curto'],['Sobrecarga',st.status?.sobrecarga,'trecho_sobrecarga'],['Seccionamento automático',st.status?.choque,'trecho_choque']],st)}</div>`;
}
function mbStatusHTML(st){
  const mb=st.mb;if(!mb)return '';
  const v=(x,d=0,u='')=>typeof x==='number'?num(x,d)+(u?' '+u:''):esc(textOf(x));
  const t=st.enderecos?.mb_status;
  return `<div class="guided-result mb-result"><div class="mb-result-head"><h4>${esc(mb.modelo||'Modelo a definir')}</h4>${statusChip(mb.status)}${t?`<button type="button" class="trace-btn mini" data-cell="${esc(t.address)}" data-sheet="${esc(t.sheet)}" title="Ver cálculo" aria-label="Ver cálculo do status">🔍</button>`:''}</div>
    <p class="field-note">${esc(issueText(mb.status))}</p>
    <div class="guided-values"><div><span>In</span><b>${v(mb.in,0,'A')}</b></div><div><span>Ir</span><b>${v(mb.ir,0,'A')}</b></div><div><span>Ii/Im</span><b>${v(mb.ii,0,'A')}</b></div><div><span>Icu / Ik no ponto</span><b>${v(mb.icu,1)} / ${v(mb.ik_max,2)} kA</b></div></div>
    <div class="trecho-status">${trechoStatusRows([['Falta no quadro',mb.tn,'mb_tn']].concat(st.sem_origem?[]:[['Origem × manutenção',mb.x_origem,'mb_x_origem']]),st)}</div>
    <p class="field-note">${st.sem_origem?'Sem dispositivo na origem: este disjuntor protege o cabo contra sobrecarga (Ib ≤ Ir ≤ Iz). Faltas no próprio cabo continuam a cargo da proteção a montante.':'O dispositivo da origem protege o cabo; este disjuntor precisa conduzir Ib, suportar o Ik no ponto e eliminar as faltas no quadro.'}</p></div>`;
}

/* ---------------------------------------------------------------- grupo do formulário */
function trechoGroupHTML(g,data){
  const st=g.trecho||{},f=k=>tField(g,data,k);
  return `<div class="trecho">
    <p class="field-note">Indique onde ficam os dispositivos deste circuito. Use <b>Sem dispositivo próprio</b> em trechos como transformador → quadro ou padrão de entrada → medição, e o <b>disjuntor de manutenção</b> para o disjuntor instalado na chegada do quadro.</p>
    ${(g.ajustes_problemas||[]).length?`<div class="cascade-aviso ajustes-aviso" role="alert"><b>Ajustes do disjuntor de manutenção fora do catálogo.</b><ul>${g.ajustes_problemas.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>`:''}
    <div class="trecho-scheme" id="trecho-scheme">${trechoSchemeSVG(!st.sem_origem,!!st.tem_mb,data.name)}</div>
    <div class="trecho-grid">
      <section class="trecho-card" id="trecho-card-origem"><h4>Na origem <small>(montante)</small></h4>
        <div class="seg trecho-seg" role="group" aria-label="Dispositivo na origem"><button type="button" data-trecho-origem="SIM">Disjuntor ou fusível</button><button type="button" data-trecho-origem="NÃO">Sem dispositivo próprio</button></div>
        <div class="trecho-hidden">${f('origem')}</div>
        <p class="field-note" id="trecho-com-origem">O dispositivo da origem é escolhido logo abaixo, em “Dispositivo na origem”.</p>
        <div id="trecho-sem-origem"><div class="fields">${f('justificativa')}${f('condicoes')}${f('tempo_montante')}${f('desc_montante')}</div><div id="trecho-origem-status"></div></div>
      </section>
      <section class="trecho-card" id="trecho-card-mb"><h4>Na extremidade <small>(jusante)</small></h4>
        <div class="seg trecho-seg" role="group" aria-label="Disjuntor de manutenção"><button type="button" data-trecho-mb="NÃO">Nenhum</button><button type="button" data-trecho-mb="SIM">Disjuntor de manutenção</button></div>
        <div class="trecho-hidden">${f('manut')}</div>
        <p class="field-note" id="trecho-sem-mb">Sem disjuntor na chegada do quadro.</p>
        <div id="trecho-mb">${choiceModeHTML(data,'manutencao','Escolha do disjuntor de manutenção')}
          <div id="mb-auto-result"></div>
          <div id="mb-manual"><div id="mb-quick"></div><div class="cascade-label">Classe do dispositivo</div><div id="mb-classes"></div>
            <div class="fields">${f('mb_familia')}${f('mb_modelo')}${f('mb_ir')}${f('mb_ii')}${f('mb_isd')}${f('mb_tsd')}</div><div class="field-note" id="mb-faixa"></div></div>
          <div id="mb-status"></div>
        </div>
      </section>
    </div></div>`;
}

/* ---------------------------------------------------------------- disjuntor de manutenção: catálogo */
function mbModels(){return (protecaoCatalog||[]).filter(m=>!m.somente_magnetico);}
function mbClasseAtual(){if(mbClasseEscolhida)return mbClasseEscolhida;const m=protecaoCatalogByModelo?.[tVal('mb_modelo')];return m?m.subclasse:null;}
function mbIb(){return protNum(state?.circuits?.find(c=>c.id===drawerData?.id)?.ib);}
function mbDefaults(modelo){
  const cand=(drawerData?.workflow?.maintenance?.items||[]).find(x=>x.modelo===modelo.modelo);
  if(cand)return cand.ajustes;
  const n=x=>typeof x==='number'?x:null,ib=mbIb(),ia=modelo.ir_ajuste||{},ma=modelo.im_ajuste||{};
  const lo=n(modelo.ir_min),hi=n(modelo.ir_max);let y=null;
  if(ia.tipo==='discreto'&&ia.valores?.length){const v=[...ia.valores].sort((a,b)=>a-b);y=v.find(x=>ib==null||x>=ib)??v[v.length-1];}
  else if(lo!=null&&hi!=null){const alvo=ib!=null?Math.ceil(ib):lo;y=Math.min(Math.max(alvo,lo),hi);}
  else if(modelo.in_nominal!=null)y=modelo.in_nominal;
  const first=()=>ma.tipo==='discreto'&&ma.valores?.length?Math.min(...ma.valores):ma.tipo==='discreto_ir'&&y!=null&&ma.mult_ir?.length?Math.round(Math.min(...ma.mult_ir)*y*100)/100:n(modelo.im_min);
  const eletro=modelo.subclasse==='eletronico';
  return {mb_ir:y,mb_ii:eletro?modelo.ii_fixo:first(),mb_isd:eletro?first():null,mb_tsd:eletro?100:null};
}
function mbTsdOptions(){
  const f=drawerData?.fields?.find(x=>x.sheet==='Cálc-Prot_Cabos'&&/^BZ\d/.test(x.address));
  const list=(f?.options||[]).map(Number).filter(Number.isFinite);
  return list.length?list:[50,100,200,300,400];
}
function mbRefresh(){
  if(!document.getElementById('mb-classes')||!protecaoCatalog)return;
  const classe=mbClasseAtual();
  $('#mb-classes').innerHTML=`<div class="method-gallery clickable prot-3">${MB_CLASSES.map(c=>`<button type="button" class="method-tile protecao-classe-tile ${c===classe?'active':''}" data-mb-classe="${c}" aria-pressed="${c===classe}">${PROTECAO_CLASSE_ICONS[c]}<span>${PROTECAO_CLASSE_LABEL[c]}</span></button>`).join('')}</div>`;
  $$('[data-mb-classe]').forEach(b=>b.onclick=()=>{
    const nova=b.dataset.mbClasse;if(nova===mbClasseAtual())return;mbClasseEscolhida=nova;
    const ok=new Set(mbModels().filter(m=>m.subclasse===nova).map(m=>m.familia));
    if(tVal('mb_familia')&&!ok.has(tVal('mb_familia'))){tSet('mb_familia','');tSet('mb_modelo','');}
    else{const m=protecaoCatalogByModelo[tVal('mb_modelo')];if(m&&m.subclasse!==nova)tSet('mb_modelo','');}
    trechoDirty();mbRefresh();queueWorkflow(drawerData);
  });
  const famEl=protAsSelect(tEl('mb_familia'),false);
  if(famEl){const cur=famEl.value;const fams=classe?[...new Set(mbModels().filter(m=>m.subclasse===classe).map(m=>m.familia))].sort():[];
    protFillSelect(famEl,fams,classe?'Selecione a família':'Escolha primeiro a classe',cur);famEl.disabled=!classe;}
  const fam=famEl&&famEl.value?famEl.value:null;
  const modEl=protAsSelect(tEl('mb_modelo'),false);
  if(modEl){let cur=modEl.value;const mi=cur?protecaoCatalogByModelo[cur]:null;if(mi&&(mi.familia!==fam||mi.subclasse!==classe))cur='';
    const mods=fam?mbModels().filter(m=>m.familia===fam&&m.subclasse===classe).map(m=>m.modelo):[];
    protFillSelect(modEl,mods,fam?'Selecione o modelo':'Escolha primeiro a família',cur);modEl.disabled=!fam;}
  const modelo=modEl&&modEl.value?protecaoCatalogByModelo[modEl.value]:null;
  // Troca de modelo: ajustes válidos do novo modelo.
  const atual=modelo?modelo.modelo:null;
  if(mbModeloAnterior&&mbModeloAnterior.id===drawerData.id&&atual&&atual!==mbModeloAnterior.modelo){
    const d=mbDefaults(modelo);for(const k of ['mb_ir','mb_ii','mb_isd','mb_tsd'])tSet(k,d[k]);
  }
  mbModeloAnterior={id:drawerData.id,modelo:atual};
  const show=(k,on)=>{const w=tWrap(k);if(w)w.hidden=!on;};
  const eletro=modelo?.subclasse==='eletronico',fixo=modelo?.subclasse==='fixo';
  show('mb_ir',!!modelo);show('mb_ii',!!modelo&&!fixo);show('mb_isd',eletro);show('mb_tsd',eletro);
  const faixa=[];
  if(modelo){
    // Ir
    const ia=modelo.ir_ajuste||{tipo:'faixa',valores:[]};
    if(fixo&&modelo.in_nominal!=null){const y=protAsSelect(tEl('mb_ir'),true);protFillSelect(y,[modelo.in_nominal],'—',modelo.in_nominal);y.value=String(modelo.in_nominal);y.disabled=true;protHint(y,`Disjuntor fixo: Ir = In = ${modelo.in_nominal} A.`);}
    else if(ia.tipo==='discreto'&&ia.valores.length){const y=protAsSelect(tEl('mb_ir'),true);y.disabled=false;protFillSelect(y,ia.valores,'Selecione o ajuste',y.value);protHint(y,`Posições do dial: ${ia.valores.join(' · ')} A.`);}
    else{const y=protAsInput(tEl('mb_ir'));y.disabled=false;protHint(y,modelo.ir_min!=null?`Ajuste permitido: ${modelo.ir_min} a ${modelo.ir_max} A.`:'');}
    if(modelo.ir_min!=null)faixa.push(`Ir ${modelo.ir_min}–${modelo.ir_max} A`);
    if(fixo){tSet('mb_ii',modelo.im_min);faixa.push(`banda magnética ${modelo.im_min}–${modelo.im_max} A`);}
    const yv=protNum(tEl('mb_ir')?.value);
    const lista=a=>a.tipo==='discreto'&&a.valores.length?a.valores:a.tipo==='discreto_ir'&&yv!=null?a.mult_ir.map(m=>Math.round(m*yv*100)/100):null;
    const ma=modelo.im_ajuste||{tipo:'faixa',valores:[]};
    if(eletro){
      if(modelo.ii_fixo!=null){const z=protAsSelect(tEl('mb_ii'),true);protFillSelect(z,[modelo.ii_fixo],'—',modelo.ii_fixo);z.value=String(modelo.ii_fixo);z.disabled=true;protHint(z,`Ii fixo do modelo: ${modelo.ii_fixo} A.`);}
      else{const z=protAsInput(tEl('mb_ii'));z.disabled=false;protHint(z,'Ii instantâneo: confira o catálogo do relé.');}
      const vals=lista(ma);
      if(vals){const s=protAsSelect(tEl('mb_isd'),true);protFillSelect(s,vals,'Selecione o ajuste',vals.map(String).includes(String(s.value))?s.value:'');protHint(s,`Posições de Isd: ${vals.join(' · ')} A.`);}
      else{const s=protAsInput(tEl('mb_isd'));protHint(s,modelo.im_min!=null?`Faixa do catálogo: ${modelo.im_min} a ${modelo.im_max} A.`:'');}
      const t=protAsSelect(tEl('mb_tsd'),true);protFillSelect(t,mbTsdOptions(),'Selecione',t.value);
      if(modelo.im_min!=null)faixa.push(`Isd ${modelo.im_min}–${modelo.im_max} A`);
    }else if(!fixo){
      const vals=lista(ma);
      if(vals){const z=protAsSelect(tEl('mb_ii'),true);z.disabled=false;protFillSelect(z,vals,'Selecione o ajuste',vals.map(String).includes(String(z.value))?z.value:'');protHint(z,`Posições do dial: ${vals.join(' · ')} A.`);}
      else{const z=protAsInput(tEl('mb_ii'));z.disabled=false;protHint(z,modelo.im_min!=null?`Faixa do catálogo: ${modelo.im_min} a ${modelo.im_max} A.`:'');}
      if(modelo.im_min!=null)faixa.push(`Im ${modelo.im_min}–${modelo.im_max} A`);
    }
  }
  const box=$('#mb-faixa');if(box){box.textContent=modelo?`${modelo.modelo} · In ${modelo.in_nominal??'—'} A · Icu ${modelo.icu??'—'} · ${faixa.join(' · ')}`:'Escolha classe, família e modelo — ou use a escolha rápida acima.';}
}
function mbQuickHTML(data){
  const box=document.getElementById('mb-quick');if(!box)return;
  const items=data.workflow?.maintenance?.items||[];
  box.innerHTML=`<div class="field"><label for="mb-quick-select">Escolha rápida — modelos compatíveis com os dados atuais</label><select id="mb-quick-select"><option value="">${items.length?'Escolher um modelo…':'Nenhum candidato; revise os dados ou use o catálogo abaixo.'}</option>${items.slice(0,40).map(x=>`<option value="${esc(x.modelo)}">${esc(x.modelo)} · Ir ${num(x.ir,0)} A · Icu ${num(x.icu,0)} kA · ${esc(x.poles)}</option>`).join('')}</select></div>`;
  const sel=document.getElementById('mb-quick-select');
  sel.value=items.some(x=>x.modelo===tVal('mb_modelo'))?tVal('mb_modelo'):'';
  sel.onchange=e=>{const p=items.find(x=>x.modelo===e.target.value);if(!p)return;mbClasseEscolhida=p.classe;
    tSet('mb_familia',p.familia);tSet('mb_modelo',p.modelo);mbModeloAnterior={id:drawerData.id,modelo:p.modelo};
    for(const [k,v] of Object.entries(p.ajustes))tSet(k,v);mbRefresh();trechoDirty();queueWorkflow(data);};
}
function mbAutoHTML(data){
  const box=document.getElementById('mb-auto-result');if(!box)return;
  const w=data.workflow?.maintenance||{},best=(w.items||[])[0],msg=data.workflow?.results?.manutencao;
  // Com um modelo já escolhido, o cartão de situação abaixo mostra modelo e valores; aqui fica só o motivo.
  if(best&&trechoState(data).mb?.modelo===best.modelo){box.innerHTML=`<p class="field-note mb-auto-note">Escolha automática: ${esc(msg||'modelo e ajustes selecionados pelos dados atuais.')}</p>`;return;}
  box.innerHTML=`<div class="guided-result"><h4>${best?esc(best.modelo):'Seleção automática pendente'}</h4><p>${esc(w.reason||msg||'O aplicativo escolhe o disjuntor pela corrente de projeto'+(w.protege_cabo?', pela capacidade do cabo':'')+', pela partida e pelo Ik no ponto de instalação.')}</p>${best?`<div class="guided-values"><div><span>Ir</span><b>${num(best.ir,0)} A</b></div><div><span>Icu</span><b>${num(best.icu,0)} kA</b></div><div><span>Polos</span><b>${esc(best.poles)}</b></div></div>`:''}</div>`;
}

/* ---------------------------------------------------------------- estado visível */
function trechoApply(data=drawerData){
  if(!data||!document.getElementById('trecho-card-origem'))return;
  const semO=trechoSemOrigem(),mb=trechoComMB(),st=trechoState(data);
  $$('[data-trecho-origem]').forEach(b=>{const on=(b.dataset.trechoOrigem==='NÃO')===semO;b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on));});
  $$('[data-trecho-mb]').forEach(b=>{const on=(b.dataset.trechoMb==='SIM')===mb;b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on));});
  $('#trecho-sem-origem').hidden=!semO;$('#trecho-com-origem').hidden=semO;
  $('#trecho-mb').hidden=!mb;$('#trecho-sem-mb').hidden=mb;
  const auto=workflowMode('manutencao')==='Automático';
  $('#mb-manual').hidden=auto;$('#mb-auto-result').hidden=!auto;
  const sc=$('#trecho-scheme');if(sc)sc.innerHTML=trechoSchemeSVG(!semO,mb,data.name);
  // O disjuntor da origem não participa do cálculo quando não há dispositivo próprio.
  const body=document.getElementById('prot-origem-conteudo'),aviso=document.getElementById('prot-sem-origem-aviso');
  if(body)body.hidden=semO;if(aviso)aviso.hidden=!semO;
  const os=$('#trecho-origem-status');if(os)os.innerHTML=st.sem_origem===semO?trechoOrigemStatusHTML(st):'<p class="field-note">Atualizando a prévia…</p>';
  const ms=$('#mb-status');if(ms)ms.innerHTML=mb&&st.tem_mb?mbStatusHTML(st):'';
  if(typeof integratedRefresh==='function')integratedRefresh(data);
  mbAutoHTML(data);
  if(!auto){mbQuickHTML(data);mbRefresh();}
}
function initTrecho(data){
  mbClasseEscolhida=null;mbModeloAnterior=null;
  if(!document.getElementById('trecho-card-origem'))return;
  $$('[data-trecho-origem]').forEach(b=>b.onclick=()=>{
    const want=b.dataset.trechoOrigem==='NÃO';if(want===trechoSemOrigem())return;
    tSet('origem',want?'NÃO — sem dispositivo próprio':'');trechoDirty();trechoApply(data);queueWorkflow(data);
  });
  $$('[data-trecho-mb]').forEach(b=>b.onclick=()=>{
    const want=b.dataset.trechoMb==='SIM';if(want===trechoComMB())return;
    tSet('manut',want?'SIM':'');trechoDirty();trechoApply(data);queueWorkflow(data);
  });
  $('#drawer').addEventListener('change',e=>{
    if(drawerData!==data)return;
    const i=indexFromElId(e.target.id,'field-');const f=i>=0?data.fields[i]:null;
    if(f&&['mb_familia','mb_modelo','mb_ir'].includes(f.trecho_key))mbRefresh();
  });
  trechoApply(data);
}

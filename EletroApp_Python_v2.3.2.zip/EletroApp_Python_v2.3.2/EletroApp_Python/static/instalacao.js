/* A matriz do servidor alimenta escolhas, imagens e tabelas de consulta. */
const normalizeInstallation=value=>String(value??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim().replace(/\s+/g,' ');
let installationTablesCache=null;
function installationOptionLabels(key,result){
  if(key!=='method')return {};
  const row=installationTablesCache?.lines.find(x=>normalizeInstallation(x.name)===normalizeInstallation(result.values.line));
  const variants=row?.variants||(methodCatalog||[]).filter(m=>(result.options.method||[]).some(x=>String(x)===String(m.method))).flatMap(m=>m.tipos.map(cable=>({method:m.method,reference:m.letra,cable})));const labels={};
  for(const v of variants){const number=String(v.method).split('_')[0];const label=`${number} · ${v.reference} · ${v.cable}`;labels[v.method]=(labels[v.method]?labels[v.method]+' / ':'')+label;}
  return labels;
}
function setInstallationValue(fields,sheet,col,value){
  const i=fields.findIndex(f=>f.sheet===sheet&&/^[A-Z]+/.exec(f.address)?.[0]===col);
  if(i<0)return;
  const el=document.getElementById('field-'+i);if(!el)return;
  if(el.tagName==='SELECT'&&value!=null&&![...el.options].some(o=>o.value===String(value)))el.add(new Option(String(value),String(value)));
  el.value=value??'';
}
function renderInstallationChoices(fields){
  const idx=(sh,c)=>fields.findIndex(f=>f.sheet===sh&&/^[A-Z]+/.exec(f.address)?.[0]===c);
  const sh='Identificação-Método_Instal ',bi=idx(sh,'B'),ci=idx(sh,'C'),hi=idx(sh,'H');
  const line=liveValue(idx('Maneira de instalar','B'),'field-');
  const code=computeMetodoCodigo(liveValue(bi,'field-'),liveValue(ci,'field-'));
  const wrap=$('#metodo-cascade');if(wrap)wrap.outerHTML=metodoCascadeHTML(line,code);
  const inst=drawerData?.installation;
  // Sempre existe um ponto de montagem, inclusive quando se entra em F/G após abrir o formulário.
  let adjustment=$('#ajuste-cascade');
  if(!adjustment&&$('#metodo-cascade')){adjustment=document.createElement('div');adjustment.id='ajuste-cascade';$('#metodo-cascade').after(adjustment);}
  const options=inst?.options?.adjustment||[];
  const choices=options.filter(x=>x!=='N/A');
  if(adjustment)adjustment.outerHTML=ajusteGalleryHTML(choices,liveValue(hi,'field-'));
  if(hi>=0)document.getElementById('field-'+hi)?.closest('.field').setAttribute('hidden','');
  const changed=()=>{dirty=true;$('#save-circuit').textContent='Salvar alterações';refreshCascade(fields,true);if(window.queueWorkflow)queueWorkflow(drawerData);};
  $$('.method-tile[data-codigo]').forEach(tile=>tile.onclick=()=>{
    const allowed=linhasMetodoMapa?.[normalizeInstallation(line)]?.codigos_imagem||[];
    if(!allowed.includes(tile.dataset.codigo))return;
    const model=methodCatalogByCode[tile.dataset.codigo];
    setInstallationValue(fields,sh,'B',model.method);
    const types=model.tipos.filter(t=>(linhasMetodoMapa[normalizeInstallation(line)].cabos||[]).includes(t));
    if(types.length===1)setInstallationValue(fields,sh,'C',types[0]);
    changed();
  });
  $$('.ajuste-tile[data-ajuste]').forEach(tile=>tile.onclick=()=>{setInstallationValue(fields,sh,'H',tile.dataset.ajuste);changed();});
  const browse=$('#browse-methods');if(browse)browse.onclick=showInstallationTables;
}
function renderInstallationGeometry(inst){
  const det=$('#group-metodo');if(!det)return;
  let box=$('#installation-geometry');if(!box){box=document.createElement('div');box.id='installation-geometry';box.className='info-card wide';det.appendChild(box);}
  const g=inst.geometry;box.hidden=!g?.required;if(!g?.required){box.innerHTML='';return;}
  const settings=inst.settings||{};
  box.innerHTML=`<h4>Condições físicas desta instalação</h4><ul>${g.criteria.map(x=>`<li>${esc(x)}</li>`).join('')}</ul><p class="field-hint">${esc(g.basis)}</p><div class="field"><label for="geometry-mode">Como verificar?</label><select id="geometry-mode"><option value="">Ainda não confirmado</option><option value="confirmed">Confirmo que as condições acima são atendidas</option><option value="dimensions">Informar medidas e confirmar as demais condições</option></select></div><div class="fields geometry-dimensions" ${g.mode==='dimensions'?'':'hidden'}>${g.fields.map(f=>`<div class="field"><label for="geometry-${f.key}">${esc(f.label)} ${esc(f.unit)}</label><input id="geometry-${f.key}" inputmode="decimal" ${f.key==='space_ratio'?'list="geometry-ratios"':''} value="${esc(settings[f.key]??'')}"></div>`).join('')}</div><datalist id="geometry-ratios">${[1.5,2,3,4,5,10,15,20,30,50,100,500].map(n=>`<option value="${n}"></option>`).join('')}</datalist><p class="field-hint">A troca de montagem, cabo, isolação ou disposição exige nova conferência destas condições.</p>`;
  $('#geometry-mode').value=g.mode||'';
  const update=(key,value)=>{
    const current=drawerData.installation;
    current.settings={...current.settings,[key]:value,geometry_signature:g.signature};
    groupingDirty=true;dirty=true;$('#save-circuit').textContent='Salvar alterações';
    refreshInstallationPreview(drawerData.fields);if(window.queueWorkflow)queueWorkflow(drawerData);
  };
  $('#geometry-mode').onchange=e=>update('geometry_mode',e.target.value);
  for(const f of g.fields){const el=$('#geometry-'+f.key);el.onchange=()=>{const value=el.value.trim().replace(',','.');if(value!==''&&!Number.isFinite(Number(value))){toast('Informe uma medida válida.',true);return;}update(f.key,value===''?null:Number(value));};}
}
async function loadInstallationTables(){if(!installationTablesCache)installationTablesCache=await api('/api/installation/catalog');return installationTablesCache;}
function installationTablesHTML(data){
 return `<div class="installation-reference"><p>Leia cada célula como <b>número da instalação → método de referência</b>. “—” indica combinação não incluída nesta matriz.</p><div class="notice blue">${esc(data.note)}</div><div class="toolbar reference-filters"><label>Pesquisar instalação ou número<input data-install-search placeholder="Ex.: parede isolante, 22, bandeja"></label><label>Método de referência<select data-install-filter><option value="">Todos</option>${['A1','A2','B1','B2','C','D','E','F','G'].map(x=>`<option>${x}</option>`).join('')}</select></label><span data-install-count></span></div><div class="table-wrap"><table class="data-table installation-matrix"><thead><tr><th>Tipo de instalação e condição</th><th>Condutor isolado</th><th>Cabo unipolar</th><th>Cabo multipolar</th></tr></thead><tbody data-install-rows></tbody></table></div>${groupingTablesHTML(data.grouping)}<h3>Disposição dos condutores</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>Referência</th><th>Condutores carregados</th><th>Disposições disponíveis</th></tr></thead><tbody>${data.dispositions.map(x=>`<tr><td>${esc(x.reference)}</td><td>${x.loaded}</td><td>${esc(x.options.join(' ou '))}</td></tr>`).join('')}</tbody></table></div><h3>Afastamentos para E, F e G</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>Referência</th><th>Cabo</th><th>Até a superfície adjacente</th><th>Entre cabos</th></tr></thead><tbody>${data.clearances.map(x=>`<tr><td>${esc(x.reference)}</td><td>${esc(x.cable)}</td><td>≥ ${num(x.surface_ratio,1)} De</td><td>${x.cable_ratio?'≥ '+num(x.cable_ratio,1)+' De':'Conforme a disposição escolhida'}</td></tr>`).join('')}</tbody></table></div><p class="field-hint">Distâncias livres entre superfícies; De é o diâmetro externo completo do cabo. NBR 5410, 6.2.5.1.2, notas 5 e 6. No método 13, a área perfurada deve ser pelo menos ${data.perforation_min}% da área total da bandeja (tabela 33, nota 4).</p><h3>Isolação e classe térmica</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>Tipo de cabo</th><th>Isolação</th><th>Tensão de isolação</th></tr></thead><tbody>${Object.entries(data.insulations).map(([c,types])=>`<tr><td>${esc(c)}</td><td>${types.map(t=>`${esc(t)} (${['PVC','LSHF/A'].includes(t)?70:90} °C)`).join('; ')}</td><td>${c==='Condutor isolado'?'450/750 V':'0,6/1 kV'}</td></tr>`).join('')}</tbody></table></div><p class="field-hint">E/F/G também exigem os afastamentos indicados no formulário. De é definido pelas notas aplicáveis da tabela 33; para eletrodutos, use a dimensão externa do conduto. Nas disposições de três unipolares indicadas na nota 6, a dimensão equivalente do conjunto é 2,2 vezes o diâmetro em trifólio e 3 vezes no mesmo plano.</p><p class="field-hint">Fonte: ${esc(data.source)} As tabelas representam as combinações suportadas; condições especiais e exceções normativas exigem verificação específica.</p></div>`;
}
function bindInstallationTables(root,data){
 const search=root.querySelector('[data-install-search]'),filter=root.querySelector('[data-install-filter]');
 const renderRows=()=>{
  const q=normalizeInstallation(search.value),ref=filter.value;
  const rows=data.lines.filter(x=>(!q||normalizeInstallation(x.name+' '+x.variants.map(v=>String(v.method).split('_')[0]).join(' ')).includes(q))&&(!ref||x.references.includes(ref)));
  root.querySelector('[data-install-count]').textContent=`${rows.length} de ${data.lines.length} instalações`;
  const cell=(line,cable)=>{const groups={};for(const v of line.variants){if(v.cable!==cable)continue;const number=String(v.method).split('_')[0];if(!groups[v.reference])groups[v.reference]=new Set();groups[v.reference].add(number);}return Object.entries(groups).map(([r,ids])=>`${esc([...ids].join(', '))} → <b>${esc(r)}</b>`).join('<br>')||'—';};
  root.querySelector('[data-install-rows]').innerHTML=rows.map(x=>`<tr><td>${esc(x.name)}</td>${['Condutor isolado','Cabo unipolar','Cabo multipolar'].map(c=>`<td>${cell(x,c)}</td>`).join('')}</tr>`).join('')||'<tr><td colspan="4">Nenhuma instalação encontrada.</td></tr>';
 };
 search.oninput=filter.onchange=renderRows;renderRows();
}
async function renderInstallationTables(main){const data=await loadInstallationTables();main.innerHTML=heading('Tabelas de instalação','Consulte as mesmas relações utilizadas nas escolhas e na validação do projeto.')+installationTablesHTML(data);bindInstallationTables(main,data);}
async function showInstallationTables(){try{const data=await loadInstallationTables();modal('Tabelas de instalação',installationTablesHTML(data));$('#modal').classList.add('installation-modal');bindInstallationTables($('#modal'),data);$('#modal').addEventListener('close',()=>$('#modal').classList.remove('installation-modal'),{once:true});}catch(error){toast(error.message,true);}}

/* Agrupamento: o servidor resolve a contagem, o fator e sua referência. */
const GROUP_SETTING_KEYS=['group','spacing','depth','layers','per_layer','geometry_mode','geometry_signature','diameter','surface_gap','cable_gap','space_ratio','group_mode','count_mode','physical_count','other_units','parallel_layout','independence_basis','group_signature','homogeneity','group_temperature','heterogeneous_basis','manual_factor','manual_source','manual_reason','duct_layout','allow_guide','air_gap_ratio','low_load_count','low_load_ib','low_load_iz','low_load_basis','neutral_reduction','neutral_basis','neutral_floor'];
function cleanSettings(st){return Object.fromEntries(GROUP_SETTING_KEYS.filter(k=>st?.[k]!==undefined&&st[k]!==null&&st[k]!=='').map(k=>[k,st[k]]));}
const SPACING_LABEL={'0':'Encostados','diametro':'1 diâmetro externo','0.125':'0,125 m','0.25':'0,25 m','0.5':'0,50 m','1':'1,00 m'};
function renderGrouping(){
 const inst=drawerData?.installation,det=$('#group-metodo');if(!inst||!det)return;
 let box=$('#installation-grouping');if(!box){box=document.createElement('div');box.id='installation-grouping';box.className='info-card wide';det.appendChild(box);}
 const st=inst.settings||{},g=inst.grouping||{},nc=Number(inst.values.parallel)||1,count=g.physical_count||1,manual=st.group_mode==='manual';
 const pick=(key,label,list,value=st[key],hint='')=>`<label class="field"><span>${esc(label)}</span><select data-group-key="${key}"><option value="">Selecione…</option>${list.map(([v,t])=>`<option value="${esc(v)}" ${String(value)===String(v)?'selected':''}>${esc(t)}</option>`).join('')}</select>${hint?`<small>${esc(hint)}</small>`:''}</label>`;
 const input=(key,label,value=st[key],hint='',type='number')=>`<label class="field"><span>${esc(label)}</span><input data-group-key="${key}" data-group-type="${type}" inputmode="${type==='number'?'decimal':'text'}" ${type==='number'?'list="group-numbers"':''} value="${esc(value??'')}">${hint?`<small>${esc(hint)}</small>`:''}</label>`;
 const check=(key,label,on=st[key])=>`<label class="field"><span><input type="checkbox" data-group-key="${key}" ${on?'checked':''}> ${esc(label)}</span></label>`;
 let fields=pick('group_mode','Como escolher o fator?',[['auto','Automático — pelas condições informadas'],['manual','Manual — informar fator, fonte e justificativa']],st.group_mode||'auto');
 fields+=pick('count_mode','Como contar os conjuntos?',[['auto','Automático — paralelos deste circuito + demais conjuntos'],['total','Manual — informar o total físico no trecho']],st.count_mode||'auto');
 if(st.count_mode==='total')fields+=input('physical_count','Total de conjuntos, incluindo este circuito',st.physical_count,'Cada cabo multipolar ou conjunto completo de fases conta uma vez.');
 else fields+=input('other_units','Conjuntos dos demais circuitos no trecho',st.other_units??(Number(inst.values.circuits)===1?0:''),'Inclua os paralelos dos demais circuitos. Os deste circuito são somados automaticamente.');
 if(nc>1){
  fields+=pick('parallel_layout','Relação térmica entre os paralelos',[['together','Compartilham o trecho — contar todos'],['independent','Trechos termicamente independentes — comprovar']],st.parallel_layout||'together','Eletrodutos distintos ainda podem aquecer uns aos outros.');
  if(st.parallel_layout==='independent')fields+=input('independence_basis','Como a independência térmica foi demonstrada?',undefined,'Geometria, separação e referência do estudo.','text');
 }
 if(inst.group_options?.length)fields+=pick('group','Disposição física',inst.group_options.map(o=>[o.value,o.label]));
 if(inst.underground){
  fields+=input('depth','Profundidade (m)',st.depth??.7,'Base das tabelas de agrupamento: 0,70 m. A correção de profundidade do guia é separada.');
  if(count>1){
   fields+=pick('spacing','Distância livre entre circuitos ou grupos de dutos',(inst.spacing_options||[]).map(x=>[x,SPACING_LABEL[x]]));
   if(st.group==='dutos')fields+=pick('duct_layout','Distribuição nos dutos',[['one_cable','Um cabo multipolar em cada duto'],['one_conductor','Um condutor por duto não metálico, agrupados por circuito'],['other','Outra distribuição — requer cálculo específico']]);
   if(count>6&&!manual)fields+=check('allow_guide','Permitir extensão do guia Prysmian, identificada no resultado');
  }
 }
 if(st.group==='camadas'&&!manual){fields+=input('layers','Número de camadas');fields+=input('per_layer','Conjuntos por camada',undefined,'O produto deve coincidir com o total físico.');}
 const others=count>(g.own_count||nc)||st.count_mode==='total';
 if(count>1&&others){
  fields+=pick('homogeneity','Características do grupo',[['similar','Mesma classe térmica; seções em até 3 valores consecutivos'],['mixed','Classes térmicas diferentes; seções semelhantes'],['heterogeneous','Seções não semelhantes — cálculo específico ou 1/√n']],undefined,'Consideram-se todos os conjuntos plenamente carregados; exclusão somente com demonstração.');
  if(['mixed','heterogeneous'].includes(st.homogeneity))fields+=pick('group_temperature','Menor temperatura de serviço do grupo',[[70,'70 °C — existe PVC / LSHF de 70 °C'],[90,'90 °C — todos admitem 90 °C']]);
  if(st.homogeneity==='heterogeneous'&&!manual)fields+=input('heterogeneous_basis','Por que não é viável um cálculo específico?',undefined,'Exigido para a alternativa 1/√n de 6.2.5.5.5 b.','text');
 }
 if(manual){fields+=input('manual_factor','FCA manual (maior que 0 e até 1)');fields+=input('manual_source','Fonte do fator',undefined,'Norma, estudo ou memorial de cálculo.','text');fields+=input('manual_reason','Justificativa para este trecho',undefined,'Descreva a geometria e as condições contempladas.','text');}
 let optional='';
 if(count>1&&!manual){
  if(!inst.underground&&['parede','teto','bandeja','leito'].includes(st.group))optional+=input('air_gap_ratio','Distância horizontal livre / maior De',undefined,'Só há dispensa de redução por agrupamento quando estritamente maior que 2, entre todos os conjuntos.');
  if(others){
   optional+=input('low_load_count','Conjuntos dos demais circuitos a excluir por baixa carga',st.low_load_count||0);
   if(Number(st.low_load_count)>0){optional+=input('low_load_ib','Maior Ib dos conjuntos excluídos (A)');optional+=input('low_load_iz','Menor Iz desses conjuntos, antes do FCA (A)',undefined,'Já considerar temperatura, solo e neutro. O aplicativo aplica o FCA do grupo completo e verifica o limite de 30%.');optional+=input('low_load_basis','Identificação dos conjuntos e origem dos valores',undefined,'Registre as correntes e capacidades utilizadas.','text');}
  }
 }
 const issues=inst.issues||[];
 box.innerHTML=`<h4>Agrupamento por trecho</h4><p class="field-hint">Use o trecho termicamente mais desfavorável do percurso. Um único fator vale para fases e neutro; os paralelos entram na contagem física.</p><div class="grouping-grid">${fields}</div><datalist id="group-numbers">${[0,1,2,3,4,5,6,7,8,9,10,12,16,20].map(x=>`<option value="${x}"></option>`).join('')}</datalist>${optional?`<details class="guided-more" ${Number(st.low_load_count)>0||st.air_gap_ratio!=null?'open':''}><summary>Afastamento e exclusão por baixa carga (opcionais)</summary><div class="grouping-grid">${optional}</div></details>`:''}<div class="notice blue"><b>${esc(g.count_explanation||'Contagem pendente')}</b><br>FCA: <b>${g.factor==null?'pendente':num(g.factor,3)}</b> · ${esc(g.source||'Fonte pendente')}<br>${esc(g.coordinate||'')}<br>Base térmica: ${g.temperature||'—'} °C</div>${g.notes?.length?`<p class="field-hint">${g.notes.map(esc).join('<br>')}</p>`:''}<button type="button" class="btn small" data-group-tables>Consultar todas as relações e fatores</button><div id="installation-validation">${issues.length?`<div class="cascade-aviso">${issues.map(x=>`<p>• ${esc(x)}</p>`).join('')}</div>`:'<div class="cascade-ok">✓ Condições informadas compatíveis. Fator pronto para o cálculo.</div>'}</div>`;
 function bind(root){root.querySelectorAll('[data-group-key]').forEach(el=>el.onchange=()=>{
  let value=el.type==='checkbox'?el.checked:el.value.trim();
  if(el.dataset.groupType==='number'&&value!==''){value=Number(value.replace(',','.'));if(!Number.isFinite(value)){toast('Informe um número válido.',true);return;}}
  const key=el.dataset.groupKey;drawerData.installation.settings={...drawerData.installation.settings,[key]:value===''?null:value};
  if(['homogeneity','independence_basis','manual_reason'].includes(key))drawerData.installation.settings.group_signature=g.signature;
  groupingDirty=true;dirty=true;$('#save-circuit').textContent='Salvar alterações';refreshInstallationPreview(drawerData.fields);if(window.queueWorkflow)queueWorkflow(drawerData);
 });}
 bind(box);box.querySelector('[data-group-tables]').onclick=showInstallationTables;
 const wire=$('#group-cabos');if(wire){
  let neutral=$('#neutral-rules');if(!neutral){neutral=document.createElement('div');neutral.id='neutral-rules';neutral.className='info-card wide';wire.appendChild(neutral);}
  neutral.innerHTML=`<h4>Critérios do neutro</h4><div class="grouping-grid">${pick('neutral_reduction','Seção mínima do neutro',[['full','Automática — pelo menos a seção da fase'],['verified','Redução — condições de 6.2.6.2.6 comprovadas']],st.neutral_reduction||'full')}${st.neutral_reduction==='verified'?input('neutral_basis','Comprovação das condições de redução',undefined,'Equilíbrio em serviço, terceira harmônica ≤15%, proteção contra sobrecorrentes e mesmo metal. Se uma condição faltar, usa-se a seção da fase.','text'):''}${check('neutral_floor','Manter piso interno de corrente: 15% da fase por condutor',st.neutral_floor!==false)}</div><p class="field-hint">O piso de 15% é uma premissa interna opcional. Não substitui a seção mínima da norma. Harmônicas acima de 15% em trifásico com neutro aplicam fator térmico 0,86, separado do FCA.</p>`;
  bind(neutral);
 }
}
window.renderGrouping=renderGrouping;

function groupingTablesHTML(data){
 if(!data)return '';
 // v2.2.0: origem de cada linha (NBR ou extensão) e o solo (Tabela 41) na mesma consulta gerada das regras do cálculo.
 const ext=data.rows.filter(r=>r.extensao).length;
 const soil=(data.soil||[]).length?`<h3>Resistividade térmica do solo (Tabela 41 e extensões)</h3><p>${esc(data.soil_note||'')}</p><div class="table-wrap"><table class="data-table"><thead><tr><th>Resistividade (K·m/W)</th><th>Eletrodutos enterrados</th><th>Origem</th><th>Diretamente enterrados</th><th>Origem</th></tr></thead><tbody>${data.soil.map(r=>`<tr><td>${num(r.resistividade,1)}</td><td>${num(r.dutos,2)}</td><td>${r.extensao_dutos?'<span class="tag">extensão</span> ':''}${esc(r.fonte_dutos)}</td><td>${num(r.direto,2)}</td><td>${r.extensao_direto?'<span class="tag">extensão</span> ':''}${esc(r.fonte_direto)}</td></tr>`).join('')}</tbody></table></div><p class="field-hint">${esc(data.depth||'')}</p>`:'';
 return `<h3>Relações e fatores de agrupamento</h3><p>${data.rows.length} relações cadastradas, ${ext} delas extensões identificadas. Os valores abaixo alimentam diretamente o cálculo. A coluna “Fonte” separa a NBR das extensões opcionais do guia.</p><ul>${data.notes.map(t=>`<li>${esc(t)}</li>`).join('')}</ul><details><summary>Abrir todas as relações (tabelas 42–45 e extensões)</summary><div class="table-wrap"><table class="data-table"><thead><tr><th>Disposição</th><th>Conjuntos</th><th>Distância livre</th><th>Fator</th><th>Tabela</th><th>Fonte</th></tr></thead><tbody>${data.rows.map(r=>`<tr${r.extensao?' class="row-ext"':''}><td>${esc(r.group)}</td><td>${esc(r.count)}</td><td>${esc(r.spacing)}</td><td>${num(r.factor,2)}</td><td>${esc(r.table)}</td><td>${r.extensao?'<span class="tag">extensão</span> ':''}${esc(r.source)}</td></tr>`).join('')}</tbody></table></div></details>${soil}`;
}

'use strict';
/* Histórico do projeto (revisões, comparação, restauração e cópias de segurança)
 * e integridade das expressões e tabelas frente ao modelo do aplicativo (v2.0). Usa as funções globais de app.js. */
function fmtVal(v){if(v===null||v===undefined||v==='')return '—';if(typeof v==='number')return formatBR(v);if(typeof v==='object')return JSON.stringify(v);return String(v);}
function integrityBannerHTML(){
  const i=state&&state.integridade;if(!i||!i.problemas)return '';
  return `<div class="notice red integrity-banner" role="alert"><b>${i.problemas} item(ns) diferem do modelo do aplicativo sem registro válido de edição.</b> Os resultados usam as expressões e tabelas encontradas no projeto. <a href="#compare" data-integrity-open="1">Ver quais</a></div>`;
}
document.addEventListener('click',e=>{if(e.target.closest('[data-integrity-open]')){window.compareTab='integridade';if(location.hash==='#compare'){e.preventDefault();render();}}});
async function renderIntegrityView(main){
  main.innerHTML=heading('Integridade','Expressões, tabelas técnicas, dados de fabricante e base de cálculo do projeto conferidos com o modelo do aplicativo e com o selo das edições registradas.')+compareTabsHTML()+'<div id="integrity-body"><div class="loading-card">Conferindo…</div></div>';
  bindCompareTabs();
  const [r,rv]=await Promise.all([api('/api/integrity'),window.loadReviewer?window.loadReviewer():Promise.resolve({})]);const c=r.contagem;
  const scopeTxt=x=>x.escopo_versao==='circuito'?`só ${esc(x.circuito||'')}`:x.escopo_versao==='raiz'?'circuitos ligados à fonte':(x.circuito||(x.escopo==='circuito'?'todos os circuitos':'—'));
  const action=x=>x.situacao==='base_diferente'?'<button type="button" class="btn small" data-base-open="1">Comparar e decidir</button>'
    :x.situacao==='conversao_pendente'&&rv.desbloqueado?`<button type="button" class="btn small" data-mig-ack="${esc(x.variavel)}" data-mig-cid="${esc(x.circuito_id||'')}">Marcar como conferida</button>`
    :x.variavel&&['alterada','invalida'].includes(x.situacao)?`<button type="button" class="btn small" data-integ-var="${esc(x.variavel)}">Abrir no catálogo</button>`:'';
  const detail=x=>x.expressao?`<code>${esc(String(x.expressao).slice(0,300))}</code>`:x.celulas?`${x.celulas} célula(s) da tabela`:x.componentes?esc(x.componentes.join(', ')):'';
  const items=r.itens.map(x=>`<tr><td class="wrap-cell"><b>${esc(x.descricao||'')}</b><br><small class="mono">${esc(x.variavel||x.tabela||x.dados_fabricante||'')}</small></td><td class="wrap-cell">${scopeTxt(x)}</td><td><span class="tag red">${esc(x.rotulo)}</span></td><td class="wrap-cell">${detail(x)}</td><td>${action(x)}</td></tr>`).join('');
  const tag=(n,t,cls='red')=>n?`<span class="tag ${cls}">${n} ${t}</span>`:'';
  $('#integrity-body').innerHTML=`<div class="toolbar"><span class="tag ${r.problemas?'red':'green'}">${r.problemas?r.problemas+' item(ns) com divergência':'Tudo confere'}</span><span class="tag">${c.modelo.toLocaleString('pt-BR')} expressões do modelo</span>${tag(c.editada,'versão(ões) de expressão registrada(s)','')}${tag(c.tabela_editada,'tabela(s) editada(s) com registro','')}${tag(c.fabricante_registrado,'registro(s) de fabricante','')}${tag(c.alterada,'expressão(ões) alterada(s) fora do aplicativo')}${tag(c.tabela_alterada,'tabela(s) alterada(s) fora do aplicativo')}${tag(c.fabricante_alterado,'dado(s) de fabricante alterado(s)')}${tag(c.dado_ignorado,'valor(es) fixo(s) ignorado(s)')}${tag(c.conversao_pendente,'conversão(ões) pendente(s)')}${tag(c.base_diferente,'base de cálculo diferente')}${tag(c.invalida+c.desconhecida,'registro(s) inválido(s)')}</div>
  <div class="notice blue">Referência: ${esc(r.referencia)}. O projeto guarda só o que difere do modelo, e cada versão registrada recebe um selo; também guarda a identificação da base de cálculo com que foi revisado. Expressões, tabelas e dados de fabricante sem selo válido, fórmulas antigas não convertidas e mudança de base aparecem aqui. O selo detecta alterações fora do fluxo de revisão; não é uma assinatura digital.</div>
  ${r.problemas?`<section class="panel"><div class="panel-head"><div><h2>Itens a conferir</h2><p>${r.truncado?'Lista limitada às primeiras ocorrências.':''}</p></div></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Item</th><th>Alcance</th><th>Situação</th><th>Detalhe</th><th></th></tr></thead><tbody>${items}</tbody></table></div></section>`:''}`;
  $('#integrity-body').onclick=e=>{
    const tr=e.target.closest('[data-integ-var]');if(tr&&window.catalogEntryModal){window.catalogEntryModal(tr.dataset.integVar);return;}
    if(e.target.closest('[data-base-open]')){baseModal();return;}
    const ack=e.target.closest('[data-mig-ack]');
    if(ack){modal('Conferir fórmula não convertida',`<p class="subtitle">${esc(ack.dataset.migAck)}</p><div class="field wide"><label for="mig-just">Justificativa (mín. 15 caracteres)</label><textarea id="mig-just" rows="3"></textarea></div>`,'<button class="btn primary" id="mig-go">Registrar conferência</button>');
      $('#mig-go').onclick=()=>actionFn(async()=>{await api('/api/migration/ack',{variavel:ack.dataset.migAck,circuito_id:ack.dataset.migCid,justificativa:$('#mig-just').value});$('#modal').close();await refresh();render();},'Conferência registrada.');}
  };
}
const actionFn=(fn,msg)=>action(fn,msg);
async function baseModal(){
  busy(true,'Recalculando com a base registrada…');
  try{
    const b=await api('/api/base');const rv=window.reviewerState?window.reviewerState():{};
    const res=(b.resultados||[]).map(c=>`<tr><td><b>${esc(c.circuito)}</b></td><td class="wrap-cell">${c.campos.map(f=>`${esc(f.campo)}: <span class="muted">${esc(fmtVal(f.antes))}</span> → <b>${esc(fmtVal(f.depois))}</b>`).join('<br>')||esc(c.situacao)}</td></tr>`).join('');
    modal('Base de cálculo',`<p>${esc(b.descricao||'')}</p>
      ${!b.diferente?'<p class="subtitle">O projeto já usa a base em vigor.</p>':b.comparacao_completa?`<h4>Resultados: base registrada → base em uso</h4>${res?`<div class="table-wrap"><table class="data-table compact"><thead><tr><th>Circuito</th><th>Diferenças</th></tr></thead><tbody>${res}</tbody></table></div>`:'<p class="subtitle">Nenhuma diferença nos resultados comparados.</p>'}`:`<div class="notice">${esc(b.aviso_comparacao||'A base anterior não está disponível.')} Não é possível concluir ausência de impacto. Confira os resultados antes de adotar a base em uso.</div>`}
      <p class="subtitle">Adotar a base em uso registra a atualização (de/para, componentes, circuitos com resultados diferentes) no histórico do projeto.</p>`,
      rv.desbloqueado&&b.diferente?'<button class="btn primary" id="base-adopt">Adotar a base em uso</button>':b.diferente?'<span class="subtitle">Desbloqueie o modo revisor para adotar a base em uso.</span>':'');
    const ad=$('#base-adopt');if(ad)ad.onclick=()=>action(async()=>{await api('/api/base/adopt',{});$('#modal').close();await refresh();render();},'Base de cálculo atualizada e registrada.');
  }catch(e){toast(e.message,true);}finally{busy(false);}
}
let historySelection=[];
async function renderHistoryView(main){
  main.innerHTML=heading('Histórico do projeto','Cada gravação gera uma revisão com cargas, vínculos, cabos, dispositivos, expressões, tabelas técnicas e dados de fabricante. Compare revisões e restaure uma versão anterior sem perder as demais.',`<button class="btn" id="backup-now">Criar cópia de segurança</button>`,'PROJETO')+'<div id="history-body"><div class="loading-card">Carregando revisões…</div></div>';
  $('#backup-now').onclick=()=>action(async()=>{const r=await api('/api/backup',{});toast(`Cópia de segurança criada: ${r.arquivo}`);});
  const h=await api('/api/history');historySelection=[];
  const row=x=>{const st=x.estatistica;const det=x.tipo==='full'?'cópia completa':st?`${st.celulas} valor(es)${st.meta&&st.meta.length?' · '+esc(st.meta.join(', ')):''}`:'';
    return `<tr><td><input type="checkbox" data-hist-pick="${x.revisao}" aria-label="Selecionar revisão ${x.revisao}"></td><td class="num"><b>${x.revisao}</b>${x.atual?' <span class="tag green">atual</span>':''}</td><td>${esc(x.data)}</td><td class="wrap-cell">${esc(x.resumo||'')}</td><td>${esc(x.autor||'—')}</td><td><small class="muted">${det}</small></td><td class="actions-cell">${x.atual?'':`<button type="button" class="btn small" data-hist-compare="${x.revisao}">Comparar com a atual</button> <button type="button" class="btn small" data-hist-restore="${x.revisao}">Restaurar</button>`}</td></tr>`;};
  $('#history-body').innerHTML=`<div class="toolbar"><span class="tag">${h.revisoes.length} revisões</span><span class="tag">Revisão atual: ${h.atual}</span><button type="button" class="btn small" id="hist-compare-two" disabled>Comparar as duas selecionadas</button></div>
  <section class="panel"><div class="table-wrap"><table class="data-table"><thead><tr><th></th><th class="num">Revisão</th><th>Data</th><th>O que mudou</th><th>Autor</th><th>Registro</th><th></th></tr></thead><tbody>${h.revisoes.map(row).join('')}</tbody></table></div></section>
  <div id="hist-compare"></div>
  <div class="notice">Restaurar cria uma nova revisão com os dados da revisão escolhida; nenhuma revisão é apagada. Antes de restaurar, o aplicativo grava uma cópia de segurança do banco em <code>projetos/backups</code> (são mantidas as 10 mais recentes, também criadas ao iniciar o aplicativo).</div>`;
  $$('[data-hist-pick]').forEach(cb=>cb.onchange=()=>{const v=Number(cb.dataset.histPick);historySelection=historySelection.filter(x=>x!==v);if(cb.checked)historySelection.push(v);if(historySelection.length>2){const drop=historySelection.shift();const o=document.querySelector(`[data-hist-pick="${drop}"]`);if(o)o.checked=false;}$('#hist-compare-two').disabled=historySelection.length!==2;});
  $('#hist-compare-two').onclick=()=>{const [a,b]=[...historySelection].sort((x,y)=>x-y);compareRevisions(a,b);};
  $$('[data-hist-compare]').forEach(b=>b.onclick=()=>compareRevisions(Number(b.dataset.histCompare),h.atual));
  $$('[data-hist-restore]').forEach(b=>b.onclick=()=>{const rev=Number(b.dataset.histRestore);if(!confirm(`Restaurar a revisão ${rev}? Será criada uma nova revisão com esses dados; as atuais continuam no histórico.`))return;action(async()=>{await api('/api/history/restore',{revisao:rev});await refresh();},`Revisão ${rev} restaurada como nova revisão.`);});
}
async function compareRevisions(a,b){
  const box=$('#hist-compare');box.innerHTML='<div class="loading-card">Recalculando as duas revisões…</div>';
  busy(true,'Comparando revisões…');
  try{
    const r=await api(`/api/history/compare?a=${a}&b=${b}`);
    const res=(r.resultados||[]).map(c=>`<tr><td><b>${esc(c.circuito)}</b>${c.nome_anterior?`<small class="cell-sub">antes: ${esc(c.nome_anterior)}</small>`:''}</td><td>${esc(c.situacao)}</td><td class="wrap-cell">${c.campos.map(f=>`${esc(f.campo)}: <span class="muted">${esc(fmtVal(f.antes))}</span> → <b>${esc(fmtVal(f.depois))}</b>`).join('<br>')||'—'}</td></tr>`).join('');
    const inp=r.entradas.map(x=>`<tr><td>${esc(x.circuito||'—')}</td><td class="wrap-cell">${esc(x.campo)}<small class="cell-sub mono">${esc(x.variavel||'')}</small></td><td class="wrap-cell">${esc(fmtVal(x.antes))}</td><td class="wrap-cell">${esc(fmtVal(x.depois))}</td></tr>`).join('');
    const tb=(r.tabelas||[]).map(x=>`<tr><td class="wrap-cell">${esc(x.nome)}</td><td>${x.celulas}</td><td class="wrap-cell"><small>${esc(x.exemplos.join(', '))}</small></td></tr>`).join('');
    const fx=r.formulas.map(x=>`<tr><td class="wrap-cell">${esc(x.campo)}<small class="cell-sub mono">${esc(x.variavel||'')}</small><small class="cell-sub">${esc(x.escopo_rotulo||'Comum')} · versão ${esc(String(x.versao_antes??0))} → ${esc(String(x.versao_depois??0))}${x.historico_alterado?' · histórico atualizado':''}</small></td><td class="wrap-cell"><code>${esc(String(x.antes??'—').slice(0,240))}</code></td><td class="wrap-cell"><code>${esc(String(x.depois??'—').slice(0,240))}</code></td></tr>`).join('');
    box.innerHTML=`<section class="panel"><div class="panel-head"><div><h2>Revisão ${r.revisao_a} → revisão ${r.revisao_b}</h2><p>${r.n_entradas} dado(s) e ${r.n_formulas} expressão(ões) diferentes${r.meta.length?' · '+esc(r.meta.map(m=>m.rotulo).join(', ')):''}${r.truncado?' · lista limitada':''}${r.posicoes_vazias?` · ${r.posicoes_vazias} ajuste(s) internos em posições sem circuito omitidos`:''}</p></div></div>
      <h3 class="panel-sub">Resultados por circuito</h3>${r.aviso_comparacao?`<div class="notice">${esc(r.aviso_comparacao)}</div>`:''}<div class="table-wrap"><table class="data-table"><thead><tr><th>Circuito</th><th>Situação</th><th>Diferenças</th></tr></thead><tbody>${res||`<tr><td colspan="3" class="empty">${r.comparacao_completa===false?'Comparação de resultados indisponível; não é possível concluir ausência de impacto.':'Nenhuma diferença nos resultados comparados.'}</td></tr>`}</tbody></table></div>
      <h3 class="panel-sub">Dados de entrada</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>Circuito</th><th>Campo</th><th>Antes</th><th>Depois</th></tr></thead><tbody>${inp||'<tr><td colspan="4" class="empty">Nenhuma entrada diferente.</td></tr>'}</tbody></table></div>
      ${fx?`<h3 class="panel-sub">Expressões</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>Cálculo</th><th>Antes</th><th>Depois</th></tr></thead><tbody>${fx}</tbody></table></div>`:''}
      ${tb?`<h3 class="panel-sub">Tabelas técnicas</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>Tabela</th><th>Células</th><th>Posições</th></tr></thead><tbody>${tb}</tbody></table></div>`:''}</section>`;
    box.scrollIntoView({behavior:'smooth',block:'start'});
  }catch(e){box.innerHTML='';if(!e.conflict)toast(e.message,true);}finally{busy(false);}
}

'use strict';
/* v2.2.0 — Vista normativa da Base técnica: mapa das tabelas por norma, Tabelas 36 a 39 na forma da norma (marcas por
 * célula, uso por circuito e gráfico Iz × seção), fichas de fabricante e conferência guiada do registro normativo.
 * Usa as funções globais de app.js ($, $$, esc, num, api, action, modal, toast, render, state) e formatBR (numeros.js). */
(function () {
  const NV = { mode: 'mapa', tab: '36', mat: 'Cu', uso: true, circ: '', sel: null, ftipo: 'dps_siemens', fq: '', fusados: false, foff: 0 };
  window.normView = NV;
  const MODES = [['mapa', 'Mapa normativo'], ['ampacidade', 'Capacidade de condução (36 a 39)'], ['fichas', 'Fichas de fabricante'],
    ['conferencia', 'Conferência guiada'], ['arquivos', 'Arquivos da base']];
  const br = (v) => (typeof v === 'number' ? formatBR(v) : (v === null || v === undefined || v === '' ? '—' : String(v)));
  const fv = (v) => (v && typeof v === 'object' && v.error ? v.error : br(v));
  const dateBR = (d) => { if (!d) return ''; const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(d)); return m ? `${m[3]}/${m[2]}/${m[1]}` : String(d); };
  // `state` é um `let` global de app.js: acessível pelo nome, mas não como window.state.
  const circuits = () => ((typeof state !== 'undefined' && state && state.circuits) || []);

  /* ---------------- navegação ---------------- */
  window.renderNormNav = function () {
    return `<div class="seg-nav" role="tablist" aria-label="Vistas da Base técnica">${MODES.map(([k, l]) =>
      `<button type="button" role="tab" data-norm-mode="${k}" aria-selected="${NV.mode === k}" class="${NV.mode === k ? 'active' : ''}">${esc(l)}</button>`).join('')}</div>`;
  };
  window.bindNormNav = function (root) {
    $$('[data-norm-mode]', root).forEach((b) => { b.onclick = () => { NV.mode = b.dataset.normMode; NV.sel = null; render(); }; });
  };
  window.openNormAmpacity = function (tab, mat, addr) {
    NV.mode = 'ampacidade'; if (tab) NV.tab = String(tab); if (mat) NV.mat = mat; NV.sel = addr || null;
    window.tablesSelected = null;
    if (location.hash === '#tables') render(); else location.hash = 'tables';
  };
  window.renderNormMode = async function (box) {
    try {
      if (NV.mode === 'mapa') return await renderMap(box);
      if (NV.mode === 'ampacidade') return await renderAmp(box);
      if (NV.mode === 'fichas') return await renderCards(box);
      if (NV.mode === 'conferencia') return await renderConference(box);
    } catch (e) { box.innerHTML = `<div class="notice">${esc(e.message)}</div>`; }
    return null;
  };

  /* ---------------- chips ---------------- */
  function confChip(c) {
    if (!c) return '';
    const cls = { conferida: 'green', parcial: 'amber', pendente: 'amber', sem_referencia: '' }[c.estado] || '';
    const extra = c.estado === 'conferida' && c.em ? ` · ${dateBR(c.em)}` : '';
    return `<span class="tag ${cls}" title="${esc((c.por || []).join(', '))}">${esc(c.rotulo)}${esc(extra)}</span>`;
  }
  function refConfHTML(r) {
    const out = [];
    if (r.conferencia_base) out.push(`<span class="tag green" title="Conferência da base técnica">✓ ${esc(r.conferencia_base.por || 'Base')} · ${esc(dateBR(r.conferencia_base.em))}</span>`);
    if (r.conferencia_projeto) out.push(`<span class="tag green" title="Conferência do revisor neste projeto">✓ Revisor: ${esc(r.conferencia_projeto.por)} · ${esc(dateBR(r.conferencia_projeto.em))}</span>`);
    if (!out.length) out.push('<span class="tag amber">A conferir</span>');
    return out.join(' ');
  }

  /* ---------------- mapa ---------------- */
  async function renderMap(box) {
    box.innerHTML = '<div class="loading-card">Montando o mapa das tabelas…</div>';
    const d = await api('/api/norm/map');
    const s = d.resumo;
    const head = `<div class="norm-summary">
      <div><b>${s.total}</b><span>tabelas e regras usadas pelo cálculo</span></div>
      <div><b>${s.conferidas}</b><span>conferidas com a norma</span></div>
      <div><b>${s.com_correcoes}</b><span>com valores corrigidos nesta revisão da base</span></div>
      <div><b>${s.novas || 0}</b><span>novas na base nesta versão</span></div>
      <div><b>${s.a_confirmar}</b><span>com fonte a confirmar</span></div>
      <div><b>${s.editadas}</b><span>editadas neste projeto</span></div></div>
      <p class="subtitle norm-intro">Cada linha é uma tabela da base técnica ou uma regra do cálculo, agrupada pela norma de origem, com o localizador (tabela ou item e página), a conferência e o que mudou. “Abrir” leva à vista na forma da norma (Tabelas 36 a 39), às tabelas de instalação geradas das regras ou à grade da tabela.${s.base_atual ? '' : ' <b>Este projeto usa uma base arquivada: as marcas de correção da revisão atual não se aplicam.</b>'}</p>`;
    const rows = (items) => items.map((it) => {
      const locs = (it.refs.length ? it.refs : [{ localizador: '—' }]).map((r) => `<span class="loc">${esc(r.localizador)}${r.pagina ? `<small>${esc(r.pagina)}</small>` : ''}</span>`).join('');
      const uso = it.tipo === 'regra' ? `<span class="tag blue">regra do cálculo</span><small class="cell-sub">${esc(it.uso.descricao || '')}</small>`
        : it.uso.operacional ? `alimenta ${it.uso.n_variaveis} cálculo(s)${it.uso.regras_python ? `<small class="cell-sub">e ${esc(it.uso.regras_python)}</small>` : ''}`
          : '<span class="muted">apenas consulta</span>';
      const marks = [];
      if (it.corrigidas) marks.push(`<span class="tag red" title="Células com valor diferente da base anterior (2.1.2)">${it.corrigidas} célula(s) corrigida(s)</span>`);
      if (it.nova_em) marks.push(`<span class="tag blue" title="${esc(it.revisao_nota || '')}">nova na base (${esc(it.nova_em)})</span>`);
      if (it.mudancas) marks.push(`<span class="tag blue">alterada nesta versão</span><small class="cell-sub">${esc(it.mudancas)}</small>`);
      if (it.editadas) marks.push(`<span class="tag amber">${it.editadas} editada(s) no projeto</span>`);
      if (it.situacao_fonte === 'a_confirmar') marks.push('<span class="tag amber">fonte a confirmar</span>');
      if (it.extensao) marks.push(`<span class="tag" title="${esc(it.extensao)}">inclui extensão fora da NBR</span>`);
      return `<tr><td class="norm-locs">${locs}</td><td class="wrap-cell"><b>${esc(it.nome)}</b><small class="cell-sub">${esc(it.tipo === 'regra' ? it.fonte : it.id)} · ${esc(it.categoria || '')}</small></td>
        <td class="wrap-cell">${uso}</td><td>${confChip(it.conferencia)}</td><td class="wrap-cell">${marks.join(' ') || '<span class="muted">sem alteração</span>'}</td>
        <td><button type="button" class="btn small" data-map-open="${esc(it.id)}" data-map-view="${esc(it.vista)}">Abrir</button></td></tr>`;
    }).join('');
    box.innerHTML = head + d.grupos.map((g) => `<section class="panel"><div class="panel-head"><div><h2>${esc(g.rotulo)}</h2><p>${g.itens.length} item(ns)</p></div></div>
      <div class="table-wrap"><table class="data-table norm-map"><thead><tr><th>Localizador</th><th>Na base técnica</th><th>Uso no cálculo</th><th>Conferência</th><th>Nesta versão</th><th></th></tr></thead>
      <tbody>${rows(g.itens)}</tbody></table></div></section>`).join('')
      + '<div class="notice blue">A base traz localizadores (tabela, item e página) e não o texto da norma. As tabelas de fabricante citam o documento por linha. As regras do cálculo (matriz de instalação, agrupamento e solo) não são editáveis: mudam só com uma nova versão do aplicativo.</div>';
    box.onclick = (e) => {
      const b = e.target.closest('[data-map-open]'); if (!b) return;
      const view = b.dataset.mapView, id = b.dataset.mapOpen;
      if (view === 'ampacidade') { NV.mode = 'ampacidade'; NV.sel = null; render(); return; }
      if (view === 'regras') { location.hash = 'installtables'; return; }
      window.tablesSelected = id; render();
    };
  }

  /* ---------------- Tabelas 36 a 39 ---------------- */
  async function renderAmp(box) {
    box.innerHTML = '<div class="loading-card">Carregando a tabela…</div>';
    const d = await api('/api/norm/amp?' + new URLSearchParams({ tab: NV.tab, mat: NV.mat, id: NV.circ }));
    const cols = d.colunas;
    const groups = []; cols.forEach((c) => { const last = groups[groups.length - 1]; if (last && last.g === c.grupo) last.n++; else groups.push({ g: c.grupo, label: c.grupo_rotulo, n: 1 }); });
    const ad = d.tabela === '36' || d.tabela === '37';
    const thead = `<thead><tr><th rowspan="2" scope="col">Seção<br>(mm²)</th>${groups.map((g) => `<th colspan="${g.n}" scope="colgroup">${esc(ad ? g.g : g.label)}</th>`).join('')}</tr>
      <tr>${cols.map((c) => `<th scope="col" class="grp">${esc(ad ? c.sub : c.sub)}</th>`).join('')}</tr></thead>`;
    const selUse = (u) => NV.circ && u && u.some((x) => x.id === NV.circ);
    const body = d.linhas.map((l) => `<tr><th scope="row">${br(l.secao)}</th>${l.celulas.map((c, i) => {
      if (!c) return '<td class="na">—</td>';
      const cls = [c.anterior ? 'm-corr' : '', c.editada ? 'm-edit' : '', NV.uso && c.uso ? 'm-uso' : '', selUse(c.uso) ? 'm-uso-sel' : '', NV.sel === c.a ? 'm-sel' : ''].filter(Boolean).join(' ');
      const sup = c.anterior ? `<sup>${esc((c.correcao && c.correcao.achado) || '*')}</sup>` : c.editada ? '<sup>ed.</sup>' : '';
      return `<td class="${cls}"><button type="button" data-amp-cell="${esc(c.a)}" aria-label="${esc(cols[i].rotulo)}, ${br(l.secao)} mm²: ${br(c.v)} A">${br(c.v)}${sup}</button></td>`;
    }).join('')}</tr>`).join('');
    const circOpts = `<option value="">Todos os circuitos</option>${circuits().map((c) => `<option value="${esc(c.id)}" ${NV.circ === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}`;
    box.innerHTML = `<div class="norm-toolbar">
        <div class="seg" role="group" aria-label="Tabela">${['36', '37', '38', '39'].map((t) => `<button type="button" data-amp-tab="${t}" aria-pressed="${NV.tab === t}">Tabela ${t}</button>`).join('')}</div>
        <div class="seg" role="group" aria-label="Material">${[['Cu', 'Cobre'], ['Al', 'Alumínio']].map(([k, l]) => `<button type="button" data-amp-mat="${k}" aria-pressed="${NV.mat === k}">${l}</button>`).join('')}</div>
        <label class="check"><input type="checkbox" id="amp-uso" ${NV.uso ? 'checked' : ''}> Destacar o uso no projeto</label>
        <label class="inline-field">Uso no circuito <select id="amp-circ" class="input">${circOpts}</select></label></div>
      <section class="panel"><div class="panel-head"><div><h2>${esc(d.titulo)}</h2><p>${esc(d.condicoes)}. Condutores de ${d.material === 'Cu' ? 'cobre' : 'alumínio'}.</p></div>
        <div class="norm-head-tags">${confChip(d.conferencia)} ${d.referencia && d.referencia.pagina ? `<span class="tag">${esc(d.referencia.pagina)}</span>` : ''}</div></div>
        <div class="table-wrap"><table class="norm-table">${thead}<tbody>${body}</tbody></table></div>
        <div class="norm-legend"><span><i class="lg m-corr"></i>corrigida nesta revisão da base</span><span><i class="lg m-edit"></i>editada neste projeto</span><span><i class="lg m-uso"></i>usada por um circuito</span><span><i class="lg m-uso-sel"></i>usada pelo circuito escolhido</span>${d.nota ? `<span class="muted">${esc(d.nota)}</span>` : ''}</div></section>
      <div class="norm-split"><section class="panel" id="amp-card"></section><section class="panel" id="amp-uses"></section></div>
      <section class="panel"><div class="panel-head"><div><h2>Consistência Iz × seção</h2><p>Uma linha por coluna da tabela, em escala log. As curvas de capacidade são quase retas; um valor trocado aparece como pico ou degrau.</p></div></div><div class="panel-body" id="amp-chart"></div></section>`;
    paintAmpCard(d); paintAmpUses(d); paintChart(d);
    box.onclick = (e) => {
      const t = e.target.closest('[data-amp-tab]'); if (t) { NV.tab = t.dataset.ampTab; NV.sel = null; render(); return; }
      const m = e.target.closest('[data-amp-mat]'); if (m) { NV.mat = m.dataset.ampMat; NV.sel = null; render(); return; }
      const c = e.target.closest('[data-amp-cell]'); if (c) { NV.sel = c.dataset.ampCell; $$('.norm-table td.m-sel', box).forEach((x) => x.classList.remove('m-sel')); c.parentElement.classList.add('m-sel'); paintAmpCard(d); paintChart(d); return; }
      const g = e.target.closest('[data-amp-go]'); if (g) { NV.tab = g.dataset.tab; NV.mat = g.dataset.mat; NV.sel = g.dataset.ampGo; render(); }
    };
    $('#amp-uso').onchange = (e) => { NV.uso = e.target.checked; render(); };
    $('#amp-circ').onchange = (e) => { NV.circ = e.target.value; render(); };
  }
  function findAmpCell(d, a) {
    for (const l of d.linhas) for (let i = 0; i < l.celulas.length; i++) { const c = l.celulas[i]; if (c && c.a === a) return { c, col: d.colunas[i], secao: l.secao, ci: i }; }
    return null;
  }
  function paintAmpCard(d) {
    const box = $('#amp-card'); if (!box) return;
    const hit = NV.sel && findAmpCell(d, NV.sel);
    if (!hit) { box.innerHTML = '<div class="panel-head"><div><h2>Célula</h2><p>Clique num valor da tabela para ver a origem, a situação e quem o usa.</p></div></div>'; return; }
    const { c, col, secao } = hit;
    const usos = (c.uso || []).map((u) => `${esc(u.circuito)} (${u.papel === 'neutro' ? 'neutro' : 'fase'})`).join(', ');
    box.innerHTML = `<div class="panel-head"><div><h2>Tabela ${esc(d.tabela)} · ${d.material === 'Cu' ? 'cobre' : 'alumínio'}</h2><p>${esc(col.rotulo)} · ${br(secao)} mm²</p></div><span class="big-value">${br(c.v)} A</span></div>
      <div class="panel-body"><dl class="norm-dl">
        <dt>Situação</dt><dd>${c.anterior ? `<span class="tag red">Corrigida nesta revisão</span> valor anterior ${esc(c.anterior.map(br).join(' / '))} A` : '<span class="tag green">Igual à base anterior</span>'}${c.editada ? ` <span class="tag amber">Editada no projeto (base: ${br(c.base)} A)</span>` : ''}</dd>
        ${c.correcao ? `<dt>Correção</dt><dd>${esc(c.correcao.achado || '')}${c.correcao.fonte ? ' · ' + esc(c.correcao.fonte) : ''}${c.correcao.motivo ? `<small class="cell-sub">${esc(c.correcao.motivo)}</small>` : ''}</dd>` : ''}
        <dt>Conferência</dt><dd>${confChip(d.conferencia)}</dd>
        <dt>Origem</dt><dd class="mono">${esc(c.a)}</dd><dt>Nome interno</dt><dd class="mono">${esc(col.nome)}</dd>
        <dt>Usada por</dt><dd>${usos || '<span class="muted">nenhum circuito deste projeto</span>'}</dd></dl>
        <button type="button" class="btn small" data-catalog="${esc(c.a.split('!')[0])}">Abrir a grade da tabela ↗</button></div>`;
  }
  function paintAmpUses(d) {
    const box = $('#amp-uses'); if (!box) return;
    const rows = d.uso_circuitos.map((u) => {
      const parts = ['fase', 'neutro'].filter((k) => u[k]).map((k) => {
        const x = u[k];
        const val = typeof x.valor === 'number' ? `<b>${br(x.valor)} A</b>` : '<span class="tag amber">Iz pendente</span>';
        return `<div class="uso-line"><span>${k === 'fase' ? 'Fase' : 'Neutro'}: Tabela ${esc(x.tabela_norma)}, ${x.material === 'Cu' ? 'cobre' : 'alumínio'}, ${esc(x.coluna)}, ${br(x.secao)} mm² = ${val}</span> <button type="button" class="btn small" data-amp-go="${esc(x.tabela + '!' + x.endereco)}" data-tab="${esc(x.tabela_norma)}" data-mat="${esc(x.material)}" aria-label="Ver a célula de ${esc(u.circuito)} (${k})">ver</button></div>`;
      }).join('');
      return `<li class="${NV.circ === u.id ? 'sel' : ''}"><b>${esc(u.circuito)}</b>${parts || `<div class="muted">${u.matriz ? 'Seção ainda não escolhida.' : 'Instalação incompleta: sem tabela de capacidade.'}</div>`}${u.pendente ? `<small class="cell-sub">Pendente: ${esc(u.pendente)}</small>` : ''}</li>`;
    }).join('');
    box.innerHTML = `<div class="panel-head"><div><h2>Uso no projeto</h2><p>Célula de onde sai o Iz de cada circuito (fase e neutro).</p></div></div><ul class="uso-list">${rows || '<li class="muted">Nenhum circuito.</li>'}</ul>`;
  }
  function paintChart(d) {
    const box = $('#amp-chart'); if (!box) return;
    const W = 760, H = 320, L = 54, R = 18, T = 14, B = 42;
    const pts = [];
    d.colunas.forEach((c, ci) => d.linhas.forEach((l) => { const cell = l.celulas[ci]; if (cell && typeof cell.v === 'number' && cell.v > 0) pts.push({ ci, s: l.secao, v: cell.v, cell }); }));
    if (!pts.length) { box.innerHTML = '<p class="muted">Sem valores.</p>'; return; }
    const xs = pts.map((p) => p.s), ys = pts.map((p) => p.v);
    const x0 = Math.log10(Math.min(...xs)), x1 = Math.log10(Math.max(...xs)), y0 = Math.log10(Math.min(...ys) * 0.9), y1 = Math.log10(Math.max(...ys) * 1.12);
    const X = (s) => L + (Math.log10(s) - x0) / ((x1 - x0) || 1) * (W - L - R), Y = (v) => T + (1 - (Math.log10(v) - y0) / ((y1 - y0) || 1)) * (H - T - B);
    const hit = NV.sel && findAmpCell(d, NV.sel);
    let g = '';
    [5, 10, 20, 50, 100, 200, 500, 1000, 2000].filter((v) => Math.log10(v) >= y0 && Math.log10(v) <= y1).forEach((v) => { g += `<line x1="${L}" x2="${W - R}" y1="${Y(v)}" y2="${Y(v)}" class="grid"/><text x="${L - 8}" y="${Y(v) + 4}" text-anchor="end" class="tick">${br(v)}</text>`; });
    [0.5, 1, 2.5, 6, 16, 35, 70, 150, 300, 630, 1000].filter((s) => Math.log10(s) >= x0 - 1e-9 && Math.log10(s) <= x1 + 1e-9).forEach((s) => { g += `<line x1="${X(s)}" x2="${X(s)}" y1="${T}" y2="${H - B}" class="grid"/><text x="${X(s)}" y="${H - B + 16}" text-anchor="middle" class="tick">${br(s)}</text>`; });
    g += `<text x="${(L + W - R) / 2}" y="${H - 6}" text-anchor="middle" class="axis">Seção (mm², escala log)</text><text x="14" y="${(T + H - B) / 2}" text-anchor="middle" class="axis" transform="rotate(-90 14 ${(T + H - B) / 2})">Iz (A, escala log)</text>`;
    d.colunas.forEach((c, ci) => {
      const p = pts.filter((q) => q.ci === ci).map((q) => `${X(q.s).toFixed(1)},${Y(q.v).toFixed(1)}`);
      const hot = hit && hit.ci === ci;
      g += `<polyline points="${p.join(' ')}" class="${hot ? 'line hot' : 'line'}"><title>${esc(c.rotulo)}</title></polyline>`;
    });
    pts.forEach((q) => {
      const c = q.cell;
      if (c.anterior) g += `<circle cx="${X(q.s)}" cy="${Y(q.v)}" r="5" class="pt corr"><title>${esc(d.colunas[q.ci].rotulo)}, ${br(q.s)} mm²: ${br(q.v)} A (antes ${esc(c.anterior.map(br).join('/'))} A)</title></circle><text x="${X(q.s) - 8}" y="${Y(q.v) - 8}" text-anchor="end" class="lbl corr">${esc((c.correcao && c.correcao.achado) || 'corrigida')} · ${br(q.v)} A</text>`;
      else if (NV.uso && c.uso) g += `<circle cx="${X(q.s)}" cy="${Y(q.v)}" r="4" class="pt uso"><title>${esc(c.uso.map((u) => u.circuito).join(', '))}</title></circle>`;
    });
    if (hit) g += `<circle cx="${X(hit.secao)}" cy="${Y(hit.c.v)}" r="7" class="pt sel"/>`;
    box.innerHTML = `<svg class="norm-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Iz por seção, uma linha por coluna da tabela">${g}</svg>
      <p class="field-note">A linha destacada é a da célula escolhida. Pontos vermelhos: células corrigidas nesta revisão; pontos verdes: células usadas por circuitos do projeto.</p>`;
  }

  /* ---------------- fichas de fabricante ---------------- */
  async function renderCards(box) {
    box.innerHTML = '<div class="loading-card">Carregando as fichas…</div>';
    const d = await api('/api/norm/fichas?' + new URLSearchParams({ tipo: NV.ftipo, q: NV.fq, usados: NV.fusados ? '1' : '', offset: NV.foff, limit: 24 }));
    const pairRow = (p) => `<tr><th scope="row">${esc(p.rotulo)}</th><td class="wrap-cell">${esc(fv(p.catalogo))}</td><td class="num">${p.a_confirmar ? '<span class="tag amber">a confirmar</span>' : `<b>${esc(fv(p.calculo))}</b> <small>${esc(p.unidade || '')}</small>`}<small class="cell-sub mono">${esc(p.endereco)}</small></td></tr>`;
    const cards = d.fichas.map((c) => `<article class="ficha ${c.usado_por.length ? 'usada' : ''}"><header><h3>${esc(c.titulo)}</h3><p>${esc(c.subtitulo)}</p>
      ${c.usado_por.length ? `<p class="ficha-uso">Usado por ${c.usado_por.map((n) => `<span class="tag green">${esc(n)}</span>`).join(' ')}</p>` : ''}${c.editada ? '<span class="tag amber">editada no projeto</span>' : ''}</header>
      <table class="ficha-pares"><thead><tr><th></th><th>Catálogo</th><th class="num">O cálculo lê</th></tr></thead><tbody>${c.pares.map(pairRow).join('')}</tbody></table>
      <footer>${c.fonte ? `<p><b>Fonte:</b> ${esc(c.fonte)}</p>` : ''}${c.observacoes ? `<details><summary>Observações</summary><p>${esc(c.observacoes)}</p></details>` : ''}<p class="mono muted">linha ${c.linha} da tabela</p></footer></article>`).join('');
    box.innerHTML = `<div class="norm-toolbar"><label class="inline-field">Fichas <select id="fc-tipo" class="input">${Object.entries(d.tipos).map(([k, l]) => `<option value="${k}" ${k === NV.ftipo ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>
      <input id="fc-q" class="search" placeholder="Buscar modelo, família ou fonte…" value="${esc(NV.fq)}" aria-label="Buscar ficha">
      <label class="check"><input type="checkbox" id="fc-usados" ${NV.fusados ? 'checked' : ''}> Só os usados no projeto</label>
      <span class="tag">${d.total} ficha(s) · ${d.usados} usada(s)</span></div>
      <p class="subtitle norm-intro">${esc(d.titulo)} — ${esc(d.fonte || '')}. Ao lado do texto do catálogo, o valor que o cálculo de fato lê; “a confirmar” quando o catálogo não traz um valor único (por modo de ligação, por exemplo) e a ficha do fabricante precisa ser consultada.</p>
      <div class="ficha-grid">${cards || '<div class="empty">Nenhuma ficha encontrada.</div>'}</div>
      <div class="sheet-pagination"><span>${d.total ? `mostrando ${d.inicio + 1} a ${Math.min(d.total, d.inicio + 24)} de ${d.total}` : ''}</span><div><button class="btn small" id="fc-prev" ${NV.foff <= 0 ? 'disabled' : ''}>← Anteriores</button><button class="btn small" id="fc-next" ${NV.foff + 24 >= d.total ? 'disabled' : ''}>Próximas →</button></div></div>`;
    $('#fc-tipo').onchange = (e) => { NV.ftipo = e.target.value; NV.foff = 0; render(); };
    $('#fc-q').onkeydown = (e) => { if (e.key === 'Enter') { NV.fq = e.target.value.trim(); NV.foff = 0; render(); } };
    $('#fc-q').onchange = (e) => { NV.fq = e.target.value.trim(); NV.foff = 0; render(); };
    $('#fc-usados').onchange = (e) => { NV.fusados = e.target.checked; NV.foff = 0; render(); };
    $('#fc-prev').onclick = () => { NV.foff = Math.max(0, NV.foff - 24); render(); };
    $('#fc-next').onclick = () => { NV.foff += 24; render(); };
  }

  /* ---------------- conferência guiada ---------------- */
  async function renderConference(box) {
    box.innerHTML = '<div class="loading-card">Carregando o registro normativo…</div>';
    const [d, rv] = await Promise.all([api('/api/norm/conferencia'), window.loadReviewer ? window.loadReviewer() : Promise.resolve({})]);
    const can = rv && rv.desbloqueado;
    const pct = d.total ? Math.round(d.conferidas / d.total * 100) : 0;
    const shortNorm = (n) => String(n || '—').replace(/^ABNT\s+/, '').replace(/\s*\(versão corrigida 2008\)/, '');
    const row = (r) => `<tr><td><b>${esc(r.localizador)}</b><small class="cell-sub mono">${esc(r.id)}</small></td><td class="wrap-cell">${esc(shortNorm(r.norma))}</td><td>${esc(r.pagina || '—')}</td>
      <td class="wrap-cell">${esc((r.condicoes || []).join('; '))}${r.tabelas.length ? `<small class="cell-sub">Usada em: ${r.tabelas.map((t) => esc(t.nome)).join('; ')}</small>` : ''}</td>
      <td class="wrap-cell">${refConfHTML(r)}${r.conferencia_projeto && r.conferencia_projeto.nota ? `<small class="cell-sub">${esc(r.conferencia_projeto.nota)}</small>` : ''}</td>
      <td>${can ? (r.conferencia_projeto ? `<button type="button" class="btn small" data-ref-undo="${esc(r.id)}">Desfazer</button>` : `<button type="button" class="btn small primary" data-ref-check="${esc(r.id)}" data-ref-page="${esc(r.pagina || '')}">Conferi no exemplar</button>`) : ''}</td></tr>`;
    box.innerHTML = `<div class="norm-progress"><div><b>${d.conferidas} de ${d.total}</b> localizadores conferidos · ${d.conferidas_no_projeto} pelo revisor neste projeto</div><div class="bar"><span style="width:${pct}%"></span></div></div>
      <div class="notice blue">${esc(d.nota)} ${can ? 'Abra o exemplar na página indicada, confira a tabela ou o item e marque a linha.' : 'Desbloqueie o modo revisor para marcar as linhas conferidas.'}</div>
      ${d.grupos.map((g) => `<section class="panel"><div class="panel-head"><div><h2>${esc(g.rotulo)}</h2><p>${g.itens.filter((x) => x.verificado_por).length} de ${g.itens.length} conferidos</p></div></div>
        <div class="table-wrap"><table class="data-table norm-conf"><thead><tr><th>Localizador</th><th>Norma</th><th>Página</th><th>Condições e uso</th><th>Conferência</th><th></th></tr></thead><tbody>${g.itens.map(row).join('')}</tbody></table></div></section>`).join('')}`;
    box.onclick = (e) => {
      const c = e.target.closest('[data-ref-check]');
      if (c) {
        modal('Conferido no exemplar', `<p class="subtitle">Confirma que <b>${esc(c.dataset.refCheck)}</b> confere com o seu exemplar da norma? A marcação fica neste projeto, com o seu nome e a data de hoje.</p>
          <div class="field"><label for="rf-pg">Página no exemplar</label><input id="rf-pg" value="${esc(c.dataset.refPage)}" autocomplete="off" placeholder="Ex.: p. 101"></div>
          <div class="field"><label for="rf-nota">Observação (opcional)</label><textarea id="rf-nota" rows="3"></textarea></div>`, '<button class="btn primary" id="rf-save">Marcar como conferida</button>');
        $('#rf-save').onclick = () => action(async () => { await api('/api/normref/verify', { id: c.dataset.refCheck, pagina: $('#rf-pg').value, nota: $('#rf-nota').value }); $('#modal').close(); render(); }, 'Referência marcada como conferida.');
        return;
      }
      const u = e.target.closest('[data-ref-undo]');
      if (u && confirm('Desfazer a conferência registrada neste projeto?')) action(async () => { await api('/api/normref/verify', { id: u.dataset.refUndo, desfazer: true }); render(); }, 'Conferência desfeita.');
    };
  }

  /* ---------------- uso no circuito na grade da tabela ---------------- */
  window.tableUsageHTML = function (tid) {
    return `<label class="inline-field">Uso no circuito <select id="tb-uso" class="input"><option value="">—</option>${circuits().map((c) => `<option value="${esc(c.id)}" ${window.tableUsage && window.tableUsage.id === c.id && window.tableUsage.tabela === tid ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></label>`;
  };
  window.bindTableUsage = function (tid, rerender) {
    const s = $('#tb-uso'); if (!s) return;
    s.onchange = async () => {
      if (!s.value) { window.tableUsage = null; rerender(); return; }
      try { const u = await api('/api/norm/uso?' + new URLSearchParams({ tabela: tid, id: s.value })); window.tableUsage = { ...u, id: s.value, tabela: tid }; } catch (e) { toast(e.message, true); }
      rerender();
    };
  };
})();

'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const token=$('meta[name="eletro-token"]').content;
let state=null, currentView='overview', drawerData=null, dirty=false, sourceDirty=false, busyCount=0, activeFormGroup=null;
let methodCatalog=null, methodCatalogByCode=null, linhasMetodoMapa=null;
let protecaoCatalog=null, protecaoCatalogByModelo=null, protecaoFamiliasPorClasse=null, protecaoFusivelOpcoes=null;
// Lente client-side (nunca persistida — não existe campo novo no XLSX para a
// classe Fixo/Ajustável/Fusível, ver core/project.py:weg_catalog). Enquanto o
// usuário não clica em nenhum tile nesta sessão do drawer, a classe efetiva é
// a derivada pelo servidor a partir de AL/AM/J já salvos (group.classe_atual).
// Reiniciada a cada abertura de circuito (ver editCircuit).
let protecaoClasseEscolhida=null;
const SOURCE_BLOCK_SCENARIOS={gerador_dinamico:['Gerador BT'],mt_dados:['Rede MT/Trafo com dados'],transformador:['Rede MT/Trafo com dados','Rede MT/Trafo sem dados'],bt_direta:['Rede BT Direta'],gerador:['Gerador BT']};
const SOURCE_BLOCK_LABELS={protecao_entrada:'Proteção a montante do ramal',gerador_dinamico:'Gerador — corrente de curto ao longo do tempo',geral:'Informações gerais (aterramento e choque elétrico)',mt_dados:'Média tensão — dados da concessionária',transformador:'Transformador de potência',bt_direta:'Baixa tensão — rede da concessionária',gerador:'Gerador de baixa tensão',criterios:'Critérios de projeto (queda de tensão e condutor de proteção)'};
const SOURCE_BLOCK_ORDER=['geral','mt_dados','transformador','bt_direta','gerador','protecao_entrada','gerador_dinamico','criterios'];
let sheetName='Biblioteca_Proteções_WEG', sheetRow=1, sheetCol=1, sheetQuery='', sheetRequest=0;
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=(v,d=2)=>typeof v==='number'?v.toLocaleString('pt-BR',{minimumFractionDigits:d,maximumFractionDigits:d}):v?.error?esc(v.error):v===null||v===undefined||v===''?'—':esc(v);
const short=(s,n=30)=>String(s??'').length>n?String(s).slice(0,n-1)+'…':String(s??'');
const isError=v=>v&&typeof v==='object'&&v.error;
const labelStatus=s=>s==='ok'?'Sem alertas':s==='error'?'Revisar':'Pendente';
const badge=s=>`<span class="tag ${s==='ok'?'green':s==='error'?'red':'amber'}">${labelStatus(s)}</span>`;
// Situações da r42 vêm em CAIXA ALTA e longas. Na lista, mostra-se um rótulo curto; o texto completo fica no título.
const ACRONYMS={weg:'WEG',icu:'Icu',ics:'Ics',dps:'DPS',tn:'TN',mt:'MT',bt:'BT',pe:'PE',pen:'PEN',spda:'SPDA',nbr:'NBR',ib:'Ib',ir:'Ir',iz:'Iz',ik:'Ik',ii:'Ii',im:'Im',isd:'Isd',tsd:'tsd',siemens:'Siemens',clamper:'Clamper',ikmáx:'Ikmáx','n/a':'N/A','δv':'ΔV',lsi:'LSI',mcb:'MCB',mccb:'MCCB',iec:'IEC',abnt:'ABNT'};
// Mensagens em caixa alta viram frase: nomes de circuito (QGBT-01), números, símbolos já em caixa mista (Ir, Iz)
// e unidades logo após um número continuam como estão; siglas conhecidas voltam pelo ACRONYMS.
function sentenceCase(text){
  let prevNum=false;
  const out=text.replace(/[^\s·×,]+/g,w=>{
    let r=w;
    if(/\d/.test(w)||/[a-zß-ÿ]/.test(w))r=w;
    else if(prevNum&&/^(A|V|W|VA|S)[)\];:.]*$/.test(w))r=w;
    else{const m=w.match(/^([(\["']*)(.*?)([)\]"'.;:!?]*)$/);const core=m[2].toLowerCase();r=m[1]+(ACRONYMS[core]||core)+m[3];}
    prevNum=/^\(?[\d.,]+$/.test(w);
    return r;
  });
  return out.charAt(0).toUpperCase()+out.slice(1);
}
function issueText(v){return isError(v)?`${v.error}${v.detail?' — '+v.detail:''}`:String(v??'');}
function statusInfo(v){
  const full=issueText(v).trim();if(!full)return{cls:'',short:'—',full:''};
  if(isError(v))return{cls:'red',short:/Instalação pendente/i.test(v.detail||'')?'Instalação pendente':v.error,full};
  const sym=/^[✓✗△⏳⚠]/.test(full)?full[0]:'';
  const body=full.replace(/^[✓✗△⏳⚠]\s*/,'');
  const neutral=/^(N\/A|Não aplicável|Sem DPS|Não se aplica)/i.test(body);
  const cls=isError(v)||sym==='✗'?'red':sym==='✓'?'green':neutral?'':'amber';
  let head=body.split(/ — |: |; /)[0].trim();
  const rest=body.slice(head.length);
  if(/^N\/A$/i.test(head)&&rest){head=rest.replace(/^( — |: |; )/,'').split(/ — |: |; /)[0].trim();head=head.charAt(0).toUpperCase()+head.slice(1);}
  const letters=head.replace(/[^A-Za-zÀ-ÿ]/g,'');
  if(letters&&letters.replace(/[^A-ZÀ-Þ]/g,'').length/letters.length>.6){
    head=sentenceCase(head);
  }
  if(head.length>44){const par=head.indexOf(' (');if(par>=12)head=head.slice(0,par);}
  if(head.length>44)head=head.slice(0,43)+'…';
  if(cls==='amber'&&sym!=='⏳'&&/PENDENTE|PENDÊNCIA/i.test(rest))head+=' · com pendências';
  return{cls,short:(sym&&sym!=='⚠'?sym+' ':'')+head,full};
}
function statusChip(v){if(v===null||v===undefined||v==='')return '<span class="muted">—</span>';const i=statusInfo(v);return `<span class="tag status-chip ${i.cls}" title="${esc(i.full)}">${esc(i.short)}</span>`;}
function worstStatus(list){const vals=list.filter(v=>v!==null&&v!==undefined&&v!=='');const pick=re=>vals.find(v=>re.test(issueText(v)));return pick(/^✗/)||vals.find(isError)||pick(/^⏳|PENDENTE/)||pick(/^△/)||pick(/^✓/)||vals[0]||null;}
function toast(message,error=false){const el=$('#toast');el.textContent=message;el.className=error?'error':'';el.hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.hidden=true,error?9000:4000);}
function busy(on,label='Recalculando…'){busyCount=Math.max(0,busyCount+(on?1:-1));$('#busy').hidden=busyCount===0;$('#busy span').textContent=label;}
// v1.12: toda gravação leva o projeto e a revisão em que esta tela se baseou; o servidor recusa (409) pedidos de abas desatualizadas.
function projectHeaders(){return state?{'X-Eletro-Project':state.project_id||'','X-Eletro-Revision':String(state.revision??'')}:{};}
function conflictModal(message){modal('Projeto alterado em outra aba',`<p>${esc(message)}</p><p class="subtitle">Para não sobrescrever o trabalho feito na outra aba ou janela, nada foi gravado. Atualize para ver a versão atual; as alterações desta tela que ainda não foram salvas serão descartadas.</p>`,`<button class="btn primary" id="conflict-reload">Atualizar a página</button>`);$('#conflict-reload').onclick=()=>{dirty=false;sourceDirty=false;location.reload();};}
async function api(path,body,opts={}){const options={headers:{'X-Eletro-Token':token,...(body!==undefined||opts.raw!==undefined?projectHeaders():{})},...opts};if(body!==undefined){options.method='POST';options.headers={...options.headers,'Content-Type':'application/json'};options.body=JSON.stringify(body);}else if(opts.raw!==undefined){options.method='POST';options.body=opts.raw;delete options.raw;}const r=await fetch(path,options);let data;try{data=await r.json();}catch{throw Error('O aplicativo não respondeu. Confira se o terminal continua aberto.');}if(r.status===409){conflictModal(data.error||'Conflito de revisão.');const e=Error(data.error||'Conflito de revisão.');e.conflict=true;throw e;}if(!r.ok)throw Error(data.error||'Não foi possível concluir.');if(state&&data&&typeof data.revision==='number'&&data.project_id===state.project_id)state.revision=data.revision;return data;}
async function action(fn,message){busy(true);try{await fn();if(message)toast(message);}catch(e){if(!e.conflict)toast(e.message,true);}finally{busy(false);}}
async function refresh(){state=await api('/api/state');$('#project-name').textContent=state.title;$('#nav-count').textContent=state.circuits.length;$('#nav-alert').hidden=!state.pending;{const ni=$('#nav-integrity');if(ni)ni.hidden=!(state.integridade&&state.integridade.problemas);}$('#footer-engine').textContent=`${state.recalculated.toLocaleString('pt-BR')} valores calculados · Python`;const ps=await api('/api/projects');$('#project-select').innerHTML=ps.projects.map(p=>`<option value="${esc(p.id)}" ${p.id===ps.active?'selected':''}>${esc(p.name)}</option>`).join('');await render();}
function heading(title,subtitle,actions='',eyebrow='DIMENSIONAMENTO ELÉTRICO'){return `<div class="page-heading"><div><p class="eyebrow">${eyebrow}</p><h1>${title}</h1><p class="subtitle">${subtitle}</p></div><div class="heading-actions">${actions}</div></div>`;}
function kpis(){return `<div class="kpis"><div class="kpi"><div class="label">Potência ativa na origem <b>ϟ</b></div><div class="number">${num(typeof state.p_w==='number'?state.p_w/1000:null)}<span class="unit">kW</span></div><div class="note">Com simultaneidade e cargas a jusante</div></div><div class="kpi"><div class="label">Potência aparente <b>⌁</b></div><div class="number">${num(typeof state.s_va==='number'?state.s_va/1000:null)}<span class="unit">kVA</span></div><div class="note">Somatório na origem da instalação</div></div><div class="kpi"><div class="label">Quadros e circuitos <b>⌘</b></div><div class="number">${state.circuits.length.toString().padStart(2,'0')}<span class="unit">cadastrados</span></div><div class="note good">${state.circuits.filter(x=>x.kind!=='Circuito final').length} alimentadores · ${state.circuits.filter(x=>x.kind==='Circuito final').length} terminais</div></div><div class="kpi attention"><div class="label">Circuitos com pendências <b>△</b></div><div class="number">${state.pending.toString().padStart(2,'0')}<span class="unit">para revisar</span></div><div class="note"><a href="#audit">Consultar as verificações →</a></div></div></div>`;}
function circuitTable(circuits,compact=false){const headers=compact?['Circuito','Ligação','Ib (A)','Fase (mm²)','ΔV acum. (%)','Verificação','']:['Circuito / quadro','Montante','Ligação','P (kW)','Ib (A)','Fase (mm²)','N (mm²)','PE (mm²)','ΔV acum. (%)','Verificação',''];return `<div class="table-wrap"><table class="data-table"><thead><tr>${headers.map(h=>`<th class="${/\(/.test(h)?'num':''}">${h}</th>`).join('')}</tr></thead><tbody>${circuits.map(c=>`<tr class="click-row" data-edit="${esc(c.id)}"><td><div class="circuit-name"><span class="circuit-square">${c.kind==='Circuito final'?'↳':'⌘'}</span>${esc(c.name)}</div><span class="circuit-type">${esc(c.kind||'Sem classificação')}</span></td>${compact?'':`<td>${esc(c.parent||'Desvinculado')}</td>`}<td>${esc(c.phases||'—')}</td>${compact?'':`<td class="num">${num(typeof c.p_w==='number'?c.p_w/1000:null)}</td>`}<td class="num">${num(c.ib)}</td><td class="num">${num(c.sec_f,0)}</td>${compact?'':`<td class="num">${num(c.sec_n,0)}</td><td class="num">${num(c.sec_pe,0)}</td>`}<td class="num">${num(c.dv_total)}</td><td>${badge(c.status)}</td><td><button class="row-button" aria-label="Editar ${esc(c.name)}">↗</button></td></tr>`).join('')||`<tr><td colspan="12" class="empty">Nenhum circuito corresponde ao filtro.</td></tr>`}</tbody></table></div>`;}
function diagram(large=false){const nodes=state.circuits.map(c=>({...c,children:[],depth:0}));const map=new Map(nodes.map(c=>[c.name,c]));const roots=[];for(const n of nodes){const parent=map.get(n.parent);if(parent)parent.children.push(n);else roots.push(n);}let leaf=0,depth=0;const visiting=new Set();function layout(n,d){if(visiting.has(n))return;visiting.add(n);n.depth=d;depth=Math.max(depth,d);if(n.children.length){n.children.forEach(ch=>layout(ch,d+1));n.y=n.children.reduce((s,x)=>s+x.y,0)/n.children.length;}else n.y=leaf++*126+30;visiting.delete(n);}roots.forEach(n=>layout(n,0));const width=(depth+1)*224+28,height=Math.max(210,leaf*126+45);let edges='',cards='';for(const n of nodes){const x=n.depth*224+20,y=n.y;for(const ch of n.children){const xx=ch.depth*224+20;edges+=`<path d="M ${x+188} ${y+45} H ${x+204} V ${ch.y+45} H ${xx}" fill="none" stroke="#a7bdbf" stroke-width="1.5"/>`;}const color=n.status==='error'?'#c0786b':n.status==='pending'?'#c7a261':'#4f9b80';cards+=`<g class="node" role="button" tabindex="0" aria-label="Editar ${esc(n.name)}" data-edit="${esc(n.id)}" transform="translate(${x},${y})"><rect width="188" height="91" rx="7" fill="white" stroke="#d7e3e4"/><rect width="3" height="52" x="0" y="19" rx="1.5" fill="${color}"/><text x="13" y="19" font-size="8" fill="#8a9fa7">${esc(n.kind==='Circuito final'?'CIRCUITO TERMINAL':n.kind==='Origem'?'ORIGEM':'ALIMENTADOR')}</text><circle cx="172" cy="15" r="3" fill="${color}"/><text x="13" y="39" font-size="12" font-weight="600" fill="#284754">${esc(short(n.name,24))}</text><path d="M 13 49 H 175" stroke="#edf1f1"/><text x="13" y="65" font-size="8" fill="#8298a1">Ib <tspan fill="#304e5b" font-weight="600">${num(n.ib,1)} A</tspan></text><text x="107" y="65" font-size="8" fill="#8298a1">F <tspan fill="#304e5b" font-weight="600">${num(n.sec_f,0)} mm²</tspan></text><text x="13" y="80" font-size="8" fill="#8298a1">ΔV ${num(n.dv_total)} %</text><text x="107" y="80" font-size="8" fill="#8298a1">${esc(n.earthing||'—')}</text></g>`;}return `<div class="diagram-canvas ${large?'large':''}"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="Diagrama unifilar interativo dos circuitos">${edges}${cards}</svg></div><div class="diagram-footer"><span><i class="dot"></i>Sem alertas</span><span><i class="dot amber"></i>Pendente</span><span><i class="dot red"></i>Revisar</span><span>Clique em qualquer elemento para editar</span></div>`;}
function phases(){const roots=state.circuits.filter(c=>['Fonte','Transformador'].includes(c.parent));const values=['pr','ps','pt'].map(k=>roots.reduce((s,c)=>s+(typeof c[k]==='number'?c[k]:0),0));const max=Math.max(...values,1);const root=roots[0];return `<div class="panel"><div class="panel-head"><div><h2>Carga por fase</h2><p>Potência ativa na origem</p></div><span class="tag">R · S · T</span></div><div class="panel-body">${values.map((v,i)=>`<div class="phase-row"><div class="phase-label"><strong>Fase ${'RST'[i]}</strong><span>${num(v/1000)} kW</span></div><div class="phase-track"><div class="phase-fill" style="width:${v/max*100}%"></div></div></div>`).join('')}<div class="mini-stats"><div>Fator de potência<b>${num(root?.fp,3)}</b></div><div>Corrente no neutro<b>${num(root?.ineutro,1)} <small>A</small></b></div></div><p class="phase-note">Valores agregados pelos vínculos do projeto, incluindo os fatores de simultaneidade.</p></div></div>`;}
// Hierarquia de "Entrada e fontes": cada campo já chega do backend com f.block
// (a que tipo de atendimento pertence — ver SOURCE_ROW_BLOCK em core/project.py) e,
// dentro de mt_dados, f.submode (qual "Modo de entrada" realmente usa aquela linha,
// ver fórmula de B19). B2 (Tipo de atendimento) é a própria seleção-raiz: sempre
// visível, fora de qualquer bloco recolhível. Nenhum campo é removido do formulário
// — blocos não aplicáveis ficam apenas recolhidos e marcados, nunca inacessíveis,
// porque a Seção 3 do projeto exige preservar dados de MT/Trafo mesmo quando o tipo
// de atendimento atual não os usa no cálculo.
function sourceBlocksHTML(fields){
  const tipoIdx=fields.findIndex(f=>f.block==='tipo');
  const tipoHTML=tipoIdx>=0?`<div class="source-tipo">${fieldHTML(fields[tipoIdx],'source-'+tipoIdx)}</div>`:'';
  const byBlock={};
  fields.forEach((f,i)=>{if(f.block==='tipo')return;(byBlock[f.block]=byBlock[f.block]||[]).push(i);});
  const blocksHTML=SOURCE_BLOCK_ORDER.filter(b=>byBlock[b]&&byBlock[b].length).map(b=>{
    const scen=SOURCE_BLOCK_SCENARIOS[b];
    const fieldsHTML=byBlock[b].map(i=>{
      const f=fields[i];
      return f.submode?`<div class="source-subfield" data-submode="${esc(f.submode)}">${fieldHTML(f,'source-'+i)}</div>`:fieldHTML(f,'source-'+i);
    }).join('');
    return `<details class="source-block" data-block="${b}" open><summary>${esc(SOURCE_BLOCK_LABELS[b])}${scen?'<span class="block-flag" data-flag></span>':''}</summary><div class="fields source-fields">${fieldsHTML}</div></details>`;
  }).join('');
  globalThis.integratedSourceFields=fields;return tipoHTML+(typeof sourceProtectionHTML==='function'?sourceProtectionHTML():'')+blocksHTML;
}
// Reavalia, a partir do valor AO VIVO (ainda não salvo) do Tipo de atendimento e do
// Modo de entrada, quais blocos/linhas fazem sentido agora. forceToggle só é usado
// no primeiro render e quando o próprio Tipo de atendimento muda — nunca a cada
// tecla digitada em outro campo, para não recolher um bloco que o usuário acabou
// de abrir de propósito.
function refreshSourceHierarchy(fields,opts){
  opts=opts||{};
  if(typeof protectionSourceVisibility==='function')protectionSourceVisibility(fields);
  const tipoIdx=fields.findIndex(f=>f.block==='tipo');
  const tipo=tipoIdx>=0?liveValue(tipoIdx,'source-'):null;
  $$('.source-block[data-block]').forEach(det=>{
    const b=det.dataset.block,scen=SOURCE_BLOCK_SCENARIOS[b];
    const applicable=!scen||(tipo&&scen.includes(tipo));
    const flag=det.querySelector('[data-flag]');
    if(flag)flag.textContent=applicable?'':(tipo?`· não se aplica a "${tipo}" — dados preservados`:'· selecione o Tipo de atendimento acima');
    det.classList.toggle('not-applicable',!applicable);
    if(opts.forceToggle)det.open=applicable;
  });
  const modoIdx=fields.findIndex(f=>f.sheet==='Padrão de entrada'&&f.address==='B11');
  const modo=modoIdx>=0?liveValue(modoIdx,'source-'):null;
  $$('.source-subfield[data-submode]').forEach(el=>{el.hidden=!!modo&&el.dataset.submode!==modo;});
}
async function render(){if(!state)return;currentView=location.hash.slice(1)||'overview';if(!['overview','source','circuits','diagram','protection','dps','audit','sheets','compare','help','installtables','history','tables','coordination','review'].includes(currentView))currentView='overview';$$('#nav a').forEach(a=>a.classList.toggle('active',a.dataset.view===currentView));document.body.classList.remove('menu-open');const main=$('#main');const add=`<button class="btn primary" data-add>＋ Novo circuito</button>`;
if(currentView==='overview'){main.innerHTML=heading('Visão geral','Acompanhe as cargas, os condutores e as verificações da instalação.',add)+kpis()+`<div class="grid-two"><section class="panel"><div class="panel-head"><div><h2>Topologia da instalação</h2><p>Da origem aos circuitos terminais</p></div><a href="#diagram" class="tiny-link">Expandir unifilar ↗</a></div>${unifilarCompactHTML()}</section>${phases()}</div><section class="panel"><div class="panel-head"><div><h2>Resumo dos circuitos</h2><p>Seções escolhidas e resultados recalculados</p></div><a class="tiny-link" href="#circuits">Gerenciar circuitos ↗</a></div>${resumoTableHTML()}<div class="table-bottom"><span>${state.circuits.length} circuitos · ${state.circuits.filter(c=>c.parent==='Fonte'||c.parent==='Transformador').length} origem</span><span>Base de cálculo: modelo nativo</span></div></section>`;}
if(currentView==='diagram'){await renderUnifilarView(main,add);}
if(currentView==='circuits'){main.innerHTML=heading('Quadros e circuitos','Cadastre as cargas, configure a instalação e escolha as seções dos condutores.',add)+`<div class="toolbar"><input id="circuit-search" class="search" placeholder="Buscar circuito, descrição ou quadro…" aria-label="Buscar circuito"><select id="circuit-filter" class="input"><option value="">Todos os circuitos</option><option value="Distribuição">Distribuição</option><option value="Circuito final">Circuitos finais</option><option value="issues">Com pendências</option></select><span class="tag">${state.circuits.length} circuito(s)${state.capacity?` / ${state.capacity}`:' · sem limite'}</span></div><section class="panel" id="circuits-list">${circuitTable(state.circuits)}</section>`;$('#circuit-search').oninput=filterCircuits;$('#circuit-filter').onchange=filterCircuits;}
if(currentView==='protection'){main.innerHTML=heading('Proteções','Dispositivo na origem, disjuntor de manutenção na extremidade e situação de cada circuito.',`<button class="btn" data-catalog="Biblioteca_Proteções_WEG">Catálogo WEG ↗</button>`)+`<div class="notice blue">Abra um circuito para escolher Automático ou Manual, indicar um trecho sem dispositivo na origem (por exemplo, transformador → quadro) ou prever um disjuntor de manutenção na chegada do quadro.</div><section class="panel"><div class="table-wrap"><table class="data-table protection-table"><thead><tr><th>Circuito</th><th>Na origem</th><th>Modo</th><th class="num">Ir (A)</th><th class="num">Ii/Im (A)</th><th class="num">Icu (kA)</th><th>Na extremidade</th><th>Situação</th><th></th></tr></thead><tbody>${state.circuits.map(c=>{const mb=c.manutencao,sem=c.origem_ausente;let situacao=sem?worstStatus([c.trecho_curto,c.trecho_sobrecarga,c.trecho_choque]):c.prot_status;if(sem&&/^✓/.test(issueText(situacao)))situacao='✓ TRECHO VERIFICADO — curto-circuito, sobrecarga e seccionamento';return `<tr data-edit="${esc(c.id)}" data-group="${sem?'trecho':'protecao'}" class="click-row"><td><strong>${esc(c.name)}</strong></td><td class="wrap-cell">${sem?'<span class="muted">Sem dispositivo próprio</span>':num(c.protecao)}</td><td>${sem?'—':esc(c.selection_modes?.protecao||'Manual')}</td><td class="num">${sem?'—':num(c.ir_prot,0)}</td><td class="num">${sem?'—':num(c.ii_prot,0)}</td><td class="num">${sem?'—':num(c.icu)}</td><td class="wrap-cell">${mb?`${esc(mb.modelo||'Modelo pendente')}${mb.ajuste?`<small class="cell-sub">${esc(mb.ajuste)}</small>`:''}${statusChip(mb.status)}`:'<span class="muted">—</span>'}</td><td>${statusChip(situacao)}</td><td>↗</td></tr>`;}).join('')}</tbody></table></div></section>`;}
if(currentView==='dps'){main.innerHTML=heading('Proteção contra surtos','DPS por quadro, coordenação entre estágios e proteção de backup.',`<button class="btn" data-catalog="Biblioteca_DPS_Siemens">Catálogo Siemens ↗</button> <button class="btn" data-catalog="Biblioteca_DPS_Clamper">Catálogo Clamper ↗</button>`)+`<section class="panel"><div class="table-wrap"><table class="data-table"><thead><tr><th>Circuito</th><th>Natureza</th><th>DPS neste quadro</th><th>Modelo ativo</th><th>DPS a montante</th><th>Coordenação e backup</th><th></th></tr></thead><tbody>${state.circuits.map(c=>`<tr data-edit="${esc(c.id)}" data-group="dps" class="click-row"><td><strong>${esc(c.name)}</strong></td><td>${esc(c.kind)}</td><td>${c.dps_modo?esc(String(c.dps_modo).replace(/^(SIM|NÃO) — /,(m,a)=>a==='SIM'?'Sim — ':'Não — ')):'<span class="muted">Automático</span>'}</td><td class="wrap-cell">${c.dps_ausente?'<span class="muted">—</span>':num(c.dps_modelo)}</td><td class="wrap-cell">${c.dps_montante_circuito?`${esc(c.dps_montante_circuito)}<small class="cell-sub">${esc(textOf(c.dps_montante))}</small>`:'<span class="muted">—</span>'}</td><td>${statusChip(c.dps_ausente?'N/A — sem DPS neste quadro':c.dps_status)}</td><td>↗</td></tr>`).join('')}</tbody></table></div></section><div class="notice">Sem escolha do projetista, a natureza do circuito decide o DPS (origem e distribuição recebem DPS; circuito final, não). Em <b>DPS neste quadro</b> é possível dispensar o DPS de um quadro ou fixar a classe; os quadros a jusante passam a coordenar com o DPS a montante mais próximo.</div>`;}
if(currentView==='audit'){
  const rowName=new Map(state.circuits.map(c=>[c.row,c.name]));
  const dependent=x=>isError(x.value)||/#VALUE|#N\/A|NÃO ENCONTRADO NA TABELA|Instalação pendente|sem resultado válido|Corrija a instalação/i.test(issueText(x.value));
  const issueRow=(c,x)=>`<button type="button" class="issue issue-row" data-edit="${esc(c.id)}" data-group="${esc(x.group||'')}"${x.focus?` data-focus="${esc(x.focus.sheet+'!'+x.focus.col)}"`:''}><b>${esc(x.label)}</b><span class="${/^✗/.test(issueText(x.value))||isError(x.value)?'error':''}">${esc(issueText(x.value))}</span><i aria-hidden="true">›</i></button>`;
  const item=c=>{const blocker=c.issues.find(x=>x.blocks);const dep=blocker?c.issues.filter(x=>x!==blocker&&dependent(x)):[];const shown=c.issues.filter(x=>!dep.includes(x));return `<div class="audit-item"><div class="audit-title"><h3>${esc(c.name)}</h3><div>${badge(c.status)} <button class="row-button" data-edit="${esc(c.id)}" data-group="${esc((c.issues[0]||{}).group||'')}">Abrir ↗</button></div></div>${shown.map(x=>issueRow(c,x)).join('')||'<p class="subtitle">Sem pendências nos indicadores consultados.</p>'}${dep.length?`<details class="issue-more"><summary>${dep.length} ${dep.length>1?'verificações dependem':'verificação depende'} da instalação — resolva o item acima primeiro</summary>${dep.map(x=>issueRow(c,x)).join('')}</details>`:''}</div>`;};
  const groups={};state.diagnostics.forEach(x=>{const r=Number((String(x.address).match(/\d+$/)||[])[0]);const n=rowName.get(r)||'Projeto';(groups[n]=groups[n]||[]).push(x);});
  main.innerHTML=heading('Verificações do projeto','Pendências identificadas pelas regras de dimensionamento do modelo. Clique em uma pendência para abrir o campo correspondente.',`<a class="btn" href="/report" target="_blank">Relatório ↗</a>`)+`<section class="panel">${state.circuits.map(item).join('')}</section>${state.diagnostics.length?`<details class="panel diag-panel"><summary><span>Diagnósticos técnicos do cálculo</span><span class="tag red">${state.diagnostics.length}</span><small>Erros em células intermediárias, quase sempre consequência das pendências acima. Úteis para auditar as fórmulas.</small></summary><div class="diag-body">${Object.entries(groups).map(([n,list])=>`<h4>${esc(n)} <span class="muted">(${list.length})</span></h4>${list.map(x=>`<p class="subtitle error-message"><button type="button" class="link-btn" data-cell="${esc(x.address)}" data-sheet="${esc(x.sheet)}">${esc(x.sheet)}!${esc(x.address)}</button> — ${esc(x.error)} ${esc(x.detail)}</p>`).join('')}`).join('')}</div></details>`:''}<div class="notice blue">Estas verificações reproduzem a lógica da planilha. A migração para Python não é uma validação independente da conformidade normativa do projeto.</div>`;}
if(currentView==='source'){main.innerHTML=heading('Entrada e fontes','Hierarquia: o Tipo de atendimento decide quais blocos participam do cálculo. Os demais ficam recolhidos, mas os dados continuam guardados.')+`<section class="panel"><div class="panel-head"><div><h2>Dados da instalação</h2><p>Modos e parâmetros da entrada de energia do projeto</p></div><span class="tag">Fonte</span></div><form id="source-form"><div id="source-fields">Carregando…</div><div class="form-actions"><p>Alterações recalculam os circuitos e reabrem as confirmações de proteção.</p><button class="btn primary" type="submit">Recalcular e salvar</button></div></form></section>`;const fields=await api('/api/source');$('#source-fields').innerHTML=sourceBlocksHTML(fields);refreshSourceHierarchy(fields,{forceToggle:true});$('#source-form')._fields=fields;$('#source-form').oninput=(e)=>{sourceDirty=true;const idx=indexFromElId(e.target.id,'source-');const f=idx>=0?fields[idx]:null;if(f&&f.block==='tipo')refreshSourceHierarchy(fields,{forceToggle:true});else if(f&&f.sheet==='Padrão de entrada'&&f.address==='B11')refreshSourceHierarchy(fields);};$('#source-form').onsubmit=e=>{e.preventDefault();action(async()=>{await api('/api/changes',{changes:collect(fields,'source-')});sourceDirty=false;await refresh();},'Fonte salva e cálculos atualizados.');};}
if(currentView==='sheets'){await renderCatalogView(main);}
if(currentView==='tables'){await renderTablesView(main);}
if(currentView==='coordination'){await renderCoordinationView(main);}
if(currentView==='compare'&&window.compareTab==='baseline'){await renderDivergencesView(main);}else if(currentView==='compare'){await renderIntegrityView(main);}
if(currentView==='installtables'){await renderInstallationTables(main);}
if(currentView==='history'){await renderHistoryView(main);}
if(currentView==='review'&&typeof renderReviewView==='function'){await renderReviewView(main);}
if(currentView==='overview'||currentView==='compare'){const ib=integrityBannerHTML();if(ib)$('.page-heading',main)?.insertAdjacentHTML('afterend',ib);}
if(currentView==='help'){main.innerHTML=heading('Como usar','Um projeto local, com motor de cálculo próprio, variáveis nomeadas e rastreabilidade de cada resultado.')+`<div class="help-grid"><section class="panel"><div class="panel-head"><h2>Do projeto ao resultado</h2></div><div class="panel-body prose"><ol><li><b>Revise a entrada.</b> Abra Entrada e fontes e configure atendimento, tensão, transformador e demais parâmetros.</li><li><b>Cadastre os circuitos.</b> Informe nome, montante, tipo de ligação e natureza. Qualquer circuito pode ser ligado diretamente à fonte ou ao transformador; ramal e medição são circuitos como os demais.</li><li><b>Preencha as cargas e cabos.</b> Use as potências por fase, fator de potência, comprimento, método e seções escolhidas.</li><li><b>Revise as proteções e DPS.</b> O modelo mantém as recomendações e as confirmações de catálogo separadas. Em <b>Dispositivos do trecho</b>, informe trechos sem disjuntor na origem e o disjuntor de manutenção na chegada do quadro; em <b>DPS neste quadro</b>, dispense ou fixe o DPS.</li><li><b>Confira a coordenação.</b> Em Coordenação, cada par de dispositivos aparece com o nível de evidência: verificado com dados do fabricante, aproximado ou pré-verificação.</li><li><b>Leia as verificações.</b> Corrija as pendências e exporte o projeto para backup ou o relatório para PDF.</li></ol><p><b>Comentários de revisão.</b> Cada aba (e cada etapa do formulário do circuito) tem, no fim, um bloco para anotar erros, dúvidas e melhorias do aplicativo. A aba <a href="#review">Comentários de revisão</a> reúne todos e exporta em Markdown para enviar na revisão do aplicativo. Os comentários não fazem parte do projeto nem alteram cálculos.</p></div></section><section class="panel"><div class="panel-head"><h2>Arquivos e salvamento</h2></div><div class="panel-body prose"><p>As alterações são salvas no computador quando você clica em <b>Salvar e recalcular</b>. O seletor lateral alterna entre projetos.</p><p><b>Exportar → Projeto editável</b> baixa um arquivo <code>.eletro</code> com os dados de entrada, as expressões e tabelas editadas e os dados de fabricante importados. Use Importar projeto para abri-lo em outro computador. Projetos da versão 1.x são convertidos automaticamente ao abrir, preservando fórmulas editadas e sinalizando as alteradas fora do aplicativo.</p><p><b>Histórico do projeto</b> guarda cada gravação como revisão: compare duas revisões ou restaure uma anterior (cria uma nova revisão). Se outra aba gravou antes, esta aba é avisada e nada é sobrescrito.</p><p><b>Importar quadro de cargas</b> lê CSV ou XLSX (e PDF ou imagem com a extração por IA, se habilitada), mostra a origem de cada valor e só grava depois da revisão. Fórmulas de planilhas importadas nunca são executadas.</p><p>O relatório abre em uma página pronta para impressão. Escolha <b>Salvar em PDF</b> no diálogo de impressão do navegador.</p></div></section><section class="panel"><div class="panel-head"><h2>Como o cálculo é feito</h2></div><div class="panel-body prose"><p>Cada cálculo é uma <b>variável com nome</b> (por exemplo <code>corrente.i_r_a</code>), unidade, expressão e dependências explícitas; o <b>Catálogo de cálculos</b> mostra a expressão, os dados usados, a justificativa normativa e o histórico de cada uma. As regras implementadas em Python aparecem no mesmo catálogo.</p><p>As tabelas técnicas formam a <b>Base técnica</b>: cada tabela indica fonte, edição, revisão e condições de uso. Edições de expressões e tabelas são feitas pelo revisor, com justificativa, e bloqueadas se criarem erros nos resultados obrigatórios.</p><p>Ao abrir um projeto, a <b>Integridade</b> confere se as expressões e tabelas gravadas conferem com o modelo e com o selo das edições registradas.</p></div></section><section class="panel"><div class="panel-head"><h2>Limites desta versão</h2></div><div class="panel-body prose"><p>Não há limite fixo de circuitos; o tempo de recálculo cresce com a quantidade (da ordem de 0,1 s por circuito no recálculo completo). Circuitos são identificados por um identificador próprio, e não pela posição.</p><p>Um circuito sem montante precisa ser vinculado para que os resultados de alimentação sejam interpretados.</p><p>O cálculo não constitui certificação normativa independente. As tabelas de norma trazem localizadores (item e tabela) e devem ser conferidas contra a edição vigente; a recomendação de dispositivos não substitui a conferência dos dados e curvas do fabricante.</p></div></section></div>`;}
}
function filterCircuits(){const q=$('#circuit-search').value.toLowerCase(),f=$('#circuit-filter').value;const cs=state.circuits.filter(c=>(!q||[c.name,c.description,c.parent].join(' ').toLowerCase().includes(q))&&(!f||(f==='issues'?c.status!=='ok':c.kind===f)));$('#circuits-list').innerHTML=circuitTable(cs);}
function groundingSVG(scheme){const s=String(scheme||'');const isC=s==='TN-C';const w=330,h=108;const labelColor='#5a747f';const phase='#3a4650',neutral='#3568b0',pe='#3a8f52',pen='#7a8f3a';
const wire=(x1,y1,x2,y2,color,dash='')=>`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color}" stroke-width="2.4" ${dash?`stroke-dasharray="${dash}"`:''}/>`;
const gnd=(x,y)=>`<line x1="${x-9}" y1="${y}" x2="${x+9}" y2="${y}" stroke="#788e94" stroke-width="2"/><line x1="${x-6}" y1="${y+4}" x2="${x+6}" y2="${y+4}" stroke="#788e94" stroke-width="2"/><line x1="${x-3}" y1="${y+8}" x2="${x+3}" y2="${y+8}" stroke="#788e94" stroke-width="2"/>`;
const src=`<rect x="4" y="18" width="46" height="72" rx="4" fill="#eef4f5" stroke="#c4d3d6"/><text x="27" y="58" font-size="9" fill="${labelColor}" text-anchor="middle">Fonte</text>`;
const load=`<rect x="${w-50}" y="18" width="46" height="72" rx="4" fill="#eef4f5" stroke="#c4d3d6"/><text x="${w-27}" y="54" font-size="9" fill="${labelColor}" text-anchor="middle">Carga</text><text x="${w-27}" y="65" font-size="8" fill="${labelColor}" text-anchor="middle">(massa)</text>`;
let mid='';
const xs=50,xl=w-50;
if(!isC){
  mid=[wire(xs,28,xl,28,phase),wire(xs,40,xl,40,phase),wire(xs,52,xl,52,phase),
       wire(xs,66,xl,66,neutral),wire(xs,80,xl,80,pe)].join('')+
      `<text x="${w/2}" y="24" font-size="7.5" fill="${phase}" text-anchor="middle">F1·F2·F3</text>`+
      `<text x="${w/2}" y="63" font-size="7.5" fill="${neutral}" text-anchor="middle">N</text>`+
      `<text x="${w/2}" y="77" font-size="7.5" fill="${pe}" text-anchor="middle">PE</text>`+
      gnd(xs-4,80)+gnd(xl+4,80)+gnd(xl+4,66);
}else{
  mid=[wire(xs,28,xl,28,phase),wire(xs,40,xl,40,phase),wire(xs,52,xl,52,phase),
       wire(xs,73,xl,73,pen)].join('')+
      `<text x="${w/2}" y="24" font-size="7.5" fill="${phase}" text-anchor="middle">F1·F2·F3</text>`+
      `<text x="${w/2}" y="86" font-size="7.5" fill="${pen}" text-anchor="middle">PEN (condutor único)</text>`+
      gnd(xs-4,73)+gnd(xl+4,73);
}
return `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Esquema ${esc(s)}" style="display:block;width:100%;max-width:${w}px;height:auto">${src}${mid}${load}</svg>`;}
function fieldHTML(f,id,extraClass=''){const v=isError(f.value)?f.value.error:f.value??'';const numeric=f.numeric||typeof v==='number';const disabled=f.disabled?' disabled':'';const hidden=f.hidden||f.needed===false?' hidden':'';const labelFor=f.option_labels||{};let control;if(f.formula)control=`<output id="${id}">${num(f.value,5)}</output>`;else if(f.options?.length||f.installation_key&&f.strict){const known=new Set(f.options.map(String));const isCustom=!f.strict&&v!==''&&v!==null&&!known.has(String(v));const customAttr=f.strict?'':' data-has-custom="1"';control=`<select id="${id}" data-type="${numeric?'number':'text'}"${customAttr}${disabled}><option value="">${esc(f.empty_label||(f.address.startsWith('D')&&f.sheet==='Identificação dos circuitos'?'Desvinculado':'Não informado'))}</option>${[...new Set(f.options)].filter(x=>x!==''&&x!==null).map(x=>`<option value="${esc(x)}" ${!isCustom&&String(x)===String(v)?'selected':''}>${esc(labelFor[String(x)]||x)}</option>`).join('')}${f.strict&&v!==''&&v!==null&&!known.has(String(v))?`<option value="${esc(v)}" selected data-incompat="1">${esc(v)} (incompatível com as escolhas atuais)</option>`:''}${f.strict?'':`<option value="__custom__" ${isCustom?'selected':''}>Outro (digitar manualmente)…</option>`}</select>${f.strict?'':`<input id="${id}-custom" class="custom-value" value="${esc(v)}" placeholder="Digite o valor" ${isCustom?'':'hidden'} autocomplete="off">`}`;}else if(f.textarea||typeof v==='string'&&v.length>80||f.address.startsWith('C')&&f.sheet==='Identificação dos circuitos')control=`<textarea id="${id}" data-type="text">${esc(v)}</textarea>`;else{const sp=numeric&&f.spec?f.spec:null;const attrs=sp?['step','min','max','decimals'].filter(k=>sp[k]!==undefined&&sp[k]!==null).map(k=>` data-${k}="${esc(sp[k])}"`).join('')+(sp.integer?' data-integer="1"':''):'';control=`<input id="${id}" value="${esc(numeric&&typeof v==='number'?formatBR(v):numeric?String(v).replace('.',','):v)}" data-type="${numeric?'number':'text'}"${attrs} ${numeric?(sp&&sp.integer?'inputmode="numeric"':'inputmode="decimal"'):''} autocomplete="off"${sp&&sp.unit?` aria-describedby="${id}-unit"`:''}>${sp&&sp.unit?`<span class="field-unit" id="${id}-unit">${esc(sp.unit)}</span>`:''}`;}const wide=String(f.label).length>100||typeof v==='string'&&v.length>100;const hint=(f.hint?`<div class="field-note">${esc(f.hint)}</div>`:'')+(f.pending_list?`<div class="field-hint">△ A lista desta planilha depende de outra seleção acima, ainda não preenchida ou sem correspondência. Informe o valor manualmente por enquanto.</div>`:'');return `<div class="field ${wide?'wide':''} ${extraClass}"${hidden}><label for="${id}">${esc(String(f.label).replace(/\s*\[.*?\]/gs,''))}</label>${control}${hint}${f.virtual?'<div class="field-address"><small>Dado do projeto</small></div>':`<div class="field-address"><small class="mono" title="Variável do modelo">${esc(f.var||f.address)}${f.unit?' · '+esc(f.unit):''}${f.formula?' · calculado':''}</small><button type="button" class="${f.formula?'trace-btn':''}" data-cell="${esc(f.address)}" data-sheet="${esc(f.sheet)}" title="${f.formula?'Ver fórmula, precedentes e valores':'Ver origem do dado'}">${f.formula?'🔍 Ver cálculo':'Origem ↗'}</button></div>`}</div>`;}
// Reenviar um valor já salvo (mesmo texto, mesmo número) nunca precisa passar
// pelo parser numérico — isso cobre overrides textuais legítimos em colunas
// marcadas como numéricas mas sem lista nativa (ex.: "N/A" em Cálc-Prot_Cabos!BX,
// herdado do próprio arquivo de referência), que travavam "Salvar" mesmo sem
// nenhuma edição real nesse campo.
function collect(fields,prefix){const changes=[];fields.forEach((f,i)=>{if(f.formula||f.workflowIgnore)return;const el=$('#'+prefix+i);if(!el)return;let v;if(el.tagName==='SELECT'&&el.dataset.hasCustom&&el.value==='__custom__'){const custom=$('#'+prefix+i+'-custom');v=(custom?.value??'').trim();}else{v=el.value.trim();}const baseline=f.value??null;if(v===''){v=null;}else if(String(v)===String(baseline)){v=baseline;}else if(f.installation_key==='method'){v=/^\d+$/.test(v)?Number(v):v;}else if(el.dataset.type==='number'&&v.toUpperCase()!=='N/A'){const n=parseBR(v);const lab=String(f.label).replace(/\s*\[.*?\]/gs,'').trim();if(!Number.isFinite(n))throw Error(`${lab}: informe um número (ex.: 1.000,50 ou 2,5).`);if(el.dataset.integer==='1'&&!Number.isInteger(n))throw Error(`${lab}: informe um número inteiro.`);if(el.dataset.min!==undefined&&n<Number(el.dataset.min))throw Error(`${lab}: o mínimo é ${formatBR(Number(el.dataset.min))}.`);if(el.dataset.max!==undefined&&n>Number(el.dataset.max))throw Error(`${lab}: o máximo é ${formatBR(Number(el.dataset.max))}.`);v=n;}if(v!==(f.value??null))changes.push({sheet:f.sheet,address:f.address,value:v});});return changes;}
function indexFromElId(id,prefix){const m=new RegExp('^'+prefix+'(\\d+)').exec(id||'');return m?Number(m[1]):-1;}
// Lê o valor ATUAL (não salvo) de um campo já montado no DOM — select com escape
// hatch ou input simples. Serve tanto para o formulário do circuito (#field-N)
// quanto para Entrada e fontes (#source-N): o id do elemento já diz qual é.
function liveValue(idx,prefix){if(idx<0)return null;const el=$('#'+prefix+idx);if(!el)return null;let v;if(el.tagName==='SELECT'&&el.dataset.hasCustom&&el.value==='__custom__'){const custom=document.getElementById(el.id+'-custom');v=(custom?.value??'').trim();}else{v=el.value.trim();}return v===''?null:v;}
let installationPreviewTicket=0;let groupingDirty=false;
async function refreshInstallationPreview(fields,reconcile=false){
  if(!drawerData?.id)return;
  const data=drawerData,ticket=++installationPreviewTicket;
  try{
    const changes=collect(fields,'field-');
    const result=await api('/api/installation/preview',{id:data.id,changes,reconcile,settings:data.installation?.settings||{}});
    if(ticket!==installationPreviewTicket||drawerData!==data)return;
    data.installation=result;
    fields.forEach((f,i)=>{
      const key=f.installation_key;if(!key)return;
      const options=result.options?.[key];
      f.hidden=key==='temperature_soil'||key==='soil'?!result.underground:key==='temperature_air'?result.underground:key==='circuits';
      const el=document.getElementById('field-'+i);if(!el)return;
      el.closest('.field').hidden=!!f.hidden;
      if(!Array.isArray(options))return;
      f.options=options;f.disabled=!options.length;
      const current=reconcile?result.values[key]:liveValue(i,'field-');
      const labels=installationOptionLabels(key,result);
      f.option_labels=labels;
      if(el.tagName==='SELECT'){
        const incompat=current!=null&&current!==''&&!options.some(x=>String(x)===String(current));
        el.innerHTML='<option value="">Não informado</option>'+options.map(x=>`<option value="${esc(x)}">${esc(labels[String(x)]||x)}</option>`).join('')+(incompat?`<option value="${esc(current)}">${esc(current)} (incompatível)</option>`:'');
        el.value=current??'';el.disabled=!options.length;el.classList.toggle('incompat',incompat);
      }
    });
    renderInstallationChoices(fields);
    if(window.renderGrouping)window.renderGrouping();
    renderInstallationGeometry(result);
    return result;
  }catch(error){if(ticket===installationPreviewTicket)toast(error.message,true);return null;}
}
// Preenche um campo já montado a partir de sheet+coluna (mesmo casamento usado por
// drawerData.fields), incluindo o caso do select com "Outro (digitar manualmente)…".
// Usada tanto pelos cliques na galeria de métodos quanto pelo preenchimento do
// assistente (fillAdvisorField), que foi refeito por cima desta função.
function setFieldValue(fields,sheet,col,value,prefix){const idx=fields.findIndex(f=>f.address.startsWith(col)&&f.sheet===sheet);if(idx<0)return false;const el=$('#'+prefix+idx);if(!el)return false;if(el.tagName==='SELECT'&&el.dataset.hasCustom){const hasOpt=[...el.options].some(o=>o.value===String(value));el.value=hasOpt?String(value):'__custom__';const custom=document.getElementById(el.id+'-custom');if(custom){custom.hidden=hasOpt;if(!hasOpt)custom.value=value;}}else{el.value=value;}el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));return true;}
// Espelho mínimo e só-cosmético de Identificação-Método_Instal!D
// (=IF(B∈{13,14,15,16},B&"_"&C,B)) — usado apenas para destacar a foto
// correspondente na galeria e para decidir o aviso de Condutores ANTES de salvar.
// O valor autoritativo continua sendo recalculado pelo motor no servidor após
// "Salvar"; isto nunca decide validação, só qual foto acende.
function computeMetodoCodigo(bVal,cVal){if(bVal===null||bVal===undefined||bVal==='')return null;const b=String(bVal);return['13','14','15','16','17'].includes(b)?(cVal?`${b}_${cVal}`:null):b;}
function initialMetodoCodigo(metodoGroup){const bF=metodoGroup.fields.find(f=>f.address.startsWith('B'));const cF=metodoGroup.fields.find(f=>f.address.startsWith('C'));return computeMetodoCodigo(bF&&!isError(bF.value)?bF.value:null,cF&&!isError(cF.value)?cF.value:null);}
// Caminho inverso: a partir do código clicado na galeria, decide o que gravar em
// B (número/código do método) e, quando aplicável, em C (tipo de condutor).
// Duas formas reais no catálogo da r42 (ver data/metodos_instalacao.json):
//  - "<base>_Cabo unipolar" / "<base>_Cabo multipolar" (métodos 13/14/15/16):
//    a fórmula é D = B&"_"&C, então B recebe só a base e C recebe o sufixo.
//  - qualquer outro código (ex.: "3", "11A", "21_1,5-5De"): D = B (passthrough),
//    então B recebe o código inteiro, verbatim, e C não é alterado.
// (O código "17_unipolar", com erro de digitação herdado da planilha original,
// foi corrigido na própria base de dados para "17_Cabo unipolar" — o regex
// abaixo já cobre esse caso sem exceção especial.)
function resolveMethodClick(codigo){const m=/^(.+)_Cabo (unipolar|multipolar)$/.exec(codigo);if(m)return{b:m[1],c:'Cabo '+m[2]};return{b:codigo,c:null};}
async function ensureMethodData(){if(!methodCatalog){methodCatalog=await api('/api/metodos');methodCatalogByCode=Object.fromEntries(methodCatalog.map(m=>[m.codigo,m]));}if(!linhasMetodoMapa)linhasMetodoMapa=await api('/api/metodos-linha');}
// Espelho, só-cosmético (mesma ressalva de computeMetodoCodigo), do agrupamento
// TIPOS_POR_NUMERO em core/project.py: reúne, a partir do catálogo já carregado
// (methodCatalog, cada item com .tipos), quais Tipos de condutor a Tabela 33
// permite para o NÚMERO de método atual — unindo as variantes por tipo (13-17)
// e por faixa De (ex.: "21_1,5-5De"/"21_5-50De", que sempre compartilham os
// mesmos tipos). Decide, ao vivo, a galeria de Ajuste e a restrição de C; o
// valor autoritativo continua sendo recalculado no servidor após "Salvar".
function tiposForMetodoNumero(bVal){
  if(bVal===null||bVal===undefined||bVal==='')return[];
  const base=String(bVal),list=[];
  (methodCatalog||[]).forEach(m=>{
    const combo=/^(.+)_Cabo (unipolar|multipolar)$/.exec(m.codigo);
    const deRange=/^(.+)_[\d,]+-[\d,]+De$/.exec(m.codigo);
    const mb=combo?combo[1]:deRange?deRange[1]:m.codigo;
    if(mb===base)(m.tipos||[]).forEach(t=>{if(!list.includes(t))list.push(t);});
  });
  return list;
}
// Restringe, ao vivo, o <select> de Tipo de condutor (C) aos tipos que a Tabela
// 33 permite para o Método (B) atualmente selecionado — nunca removendo opções
// (Seção 30) e NUNCA sobrescrevendo um valor já existente sozinho (Seção 34:
// a escolha do usuário/dado já salvo não é trocada em silêncio, mesmo quando
// está desatualizada em relação ao método atual — só avisa). O preenchimento
// automático de C para o único tipo possível de um método sem ambiguidade
// acontece exclusivamente no clique da própria galeria de Método (ali, sim, é
// o usuário fazendo uma escolha nova) — ver o onclick de .method-tile abaixo;
// esta função só disputa estado já existente, nunca escreve nele.
function applyTipoCondutorRestriction(fields){
  const bIdx=fields.findIndex(f=>f.sheet==='Identificação-Método_Instal '&&f.address.startsWith('B'));
  const cIdx=fields.findIndex(f=>f.sheet==='Identificação-Método_Instal '&&f.address.startsWith('C'));
  if(cIdx<0)return;
  const el=document.getElementById('field-'+cIdx);
  const hintId='field-'+cIdx+'-tipo-hint';
  let hint=document.getElementById(hintId);
  if(!el||el.tagName!=='SELECT'){if(hint)hint.remove();return;}
  if(!hint){hint=document.createElement('div');hint.className='field-hint';hint.id=hintId;el.insertAdjacentElement('afterend',hint);}
  const tipos=tiposForMetodoNumero(liveValue(bIdx,'field-'));
  if(!tipos.length){[...el.options].forEach(o=>o.disabled=false);hint.textContent='';return;}
  [...el.options].forEach(o=>{if(o.value===''||o.value==='__custom__')return;o.disabled=!tipos.includes(o.value);});
  const cur=liveValue(cIdx,'field-');
  if(cur&&!tipos.includes(cur)&&el.value!=='__custom__'){
    hint.textContent=`✗ "${cur}" não é compatível com o método atual (Tabela 33 · NBR 5410). Permitidos: ${tipos.join(', ')}.`;
  }else{
    hint.textContent=tipos.length>1?`Compatíveis com o método atual: ${tipos.join(', ')}.`:'';
  }
}
// Ícones ilustrativos (SVG desenhado, não-normativo — mesma ressalva de
// groundingSVG) para a galeria de Ajuste requerido para este método. A Tabela
// 33 só pede ESTE ajuste para os métodos de referência F (leito/suporte/
// bandeja perfurada: justapostos x trifólio) e G (sobre isoladores: horizontal
// x vertical); fora disso H só pode ser "N/A" e a galeria nem aparece.
const AJUSTE_ICONS={
  'Justapostos':'<svg viewBox="0 0 64 34" aria-hidden="true"><circle cx="20" cy="20" r="9" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="32" cy="20" r="9" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="44" cy="20" r="9" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
  'Trifólio':'<svg viewBox="0 0 64 34" aria-hidden="true"><circle cx="32" cy="11" r="9" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="24.4" cy="25" r="9" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="39.6" cy="25" r="9" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
  'Horizontal':'<svg viewBox="0 0 64 34" aria-hidden="true"><line x1="8" y1="24" x2="56" y2="24" stroke="currentColor" stroke-width="2"/><circle cx="16" cy="16" r="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="32" cy="16" r="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="48" cy="16" r="5" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
  'Vertical':'<svg viewBox="0 0 64 34" aria-hidden="true"><line x1="20" y1="4" x2="20" y2="30" stroke="currentColor" stroke-width="2"/><circle cx="28" cy="8" r="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="28" cy="17" r="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="28" cy="26" r="5" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
};
function ajusteOpcoesParaLetra(letra){if(letra==='F')return['Justapostos','Trifólio'];if(letra==='G')return['Horizontal','Vertical'];return[];}
// Partida de motores: X (parâmetro do método, %) só faz sentido para
// Soft-starter/Inversor/Reator — Direta e Estrela-triângulo têm fator fixo,
// sem parâmetro do projetista. Mantém o valor salvo intacto (Seção 34): só
// habilita/desabilita visualmente e troca para "N/A" quando o próprio método
// muda para um dos dois sem parâmetro (nunca ao abrir o circuito sem clique).
const METODOS_COM_PARAMETRO=new Set(['Soft-starter','Inversor de frequência','Reator série']);
function applyPartidaRestriction(fields,fromUserChange){
  const wIdx=fields.findIndex(f=>f.sheet==='ΔV_Partida_Motores'&&f.address.startsWith('W'));
  const xIdx=fields.findIndex(f=>f.sheet==='ΔV_Partida_Motores'&&f.address.startsWith('X'));
  if(wIdx<0||xIdx<0)return;
  const w=liveValue(wIdx,'field-');const xEl=document.getElementById('field-'+xIdx);
  if(!xEl)return;
  const precisa=METODOS_COM_PARAMETRO.has(w);
  xEl.disabled=!precisa;
  if(fromUserChange){
    if(!precisa&&xEl.value!=='N/A')setFieldValue(fields,'ΔV_Partida_Motores','X','N/A','field-');
    else if(precisa&&xEl.value==='N/A')setFieldValue(fields,'ΔV_Partida_Motores','X','','field-');
  }
  let hint=document.getElementById('field-'+xIdx+'-partida-hint');
  if(!hint){hint=document.createElement('div');hint.className='field-hint';hint.id='field-'+xIdx+'-partida-hint';xEl.closest('.field').appendChild(hint);}
  hint.textContent=precisa?'% de tensão aplicada ao motor na partida (soft-starter/reator) ou limite de corrente configurado (inversor), relativo à partida direta.':'Este método tem fator fixo pela própria topologia — não há parâmetro a ajustar.';
}
// Painel-resumo (estático, a partir dos valores já salvos): compara a pior
// hipótese (M, partida direta) com o resultado do método efetivamente
// escolhido (AB) — não recalcula nada, só lê os campos já carregados.
function partidaResumoHTML(fields){
  // O número da linha vem de qualquer campo do grupo — usa W como referência.
  const wField=fields.find(f=>f.address.startsWith('W'));
  if(!wField)return'';
  const row=wField.address.match(/\d+$/)[0];
  const g=addr=>{const f=fields.find(x=>x.address===addr+row);return f?f.value:null;};
  const mVal=g('M'),abVal=g('AB'),acVal=g('AC'),adVal=g('AD'),aeVal=g('AE'),yVal=g('Y'),metodo=g('W');
  if(mVal==null||mVal===''||isError(mVal))return'<div class="cascade-aviso">Nenhum motor identificado neste circuito ou a jusante dele — o método de partida não se aplica. Informe a potência (cv) em "Cargas por fase e motores" caso este circuito alimente um motor.</div>';
  // Método escolhido precisa de parâmetro (Soft-starter/Inversor/Reator) mas o
  // campo abaixo (X) ainda está vazio: Y/Z já sinalizam "⏳ PENDENTE" e toda a
  // cadeia AA/AB/AC/AD fica em branco — mostrar isso como um aviso claro em
  // vez de uma grade com travessões, que pareceria um erro de cálculo.
  const pendente=typeof yVal==='string'&&yVal.includes('PENDENTE');
  const tagClass=v=>typeof v==='string'&&v.includes('✓')?'green':typeof v==='string'&&(v.includes('✗')||v.includes('EXCEDE'))?'red':'amber';
  return `<div class="method-cascade" id="partida-resumo"><div class="cascade-label">Partida direta (pior caso) × método escolhido</div>
    <div class="secoes-grid partida-grid">
      <div class="secao-bloco"><h4>Partida direta (referência)</h4><table class="data-table compact"><tbody>
        <tr><td>ΔV_partida total</td><td class="num">${num(mVal,2)}${typeof mVal==='number'?'%':''}</td></tr>
      </tbody></table></div>
      <div class="secao-bloco"><h4>Com método: ${esc(metodo||'—')}</h4>${pendente?'<div class="field-hint">Informe o parâmetro do método (%) logo abaixo para calcular a partida com este método.</div>':`<table class="data-table compact"><tbody>
        <tr><td>ΔV_partida total</td><td class="num">${num(abVal,2)}${typeof abVal==='number'?'%':''}</td></tr>
      </tbody></table><span class="tag ${tagClass(acVal)}">Rede: ${esc(String(acVal??'—'))}</span> <span class="tag ${tagClass(adVal)}">Motor: ${esc(String(adVal??'—'))}</span>`}</div>
    </div>
    ${!pendente&&aeVal?`<div class="cascade-aviso ${typeof aeVal==='string'&&aeVal.includes('⚠')?'':'aviso-ok'}">${esc(aeVal)}</div>`:''}
  </div>`;
}
function ajusteGalleryHTML(opcoes,atual){
  if(!opcoes||!opcoes.length)return '<div id="ajuste-cascade" hidden></div>';
  const tiles=opcoes.map(o=>`<button type="button" class="method-tile ajuste-tile ${o===atual?'active':''}" data-ajuste="${esc(o)}" aria-pressed="${o===atual}">${AJUSTE_ICONS[o]||''}<span>${esc(o)}</span></button>`).join('');
  return `<div class="method-cascade" id="ajuste-cascade"><div class="cascade-label">Ajuste requerido para este método · clique na imagem para escolher</div><div class="method-gallery clickable ajuste-gallery">${tiles}</div></div>`;
}
function methodTileHTML(m,active){const img=m.imagem?`<img src="/${esc(m.imagem)}" alt="" loading="lazy">`:'<div class="method-tile-noimg">Sem imagem cadastrada</div>';return `<button type="button" class="method-tile ${active?'active':''}" data-codigo="${esc(m.codigo)}" aria-pressed="${active}" title="${esc(m.descricao||'')}">${img}<b>${esc(m.numero||String(m.codigo).split("_")[0])} · ${esc(m.letra||"—")}</b><span>${esc(short(m.descricao||m.codigo,78))}</span></button>`;}
function metodoCascadeHTML(linha,codigoAtual){
 const compat=linhasMetodoMapa?.[normalizeInstallation(linha)];
 const tiles=compat?(compat.codigos_imagem||[]).map(c=>methodCatalogByCode?.[c]).filter(Boolean).map(m=>methodTileHTML(m,m.codigo===codigoAtual)).join(''):'';
 const body=!linha?'Selecione o tipo de linha elétrica para escolher a montagem.':!compat?'Tipo de instalação não reconhecido. Selecione uma opção da lista; nenhum método foi liberado.':'';
 // v2.2.0 (C12): notas da Tabela 33 que se aplicam ao método escolhido.
 const sel=!body&&codigoAtual?methodCatalogByCode?.[codigoAtual]:null;
 const notas=sel?.notas?.length?`<div class="cascade-aviso nota-norma"><b>NBR 5410, Tabela 33 — método ${esc(sel.numero||String(sel.codigo).split('_')[0])}</b><ul>${sel.notas.map(n=>`<li>${esc(n)}</li>`).join('')}</ul></div>`:'';
 return `<div class="method-cascade" id="metodo-cascade"><div class="cascade-label">Instalação → montagem → tipo de cabo</div>${body?`<div class="cascade-aviso">${esc(body)}</div>`:`<div class="method-gallery clickable">${tiles}</div>`}${notas}<div class="cascade-foot"><button type="button" class="btn small" id="browse-methods">Consultar tabelas e métodos</button></div></div>`;
}
function cabosAvisoHTML(codigoAtual){return `<div id="cabos-aviso">${codigoAtual?'':'<div class="cascade-aviso">⚠ Selecione primeiro o Método de instalação para liberar as opções de isolação, material e afastamento dos condutores.</div>'}</div>`;}
// Comparação de critérios de dimensionamento (Seção escolhida): mostra, lado a
// lado, cada critério já calculado pela r42 (ampacidade, queda de tensão, Icc,
// seção mínima, concessionária), a MAIOR seção entre eles (o piso técnico) e a
// seção que o projetista escolheu — igual ao que a planilha original já
// calculava, só que nunca exposto de forma comparativa. Puramente informativo:
// não decide nada por conta própria, só ajuda a enxergar o maior critério e
// avisa (com a cor do próprio "*: seção OK?" da r42) quando a escolha ficou
// abaixo de algum cálculo.
function mTrace(t){return t?`<button type="button" class="trace-btn mini" data-cell="${esc(t.address)}" data-sheet="${esc(t.sheet)}" title="Ver cálculo" aria-label="Ver cálculo">🔍</button>`:'';}
function secoesComparacaoHTML(blocos,aviso){
  if(!blocos||!blocos.length)return'';
  const okClass=v=>typeof v==='string'&&v.includes('✓')?'green':typeof v==='string'&&(v.includes('✗')||v.includes('PENDENTE'))?'red':'amber';
  const blocosHTML=blocos.map(b=>{
    const tr=(sheet,addr)=>sheet&&addr?` <button type="button" class="trace-btn mini" data-cell="${esc(addr)}" data-sheet="${esc(sheet)}" title="Ver cálculo" aria-label="Ver cálculo">🔍</button>`:'';
    const crit=b.criterios.map(c=>`<tr><td>${esc(c.label)}</td><td class="num">${num(c.value,1)}${tr(c.sheet,c.address)}</td></tr>`).join('');
    const abaixo=typeof b.maior==='number'&&typeof b.escolhida==='number'&&b.escolhida<b.maior;
    return `<div class="secao-bloco"><h4>${esc(b.nome)}</h4><table class="data-table compact"><tbody>${crit}
      <tr class="secao-maior"><td><b>Maior seção calculada</b></td><td class="num"><b>${num(b.maior,1)}</b>${b.enderecos?tr(b.enderecos.sheet,b.enderecos.maior):''}</td></tr>
      ${b.reduzida!=null&&b.reduzida!==b.maior?`<tr><td>Seção com redução admitida</td><td class="num">${num(b.reduzida,1)}</td></tr>`:''}
      <tr class="secao-escolhida"><td>Seção escolhida</td><td class="num">${num(b.escolhida,1)}</td></tr>
      </tbody></table><span class="tag ${okClass(b.ok)}">${esc(String(b.ok??'—'))}</span>${abaixo?`<div class="cascade-aviso">✗ A seção escolhida (${num(b.escolhida,1)} mm²) é menor que a maior seção calculada (${num(b.maior,1)} mm²) entre os critérios acima.</div>`:''}</div>`;
  }).join('');
  return `<div class="method-cascade" id="secoes-comparacao"><div class="cascade-label">Critérios de dimensionamento · a maior seção entre eles orienta a escolha</div>${aviso?`<div class="cascade-aviso">✗ ${esc(aviso)}</div>`:''}<div class="secoes-grid">${blocosHTML}</div></div>`;
}
async function ensureProtecaoData(){if(!protecaoCatalog){const d=await api('/api/protecao-catalogo');protecaoCatalog=d.catalogo;protecaoCatalogByModelo=Object.fromEntries(protecaoCatalog.map(m=>[m.modelo,m]));protecaoFamiliasPorClasse=d.familias_por_classe;protecaoFusivelOpcoes=d.fusivel_opcoes;}}
// Painel-resumo (estático, a partir dos valores já salvos — mesma ressalva de
// partidaResumoHTML/secoesComparacaoHTML: não recalcula nada). Destaca o
// status final (BJ/CG, Seção 25/30 — nunca um "aprovado geral" escondendo
// falhas) e, lado a lado, a faixa de ajuste permitida pelo catálogo (AP-AU)
// junto do valor adotado pelo projetista (Y/Z) — é exatamente o "parâmetro de
// ajuste exibido para orientar a escolha" pedido.
function protecaoResumoHTML(g){
  const fields=g.fields;
  const ref=fields.find(f=>f.address.match(/^[A-Z]+\d+$/));
  if(!ref)return'';
  const row=ref.address.match(/\d+$/)[0];
  const v=addr=>{const f=fields.find(x=>x.address===addr+row);return f?f.value:null;};
  const statusClass=s=>typeof s==='string'&&s.includes('✓')?'green':typeof s==='string'&&(s.includes('✗')||s.includes('SEM MODELO')||s.includes('PENDENTE'))?'red':'amber';
  const bj=v('BJ'),cg=v('CG'),dn=v('DN'),am=v('AM');
  const mi=g.modelo_info;
  // Passo (AT/AU): texto descritivo p/ modelo fixo ("Fixo (Ir=In, sem
  // ajuste)") ou lista "160|180|...|400" p/ ajustável — nesse segundo caso
  // troca o "|" interno por ", " + unidade, só pra leitura; o valor que
  // realmente vira <select> em Y/Z é a mesma string, dividida em protecao().
  const passoLegivel=passo=>typeof passo==='string'&&passo.includes('|')?passo.split('|').map(x=>x.trim()).join(' | ')+' A':String(passo??'—');
  // AC/AD (Ib≤Ir≤Iz? / Ii≥1,2×Ip?) vêm como booleano puro do motor, não como
  // texto "✓ OK" já formatado (diferente da maioria dos outros status desta
  // planilha) — sem isto o tag mostraria literalmente "true"/"false".
  const tagLabel=v=>typeof v==='boolean'?(v?'✓ Atende':'✗ Não atende'):String(v??'—');
  const faixa=(adotado,min,max,passo,tagVal)=>`<table class="data-table compact"><tbody>
      <tr><td>Faixa permitida (catálogo)</td><td class="num">${num(min,1)} – ${num(max,1)} A</td></tr>
      <tr><td>Passo de ajuste</td><td class="wrap-cell">${esc(passoLegivel(passo))}</td></tr>
      <tr class="secao-escolhida"><td>Adotado pelo projetista</td><td class="num">${num(adotado,1)} A</td></tr>
    </tbody></table>${tagVal!=null?`<span class="tag ${statusClass(tagLabel(tagVal))}">${esc(tagLabel(tagVal))}</span>`:''}`;
  const modeloBloco=mi?`<div class="secao-bloco"><h4>Modelo selecionado · ${esc(am||'—')}</h4><table class="data-table compact"><tbody>
      <tr><td>Frame</td><td>${esc(String(mi.frame??'—'))}</td></tr>
      <tr><td>Disparador</td><td>${esc(mi.disparador||'—')}</td></tr>
      <tr><td>Icu / Ics (catálogo)</td><td>${esc(String(mi.icu??'—'))} / ${esc(String(mi.ics??'—'))}</td></tr>
    </tbody></table></div>`:'';
  const aj=(g.ajustes_problemas||[]).length?`<div class="cascade-aviso ajustes-aviso" role="alert"><b>Ajustes fora do catálogo do fabricante.</b><ul>${g.ajustes_problemas.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>O servidor não grava ajustes inexistentes no equipamento. Escolha uma posição válida abaixo.</div>`:'';
  return `<div class="method-cascade" id="protecao-resumo"><div class="cascade-label">Status final da proteção (fórmula única, não editável)</div>
    <span class="tag ${statusClass(bj)}">${esc(String(bj??'—'))}</span>${aj}
    ${cg?`<div class="cascade-aviso ${statusClass(cg)==='green'?'aviso-ok':''}">${esc(String(cg))}</div>`:''}
    ${dn&&am&&dn!==am?`<div class="cascade-aviso">Modelo efetivamente usado pelo cálculo (conforme "Comando de seleção"): <b>${esc(String(dn))}</b>.</div>`:''}
    <div class="secoes-grid">
      ${modeloBloco}
      <div class="secao-bloco"><h4>Ajuste de Ir (térmico/sobrecarga)</h4>${faixa(v('Y'),v('AP'),v('AQ'),v('AT'),v('AC'))}</div>
      <div class="secao-bloco"><h4>Ajuste de Ii/Im (magnético/curto)</h4>${faixa(v('Z'),v('AR'),v('AS'),v('AU'),v('AD'))}</div>
    </div>
  </div>`;
}
// Recalcula e reencaixa a galeria de Método e o aviso de Condutores a partir dos
// valores AO VIVO (ainda não salvos) de Instalação/Método — chamada após montar o
// formulário e após qualquer clique/edição que mude esses campos. Reatribui os
// cliques a cada chamada porque outerHTML descarta os listeners antigos.
function refreshCascade(fields,reconcile=true){renderInstallationChoices(fields);return refreshInstallationPreview(fields,reconcile);}
async function editCircuit(id,group,focus){if(dirty&&!confirm('Descartar as alterações ainda não salvas?'))return;busy(true,'Abrindo circuito…');try{protecaoClasseEscolhida=null;const[data]=await Promise.all([api('/api/form?id='+encodeURIComponent(id)),ensureMethodData(),ensureProtecaoData()]);drawerData=data;data.installation=(data.groups.find(g=>g.key==='metodo')||{}).installation||null;groupingDirty=false;dirty=false;activeFormGroup=group;const c=state.circuits.find(c=>c.id===id);let index=0;data.fields=[];const metodoGroupData=data.groups.find(g=>g.key==='metodo');const initialCodigo=metodoGroupData?initialMetodoCodigo(metodoGroupData):null;const sectionMap={};const sectionList=data.groups.filter(g=>g.fields.length).map(g=>{const protH={};const content=g.fields.map(f=>{data.fields.push(f);const idx=index++;
  // Campos de apoio que já aparecem de forma mais legível num bloco próprio
  // (galeria de Ajuste, comparação de Seções) ficam fora da grade normal —
  // continuam no DOM (collect()/Origem↗ funcionam) só que ocultos, para não
  // repetir a mesma informação duas vezes e não poluir a tela com dados que
  // não ajudam a decisão (pedido do usuário: "informações que não servirem
  // para balizar decisões do usuário devem ficar no back-end").
  const isAjusteField=g.key==='metodo'&&f.sheet==='Identificação-Método_Instal '&&f.address.startsWith('H');
  const isSecoesApoio=g.key==='secoes'&&!['T','W','Z'].includes(/^[A-Z]+/.exec(f.address)[0]);
  const isPartidaApoio=g.key==='partida'&&!['W','X'].includes(/^[A-Z]+/.exec(f.address)[0]);
  // Colunas calculadas/auto da nova hierarquia Fixo/Ajustável/Fusível (AP-AU,
  // DN, BJ/CG etc.): ficam ocultas aqui porque protecaoResumoHTML já as
  // mostra de forma pareada e legível (Y ao lado de AP/AQ/AT, por exemplo).
  // J/AL/AM NÃO entram nesta lista — a visibilidade deles é dinâmica (lente de
  // classe), não estática, e é tratada por refreshProtecaoCascade.
  const isProtecaoApoio=g.key==='protecao'&&['S','T','AN','AO','AP','AQ','AR','AS','AT','AU','AA','AC','AD','BR','DN','BJ','CG'].includes(/^[A-Z]+/.exec(f.address)[0]);
  const extra=isAjusteField?'ajuste-field-wrap':isSecoesApoio?'secoes-apoio-wrap':isPartidaApoio?'partida-apoio-wrap':isProtecaoApoio?'protecao-apoio-wrap':'';
  const fhtml=fieldHTML(f,'field-'+idx,extra);if(g.key==='protecao')protH[protCol(f.address)]=fhtml;return fhtml;}).join('');const groundField=g.key==='identificacao'?g.fields.find(f=>f.address.startsWith('F')&&f.sheet==='Identificação dos circuitos'):null;
const hFieldInicial=g.key==='metodo'?g.fields.find(f=>f.address.startsWith('H')):null;
const letraInicial=initialCodigo?methodCatalogByCode?.[initialCodigo]?.letra:null;
const advisorBanner=false?`<div class="advisor-banner"><span>IA local (offline): ${g.key==='protecao'?'sugestões de modelo compatível com Ib/Iz e pré-verificação de seletividade com o montante':'candidatos de DPS do catálogo compatíveis com o aterramento deste circuito'}. Só sugere — a escolha final é sua.</span><button type="button" class="btn small" data-advisor="1">Ver sugestões ↗</button></div>`:'';
const preview=(g.key==='metodo'?metodoCascadeHTML(g.linha_instalacao,initialCodigo)+ajusteGalleryHTML(ajusteOpcoesParaLetra(letraInicial),hFieldInicial&&!isError(hFieldInicial.value)?hFieldInicial.value:null):g.key==='cabos'?cabosAvisoHTML(initialCodigo)+(g.cabos_aviso_valor?`<div class="cascade-aviso">${esc(g.cabos_aviso_valor)}</div>`:''):g.key==='secoes'?secoesComparacaoHTML(g.comparacao,g.comparacao_aviso):g.key==='partida'?'':g.key==='protecao'?'':groundField&&groundField.value?`<div class="scheme-preview"><div class="scheme-diagram">${groundingSVG(groundField.value)}</div><span>Esquemático simplificado do esquema <b>${esc(groundField.value)}</b>. ${groundField.value==='TN-C'?'Neutro e PE formam um único condutor (PEN) em toda a extensão.':'Neutro e PE são condutores distintos; o PE é aterrado e não é chaveado.'} Não substitui o projeto de aterramento.</span></div>`:'')+advisorBanner;return `<details class="form-section" id="group-${g.key}" open><summary>${esc(g.label)}</summary>${preview}${g.key==='protecao'?`<div class="notice" id="prot-sem-origem-aviso" hidden>Sem dispositivo na origem: o disjuntor da origem não participa do cálculo deste circuito. As escolhas abaixo ficam guardadas caso o dispositivo volte a ser previsto.</div><div id="prot-origem-conteudo">${choiceModeHTML(data,'protecao','Escolha do disjuntor da origem')}${protecaoBlocosHTML(protH,g,protecaoClasseEscolhida||g.classe_atual||null)}</div>`:g.key==='integrada'?integratedGroupHTML(g,data):g.key==='trecho'?trechoGroupHTML(g,data):['motores','partida','dps'].includes(g.key)?workflowGroupHTML(g,data):`<div class="fields">${content}</div>`}</details>`;});data.groups.filter(g=>g.fields.length).forEach((g,i)=>{sectionMap[g.key]=sectionList[i];});const sections=drawerTabsHTML(data.info||[],sectionMap,group);$('#drawer').innerHTML=`<div class="drawer-header"><div><div class="eyebrow">CIRCUITO ${data.row-1}</div><h2 id="drawer-title">${esc(data.name)}</h2><p>Edite os dados e recalcule os resultados do projeto.</p></div><div class="drawer-header-actions"><label class="addr-toggle" title="Mostra, abaixo de cada campo, o nome da variável do modelo"><input type="checkbox" id="toggle-addresses" ${document.body.classList.contains('show-addresses')?'checked':''}> Nomes das variáveis</label><button class="icon-btn" id="close-drawer" aria-label="Fechar">×</button></div></div><div class="drawer-metrics"><div><span>Corrente Ib</span><b>${num(c?.ib)} A</b></div><div><span>Fase escolhida</span><b>${num(c?.sec_f,0)} mm²</b>${mTrace(data.trace?.sec_f)}</div><div><span>ΔV acumulada</span><b>${num(c?.dv_total)} %</b>${mTrace(data.trace?.dv_total)}</div><div><span>Ik máximo</span><b>${num(c?.icc_max)} kA</b>${mTrace(data.trace?.icc_max)}</div><div class="metric-status"><span>Situação</span><b>${badge(c?.status)}</b><small>${c?.issues?.length?`${c.issues.length} ${c.issues.length>1?'pendências':'pendência'}`:'Sem pendências'}</small></div></div>${drawerIssuesHTML(c)}<div class="drawer-body">${sections}</div><div class="drawer-footer"><button class="btn small ${data.row<4?'':'danger'}" id="delete-circuit" ${data.row<4?'disabled':''}>Excluir</button><span id="choice-preview-state" class="preview-state" role="status">Sem alterações</span><button type="button" class="btn small" id="choice-preview" title="Recalcula os resultados com as alterações ainda não salvas">Atualizar prévia</button><button class="btn small" id="duplicate-circuit">Duplicar</button><button class="btn primary" id="save-circuit">Salvar e recalcular</button></div>`;$('#drawer').hidden=false;$('#drawer-shade').hidden=false;document.body.classList.add('no-scroll');$('#drawer').oninput=(e)=>{dirty=true;$('#save-circuit').textContent='Salvar alterações';const idx=indexFromElId(e.target.id,'field-');const f=idx>=0?data.fields[idx]:null;if(f&&(f.sheet==='Maneira de instalar'||f.sheet==='Identificação-Método_Instal '))refreshCascade(data.fields);else if(f&&(f.installation_key||(f.sheet==='Identificação dos circuitos'&&/^E\d+$/.test(f.address))))refreshInstallationPreview(data.fields,true);if(f&&f.sheet==='ΔV_Partida_Motores'&&f.address.startsWith('W'))applyPartidaRestriction(data.fields,true);if(f&&f.sheet==='Cálc-Prot_Cabos'&&(f.address.startsWith('AL')||f.address.startsWith('AM')||/^Y\d/.test(f.address)))refreshProtecaoCascade(data.fields);};$('#close-drawer').onclick=()=>closeDrawer();$('#save-circuit').onclick=()=>action(async()=>{await refreshInstallationPreview(data.fields,true);const changes=workflowChanges(data);const inst=drawerData.installation;const body={changes};if(groupingDirty&&inst&&inst.reference)body.installation={id:data.id,reference:inst.reference,settings:cleanSettings(inst.settings)};if(changes.length||body.installation)await api('/api/changes',body);dirty=false;closeDrawer(true);await refresh();},'Circuito salvo. Resultados recalculados.');$('#delete-circuit').onclick=()=>{if(confirm(`Excluir ${data.name}? Transfira os circuitos filhos antes de excluir.`))action(async()=>{await api('/api/circuit/delete',{id});dirty=false;closeDrawer(true);await refresh();},'Circuito excluído.');};$('#duplicate-circuit').onclick=()=>{if(dirty&&!confirm('Descartar as alterações ainda não salvas?'))return;closeDrawer(true);newCircuit(c.parent,id,c.name+' — cópia');};refreshCascade(data.fields,false);applyPartidaRestriction(data.fields,false);refreshProtecaoCascade(data.fields);initWorkflow(data);$$('[data-advisor]').forEach(b=>b.onclick=()=>advisorModal(id));$('#toggle-addresses').onchange=e=>{document.body.classList.toggle('show-addresses',e.target.checked);try{localStorage.setItem('eletroapp.addresses',e.target.checked?'1':'0');}catch(err){}};$('#close-drawer').focus();if(group)setTimeout(()=>jumpToGroup(group,focus),80);}catch(e){toast(e.message,true);}finally{busy(false);}}
function drawerIssuesHTML(c){
  if(!c?.issues?.length)return '';
  return `<details class="drawer-issues"><summary>Ver as pendências deste circuito (${c.issues.length})</summary>${c.issues.map(x=>`<button type="button" class="issue issue-row" data-jump-group="${esc(x.group||'')}"${x.focus?` data-focus="${esc(x.focus.sheet+'!'+x.focus.col)}"`:''}><b>${esc(x.label)}</b><span class="${/^✗/.test(issueText(x.value))||isError(x.value)?'error':''}">${esc(issueText(x.value))}</span><i aria-hidden="true">›</i></button>`).join('')}</details>`;
}
// Leva da pendência ao campo: abre a aba do grupo, rola até ele e destaca o campo, quando conhecido.
function jumpToGroup(group,focus){
  if(!drawerData||!group)return;
  const tab=(drawerData.info||[]).find(t=>t.groups.includes(group));if(tab)switchDrawerTab(tab.key);
  const sec=document.getElementById('group-'+group);if(!sec)return;
  sec.open=true;let target=sec;
  if(focus){const [sheet,col]=focus.split('!');const idx=drawerData.fields.findIndex(f=>f.sheet===sheet&&/^[A-Z]+/.exec(f.address)[0]===col);const w=idx>=0?document.getElementById('field-'+idx)?.closest('.field'):null;if(w&&!w.hidden&&w.offsetParent)target=w;}
  target.scrollIntoView({behavior:'smooth',block:target===sec?'start':'center'});
  target.classList.remove('flash');void target.offsetWidth;target.classList.add('flash');
  if(target!==sec)target.querySelector('select,input,textarea')?.focus({preventScroll:true});
}
async function methodsGalleryModal(){busy(true,'Carregando catálogo de métodos…');try{await ensureMethodData();const list=methodCatalog||[];modal('Catálogo completo de métodos de instalação — Tabela 33 · NBR 5410',list.length?`<p class="subtitle">Ilustrações de referência extraídas da planilha de origem, com os 59 códigos cadastrados. A galeria do formulário do circuito já restringe esta lista aos métodos compatíveis com a Instalação escolhida; aqui ficam todos, para consulta.</p><div class="method-gallery">${list.map(m=>`<div class="method-card"><img src="/${esc(m.imagem)}" alt="" loading="lazy"><b>${esc(m.numero||String(m.codigo).split("_")[0])} · ${esc(m.letra||"—")}</b><span>${esc(short(m.descricao,110))}</span></div>`).join('')}</div>`:'<p>Catálogo de imagens não disponível nesta instalação.</p>');}catch(e){toast(e.message,true);}finally{busy(false);}}
async function advisorModal(id){busy(true,'Calculando sugestões (IA local)…');try{const r=await api('/api/advisor?id='+encodeURIComponent(id));
const prot=r.protecao,sel=r.seletividade,dps=r.dps;
const fitLabel={atende:'Atende Ib≤Ir≤Iz',nao_atende:'Não atende',dados_insuficientes:'Dados insuficientes',sem_dados:'Fora do catálogo'};
const protBody=prot.status!=='ok'?`<p class="subtitle">${esc(prot.message)}</p>`:`<p class="subtitle">Ib = ${num(prot.ib,1)} A · Iz = ${num(prot.iz,1)} A · Ik,máx no quadro de instalação = ${num(prot.icc_max,3)} kA · família escolhida: <b>${esc(prot.family)}</b></p><div class="advisor-list">${prot.items.map(it=>`<div class="advisor-item ${it.fit}"><div><b>${esc(it.modelo)}</b><span class="advisor-tag">${esc(fitLabel[it.fit]||it.fit)}</span><span>${esc(it.nota_fit||it.nota||'')}</span>${it.nota_icu?`<span class="advisor-icu">${esc(it.nota_icu)}</span>`:''}</div>${it.fit==='atende'?`<button type="button" class="btn small" data-fill-model="${esc(it.modelo)}">Usar</button>`:''}</div>`).join('')||'<p class="subtitle">Nenhum candidato retornado.</p>'}</div>`;
const selClass=sel.status==='atencao'?'red':sel.status==='provavel'?'green':'amber';
const selBody=`<p class="subtitle">${sel.label?`<span class="tag ${selClass}">${esc(sel.label)}</span> `:''}${esc(sel.message)}</p>`;
const dpsBody=dps.items?.length?`<div class="advisor-list">${dps.items.map(it=>`<div class="advisor-item"><div><b>${esc(it.fabricante)} · ${esc(it.linha)}</b><span>${esc(it.classe)} · Uc ${esc(it.uc)} · Iimp ${esc(it.iimp)} · In ${esc(it.in_)}</span></div><button type="button" class="btn small" data-fill-dps="${esc((it.linha||'')+' '+(it.codigo||''))}">Usar</button></div>`).join('')}</div>`:`<p class="subtitle">${esc(dps.message||'Sem candidatos no catálogo incorporado.')}</p>`;
modal('Sugestões (IA local) — só assessora, não decide',`<p class="subtitle">Heurística local e offline sobre os dados já calculados e os catálogos da base técnica (sem internet, sem IA generativa, sem envio de dados). Não substitui a conferência normativa nem a curva/tabela do fabricante — apenas restringe a lista de opções para você escolher. “Usar” preenche o campo; nada é salvo até você clicar em Salvar no formulário.</p><h3>Proteção</h3>${protBody}<h3>Seletividade com o circuito a montante</h3>${selBody}<h3>DPS — candidatos do catálogo</h3>${dpsBody}`);
$$('#modal [data-fill-model]').forEach(b=>b.onclick=()=>fillAdvisorField('AM',b.dataset.fillModel,'Cálc-Prot_Cabos'));
$$('#modal [data-fill-dps]').forEach(b=>b.onclick=()=>fillAdvisorField('AU',b.dataset.fillDps,'DPS'));
}catch(e){toast(e.message,true);}finally{busy(false);}}
function fillAdvisorField(col,value,sheet){if(!drawerData)return;const ok=setFieldValue(drawerData.fields,sheet,col,value,'field-');if(!ok){toast('Campo não encontrado no formulário aberto.',true);return;}const idx=drawerData.fields.findIndex(f=>f.address.startsWith(col)&&f.sheet===sheet);const el=$('#field-'+idx);$('#modal').close();el?.closest('details')?.setAttribute('open','');el?.scrollIntoView({behavior:'smooth',block:'center'});el?.focus();toast('Valor preenchido no formulário. Revise e clique em Salvar para confirmar.');}
function closeDrawer(force=false){if(dirty&&!force&&!confirm('Descartar as alterações ainda não salvas?'))return false;$('#drawer').hidden=true;$('#drawer-shade').hidden=true;document.body.classList.remove('no-scroll');dirty=false;drawerData=null;return true;}
function modal(title,body,actions=''){const d=$('#modal');d.innerHTML=`<div class="modal-header"><h2>${title}</h2><button class="icon-btn" data-close-modal aria-label="Fechar">×</button></div><div class="modal-content">${body}</div>${actions?`<div class="modal-actions">${actions}</div>`:''}`;if(!d.open)d.showModal();d.querySelector('[data-close-modal]').onclick=()=>d.close();}
function newCircuit(parent,duplicate,name=''){modal(duplicate?'Duplicar circuito':'Novo circuito',`<div class="field"><label for="new-name">Nome do circuito / quadro</label><input id="new-name" placeholder="Ex.: QDL-02 ou Iluminação térreo" value="${esc(name)}" autofocus></div><div class="field"><label for="new-parent">Circuito a montante</label><select id="new-parent"><option value="">Desvinculado</option>${state.circuits.map(c=>`<option value="${esc(c.name)}" ${c.name===(parent||state.circuits.find(c=>c.kind==='Distribuição'&&c.row>=4)?.name)?'selected':''}>${esc(c.name)}</option>`).join('')}</select></div><p>${duplicate?'Os dados do circuito serão copiados. As confirmações da proteção ficam pendentes.':'O circuito será criado com carga zero e parâmetros iniciais editáveis. Preencha as cargas, condições e proteções no formulário.'}</p>`,`<button class="btn primary" id="create-circuit">${duplicate?'Duplicar':'Criar e editar'}</button>`);$('#create-circuit').onclick=()=>action(async()=>{const r=await api('/api/circuit/add',{name:$('#new-name').value,parent:$('#new-parent').value,duplicate});$('#modal').close();await refresh();await editCircuit(r.id);});}
async function cellModal(sheet,address){busy(true,'Consultando fórmula…');try{const f=await api('/api/cell?'+new URLSearchParams({sheet,address}));modal('Rastrear resultado',`<p><b>${esc(sheet)}!${esc(address)}</b><br>${esc(f.label)}</p><div class="compare-values"><div><label>RECALCULADO EM PYTHON</label><span>${num(f.value,8)}</span></div><div><label>SALVO NO ARQUIVO DE ORIGEM</label><span>${num(f.saved,8)}</span></div></div>${f.formula?`<pre class="formula-code">${esc(f.formula)}</pre>`:'<p>Esta célula contém uma entrada ou valor de referência, sem fórmula.</p>'}`);}catch(e){toast(e.message,true);}finally{busy(false);}}
function catalogModal(){modal('Bases e catálogos',`<div class="reference-grid">${[['tab_weg_protecoes','Disjuntores WEG'],['tab_dps_clamper','DPS Clamper'],['tab_dps_siemens','DPS Siemens'],['tab_fusiveis_nh','Fusíveis NH gG (backup do DPS)'],['tab_ampacidade_3c','Ampacidade · 3 condutores'],['tab_impedancias','Impedância dos cabos'],['tab_motores','Motores']].map(([id,title])=>`<button class="ref-card" data-catalog="${esc(id)}"><h3>${title}</h3><p>Consultar na base técnica ↗</p></button>`).join('')}</div>`);}
document.addEventListener('click',e=>{const edit=e.target.closest('[data-edit]'),add=e.target.closest('[data-add]'),cell=e.target.closest('[data-cell]'),cat=e.target.closest('[data-catalog]');const jump=e.target.closest('[data-jump-group]');if(jump){jumpToGroup(jump.dataset.jumpGroup,jump.dataset.focus);jump.closest('details')?.removeAttribute('open');return;}if(edit){editCircuit(edit.dataset.edit,edit.dataset.group||undefined,edit.dataset.focus);return;}if(add){newCircuit();return;}if(cell){cellModal(cell.dataset.sheet,cell.dataset.cell);return;}if(cat){window.tablesSelected=cat.dataset.catalog;$('#modal').close();if(location.hash==='#tables')render();else location.hash='tables';return;}if(!e.target.closest('.export-wrap'))$('#exports').hidden=true;});
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.matches('[data-edit]'))editCircuit(e.target.dataset.edit);if(e.key==='Escape'&&!$('#drawer').hidden&&!$('#modal').open){e.preventDefault();closeDrawer();}});
document.addEventListener('change',e=>{if(e.target.matches('select[data-has-custom]')){const custom=document.getElementById(e.target.id+'-custom');if(custom){custom.hidden=e.target.value!=='__custom__';if(!custom.hidden)custom.focus();}}});
$('#drawer-shade').onclick=()=>closeDrawer();$('#export-menu').onclick=()=>$('#exports').hidden=!$('#exports').hidden;$('#mobile-menu').onclick=()=>document.body.classList.toggle('menu-open');
const PROJECT_MODE_NOTES={blank:'Começa com o ramal de entrada e o quadro de medição do exemplo (podem ser editados ou excluídos); os demais circuitos ficam para você cadastrar.',example:'Instalação de exemplo completa, com disjuntor na origem de cada circuito e DPS pela regra do modelo.',example_entrada:'Instalação de exemplo com ramal de entrada, QM-01 e QGBT-01 sem disjuntor na origem. Disjuntor geral (de manutenção) na chegada do QGBT-01 e primeiro DPS no QGBT-01. Ficam pendentes as confirmações da dispensa e o tempo da proteção a montante.'};
$('#new-project').onclick=()=>{modal('Novo projeto',`<div class="field"><label for="project-new-name">Nome do projeto</label><input id="project-new-name" placeholder="Ex.: Instalações elétricas — Obra 01"></div><div class="field"><label for="project-mode">Ponto de partida</label><select id="project-mode"><option value="blank">Entrada e medição, sem os demais circuitos</option><option value="example">Exemplo completo</option><option value="example_entrada">Exemplo — transformador e medição sem disjuntor na origem</option></select><p class="field-note" id="project-mode-note"></p></div>${newProjectModesHTML()}<p>Os parâmetros da fonte começam com os valores do exemplo. Revise Entrada e fontes antes de dimensionar.</p>`,`<button class="btn primary" id="project-create">Criar projeto</button>`);const modeNote=()=>{$('#project-mode-note').textContent=PROJECT_MODE_NOTES[$('#project-mode').value]||'';};$('#project-mode').onchange=modeNote;modeNote();$('#project-create').onclick=()=>action(async()=>{await api('/api/projects/new',{name:$('#project-new-name').value||'Novo projeto',blank:$('#project-mode').value==='blank',preset:$('#project-mode').value==='example_entrada'?'entrada_sem_disjuntor':undefined,selection_defaults:newProjectModes()});$('#modal').close();location.hash='source';await refresh();},'Projeto criado.');};
$('#project-select').onchange=e=>action(async()=>{if((dirty||sourceDirty)&&!confirm('Descartar as alterações ainda não salvas?')){e.target.value=state.project_id;return;}await api('/api/projects/open',{id:e.target.value});sourceDirty=false;closeDrawer(true);await refresh();},'Projeto aberto.');
$('#new-project-side').onclick=()=>{document.body.classList.remove('menu-open');$('#new-project').onclick();};
$('#rename-project').onclick=()=>{modal('Renomear projeto',`<div class="field"><label for="project-rename">Nome</label><input id="project-rename" value="${esc(state.title)}"></div>`,`<button class="btn primary" id="rename-submit">Salvar nome</button>`);$('#rename-submit').onclick=()=>action(async()=>{await api('/api/projects/rename',{name:$('#project-rename').value});$('#modal').close();await refresh();});};
$('#import-project').onclick=()=>$('#file-input').click();$('#file-input').onchange=e=>{const file=e.target.files[0];if(!file)return;action(async()=>{const r=await fetch('/api/import',{method:'POST',headers:{'X-Eletro-Token':token,'X-Filename':encodeURIComponent(file.name)},body:file});const d=await r.json();if(!r.ok)throw Error(d.error);sourceDirty=false;closeDrawer(true);location.hash='overview';await refresh();},'Arquivo importado em um novo projeto.');e.target.value='';};
window.addEventListener('beforeunload',e=>{if(dirty||sourceDirty){e.preventDefault();e.returnValue='';}});
window.addEventListener('hashchange',(hcEvt)=>{if(sourceDirty&&!confirm('Descartar as alterações ainda não salvas na fonte?')){history.replaceState(null,'','#source');return;}if(!closeDrawer()){let prevHash='#circuits';try{prevHash=new URL(hcEvt.oldURL).hash||prevHash;}catch(e){}history.replaceState(null,'',prevHash);return;}sourceDirty=false;render().catch(e=>toast(e.message,true));});
window.addEventListener('DOMContentLoaded',()=>{try{document.body.classList.toggle('show-addresses',localStorage.getItem('eletroapp.addresses')==='1');}catch(e){}action(refresh);});

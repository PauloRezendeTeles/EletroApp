'use strict';
/* v2.3 — um cadastro por dispositivo e curvas temporais calculadas no servidor. */
function sourceProtectionHTML(){
  const p=state?.origem?.protection||{};
  if(!p.profile)return '';
  return `<div class="notice integrated-source"><b>${esc(p.description)}</b>${p.note?`<p>${esc(p.note)}</p>`:''}${p.issues?.length?`<ul>${p.issues.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}${p.qta_id?`<button type="button" class="btn small" data-integrated-edit="${esc(p.qta_id)}" data-integrated-group="trecho">Disjuntor do quadro de transferência</button>`:''}<button type="button" class="btn small" data-confirm-source-curve>Confirmar curva do elo para os dados salvos</button></div>`;
}
function protectionSourceVisibility(fields){
  if(!fields)return;
  const field=k=>fields.findIndex(f=>f.protection_key===k),value=k=>{const i=field(k);return i<0?null:liveValue(i,'source-');};
  const ti=fields.findIndex(f=>f.block==='tipo'),type=ti<0?null:liveValue(ti,'source-');
  const mapping={'Rede MT/Trafo sem dados':'Chave fusível MT','Rede MT/Trafo com dados':'Disjuntor MT com relé','Rede BT Direta':'Rede BT — proteção externa desconhecida','Gerador BT':'Gerador — disjuntor no quadro de transferência'};
  const selected=value('tipo');const profile=selected&&selected!=='Automático pelo atendimento'?selected:mapping[type];
  fields.forEach((f,i)=>{
    if(!f.protection_key)return;
    const wrap=document.getElementById('source-'+i)?.closest('.field');if(!wrap)return;
    const b=f.protection_block,k=f.protection_key;
    let show=b==='entrada'||b==='fusivel'&&profile==='Chave fusível MT'||b==='rele'&&profile==='Disjuntor MT com relé'||b==='gerador_dinamico'&&type==='Gerador BT';
    if(k==='medicao')show=profile===mapping['Rede BT Direta'];
    if(k==='qta')show=profile===mapping['Gerador BT'];
    if(k.startsWith('gerador_')&&k!=='gerador_modo'&&value('gerador_modo')==='Curvas I(t) por ponto de falta')show=false;
    const fn=/^(50N?|51N?)_(corrente|tempo|curva)$/.exec(k);
    if(fn&&value(fn[1]+'_ativa')==='NÃO')show=false;
    wrap.hidden=!show;
  });
  document.querySelectorAll('[data-confirm-source-curve]').forEach(b=>b.hidden=profile!=='Chave fusível MT');
}
function integratedCurveSVG(f){
  const pts=f.samples||[];if(pts.length<2)return '';
  const w=640,h=220,l=66,r=20,t=20,b=40,end=pts[pts.length-1][0],max=Math.max(...pts.map(p=>p[2]),1);
  const x=v=>l+(w-l-r)*Math.log1p(v/.001)/Math.log1p(end/.001),y=v=>h-b-(h-t-b)*v/max;
  const path=k=>pts.map((p,i)=>`${i?'L':'M'}${x(p[0]).toFixed(2)},${y(p[k]).toFixed(2)}`).join(' ');
  const ticks=[0,.001,.01,.1,1,10,30].filter(v=>v<=end);
  const grid=ticks.map(v=>`<line x1="${x(v)}" y1="${t}" x2="${x(v)}" y2="${h-b}" stroke="#d9e2e8"/><text x="${x(v)}" y="${h-18}" text-anchor="middle">${esc(formatBR(v))}</text>`).join('');
  return `<svg class="integrated-curve" viewBox="0 0 ${w} ${h}" role="img" aria-label="Corrente de curto ${esc(f.fault)} ao longo do tempo"><rect width="${w}" height="${h}" fill="#fff"/>${grid}<path d="M${l},${t}V${h-b}H${w-r}" fill="none" stroke="#627987"/><path d="${path(2)}" fill="none" stroke="#1b6b8a" stroke-width="2"/><path d="${path(1)}" fill="none" stroke="#b66b36" stroke-width="2" stroke-dasharray="5 3"/><text x="${l-8}" y="${t+4}" text-anchor="end">${esc(num(max,1))}</text><text x="${l-8}" y="${h-b}" text-anchor="end">0</text><text x="8" y="14">A</text><text x="${w-r}" y="${h-4}" text-anchor="end">tempo (s), escala log(1+t/0,001)</text><text x="${l+10}" y="${t+14}" fill="#1b6b8a">Imax</text><text x="${l+70}" y="${t+14}" fill="#b66b36">Imin</text></svg>`;
}
function integratedGroupHTML(g,data){
  const r=g.protection||{},link=g.link||{},numOr=(v,d=4)=>typeof v==='number'?num(v,d):'—';
  const fields=g.fields.map(f=>fieldHTML(f,'field-'+data.fields.indexOf(f))).join('');
  const faults=r.faults||[];
  return `<div class="integrated-protection"><div class="notice"><b>${esc(link.descricao||'Proteção do alimentador')}</b>${link.erro?`<p>${esc(link.erro)}</p>`:''}${link.vinculado&&link.editar_id?`<p><button type="button" class="btn small" data-integrated-edit="${esc(link.editar_id)}" data-integrated-group="trecho">Editar disjuntor no quadro precedente</button></p>`:''}</div>
    ${g.outgoing?.length?`<div class="integrated-outgoing"><h4>Disjuntores das saídas deste quadro</h4>${g.outgoing.map(o=>`<button type="button" class="btn small" data-integrated-edit="${esc(o.circuito_id)}" data-integrated-group="integrada">Saída para ${esc(o.nome)}</button>`).join(' ')}</div>`:''}
    <div class="fields">${fields}</div>
    <p class="field-note">Os campos do dispositivo de saída pertencem ao quadro precedente. A chegada deste quadro é um equipamento distinto, salvo quando o vínculo acima identifica explicitamente o mesmo disjuntor.</p>
    ${state?.origem?.tipo==='Gerador BT'?`<button type="button" class="btn small" data-confirm-generator-curve="${esc(data.id)}">Confirmar curvas I(t) para os dados salvos deste circuito</button>`:''}
    <div class="integrated-results"><h4>${esc(r.status||'Atualize a prévia para calcular')}</h4><p>${esc(r.detail||'')}</p>
      ${faults.length?`<div class="table-scroll"><table><thead><tr><th>Falta</th><th>Imin inicial (A)</th><th>Imax inicial (A)</th><th>Função</th><th>Tempo de atuação (s)</th><th>Interrupção (s)</th><th>Eliminação (s)</th><th>∫I²dt (A²s)</th></tr></thead><tbody>${faults.map(f=>`<tr><td>${esc(f.fault)}</td><td>${numOr(f.imin_a,1)}</td><td>${numOr(f.imax_a,1)}</td><td>${esc(f.function||'—')}</td><td>${numOr(f.trip_s)}</td><td>${numOr(f.opening_s)}</td><td>${numOr(f.clear_s)}</td><td>${numOr(f.energy,1)}</td></tr>${f.reason?`<tr><td colspan="8">${esc(f.reason)}</td></tr>`:''}`).join('')}</tbody></table></div>`:''}
      ${r.thermal?`<p><b>Cabo:</b> ${esc(r.thermal)}</p>`:''}${r.tn?`<p><b>Seccionamento:</b> ${esc(r.tn)}</p>`:''}
      ${faults.filter(f=>f.samples?.length>1).map(f=>`<details><summary>Curva corrente × tempo — ${esc(f.fault)}</summary>${integratedCurveSVG(f)}</details>`).join('')}
    </div></div>`;
}
function integratedRefresh(data=drawerData){
  const fields=data?.fields;if(!fields)return;
  const fi=fields.findIndex(f=>f.protection_key==='vinculo');
  const linked=fi>=0&&liveValue(fi,'field-')==='Usar o disjuntor de chegada do quadro precedente';
  const box=document.getElementById('prot-origem-conteudo');if(box)box.hidden=linked||trechoSemOrigem();
  const opening=fields.findIndex(f=>f.sheet==='Cálc-Prot_Cabos'&&f.address.replace(/\d+$/,'')==='CX');
  const openingWrap=opening>=0?document.getElementById('field-'+opening)?.closest('.field'):null;
  if(openingWrap&&(linked||state?.origem?.tipo==='Gerador BT'))openingWrap.hidden=linked||trechoSemOrigem();
  fields.forEach((f,i)=>{
    if(!f.protection_key)return;
    const wrap=document.getElementById('field-'+i)?.closest('.field');if(!wrap)return;
    if(f.protection_key.startsWith('curva_'))wrap.hidden=state?.origem?.tipo!=='Gerador BT';
    if(f.protection_key.startsWith('mb_'))wrap.hidden=!trechoComMB();
    if(f.protection_key==='instantaneo_s')wrap.hidden=linked||trechoSemOrigem();
  });
}
document.addEventListener('change',e=>{
  if(e.target.id?.startsWith('source-')){
    const fs=globalThis.integratedSourceFields;
    if(fs)protectionSourceVisibility(fs);
  }
  if(e.target.id?.startsWith('field-')&&drawerData)integratedRefresh();
});
document.addEventListener('click',e=>{
  const edit=e.target.closest('[data-integrated-edit]');
  if(edit){e.preventDefault();editCircuit(edit.dataset.integratedEdit,edit.dataset.integratedGroup||'integrada');return;}
  const fuse=e.target.closest('[data-confirm-source-curve]'),gen=e.target.closest('[data-confirm-generator-curve]');
  if(!fuse&&!gen)return;
  e.preventDefault();
  if(dirty||sourceDirty){toast('Salve as alterações antes de confirmar a curva.',true);return;}
  action(async()=>{await api('/api/protection/confirm-curve',{category:fuse?'fusivel':'gerador',id:gen?.dataset.confirmGeneratorCurve});await refresh();if(gen)await editCircuit(gen.dataset.confirmGeneratorCurve,'integrada');},'Curva confirmada para os dados atuais.');
});

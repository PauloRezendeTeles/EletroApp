/* EletroApp — camada de usabilidade (v1.11; v1.12: textos via DOM e passos por campo).
 * Não altera cálculos: só acrescenta botões e navegação sobre a interface existente.
 *  1. Listas curtas (<select> com até 6 opções) viram botões de escolha.
 *  2. Campos numéricos ganham botões − / +.
 *  3. Formulário do circuito: botões Anterior/Próxima etapa e navegação entre circuitos.
 *  4. Visão geral: barra de etapas com atalhos para cada página.
 */
(function(){
  const MAX_OPTS=6;
  const q=(s,r=document)=>r.querySelector(s), qa=(s,r=document)=>[...r.querySelectorAll(s)];
  const fire=el=>{el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));};

  /* 1. Botões de escolha ------------------------------------------------ */
  function segFor(sel){
    const opts=[...sel.options];
    const wrap=document.createElement('div');
    wrap.className='ux-seg';wrap.setAttribute('role','radiogroup');
    if(sel.id)wrap.dataset.for=sel.id;
    opts.forEach(o=>{
      const b=document.createElement('button');b.type='button';
      b.textContent=o.textContent.trim()||'—';b.dataset.value=o.value;
      b.setAttribute('role','radio');
      const on=o.selected;b.classList.toggle('on',on);b.setAttribute('aria-checked',on);
      b.disabled=sel.disabled||o.disabled;
      b.onclick=()=>{if(sel.value===o.value)return;sel.value=o.value;fire(sel);sync(sel);};
      wrap.appendChild(b);
    });
    return wrap;
  }
  function sync(sel){
    const w=sel._uxSeg;if(!w)return;
    qa('button',w).forEach(b=>{const on=b.dataset.value===sel.value;b.classList.toggle('on',on);b.setAttribute('aria-checked',on);b.disabled=sel.disabled;});
  }
  function signature(sel){return [...sel.options].map(o=>o.value+'\u0001'+o.textContent).join('\u0002')+'|'+sel.disabled;}
  function enhanceSelect(sel){
    if(sel.multiple||sel.closest('.ux-noseg,#sidebar,.topbar,.toolbar,.uni-focus'))return;
    const n=sel.options.length;
    const longText=[...sel.options].some(o=>o.textContent.trim().length>48);
    const fits=n>=2&&n<=MAX_OPTS&&!longText;
    if(sel._uxSeg){
      if(!fits){sel._uxSeg.remove();sel._uxSeg=null;sel.classList.remove('ux-hidden-select');return;}
      if(sel._uxSig!==signature(sel)){const w=segFor(sel);sel._uxSeg.replaceWith(w);sel._uxSeg=w;sel._uxSig=signature(sel);}
      else sync(sel);
      return;
    }
    if(!fits)return;
    const w=segFor(sel);sel.insertAdjacentElement('afterend',w);
    sel._uxSeg=w;sel._uxSig=signature(sel);sel.classList.add('ux-hidden-select');
    sel.addEventListener('change',()=>sync(sel));
  }

  /* 2. Botões − / + ------------------------------------------------------ */
  function enhanceNumber(inp){
    if(inp._uxStep||inp.readOnly||inp.closest('.ux-noseg,.toolbar'))return;
    const isNum=inp.type==='number'||inp.dataset.type==='number'||inp.inputMode==='decimal';
    if(!isNum)return;
    inp._uxStep=true;
    const wrap=document.createElement('span');wrap.className='ux-step';
    inp.parentNode.insertBefore(wrap,inp);wrap.appendChild(inp);
    // v1.12: incremento, limites e casas decimais vêm do campo (data-step/min/max/integer/decimals);
    // o texto é lido no formato brasileiro ("1.000,00" = mil), nunca com parseFloat direto.
    const ds=inp.dataset;
    const parse=window.parseBR||(x=>Number(String(x).replace(',','.')));
    const fmt=window.formatBR||((v)=>String(v).replace('.',','));
    const mk=(t,d)=>{const b=document.createElement('button');b.type='button';b.textContent=t;b.tabIndex=-1;
      b.setAttribute('aria-label',d>0?'Aumentar':'Diminuir');
      b.onclick=()=>{if(inp.disabled)return;
        const cur=parse(inp.value);const v=Number.isFinite(cur)?cur:(ds.min!==undefined&&ds.min!==''?Number(ds.min):0);
        const integer=ds.integer==='1';
        let step=Number(ds.step);if(!Number.isFinite(step)||step<=0)step=integer?1:(Math.abs(v)>=100?10:Math.abs(v)>=10?1:Math.abs(v)>=1?0.5:0.05);
        const dec=ds.decimals!==undefined&&ds.decimals!==''?Number(ds.decimals):(integer?0:Math.min(6,Math.max(0,(String(step).split('.')[1]||'').length)));
        let nv=Number.isFinite(cur)?v+d*step:v;
        if(integer)nv=Math.round(nv);
        nv=Number(nv.toFixed(Math.max(dec,(String(step).split('.')[1]||'').length)));
        if(ds.min!==undefined&&ds.min!==''&&nv<Number(ds.min))nv=Number(ds.min);
        if(ds.max!==undefined&&ds.max!==''&&nv>Number(ds.max))nv=Number(ds.max);
        inp.value=fmt(nv,integer?0:null);fire(inp);};
      return b;};
    wrap.prepend(mk('−',-1));wrap.append(mk('+',1));
  }

  /* 3. Navegação no formulário do circuito ------------------------------ */
  function enhanceDrawer(){
    const dr=q('#drawer');if(!dr||dr.hidden)return;
    const tabs=qa('.dtab',dr);
    // Navegação entre etapas
    qa('.dpane',dr).forEach((pane,i)=>{
      if(pane.querySelector(':scope > .ux-stepnav'))return;
      if(!tabs.length)return;
      const prev=tabs[i-1],next=tabs[i+1];
      const nav=document.createElement('div');nav.className='ux-stepnav';
      const count=document.createElement('span');count.className='ux-stepcount';count.textContent=`Etapa ${i+1} de ${tabs.length}`;
      const box=document.createElement('div');
      const stepBtn=(tab,label,primary)=>{const b=document.createElement('button');b.type='button';b.className='btn small'+(primary?' ux-primary':'');
        b.dataset.dtab=tab.dataset.dtab||'';b.textContent=label;return b;};
      if(prev)box.appendChild(stepBtn(prev,'‹ '+prev.textContent,false));
      if(next)box.appendChild(stepBtn(next,next.textContent+' ›',true));
      nav.append(count,box);
      pane.appendChild(nav);
    });
    // Numeração das abas
    tabs.forEach((t,i)=>{if(!t.querySelector('.ux-n')){const s=document.createElement('span');s.className='ux-n';s.textContent=i+1;t.prepend(s);}});
    // Anterior / próximo circuito
    const head=dr.querySelector('.drawer-head, header, .drawer-header')||dr.firstElementChild;
    if(head&&!dr.querySelector('.ux-circnav')&&typeof state!=='undefined'&&state&&typeof drawerData!=='undefined'&&drawerData){
      const list=state.circuits||[];const id=drawerData.id??(drawerData.circuit&&drawerData.circuit.id);
      const idx=list.findIndex(c=>c.id===id);
      if(idx>=0){
        const nav=document.createElement('div');nav.className='ux-circnav';
        const p=list[idx-1],n=list[idx+1];
        // Nomes de circuito vêm do projeto (podem ter sido importados): sempre como texto, nunca como HTML.
        const circBtn=(c,label,title)=>{const b=document.createElement('button');b.type='button';b.className='btn small';b.title=title;
          if(c){b.dataset.uxEdit=String(c.id);}else b.disabled=true;b.textContent=label;return b;};
        const pos=document.createElement('span');pos.textContent=`${idx+1} / ${list.length}`;
        nav.append(circBtn(p,'‹ '+(p?String(p.name??''):''),'Circuito anterior'),pos,circBtn(n,(n?String(n.name??''):'')+' ›','Próximo circuito'));
        head.appendChild(nav);
      }
    }
  }
  document.addEventListener('click',e=>{const b=e.target.closest('[data-ux-edit]');if(b&&typeof editCircuit==='function'){editCircuit(b.dataset.uxEdit);}});

  /* 4. Barra de etapas na visão geral ----------------------------------- */
  const STEPS=[['source','ϟ','Entrada e fontes','Rede, transformador e aterramento'],['circuits','☷','Circuitos','Cargas, cabos e instalação'],['protection','◇','Proteções','Disjuntores e seletividade'],['dps','↯','DPS','Surtos por quadro'],['audit','✓','Verificações','Pendências a resolver'],['diagram','⌘','Unifilar','Diagrama e quadro de cargas']];
  function enhanceMain(){
    const main=q('#main');if(!main)return;
    const view=location.hash.slice(1)||'overview';
    if(view==='overview'&&!q('.ux-flow',main)&&q('.kpi',main)){
      const bar=document.createElement('nav');bar.className='ux-flow';bar.setAttribute('aria-label','Etapas do projeto');
      bar.innerHTML=STEPS.map(([k,ic,t,d],i)=>`<a href="#${k}" class="ux-flow-step"><span class="ux-flow-n">${i+1}</span><span class="ux-flow-ic">${ic}</span><b>${t}</b><small>${d}</small></a>`).join('')+
        `<a href="/report" target="_blank" class="ux-flow-step ux-flow-end"><span class="ux-flow-n">✓</span><span class="ux-flow-ic">▤</span><b>Relatório</b><small>Gerar PDF</small></a>`;
      const h=main.querySelector('.kpis, .kpi-grid')||main.querySelector('.kpi').parentElement;
      h.insertAdjacentElement('beforebegin',bar);
    }
    // Botão de ação nas linhas de circuitos
    qa('tr[data-edit]',main).forEach(tr=>{
      if(tr._ux)return;tr._ux=true;tr.classList.add('ux-row');
      const last=tr.lastElementChild;if(!last)return;
      const b=document.createElement('span');b.className='ux-open';b.textContent='Abrir ›';b.dataset.edit=tr.dataset.edit;
      last.appendChild(b);
    });
  }

  /* Observador ---------------------------------------------------------- */
  let pending=false;
  function run(){pending=false;
    qa('#drawer select, #modal select, #main .field select, #main .mode-bar select').forEach(enhanceSelect);
    qa('#drawer input, #modal input').forEach(enhanceNumber);
    enhanceDrawer();enhanceMain();
  }
  const schedule=()=>{if(!pending){pending=true;requestAnimationFrame(run);}};
  new MutationObserver(schedule).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['disabled','hidden']});
  window.addEventListener('hashchange',schedule);
  document.addEventListener('DOMContentLoaded',schedule);

  /* Atalhos de teclado: Alt+← / Alt+→ trocam de etapa no formulário */
  document.addEventListener('keydown',e=>{
    if(!e.altKey||!['ArrowLeft','ArrowRight'].includes(e.key))return;
    const dr=q('#drawer');if(!dr||dr.hidden)return;
    const tabs=qa('.dtab',dr);const i=tabs.findIndex(t=>t.classList.contains('active'));
    const t=tabs[i+(e.key==='ArrowRight'?1:-1)];if(t){e.preventDefault();t.click();}
  });
})();

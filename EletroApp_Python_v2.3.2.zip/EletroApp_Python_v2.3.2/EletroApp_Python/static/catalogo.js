/* Catálogo de cálculos (variáveis nomeadas e regras em Python), trilha de cálculo, edição segura e expressões editadas.
   Depende das funções globais de app.js ($, esc, api, toast, busy, modal, refresh, render, heading). */
(function () {
  'use strict';
  window.compareTab = 'integridade';
  let reviewer = { configurado: false, desbloqueado: false, nome: null };
  const cat = { q: '', aba: '', status: '', norma: '', items: [], total: 0, info: null, loading: false };

  const fv = (v) => {
    if (v === null || v === undefined || v === '') return '—';
    if (typeof v === 'object' && v.error) return v.error;
    if (typeof v === 'number') return v.toLocaleString('pt-BR', { maximumFractionDigits: 8 });
    return String(v);
  };
  const isErr = (v) => v && typeof v === 'object' && v.error;
  const short = (t, n) => { t = String(t ?? ''); return t.length > n ? t.slice(0, n - 1) + '…' : t; };
  const STATUS = { modelo: ['modelo do aplicativo', ''], editada: ['editada (registrada)', 'amber'], alterada: ['alterada fora do aplicativo', 'red'], regra_python: ['regra em Python', 'blue'] };
  const statusChip = (s) => { const [t, c] = STATUS[s] || [s, '']; return `<span class="tag ${c}">${esc(t)}</span>`; };
  const wide = () => { const d = $('#modal'); d.classList.add('wide'); if (!d.dataset.wideBound) { d.dataset.wideBound = '1'; d.addEventListener('close', () => d.classList.remove('wide')); } };
  const unitSuffix = (label, unit) => unit && !String(label || '').includes('(' + unit + ')') ? ` <small>(${esc(unit)})</small>` : '';
  const fmtTs = (ts) => { try { return new Date(ts).toLocaleString('pt-BR'); } catch { return ts || ''; } };

  async function loadReviewer() { try { reviewer = await api('/api/reviewer'); } catch { /* ignora */ } return reviewer; }

  /* ---------------- abas ---------------- */
  window.compareTabsHTML = () => `<div class="tabs" role="tablist">
    <button class="tab ${window.compareTab !== 'baseline' ? 'active' : ''}" data-compare-tab="integridade" role="tab">Integridade${state && state.integridade && state.integridade.problemas ? ` <span class="tag red">${state.integridade.problemas}</span>` : ''}</button>
    <button class="tab ${window.compareTab === 'baseline' ? 'active' : ''}" data-compare-tab="baseline" role="tab">Expressões editadas</button></div>`;
  window.bindCompareTabs = () => $$('[data-compare-tab]').forEach((b) => { b.onclick = () => { window.compareTab = b.dataset.compareTab; render(); }; });
  window.loadReviewer = loadReviewer;
  window.reviewerBarHTML = () => reviewerBarHTML();
  window.bindReviewerBar = (after) => bindReviewerBar(after);
  window.reviewerState = () => reviewer;

  /* ---------------- modo revisor ---------------- */
  function reviewerBarHTML() {
    return reviewer.desbloqueado
      ? `<div class="reviewer-bar on"><span>🔓 <b>Modo revisor ativo</b> · ${esc(reviewer.nome)} — edição de expressões, tabelas técnicas, dados de fabricante e referências normativas liberada (a sessão expira em 1 h).</span><button class="btn small" id="rev-lock">Bloquear</button></div>`
      : `<div class="reviewer-bar"><span>🔒 Modo revisor bloqueado. Cálculos e tabelas podem ser consultados e rastreados; a edição exige a senha local de revisor.</span><button class="btn small" id="rev-unlock">Desbloquear…</button></div>`;
  }
  function bindReviewerBar(after) {
    const u = $('#rev-unlock'), l = $('#rev-lock');
    if (u) u.onclick = () => reviewerModal(after);
    if (l) l.onclick = () => action(async () => { reviewer = await api('/api/reviewer/lock', {}); after(); }, 'Modo revisor bloqueado.');
  }
  function reviewerModal(after) {
    const first = !reviewer.configurado;
    modal(first ? 'Definir senha de revisor' : 'Desbloquear modo revisor',
      `<p class="subtitle">${first ? 'Primeiro uso: a senha que você digitar agora passa a ser a senha local de revisor deste computador (mínimo 6 caracteres). Ela fica gravada apenas como hash, ao lado dos projetos.' : 'Informe seu nome (vai para o histórico de edições) e a senha de revisor.'}</p>
       <div class="field"><label for="rev-nome">Nome do revisor</label><input id="rev-nome" autocomplete="off" value="${esc(localStorage.getItem('eletro-revisor') || '')}"></div>
       <div class="field"><label for="rev-senha">${first ? 'Nova senha' : 'Senha'}</label><input id="rev-senha" type="password" autocomplete="off"></div>`,
      `<button class="btn primary" id="rev-go">${first ? 'Definir e desbloquear' : 'Desbloquear'}</button>`);
    const go = () => action(async () => {
      const nome = $('#rev-nome').value.trim();
      reviewer = await api('/api/reviewer/unlock', { nome, senha: $('#rev-senha').value });
      try { localStorage.setItem('eletro-revisor', nome); } catch { /* ignora */ }
      $('#modal').close(); after();
    });
    $('#rev-go').onclick = go;
    $('#rev-senha').onkeydown = (e) => { if (e.key === 'Enter') go(); };
  }

  /* ---------------- catálogo ---------------- */
  async function fetchCatalog(append) {
    cat.loading = true;
    const params = new URLSearchParams({ q: cat.q, aba: cat.aba, status: cat.status, norma: cat.norma, limit: 60, offset: append ? cat.items.length : 0 });
    const d = await api('/api/catalog?' + params);
    cat.info = d; cat.total = d.total; cat.items = append ? cat.items.concat(d.entradas) : d.entradas; cat.loading = false;
  }
  const refChips = (refs) => (refs || []).map((r) => `<span class="tag ${r.verificada ? 'green' : 'amber'}" title="${esc(r.norma)} — ${esc(r.aviso || '')} ${esc(r.aviso_verificacao || '')}">${esc(r.item || r.tabela)}${r.verificada ? ' ✓' : ''}</span>`).join(' ');

  function catalogRowsHTML() {
    if (!cat.items.length) return '<tr><td colspan="5" class="empty">Nenhum cálculo encontrado com estes filtros.</td></tr>';
    return cat.items.map((e) => `<tr class="click-row" data-cat-id="${esc(e.id)}">
      <td class="wrap-cell"><b>${esc(e.descricao)}</b>${unitSuffix(e.descricao, e.unidade)}<br><small class="mono">${esc(e.id)}</small></td>
      <td class="wrap-cell">${esc(e.grupo_nome)}<br><small>${esc(e.escopo_rotulo)}</small></td>
      <td class="wrap-cell"><code class="mini-code">${esc(short(e.expressao, 130))}</code></td>
      <td>${statusChip(e.status)}${e.versao_ativa ? ` <small>v${e.versao_ativa}</small>` : ''}</td>
      <td>${e.sem_justificativa ? '<span class="tag">sem justificativa atribuída</span>' : refChips(e.refs_normativas)}</td></tr>`).join('');
  }

  function rulesHTML() {
    const rules = (cat.info && cat.info.regras_python) || [];
    return rules.map((r) => `<details class="panel rule-card"><summary><b>${esc(r.nome)}</b> <small class="mono">${esc(r.id)}</small> <span class="tag blue">regra em Python · v${esc(r.versao)}</span> ${refChips(r.refs_normativas)}</summary>
      <p>${esc(r.descricao)}</p><p class="subtitle">Módulo: <span class="mono">${esc(r.modulo)}</span>${r.funcoes.length ? ` · funções: <span class="mono">${esc(r.funcoes.join(', '))}</span>` : ''} · autor: ${esc(r.autor)}</p>
      <p class="subtitle">${esc(r.edicao)}</p>
      ${r.parametros.length ? `<h4>Dados usados</h4><p>${r.parametros.map((x) => `<span class="tag" title="${esc(x.id)}">${esc(x.rotulo)}${x.unidade ? ' (' + esc(x.unidade) + ')' : ''}</span>`).join(' ')}</p>` : ''}
      ${r.resultados.length ? `<h4>Resultados gravados ou calculados (${r.n_resultados})</h4><p>${r.resultados.map((x) => `<button class="tag link-tag" data-cat-open="${esc(x.id)}">${esc(x.rotulo)}</button>`).join(' ')}</p>` : ''}
      ${r.efeitos && r.efeitos.length ? `<h4>Efeitos</h4><ul>${r.efeitos.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}
      <p><select class="input" data-rule-circ="${esc(r.id)}" aria-label="Circuito">${(state.circuits || []).map((c) => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('')}</select>
      <button class="btn small" data-rule-apply="${esc(r.id)}">Ver aplicação no circuito</button></p>
      <h4>Histórico</h4><p class="subtitle">${r.historico.map((h) => `v${esc(h.versao)} · ${esc(h.data)} — ${esc(h.nota)}`).join('<br>')}</p>
      ${reviewer.desbloqueado ? `<button class="btn small" data-rule-link="${esc(r.id)}">Associar referências</button>` : ''}</details>`).join('');
  }

  function paintCatalog() {
    const i = cat.info; if (!i) return;
    $('#cat-tags').innerHTML = `<span class="tag">${i.total_entradas.toLocaleString('pt-BR')} cálculos com nome e unidade</span><span class="tag">${i.regras_python.length} regras em Python</span>
      <span class="tag ${i.editadas ? 'amber' : 'green'}">${i.editadas} expressão(ões) editada(s) no projeto</span>
      <span class="tag">${i.sem_justificativa} sem justificativa atribuída</span><span class="tag blue">${cat.total} no filtro</span>`;
    $('#cat-body').innerHTML = catalogRowsHTML();
    const more = $('#cat-more'); more.hidden = cat.items.length >= cat.total;
    more.textContent = `Carregar mais (${cat.items.length} de ${cat.total})`;
    $('#cat-rules').innerHTML = rulesHTML();
  }

  window.renderCatalogView = async function (main) {
    await loadReviewer();
    main.innerHTML = heading('Catálogo de cálculos', 'Cada cálculo é uma variável com nome, unidade, expressão, dependências explícitas, justificativa normativa e histórico. As regras implementadas em Python aparecem com os dados que usam e os resultados que produzem.')
      + `<div id="rev-bar"></div>
      <div class="explorer-controls"><input id="cat-q" class="search" placeholder="Buscar por nome, descrição, variável ou expressão…" value="${esc(cat.q)}" aria-label="Buscar cálculo">
      <select id="cat-aba" class="input" aria-label="Filtrar por grupo"><option value="">Todos os grupos</option></select>
      <select id="cat-status" class="input" aria-label="Filtrar por situação"><option value="">Todas as situações</option><option value="editada">Editadas</option><option value="alterada">Alteradas fora do aplicativo</option><option value="modelo">Modelo do aplicativo</option><option value="regra_python">Regras em Python</option><option value="sem_justificativa">Sem justificativa normativa</option></select>
      <select id="cat-norma" class="input" aria-label="Filtrar por norma"><option value="">Qualquer norma</option></select></div>
      <div class="toolbar" id="cat-tags"></div>
      <section class="panel"><div class="table-wrap"><table class="data-table"><thead><tr><th>Cálculo (variável)</th><th>Grupo</th><th>Expressão</th><th>Situação</th><th>Justificativa normativa</th></tr></thead><tbody id="cat-body"><tr><td colspan="5" class="empty">Carregando catálogo…</td></tr></tbody></table></div></section>
      <div class="more-wrap"><button class="btn" id="cat-more" hidden>Carregar mais</button>
      <button class="btn" id="cat-refs">Registro normativo</button></div>
      <h3>Regras implementadas em Python</h3><div id="cat-rules"></div>`;
    const bar = () => { $('#rev-bar').innerHTML = reviewerBarHTML(); bindReviewerBar(() => { bar(); paintCatalog(); }); };
    bar();
    await fetchCatalog(false);
    $('#cat-aba').innerHTML += cat.info.grupos.map((g) => `<option value="${esc(g.id)}" ${g.id === cat.aba ? 'selected' : ''}>${esc(g.nome)}</option>`).join('');
    $('#cat-norma').innerHTML += cat.info.normas.map((n) => `<option ${n === cat.norma ? 'selected' : ''}>${esc(n)}</option>`).join('');
    $('#cat-status').value = cat.status;
    paintCatalog();
    let timer;
    const reload = async () => { try { await fetchCatalog(false); paintCatalog(); } catch (e) { toast(e.message, true); } };
    $('#cat-q').oninput = (e) => { cat.q = e.target.value; clearTimeout(timer); timer = setTimeout(reload, 250); };
    $('#cat-aba').onchange = (e) => { cat.aba = e.target.value; reload(); };
    $('#cat-status').onchange = (e) => { cat.status = e.target.value; reload(); };
    $('#cat-norma').onchange = (e) => { cat.norma = e.target.value; reload(); };
    $('#cat-more').onclick = async () => { try { await fetchCatalog(true); paintCatalog(); } catch (e) { toast(e.message, true); } };
    $('#cat-refs').onclick = () => normrefsModal();
    $('#cat-body').onclick = (e) => { const tr = e.target.closest('[data-cat-id]'); if (tr) catalogEntryModal(tr.dataset.catId); };
    $('#cat-rules').onclick = (e) => {
      const o = e.target.closest('[data-cat-open]'); if (o) { catalogEntryModal(o.dataset.catOpen); return; }
      const ap = e.target.closest('[data-rule-apply]');
      if (ap) { const sel = document.querySelector(`[data-rule-circ="${ap.dataset.ruleApply}"]`); ruleApplicationModal(ap.dataset.ruleApply, sel.value); return; }
      const l = e.target.closest('[data-rule-link]');
      if (l) { const r = cat.info.regras_python.find((x) => x.id === l.dataset.ruleLink); linkRefsModal({ id: r.id, refs_normativas: r.refs_normativas }, async () => { await fetchCatalog(false); paintCatalog(); $('#modal').close(); }); }
    };
  };

  async function ruleApplicationModal(rid, uid) {
    busy(true);
    try {
      const a = await api('/api/rule?' + new URLSearchParams({ id: rid, circuito: uid }));
      const rows = (xs) => xs.length ? `<div class="table-wrap"><table class="data-table compact"><thead><tr><th>Dado</th><th>Valor neste circuito</th></tr></thead><tbody>${xs.map((x) => `<tr><td class="wrap-cell">${esc(x.rotulo)}<br><small class="mono">${esc(x.id)}</small></td><td class="wrap-cell">${esc(fv(x.valor))}${x.unidade ? ' ' + esc(x.unidade) : ''}</td></tr>`).join('')}</tbody></table></div>` : '<p class="subtitle">—</p>';
      modal(esc(a.nome) + ' · ' + esc(a.circuito), `<h4>Dados usados</h4>${rows(a.dados)}<h4>Resultados</h4>${rows(a.resultados)}
        <h4>Efeitos registrados</h4>${a.efeitos.length ? `<ul>${a.efeitos.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : '<p class="subtitle">—</p>'}`);
      wide();
    } catch (err) { toast(err.message, true); } finally { busy(false); }
  }

  /* ---------------- detalhe da fórmula ---------------- */
  async function catalogEntryModal(id) {
    busy(true, 'Abrindo cálculo…');
    try {
      const [e] = await Promise.all([api('/api/catalog/entry?id=' + encodeURIComponent(id)), loadReviewer()]);
      const canEdit = reviewer.desbloqueado && !e.gerida_por_instalacao;
      modal(esc(e.descricao) + unitSuffix(e.descricao, e.unidade),
        `<p class="subtitle"><span class="mono">${esc(e.id)}</span> · ${esc(e.grupo_nome)} · ${esc(e.escopo_rotulo)}${e.escopo === 'circuito' ? ` · vale para os ${e.n_circuitos} circuitos` : ''}</p>
        <div class="toolbar">${statusChip(e.status)}<span class="tag">${esc(e.baseline)}</span>${e.gerida_por_instalacao ? '<span class="tag red">regra em Python — não editável aqui</span>' : ''}</div>
        ${e.status === 'alterada' ? '<div class="notice red">A expressão em uso não tem registro válido de edição (alterada fora do aplicativo ou herdada de um projeto antigo). Confira-a; o revisor pode assumi-la com justificativa ou voltar ao modelo.</div>' : ''}
        <h4>Expressão em uso${e.versao_ativa ? ` (v${e.versao_ativa})` : ''}</h4><pre class="formula-code">${esc(e.expressao)}</pre>
        ${e.variantes && e.variantes.raiz ? `<h4>Circuitos ligados diretamente à fonte${e.versao_ativa_raiz ? ` (v${e.versao_ativa_raiz})` : ' (variante do modelo)'}</h4>
          <pre class="formula-code">${esc(e.expressao_raiz)}</pre><p class="subtitle">Esta variante é versionada à parte: editar a expressão comum não a altera.</p>
          ${canEdit ? '<button class="btn small" id="entry-edit-raiz">Editar a variante dos circuitos ligados à fonte</button>' : ''}` : ''}
        ${(e.escopos || []).filter((x) => x.escopo.startsWith('circuito:')).map((x) => `<h4>${esc(x.rotulo)} — versão própria${x.versao_ativa ? ` (v${x.versao_ativa})` : ' (inativa)'} <span class="tag ${x.situacao === 'alterada' ? 'red' : 'amber'}">${esc(x.situacao)}</span></h4>
          <pre class="formula-code">${esc(x.expressao)}</pre>${historyTable({ historico: x.historico }, canEdit, x.escopo)}`).join('')}
        ${e.versao_ativa ? `<h4>Expressão do modelo do aplicativo (imutável)</h4><pre class="formula-code">${esc(e.expressao_baseline)}</pre>` : ''}
        <h4>Dados usados</h4>${paramsTable(e.parametros)}
        ${e.dependentes && e.dependentes.length ? `<h4>Usado por</h4><p>${e.dependentes.map((d) => `<button class="tag link-tag" data-cat-open="${esc(d.id)}" title="${esc(d.id)}">${esc(d.rotulo)}</button>`).join(' ')}</p>` : ''}
        <h4>Justificativa normativa</h4><div id="entry-refs">${entryRefsHTML(e)}</div>
        <h4>Histórico</h4>${historyTable(e, canEdit)}`,
        `${reviewer.desbloqueado ? `<button class="btn" id="entry-link">Associar referências</button>` : ''}
         ${e.gerida_por_instalacao ? '' : `<button class="btn primary" id="entry-edit" ${reviewer.desbloqueado ? '' : 'disabled title="Desbloqueie o modo revisor para editar"'}>${e.status === 'alterada' ? 'Revisar expressão' : 'Editar expressão'}</button>`}`);
      wide();
      const edit = $('#entry-edit'); if (edit && reviewer.desbloqueado) edit.onclick = () => formulaEditModal(e);
      const editRaiz = $('#entry-edit-raiz'); if (editRaiz) editRaiz.onclick = () => formulaEditModal(e, 'raiz');
      const link = $('#entry-link'); if (link) link.onclick = () => linkRefsModal(e, () => catalogEntryModal(e.id));
      $$('[data-rollback]').forEach((b) => { b.onclick = () => rollbackFlow(e, Number(b.dataset.rollback), b.dataset.escopo || 'comum'); });
      $$('#modal [data-cat-open]').forEach((b) => { b.onclick = () => catalogEntryModal(b.dataset.catOpen); });
    } catch (err) { toast(err.message, true); } finally { busy(false); }
  }
  const paramsTable = (ps) => !ps || !ps.length ? '<p class="subtitle">Não usa outros dados.</p>'
    : `<div class="table-wrap"><table class="data-table compact"><thead><tr><th>Dado</th><th>Unidade</th><th>Origem</th><th>Grupo</th></tr></thead><tbody>${ps.map((p) => `<tr><td class="wrap-cell">${esc(p.rotulo)}<br><small class="mono">${esc(p.ref)}</small></td><td>${esc(p.unidade || '—')}</td><td class="wrap-cell">${esc(p.origem)}</td><td class="wrap-cell">${esc(p.grupo || p.escopo || '')}</td></tr>`).join('')}</tbody></table></div>`;
  function entryRefsHTML(e) {
    if (!e.refs_normativas.length) return '<p class="subtitle">Sem justificativa atribuída. O aplicativo não inventa citações: um revisor associa item/tabela da norma a este cálculo.</p>';
    return e.refs_normativas.map(refCard).join('');
  }
  const refCard = (r) => `<div class="ref-card"><b>${esc(r.norma)}</b> · ${esc(r.item ? 'item ' + r.item : r.tabela || '')} ${r.verificada ? `<span class="tag green">verificada por ${esc(r.verificado_por)} em ${esc(r.verificado_em)}</span>` : '<span class="tag amber">não verificada</span>'}
    ${(r.condicoes || []).length ? `<div><small>Condições: ${esc(r.condicoes.join('; '))}</small></div>` : ''}
    ${r.trecho ? `<blockquote>${esc(r.trecho)}</blockquote>` : ''}<div class="ref-warn">${esc(r.aviso || '')}</div></div>`;
  function historyTable(e, canRollback, escopo = 'comum') {
    return `<div class="table-wrap"><table class="data-table compact"><thead><tr><th>Versão</th><th>Tipo</th><th>Autor</th><th>Quando</th><th>Justificativa</th><th></th></tr></thead><tbody>${e.historico.map((h) => `<tr>
      <td>v${h.versao}${h.ativa ? ' <span class="tag green">ativa</span>' : ''}</td><td>${esc(h.tipo)}</td><td>${esc(h.autor || '—')}</td><td>${esc(h.ts ? fmtTs(h.ts) : '—')}</td>
      <td class="wrap-cell">${esc(h.justificativa)}${h.impacto ? `<br><small>${h.impacto.campos_afetados} campo(s) · ${h.impacto.circuitos_afetados} circuito(s) · ${h.impacto.novos_erros} novo(s) erro(s)</small>` : ''}</td>
      <td>${canRollback && !h.ativa ? `<button class="btn small" data-rollback="${h.versao}" data-escopo="${esc(escopo)}">Voltar para v${h.versao}</button>` : ''}</td></tr>`).join('')}</tbody></table></div>`;
  }
  function rollbackFlow(e, versao, escopo = 'comum') {
    if (!confirm(`Voltar o cálculo "${e.id}" (${escopo}) para a versão ${versao}${versao === 0 ? ' (modelo do aplicativo)' : ''}? As confirmações de proteção de todos os circuitos serão reabertas.`)) return;
    action(async () => {
      await api('/api/formula/rollback', { id: e.id, versao, escopo });
      await refresh(); await fetchCatalog(false); await catalogEntryModal(e.id);
    }, 'Versão restaurada.');
  }

  /* ---------------- edição segura ---------------- */
  function diffHTML(d, titulo) {
    if (!d) return '';
    const rows = d.campos.map((c) => `<tr><td class="wrap-cell">${esc(c.rotulo || c.id)}${c.unidade ? ' (' + esc(c.unidade) + ')' : ''}<br><small class="mono">${esc(c.id)}</small></td><td>${c.celulas}</td><td class="wrap-cell">${esc(short(c.circuitos.join(', '), 80))}</td>
      <td>${c.delta_rel_max == null ? '—' : (c.delta_rel_max * 100).toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + ' %'}</td>
      <td class="wrap-cell"><small>${esc(c.exemplos[0].circuito)}: ${esc(fv(c.exemplos[0].antes))} → ${esc(fv(c.exemplos[0].depois))}</small></td></tr>`).join('');
    return `<h4>${esc(titulo)}</h4><div class="toolbar"><span class="tag ${d.circuitos_afetados ? 'amber' : 'green'}">${d.circuitos_afetados} circuito(s) mudam</span><span class="tag">${d.campos_afetados} campo(s)</span><span class="tag">${d.celulas_afetadas} valor(es)</span><span class="tag ${d.novos_erros ? 'red' : 'green'}">${d.novos_erros} novo(s) erro(s)</span></div>
      ${d.campos.length ? `<div class="table-wrap"><table class="data-table compact"><thead><tr><th>Cálculo</th><th>Valores</th><th>Circuitos</th><th>Maior variação</th><th>Exemplo (antes → depois)</th></tr></thead><tbody>${rows}</tbody></table></div>` : '<p class="subtitle">Nenhum valor muda nos circuitos ativos.</p>'}${d.truncado ? '<p class="subtitle">Lista truncada.</p>' : ''}`;
  }
  function formulaEditModal(e, escopo = 'comum') {
    const atual = escopo === 'raiz' ? e.expressao_raiz : e.expressao;
    modal('Editar expressão · ' + esc(e.descricao) + (escopo === 'raiz' ? ' · circuitos ligados à fonte' : ''),
      `<div class="notice">A edição <b>nunca apaga</b> a expressão do modelo do aplicativo. A nova expressão é compilada, executada em todos os circuitos e comparada antes de ser gravada; se criar erros novos nos resultados obrigatórios, a gravação é bloqueada. Use os <b>nomes das variáveis</b> (ex.: <code>corrente.i_r_a</code>); <code>CIRCUITOS(x)</code> lê a variável em todos os circuitos, <code>ANTERIOR(x)</code> no circuito anterior e <code>FAIXA(a,b)</code> um bloco do mesmo circuito. Endereços de célula não são aceitos.</div>
       <div class="field wide"><label for="fx-expr">Expressão (comece com =)</label><textarea id="fx-expr" class="mono" rows="6" spellcheck="false">${esc(atual)}</textarea></div>
       ${e.variantes && e.variantes.raiz && escopo === 'comum' ? '<div class="notice blue">Esta edição vale para os circuitos comuns. Os circuitos ligados diretamente à fonte continuam com a variante própria.</div>' : ''}
       <div class="modal-inline"><button class="btn" id="fx-preview">Pré-validar e comparar</button><span class="subtitle" id="fx-status"></span></div>
       <div id="fx-diff"></div>
       <div id="fx-confirm" hidden>
         <div class="field wide"><label for="fx-just">Justificativa (obrigatória, mín. 15 caracteres — vai para o histórico e para o relatório)</label><textarea id="fx-just" rows="3"></textarea></div>
         <label class="check"><input type="checkbox" id="fx-ok"> Revisei o diff acima e confirmo a alteração. Entendo que as confirmações de proteção de todos os circuitos serão reabertas (PENDENTE).</label>
       </div>`,
      `<button class="btn" id="fx-back">Voltar</button><button class="btn primary" id="fx-save" disabled>Confirmar e salvar nova versão</button>`);
    wide();
    let validated = null;
    const original = $('#fx-expr').value;
    $('#fx-back').onclick = () => catalogEntryModal(e.id);
    $('#fx-expr').oninput = () => { validated = null; $('#fx-confirm').hidden = true; $('#fx-save').disabled = true; $('#fx-diff').innerHTML = ''; };
    $('#fx-preview').onclick = async () => {
      const expressao = $('#fx-expr').value.trim();
      if (expressao === original.trim() && e.status !== 'alterada') { toast('A expressão é igual à versão ativa.', true); return; }
      busy(true, 'Executando a nova expressão em todos os circuitos…');
      try {
        const r = await api('/api/formula/edit', { id: e.id, expressao, escopo });
        validated = expressao;
        $('#fx-status').textContent = `${r.celulas_alteradas} circuito(s) simulados · versão proposta v${r.versao_proposta}.`;
        const showBase = r.diff_baseline && (r.diff_baseline.celulas_afetadas !== r.diff.celulas_afetadas || r.diff_baseline.campos_afetados !== r.diff.campos_afetados);
        $('#fx-diff').innerHTML = diffHTML(r.diff, 'Impacto desta edição (antes → depois)')
          + (showBase ? diffHTML(r.diff_baseline, 'Diferença acumulada contra o modelo do aplicativo') : '');
        $('#fx-confirm').hidden = false; syncSave();
      } catch (err) { validated = null; toast(err.message, true); } finally { busy(false); }
    };
    const syncSave = () => { $('#fx-save').disabled = !(validated && $('#fx-ok').checked && $('#fx-just').value.trim().length >= 15); };
    document.addEventListener('input', function h(ev) { if (!$('#fx-just')) { document.removeEventListener('input', h); return; } if (ev.target.id === 'fx-just' || ev.target.id === 'fx-ok') syncSave(); });
    $('#fx-save').onclick = () => action(async () => {
      await api('/api/formula/confirm', { id: e.id, expressao: validated, justificativa: $('#fx-just').value.trim(), confirmado: true, escopo });
      await refresh(); await fetchCatalog(false); await catalogEntryModal(e.id);
      if (location.hash === '#sheets') render();
    }, 'Nova versão da expressão gravada. Confirmações de proteção reabertas.');
  }

  /* ---------------- referências normativas ---------------- */
  async function linkRefsModal(e, back) {
    const { refs } = await api('/api/normrefs');
    const cur = new Set(e.refs_normativas.map((r) => r.id));
    modal('Associar referências · ' + esc(e.id),
      `<p class="subtitle">Escolha o que justifica este cálculo. As referências embarcadas são localizadores (item/tabela) sem texto da norma: confira na edição vigente. Referência errada é pior que referência ausente.</p>
       <div id="ref-list">${refs.map((r) => `<label class="check ref-pick"><input type="checkbox" value="${esc(r.id)}" ${cur.has(r.id) ? 'checked' : ''}> <span><b>${esc(r.norma)}</b> · ${esc(r.item ? 'item ' + r.item : r.tabela || '')} <small class="mono">${esc(r.id)}</small> ${r.verificada ? '<span class="tag green">verificada</span>' : '<span class="tag amber">não verificada</span>'}<br><small>${esc((r.condicoes || []).join('; '))}</small></span></label>`).join('') || '<p class="empty">Registro vazio.</p>'}</div>
       <button class="btn" id="ref-new">+ Nova referência…</button>`,
      `<button class="btn" id="ref-back">Voltar</button><button class="btn primary" id="ref-save">Salvar associação</button>`);
    wide();
    $('#ref-back').onclick = () => back();
    $('#ref-new').onclick = () => newRefModal(() => linkRefsModal(e, back));
    $('#ref-save').onclick = () => action(async () => {
      await api('/api/normref/link', { id: e.id, refs: $$('#ref-list input:checked').map((i) => i.value) });
      await fetchCatalog(false); await back();
    }, 'Associação salva.');
  }
  function newRefModal(back) {
    modal('Nova referência normativa',
      `<div class="notice">Cadastre o <b>identificador de localização</b> (norma, item/tabela, condições). O trecho é opcional: se colar texto, marque se é transcrição literal; caso contrário ele será exibido como paráfrase. Direitos autorais: prefira item/tabela e um trecho curto.</div>
       <div class="field-grid">
       <div class="field"><label for="nr-id">Identificador</label><input id="nr-id" placeholder="NBR5410-6.2.5.2" autocomplete="off"></div>
       <div class="field"><label for="nr-norma">Norma</label><input id="nr-norma" placeholder="ABNT NBR 5410:2004" autocomplete="off"></div>
       <div class="field"><label for="nr-item">Item</label><input id="nr-item" autocomplete="off"></div>
       <div class="field"><label for="nr-tab">Tabela</label><input id="nr-tab" autocomplete="off"></div></div>
       <div class="field wide"><label for="nr-cond">Condições (separe por ;)</label><input id="nr-cond" placeholder="Ib ≤ In ≤ Iz" autocomplete="off"></div>
       <div class="field wide"><label for="nr-trecho">Trecho (opcional, curto)</label><textarea id="nr-trecho" rows="3"></textarea></div>
       <label class="check"><input type="checkbox" id="nr-verb"> O trecho acima é transcrição literal da norma</label>
       <label class="check"><input type="checkbox" id="nr-ver"> Eu verifiquei esta referência diretamente na norma (carimbo de revisor e data)</label>`,
      `<button class="btn" id="nr-back">Voltar</button><button class="btn primary" id="nr-save">Salvar referência</button>`);
    wide();
    $('#nr-back').onclick = back;
    $('#nr-save').onclick = () => action(async () => {
      await api('/api/normref/save', { ref: { id: $('#nr-id').value, norma: $('#nr-norma').value, item: $('#nr-item').value, tabela: $('#nr-tab').value, condicoes: $('#nr-cond').value, trecho: $('#nr-trecho').value, verbatim: $('#nr-verb').checked }, verificar: $('#nr-ver').checked });
      back();
    }, 'Referência salva.');
  }
  async function normrefsModal() {
    busy(true);
    try {
      const { refs } = await api('/api/normrefs');
      modal('Registro normativo', `<p class="subtitle">Identificadores de norma disponíveis neste projeto. Itens sem carimbo de revisor aparecem como “não verificada”.</p>
        ${refs.map(refCard).join('') || '<p class="empty">Registro vazio.</p>'}`,
        reviewer.desbloqueado ? '<button class="btn primary" id="nr-add">+ Nova referência…</button>' : '');
      wide();
      const add = $('#nr-add'); if (add) add.onclick = () => newRefModal(normrefsModal);
    } finally { busy(false); }
  }

  /* ---------------- trilha de cálculo ---------------- */
  const traceStack = [];
  const originTag = (o) => `<span class="tag ${o === 'cálculo' ? 'blue' : o === 'dado informado' ? 'green' : ''}">${esc(o)}</span>`;
  function precedentHTML(p, depth, cid) {
    const label = `<b>${esc(p.rotulo || p.ref)}</b>${unitSuffix(p.rotulo, p.unidade)} <small class="mono">${esc(p.ref)}</small>`;
    if (p.tipo === 'variavel') {
      const expandable = p.origem === 'cálculo' && depth < 6;
      return `<li class="prec"><div class="prec-row">${expandable ? `<button class="prec-toggle" data-open="0" data-var="${esc(p.ref)}" data-cid="${esc(cid || '')}" data-depth="${depth}" aria-label="Expandir precedentes">▸</button>` : '<span class="prec-toggle off">•</span>'}
        <button class="prec-link" data-trace-var="${esc(p.ref)}" data-trace-cid="${esc(cid || '')}">${label}</button><span class="prec-val">${esc(fv(p.valor))}</span>${originTag(p.origem)}</div><ul class="prec-children"></ul></li>`;
    }
    if (p.tipo === 'vetor') return `<li class="prec"><div class="prec-row"><span class="prec-toggle off">▤</span><span>${label}</span><span class="prec-val">todos os circuitos</span>${originTag(p.origem)}</div></li>`;
    if (p.tipo === 'nome') return `<li class="prec"><div class="prec-row"><span class="prec-toggle off">•</span><span>${label}</span><span class="prec-val">intervalo de tabela</span><small class="mono">${esc(p.destino || '')}</small></div></li>`;
    return `<li class="prec"><div class="prec-row"><span class="prec-toggle off">▦</span><span>${label}</span><span class="prec-val">tabela técnica</span>${p.tabela ? `<a class="btn small" href="#tables" data-goto-table="${esc(p.tabela)}">Abrir tabela</a>` : ''}</div></li>`;
  }
  function traceBody(t) {
    const cmp = (rot, v, extra = '') => `<div><label>${rot}</label>${extra ? extra : `<span class="${isErr(v) ? 'err' : ''}">${esc(fv(v))}</span>`}</div>`;
    const integ = t.integridade && t.integridade.situacao !== 'modelo' ? `<span class="tag ${['alterada', 'invalida', 'desconhecida'].includes(t.integridade.situacao) ? 'red' : 'amber'}">${esc(t.integridade.rotulo)}</span>` : '';
    return `<div class="trace-head"><div><b>${esc(t.rotulo || '')}</b>${unitSuffix(t.rotulo, t.unidade)}<br><small class="mono">${esc(t.campo || '')}</small>${t.circuito ? ` · circuito <b>${esc(t.circuito)}</b>` : ''}</div><div>${originTag(t.origem)} ${integ}${t.catalogo_id ? ` <button class="btn small" data-open-cat="${esc(t.catalogo_id)}">Abrir no catálogo</button>` : ''}</div></div>
      <h4>1 · Expressão</h4>${t.expressao ? `<pre class="formula-code">${esc(t.expressao)}</pre>${t.variante ? '<p class="subtitle">Variante para circuito ligado diretamente à fonte.</p>' : ''}${t.funcoes_python && t.funcoes_python.length ? `<p class="subtitle">Usa regra do aplicativo em Python: ${esc(t.funcoes_python.join(', '))}.</p>` : ''}` : `<p class="subtitle">${t.origem === 'dado informado' ? 'Dado informado no projeto' : 'Valor da base técnica'}, sem expressão.</p>`}
      ${t.eh_formula ? `<h4>2 · Dados usados <small>(▸ expande; clique para rastrear)</small></h4>
      ${t.precedentes.length ? `<ul class="prec-tree" id="prec-root">${t.precedentes.map((p) => precedentHTML(p, 0, t.circuito_id)).join('')}</ul>` : '<p class="subtitle">Não usa outros dados.</p>'}
      <h4>3 · Substituição numérica</h4><pre class="formula-code">${esc(t.substituicao || '')}</pre>` : ''}
      <h4>${t.eh_formula ? '4' : '2'} · Valores</h4>
      <div class="compare-values three">${cmp(t.baseline_diverge ? 'COM A EXPRESSÃO DO MODELO' : 'VALOR CALCULADO', t.recalculado)}${t.editada !== null && t.editada !== undefined || t.baseline_diverge ? cmp('COM A EXPRESSÃO EDITADA (EM USO)', t.editada ?? t.valor_atual) : cmp('VERSÃO EDITADA', null, '<small>sem edição neste cálculo</small>')}</div>
      ${t.baseline_diverge ? '<div class="notice">Este cálculo usa uma expressão editada: o valor em uso difere do obtido com a expressão do modelo do aplicativo.</div>' : ''}`;
  }
  async function traceInto(query, push) {
    const t = await api('/api/trace?' + new URLSearchParams(query));
    if (push) traceStack.push(query);
    const back = traceStack.length > 1 ? '<button class="btn small" id="trace-back">← Voltar</button>' : '';
    modal('Trilha de cálculo', traceBody(t), back);
    wide();
    const b = $('#trace-back'); if (b) b.onclick = () => { traceStack.pop(); const prev = traceStack[traceStack.length - 1]; action(() => traceInto(prev, false)); };
  }
  window.cellModal = async function (sheet, address) {
    busy(true, 'Montando a trilha de cálculo…');
    try { traceStack.length = 0; await traceInto({ campo: sheet + '!' + address }, true); } catch (e) { toast(e.message, true); } finally { busy(false); }
  };
  window.traceVariable = async function (variable, circuitId) {
    busy(true, 'Montando a trilha de cálculo…');
    try { traceStack.length = 0; await traceInto({ campo: variable, circuito: circuitId || '' }, true); } catch (e) { toast(e.message, true); } finally { busy(false); }
  };
  document.addEventListener('click', async (ev) => {
    const link = ev.target.closest('[data-trace-var]'), tog = ev.target.closest('.prec-toggle[data-var]'), opn = ev.target.closest('[data-open-cat]');
    const gt = ev.target.closest('[data-goto-table]');
    if (gt) { window.tablesSelected = gt.dataset.gotoTable; $('#modal').close(); return; }
    if (opn) { catalogEntryModal(opn.dataset.openCat); return; }
    if (link) { ev.preventDefault(); busy(true); try { await traceInto({ campo: link.dataset.traceVar, circuito: link.dataset.traceCid }, true); } catch (e) { toast(e.message, true); } finally { busy(false); } return; }
    if (tog) {
      const li = tog.closest('li'), ul = li.querySelector(':scope > .prec-children');
      if (tog.dataset.open === '1') { ul.style.display = 'none'; tog.textContent = '▸'; tog.dataset.open = '0'; return; }
      if (!ul.dataset.loaded) {
        try {
          const t = await api('/api/trace?' + new URLSearchParams({ campo: tog.dataset.var, circuito: tog.dataset.cid }));
          ul.innerHTML = t.precedentes.map((p) => precedentHTML(p, Number(tog.dataset.depth) + 1, t.circuito_id)).join('') || '<li class="subtitle">Sem precedentes.</li>';
          ul.dataset.loaded = '1';
        } catch (e) { toast(e.message, true); return; }
      }
      ul.style.display = 'block'; tog.textContent = '▾'; tog.dataset.open = '1';
    }
  });

  /* ---------------- expressões editadas ---------------- */
  window.renderDivergencesView = async function (main) {
    await loadReviewer();
    main.innerHTML = heading('Integridade e expressões editadas', 'Expressões diferentes do modelo do aplicativo: autor, justificativa, situação do registro e diferença de resultados.') + compareTabsHTML() + '<div id="div-body"><div class="loading-card">Comparando com o modelo…</div></div>';
    bindCompareTabs();
    const d = await api('/api/formula/divergences');
    const items = d.itens.length ? d.itens.map((i) => `<tr class="click-row" data-cat-id="${esc(i.id)}"><td class="wrap-cell"><b>${esc(i.descricao)}</b><br><small class="mono">${esc(i.id)}</small><br><small>${esc(i.escopo_rotulo || '')}</small></td><td>v${esc(i.versao)}${['alterada', 'invalida'].includes(i.integridade) ? ' <span class="tag red">sem registro válido</span>' : ''}</td><td>${esc(i.autor || '—')}</td><td>${esc(fmtTs(i.ts))}</td><td class="wrap-cell">${esc(i.justificativa || '—')}</td>
      <td class="wrap-cell"><small>modelo:</small> <code class="mini-code">${esc(short(i.expressao_baseline, 110))}</code><br><small>em uso:</small> <code class="mini-code">${esc(short(i.expressao, 110))}</code></td></tr>`).join('')
      : '<tr><td colspan="6" class="empty">Nenhuma expressão editada: todos os cálculos usam o modelo do aplicativo.</td></tr>';
    const hist = d.historico_completo.length ? `<h3>Histórico completo de edições</h3><div class="table-wrap"><table class="data-table compact"><thead><tr><th>Quando</th><th>Cálculo</th><th>Versão</th><th>Tipo</th><th>Autor</th><th>Justificativa</th></tr></thead><tbody>${d.historico_completo.map((h) => `<tr><td>${esc(fmtTs(h.ts))}</td><td class="mono">${esc(h.id)}</td><td>v${esc(h.versao)}</td><td>${esc(h.tipo)}</td><td>${esc(h.autor || '—')}</td><td class="wrap-cell">${esc(h.justificativa || '')}</td></tr>`).join('')}</tbody></table></div>` : '';
    $('#div-body').innerHTML = `<section class="panel"><div class="table-wrap"><table class="data-table"><thead><tr><th>Cálculo</th><th>Versão</th><th>Autor</th><th>Data</th><th>Justificativa</th><th>Expressões</th></tr></thead><tbody>${items}</tbody></table></div></section>
      ${d.diff_baseline ? diffHTML(d.diff_baseline, 'Diferença acumulada contra o modelo do aplicativo') : ''}${hist}`;
    $('#div-body').onclick = (e) => { const tr = e.target.closest('[data-cat-id]'); if (tr) catalogEntryModal(tr.dataset.catId); };
  };
  window.catalogEntryModal = catalogEntryModal;
})();

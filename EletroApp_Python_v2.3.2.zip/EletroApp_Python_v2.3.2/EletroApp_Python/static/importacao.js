'use strict';
/* v1.12 — Importação de quadros de cargas e unifilares com revisão antes de gravar.
 * CSV e XLSX são lidos localmente (as fórmulas do XLSX não são executadas). PDF e imagens usam a
 * extração assistida por IA, somente quando habilitada no servidor. Nada é gravado sem confirmação;
 * o servidor revalida tudo e o motor do EletroApp recalcula os resultados. */
let importRows=null;
const IMP_LIG=['Monofásico','Bifásico','Trifásico'];
const IMP_NAT=['Distribuição','Circuito final','Origem'];
function readAsBase64(file){return new Promise((ok,fail)=>{const r=new FileReader();r.onload=()=>ok(String(r.result).split(',')[1]||'');r.onerror=()=>fail(Error('Não foi possível ler '+file.name));r.readAsDataURL(file);});}
function importLoadsModal(){
  const ia=state&&state.ia_importacao;
  modal('Importar quadro de cargas ou unifilar',`<p>Envie um ou mais documentos do mesmo projeto: quadro de cargas, unifilar ou ambos. O EletroApp identifica quadros, circuitos, cargas, condutores e vínculos, mostra de onde veio cada valor e o que falta, e só grava depois da sua revisão.</p>
    <div class="field"><label for="imp-files">Documentos</label><input type="file" id="imp-files" multiple accept=".csv,.txt,.xlsx${ia?',.pdf,.png,.jpg,.jpeg,.webp':''}"></div>
    <ul class="field-note"><li><b>CSV e XLSX</b>: a primeira linha da tabela deve ter o nome do circuito e outras colunas como montante, ligação, potência (W, kW ou por fase), fator de potência, comprimento e seções. Fórmulas de planilha não são executadas: valem os valores salvos no arquivo.</li>
    <li><b>PDF e imagens</b>: ${ia?'lidos pela extração assistida por IA. <b>O documento é enviado à API da Anthropic</b>; a IA só interpreta o documento, e os cálculos continuam no EletroApp.':'exigem a extração assistida por IA, desativada neste computador (defina a variável <code>ANTHROPIC_API_KEY</code> antes de iniciar o aplicativo).'}</li>
    <li><b>DXF</b>: previsto para uma etapa posterior.</li></ul>`,`<button class="btn primary" id="imp-read">Ler documentos</button>`);
  $('#imp-read').onclick=()=>action(async()=>{
    const files=[...$('#imp-files').files];if(!files.length)throw Error('Escolha ao menos um documento.');
    if(files.length>6)throw Error('Envie no máximo 6 documentos por vez.');
    const arquivos=[];for(const f of files){if(f.size>12_000_000)throw Error(`${f.name} excede 12 MB.`);arquivos.push({nome:f.name,conteudo:await readAsBase64(f)});}
    busy(true,files.some(f=>/\.(pdf|png|jpe?g|webp)$/i.test(f.name))?'Lendo documentos com IA…':'Lendo documentos…');
    try{const r=await api('/api/import-loads/preview',{arquivos});importRows=r;importReviewModal(r);}finally{busy(false);}
  });
}
function impInput(r,key,val,cls=''){return `<input class="imp-in ${cls}" data-imp-row="${r.id}" data-imp-key="${esc(key)}" value="${esc(val==null?'':(typeof val==='number'?formatBR(val):val))}" ${['p_R','p_S','p_T','fp','comprimento','sec_f','sec_n','sec_pe'].includes(key)?'inputmode="decimal"':''}>`;}
function impSelect(r,key,val,opts){return `<select class="imp-in" data-imp-row="${r.id}" data-imp-key="${esc(key)}">${opts.map(o=>`<option ${o===val?'selected':''}>${esc(o)}</option>`).join('')}</select>`;}
function importReviewModal(r){
  const docs=r.documentos.map(d=>`<li><b>${esc(d.documento)}</b>${d.planilha?` · aba ${esc(d.planilha)}, cabeçalho na linha ${d.linha_cabecalho}`:''}${d.ia?' · leitura por IA':''}<br><small>Colunas reconhecidas: ${Object.entries(d.mapeamento).map(([k,v])=>`${esc(r.campos[k]||k)} ← “${esc(v)}”`).join(' · ')}</small>${d.colunas_ignoradas&&d.colunas_ignoradas.length?`<br><small class="muted">Ignoradas: ${esc(d.colunas_ignoradas.join(', '))}</small>`:''}${d.observacoes&&d.observacoes.length?`<br><small>Observações da leitura: ${esc(d.observacoes.join(' · '))}</small>`:''}</li>`).join('');
  const row=x=>{const d=x.dados,p=d.p||{};const tip=Object.entries(x.fontes||{}).map(([k,v])=>`${r.campos[k]||k}: ${v}`).join('\n');
    const msgs=[...x.conflitos.map(m=>`<li class="imp-err">✗ ${esc(m)}</li>`),...x.ausentes.map(m=>`<li class="imp-miss">△ ${esc(m)}</li>`),...x.avisos.map(m=>`<li class="imp-note">${esc(m)}</li>`)].join('');
    return `<tr class="imp-row ${x.conflitos.length?'has-conflict':''}"><td>${impSelect(x,'acao',x.acao,x.existe?['atualizar','ignorar']:['incluir','ignorar'])}</td>
      <td>${impInput(x,'nome',d.nome)}<small class="cell-sub" title="${esc(tip)}">${esc(x.origem||'')}</small></td><td>${impInput(x,'montante',d.montante)}</td>
      <td>${impSelect(x,'ligacao',d.ligacao,IMP_LIG)}</td><td>${impSelect(x,'natureza',d.natureza,IMP_NAT)}</td>
      <td>${impInput(x,'p_R',p.R,'num')}</td><td>${impInput(x,'p_S',p.S,'num')}</td><td>${impInput(x,'p_T',p.T,'num')}</td>
      <td>${impInput(x,'fp',d.fp,'num')}</td><td>${impInput(x,'comprimento',d.comprimento,'num')}</td>
      <td>${impInput(x,'sec_f',d.sec_f,'num')}</td><td>${impInput(x,'sec_n',d.sec_n,'num')}</td><td>${impInput(x,'sec_pe',d.sec_pe,'num')}</td>
      <td class="wrap-cell"><ul class="imp-msgs">${msgs}</ul></td></tr>`;};
  modal('Revisar antes de gravar',`<ul class="imp-docs">${docs}</ul>
    <div class="toolbar"><span class="tag">${r.resumo.total} circuitos lidos</span><span class="tag green">${r.resumo.incluir} a incluir</span><span class="tag">${r.resumo.atualizar} a atualizar</span>${r.resumo.com_conflito?`<span class="tag red">${r.resumo.com_conflito} com conflito</span>`:''}</div>
    ${r.aviso_capacidade?`<div class="notice red">${esc(r.aviso_capacidade)}</div>`:''}
    <p class="field-note">Linhas com conflito começam como “ignorar”. Corrija os valores aqui ou no documento e escolha “incluir”. Passe o mouse sobre a origem para ver de onde veio cada valor. Potências em W por fase; seções em mm². Ao gravar, os resultados são recalculados pelo EletroApp e as proteções seguem o modo Automático/Manual do projeto.</p>
    <div class="table-wrap imp-wrap ux-noseg"><table class="data-table compact imp-table"><thead><tr><th>Ação</th><th>Circuito</th><th>Montante</th><th>Ligação</th><th>Natureza</th><th>P R (W)</th><th>P S (W)</th><th>P T (W)</th><th>FP</th><th>Compr. (m)</th><th>Fase (mm²)</th><th>N (mm²)</th><th>PE (mm²)</th><th>Origem, ausências e conflitos</th></tr></thead><tbody>${r.linhas.map(row).join('')}</tbody></table></div>`,
    `<button class="btn" id="imp-back">Escolher outros documentos</button><button class="btn primary" id="imp-save">Gravar circuitos selecionados</button>`);
  $('#modal').classList.add('wide-modal');
  $('#imp-back').onclick=importLoadsModal;
  $('#imp-save').onclick=()=>action(async()=>{
    const linhas=collectImportRows();
    if(!linhas.some(x=>x.acao!=='ignorar'))throw Error('Nenhum circuito marcado para incluir ou atualizar.');
    const res=await api('/api/import-loads/confirm',{linhas});
    $('#modal').close();$('#modal').classList.remove('wide-modal');location.hash='circuits';await refresh();
    toast(`Importação gravada: ${res.incluidos} incluído(s), ${res.atualizados} atualizado(s). Revise as pendências de cada circuito.`);
  });
}
function collectImportRows(){
  const byId=new Map(importRows.linhas.map(x=>[x.id,JSON.parse(JSON.stringify(x))]));
  $$('.imp-in').forEach(el=>{const x=byId.get(Number(el.dataset.impRow));if(!x)return;const k=el.dataset.impKey;let v=el.value.trim();
    if(k==='acao'){x.acao=v;return;}
    const numeric=['p_R','p_S','p_T','fp','comprimento','sec_f','sec_n','sec_pe'].includes(k);
    if(numeric){if(v===''){v=null;}else{const n=parseBR(v);if(!Number.isFinite(n))throw Error(`${x.dados.nome||'Linha'}: “${v}” não é um número.`);v=n;}}
    else if(v==='')v=null;
    if(k.startsWith('p_')){x.dados.p=x.dados.p||{R:0,S:0,T:0};x.dados.p[k.slice(2)]=v??0;}else x.dados[k]=v;});
  return [...byId.values()].map(x=>({acao:x.acao,dados:x.dados}));
}
document.addEventListener('DOMContentLoaded',()=>{const b=document.getElementById('import-loads');if(b)b.onclick=importLoadsModal;});
document.addEventListener('close',e=>{if(e.target&&e.target.id==='modal')e.target.classList.remove('wide-modal');},true);

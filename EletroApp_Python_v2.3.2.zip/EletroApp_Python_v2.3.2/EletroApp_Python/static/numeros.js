'use strict';
/* v1.12 — números no formato brasileiro. Mesma regra de core/numeros.py:
 *  - com vírgula: vírgula decimal e pontos de milhar ("1.000,00" → 1000; "1,5" → 1,5);
 *  - sem vírgula: pontos em grupos de três dígitos são milhar ("1.000" → 1000); outro ponto é decimal ("1.5" → 1,5).
 * Devolve NaN quando o texto não é um número. */
(function(){
  const THOUSANDS=/^[+-]?\d{1,3}(?:\.\d{3})+$/;
  const BR=/^[+-]?(?:\d{1,3}(?:\.\d{3})+|\d+)(?:,\d+)?,?$/;
  const PLAIN=/^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/;
  function parseBR(text){
    if(typeof text==='number')return Number.isFinite(text)?text:NaN;
    const t=String(text??'').replace(/[\s ]/g,'');
    if(!t)return NaN;
    let v;
    if(t.includes(',')){if((t.match(/,/g)||[]).length>1||!BR.test(t))return NaN;v=Number(t.replace(/\./g,'').replace(',','.'));}
    else if(THOUSANDS.test(t))v=Number(t.replace(/\./g,''));
    else if(PLAIN.test(t))v=Number(t);
    else return NaN;
    return Number.isFinite(v)?v:NaN;
  }
  // Exibição: vírgula decimal, sem separador de milhar (o campo continua editável e sem ambiguidade).
  function formatBR(v,decimals){
    if(typeof v!=='number'||!Number.isFinite(v))return '';
    let s=decimals==null?String(+v.toFixed(6)):v.toFixed(decimals);
    if(decimals!=null&&s.includes('.'))s=s.replace(/0+$/,'').replace(/\.$/,'');
    return s.replace('.',',');
  }
  window.parseBR=parseBR;window.formatBR=formatBR;
})();

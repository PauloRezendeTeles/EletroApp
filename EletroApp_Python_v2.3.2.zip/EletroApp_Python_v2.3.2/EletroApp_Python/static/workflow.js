/* Escolhas guiadas. Cálculos e seleção pertencem ao servidor; a prévia não salva. */
const FLOW_SHEET='Escolhas (EletroApp)', FLOW_LOAD='Levantamento de carga';
let workflowTimer=null, workflowTicket=0, workflowPreviewBusy=false;
const fcol=f=>/^[A-Z]+/.exec(f.address)?.[0];
function workflowMode(key){
  const index=drawerData?.choice_fields?.findIndex(f=>f.address.startsWith(key+':'))??-1;
  return index>=0?document.getElementById('choice-'+index)?.value||drawerData.choice_fields[index].value:null;
}
// v1.10: os modos ficam nas próprias abas (Proteções e DPS); a prévia fica no rodapé do formulário.
function choiceHeaderHTML(){return '';}
const CHOICE_HINTS={protecao:'O aplicativo escolhe modelo e ajustes pela corrente, pelo cabo, pela partida e pelo curto-circuito.',
  manutencao:'O aplicativo escolhe o disjuntor pela corrente, pela partida e pelo Ik no ponto de instalação (e pelo cabo, quando não há dispositivo na origem).',
  dps:'O aplicativo escolhe um modelo compatível com a classe, os polos, o aterramento e a tensão.',
  backup:'O aplicativo escolhe o fusível do catálogo dentro do limite do DPS e com poder de corte suficiente.'};
function choiceModeHTML(data,key,label){
  const i=(data.choice_fields||[]).findIndex(f=>f.address.startsWith(key+':'));if(i<0)return '';
  const f=data.choice_fields[i];
  return `<div class="mode-bar"><label for="choice-${i}">${esc(label)}</label><select id="choice-${i}" data-type="text">${['Automático','Manual'].map(o=>`<option ${o===f.value?'selected':''}>${o}</option>`).join('')}</select><span class="mode-hint" data-mode-hint="${key}">${esc(f.value==='Automático'?CHOICE_HINTS[key]:'Escolha manual: você define o modelo; as verificações continuam ativas.')}</span></div>`;
}
const NEW_PROJECT_MODES=[['protecao','Disjuntor na origem'],['manutencao','Disjuntor de manutenção'],['dps','DPS'],['backup','Backup do DPS']];
function newProjectModesHTML(){return `<div class="choice-start"><h3>Escolha das proteções</h3><div class="choice-grid">${NEW_PROJECT_MODES.map(([key,label])=>`<div class="field"><label for="new-mode-${key}">${label}</label><select id="new-mode-${key}"><option>Automático</option><option>Manual</option></select></div>`).join('')}</div></div>`;}
function newProjectModes(){return Object.fromEntries(NEW_PROJECT_MODES.map(([k])=>[k,document.getElementById('new-mode-'+k).value]));}
function flowField(g,data,col,sheet){
  const f=g.fields.find(x=>fcol(x)===col&&(!sheet||x.sheet===sheet));if(!f)return '';
  return fieldHTML(f,'field-'+data.fields.indexOf(f));
}
function workflowGroupHTML(g,data){
  const f=(col,sheet)=>flowField(g,data,col,sheet);
  if(g.key==='motores')return `<div class="motor-guide"><p>Cadastre apenas os motores deste circuito. Os quadros a montante recebem a contribuição dos circuitos vinculados automaticamente.</p>
    <div class="motor-block"><h4>1. Maior motor</h4><p>Informe a potência e os polos. A tabela de motores da base técnica completa os parâmetros disponíveis.</p><div class="fields">${f('V',FLOW_LOAD)}${f('T',FLOW_LOAD)}${f('U',FLOW_LOAD)}</div>
    <div id="motor-values">${motorValuesHTML(data)}</div>
    <details class="guided-more" id="motor-plate"><summary>Dados de placa / entrada manual</summary><p>Preencha só o que deseja substituir. Em branco, o aplicativo usa a tabela ou o cálculo disponível. Para um motor fora da tabela, informe fp, rendimento e Ip/In; a corrente pode ser calculada.</p><div class="fields">${['AG','AH','AI','AJ','AK','AL'].map(c=>f(c,FLOW_LOAD)).join('')}</div></details></div>
    <div class="motor-block"><h4>2. Demais motores</h4><p>Some as potências em cv, excluindo o maior motor acima. Não repita os motores já cadastrados nos circuitos filhos.</p><div class="fields">${f('Y',FLOW_LOAD)}<div class="motor-others wide"><div class="fields">${f('AA',FLOW_LOAD)}${f('AB',FLOW_LOAD)}</div><p class="field-hint">O fp e o rendimento médios dependem do conjunto instalado. Informe os valores do levantamento; o aplicativo calcula a corrente e o total.</p></div></div></div>
    <div class="motor-block"><h4>3. Totalização das cargas</h4><div class="fields">${f('AN',FLOW_LOAD)}${f('AO',FLOW_LOAD)}</div><p class="field-hint" id="motor-count-hint"></p><div id="motor-total"></div></div><div id="motor-issues" role="status"></div></div>`;
  if(g.key==='partida')return `<p class="field-hint">Selecione a partida do maior motor considerado neste trecho. Direta e estrela-triângulo têm fator calculado; os outros métodos precisam do ajuste definido para o equipamento.</p><div class="fields">${f('W')}${f('X')}</div><div class="notice blue" id="starting-guide"></div><details class="guided-more"><summary>Parâmetros e limites de partida</summary><p class="field-hint">Em branco, o aplicativo adota o fp de rotor bloqueado de 0,3 e os limites da NBR 5410: 10% nos terminais do dispositivo de partida (6.5.1.3.3) e o limite de 6.2.7 nos demais pontos. Informe outro valor só quando o projeto ou o fabricante da máquina o definirem.</p><div class="fields">${f('D')}${f('O')}${f('P')}</div><div class="fields">${f('AF')}${f('AG')}${f('AH')}</div></details><div id="starting-results">${partidaResumoHTML(g.fields)}</div>`;
  // v2.2.0: requisitos da norma (Tabela 49, Tabela 31, 6.3.5.2.4 d, NBR 5419-1 Anexo E, NBR 5419-4 Tabela 1) em bloco
  // próprio; a avaliação C.2.1.9 do circuito final fica fora do bloco do DPS do quadro, porque vale mesmo sem DPS nele.
  if(g.key==='dps')return `<div class="fields">${f('BT')}${f('BU')}</div><div id="dps-sem" hidden></div><div id="dps-ativo">${choiceModeHTML(data,'dps','Escolha do DPS')}<div class="fields">${f('H')}${f('BH')}</div>
    <details class="guided-more" id="dps-iimp"><summary>Corrente de impulso do DPS Classe I (NBR 5419-1, Anexo E)</summary><p class="field-note">Só para o DPS Classe I (Tipo 1+2). Com o nível de proteção (NP) da análise de risco, a Iimp por condutor é I’F = ke·I/(n·n’). Sem NP, vale o mínimo de 12,5 kA por modo de proteção (NBR 5410, 6.3.5.2.4 d).</p><div class="fields">${f('BW')}${f('BX')}</div></details>
    <div id="dps-manual-model"><h4>Escolha o modelo do DPS</h4><p class="field-note">A lista mostra classe, polos e dados elétricos. Opções fora dos critérios ficam identificadas.</p><div class="fields">${f('AU')}</div></div><div id="dps-choice-result"></div>
    <details class="guided-more"><summary>Requisitos da norma para este DPS</summary><p class="field-note">Valores mínimos e máximos que o modelo escolhido deve atender: Uc pela Tabela 49, Up pela categoria de suportabilidade da Tabela 31, In/Iimp por 6.3.5.2.4 d) e a seção do condutor de ligação.</p><div class="fields">${['K','L','M','CB','CA','CC','N'].map(c=>f(c)).join('')}</div></details>
    <div class="motor-block"><h4>Proteção de backup</h4>${choiceModeHTML(data,'backup','Escolha do backup')}<div id="backup-manual"><div class="fields">${f('BI')}${f('BP')}${f('BM')}</div><details class="guided-more"><summary>Poder de corte informado manualmente</summary><div class="fields">${f('BJ')}</div></details></div><div id="backup-choice-result"></div></div>
    <details class="guided-more"><summary>Declaração do fabricante e coordenação</summary><p class="field-note">Preencha quando houver comprovação do fabricante. O modo automático não confirma documentos nem a equivalência de disjuntor com fusível.</p><div class="fields">${f('BK')}${f('BL')}</div></details><details class="guided-more"><summary>Consultar parâmetros e verificações do DPS</summary><div class="fields">${['AE','AF','AG','AH','AI','AJ','AK','AN','AO','AP'].map(c=>f(c)).join('')}</div></details></div>
    <details class="guided-more" id="dps-c219"><summary>Proteção do equipamento no circuito final (NBR 5419-4, C.2.1.9)</summary><p class="field-note">O equipamento fica protegido pelo DPS a montante quando UP/F ≤ UW com ligação desprezível, UP/F ≤ 0,8·UW até 10 m ou UP/F ≤ 0,5·UW até 10 m se a falha for crítica. Acima de 10 m: DPS adicional junto ao equipamento ou DPS de duas portas na origem.</p><div class="fields">${f('BY')}${f('AL')}${f('BF')}</div></details>`;
  return '';
}
function flowFind(sheet,col){return drawerData?.fields?.findIndex(f=>f.sheet===sheet&&fcol(f)===col)??-1;}
function flowElement(sheet,col){const idx=flowFind(sheet,col);return idx<0?null:document.getElementById('field-'+idx);}
function flowWrap(sheet,col){return flowElement(sheet,col)?.closest('.field');}
function flowValue(sheet,col){const idx=flowFind(sheet,col);return idx>=0?liveValue(idx,'field-'):null;}
function flowSet(sheet,col,value){
  const e=flowElement(sheet,col);if(!e)return;
  if(e.tagName==='SELECT'&&!Array.from(e.options).some(o=>o.value===String(value??''))){const o=new Option(String(value??''),String(value??''));e.add(o);}
  e.value=value??'';if(e.dataset.hasCustom){const c=document.getElementById(e.id+'-custom');if(c)c.hidden=true;}
}
function workflowChanges(data){
  const choices=collect(data.choice_fields||[],'choice-');
  const changes=collect(data.fields,'field-');
  // O modo é autoritativo inclusive quando é igual ao modo salvo. Assim o
  // servidor pode distinguir uma escolha assistida de uma chamada legada.
  for(let i=0;i<(data.choice_fields||[]).length;i++){
    const f=data.choice_fields[i];if(!choices.some(x=>x.address===f.address))choices.push({sheet:f.sheet,address:f.address,value:document.getElementById('choice-'+i).value});
  }
  return [...choices,...changes];
}
function motorValuesHTML(data){
  const g=data.groups.find(g=>g.key==='motores');if(!g)return '';
  const value=(sh,c)=>g.fields.find(f=>f.sheet===sh&&fcol(f)===c)?.value;
  const entries=[['Potência mecânica',value('Cálc_Icc-Motores','D'),'W'],['Corrente nominal',value('Cálc_Icc-Motores','H'),'A'],['Corrente de partida direta',value('Cálc_Icc-Motores','I'),'A'],['Fator de potência',value('Cálc_Icc-Motores','E'),''],['Rendimento',value('Cálc_Icc-Motores','F'),'%'],['Ip/In',value('Cálc_Icc-Motores','G'),'']];
  return `<div class="guided-values">${entries.map(([label,v,unit])=>`<div><span>${label}</span><b>${num(v,2)} ${unit}</b></div>`).join('')}</div>`;
}
function workflowState(data=drawerData){
  if(!data)return;
  const auto=workflowMode('protecao')==='Automático',dpsAuto=workflowMode('dps')==='Automático',backupAuto=workflowMode('backup')==='Automático',mbAuto=workflowMode('manutencao')==='Automático';
  $$('[data-mode-hint]').forEach(el=>{el.textContent=workflowMode(el.dataset.modeHint)==='Automático'?CHOICE_HINTS[el.dataset.modeHint]:'Escolha manual: você define o modelo; as verificações continuam ativas.';});
  const primary=document.getElementById('prot-bloco-1'),adjust=document.getElementById('prot-bloco-2');
  if(primary)primary.hidden=auto;if(adjust)adjust.hidden=auto||adjust.hidden;
  const control=new Set(['J','AL','AM','K','Y','Z','BX','BZ','CA','CH']);
  const backupControls=new Set(['BI','BP','BM','BJ']);
  for(const f of data.fields){
    f.workflowIgnore=f.sheet==='Cálc-Prot_Cabos'&&((auto&&control.has(fcol(f)))||fcol(f)==='CH')||f.sheet==='DPS'&&(fcol(f)==='AT'||(dpsAuto&&fcol(f)==='AU')||(backupAuto&&backupControls.has(fcol(f))))||
      f.sheet===TRECHO_SHEET&&mbAuto&&MB_KEYS.includes(f.trecho_key);
  }
  const ch=flowWrap('Cálc-Prot_Cabos','CH');if(ch)ch.hidden=true;
  let autoBox=document.getElementById('breaker-auto-result');
  if(!autoBox&&primary){autoBox=document.createElement('div');autoBox.id='breaker-auto-result';primary.before(autoBox);}
  if(autoBox){autoBox.hidden=!auto;const best=data.workflow?.breakers?.items?.[0];autoBox.innerHTML=`<div class="guided-result"><h4>${best?esc(best.modelo):'Seleção automática pendente'}</h4><p>${esc(data.workflow?.breakers?.reason||'Modelo escolhido pela corrente do circuito, capacidade do cabo, partida e curto-circuito.')}</p>${best?`<div class="guided-values"><div><span>Ir</span><b>${num(best.ir)} A</b></div><div><span>Icu</span><b>${num(best.icu)} kA</b></div><div><span>Polos</span><b>${esc(best.poles)}</b></div></div>`:''}<p class="field-hint">As verificações de seccionamento, seletividade e confirmação do projeto continuam abaixo.</p></div>`;}
  let quick=document.getElementById('breaker-manual-quick');
  if(!quick&&primary){quick=document.createElement('div');quick.id='breaker-manual-quick';primary.before(quick);}
  if(quick){
    quick.hidden=auto;const candidates=data.workflow?.breakers?.items||[];
    quick.innerHTML=`<div class="guided-result"><h4>Escolha rápida por modelo</h4><p class="field-note">Modelos do catálogo que atendem aos critérios calculados. Para outro modelo, use a classe, a família e o modelo logo abaixo.</p><div class="field"><label for="breaker-quick-select">Modelos compatíveis com os dados atuais</label><select id="breaker-quick-select"><option value="">${candidates.length?'Escolher um modelo…':'Nenhum candidato; revise os dados ou use o catálogo abaixo.'}</option>${candidates.map(x=>`<option value="${esc(x.modelo)}">${esc(x.modelo)} · Ir ${num(x.ir)} A · Icu ${num(x.icu)} kA · ${esc(x.poles)}</option>`).join('')}</select></div></div>`;
    const quickSelect=document.getElementById('breaker-quick-select');
    quickSelect.value=candidates.some(x=>x.modelo===flowValue('Cálc-Prot_Cabos','AM'))?flowValue('Cálc-Prot_Cabos','AM'):'';
    quickSelect.onchange=e=>{
      const picked=candidates.find(x=>x.modelo===e.target.value);if(!picked)return;
      protecaoClasseEscolhida=picked.classe;
      flowSet('Cálc-Prot_Cabos','AL',picked.familia);flowSet('Cálc-Prot_Cabos','AM',picked.modelo);
      refreshProtecaoCascade(data.fields);
      for(const [c,v] of Object.entries(picked.ajustes))flowSet('Cálc-Prot_Cabos',c,v);
      flowSet('Cálc-Prot_Cabos','J',picked.in<=63?'Disjuntor_C - In <= 63A':'Disjuntor_C - In > 63A');
      dirty=true;$('#save-circuit').textContent='Salvar alterações';queueWorkflow(data);
    };
  }
  // Decisões físicas permanecem acessíveis mesmo no modo automático.
  if(primary){
    let physical=document.getElementById('breaker-physical');if(!physical){physical=document.createElement('div');physical.id='breaker-physical';physical.className='fields';primary.before(physical);}
    for(const col of ['BG','BO','BQ','CX','CY']){const w=flowWrap('Cálc-Prot_Cabos',col);if(w&&w.parentElement!==physical)physical.append(w);}
    // Tempo de abertura e margem só entram no curto retardo (relé eletrônico).
    const modelo=protecaoCatalogByModelo?.[flowValue('Cálc-Prot_Cabos','AM')];
    for(const col of ['CX','CY']){const w=flowWrap('Cálc-Prot_Cabos',col);if(w)w.hidden=modelo?.subclasse!=='eletronico'&&!(col==='CX'&&state?.origem?.tipo==='Gerador BT');}
  }
  // DPS opcional por quadro.
  const bt=String(flowValue('DPS','BT')||'');const semDps=bt.startsWith('NÃO');
  const ativo=document.getElementById('dps-ativo');if(ativo)ativo.hidden=semDps;
  const semBox=document.getElementById('dps-sem');
  if(semBox){semBox.hidden=!semDps;const m=data.groups.find(g=>g.key==='dps')?.dps_montante||{};
    semBox.innerHTML=`<div class="guided-result"><h4>Sem DPS neste quadro</h4><p>${m.circuito?`O DPS a montante mais próximo é o de <b>${esc(m.circuito)}</b> (${esc(textOf(m.tipo))}). Os quadros a jusante passam a coordenar com ele.`:'Não há DPS a montante deste quadro. Confirme como a instalação fica protegida contra surtos.'}</p></div>`;}
  const bu=flowWrap('DPS','BU');if(bu)bu.hidden=!bt;
  const dpsManual=document.getElementById('dps-manual-model');if(dpsManual)dpsManual.hidden=dpsAuto;
  const backupManual=document.getElementById('backup-manual');if(backupManual)backupManual.hidden=backupAuto;
  const backupType=flowValue('DPS','BI')||'FUSÍVEL gL/gG (catálogo)';
  for(const col of ['BP','BM']){const w=flowWrap('DPS',col);if(w)w.hidden=col==='BP'?backupType.startsWith('DISJUNTOR'):!backupType.startsWith('DISJUNTOR');}
  const au=flowElement('DPS','AU');
  if(au){const cur=flowValue('DPS','AU');const options=[...(data.workflow?.dps_catalog||[])].sort((a,b)=>Number(b.compatible)-Number(a.compatible));
    if(au.tagName==='SELECT'&&au.value!=='__custom__'){
      au.innerHTML='<option value="">Selecione o DPS</option>'+options.map(x=>`<option value="${esc(x.modelo)}">${esc(x.modelo+' · '+x.classe+' · '+x.polos+' · Uc '+(x.uc??'a confirmar')+' V · Up '+(x.up??'a confirmar')+' kV'+(x.compatible?'':' — REVISAR: '+x.notes.join(', ')))}</option>`).join('')+'<option value="__custom__">Outro (informar código manualmente)…</option>';
      au.dataset.hasCustom='1';if(cur){if(options.some(x=>x.modelo===cur))au.value=cur;else{au.value='__custom__';const input=document.getElementById(au.id+'-custom');if(input){input.value=cur;input.hidden=false;}}}
    }
  }
  const ds=data.workflow?.dps_summary||{};
  if(document.getElementById('dps-choice-result'))document.getElementById('dps-choice-result').innerHTML=`<div class="guided-result"><h4>${esc(ds.modelo||'DPS a definir')}</h4><p>${esc(data.workflow?.dps_status||'Atualize a prévia.')}</p><span class="field-hint">${esc(ds.tipo||'')}</span></div>`;
  if(document.getElementById('backup-choice-result'))document.getElementById('backup-choice-result').innerHTML=`<div class="guided-result"><h4>${esc(ds.backup||'Backup a definir')}</h4><p>${esc(data.workflow?.results?.backup||(backupAuto?'Seleção automática pelo catálogo.':'Seleção manual.'))}</p><p class="field-hint">Limite do DPS: ${num(ds.limite)} A · Ik: ${num(ds.ik)} kA · Icu adotado: ${num(ds.icu)} kA</p></div>`;
  const other=Number(String(flowValue(FLOW_LOAD,'Y')||0).replace(',','.'));
  const others=document.querySelector('.motor-others');if(others)others.hidden=!(other>0);
  const phase=flowWrap(FLOW_LOAD,'AO');const g=data.groups.find(g=>g.key==='motores');
  const phases=g?.fields.find(f=>f.sheet===FLOW_LOAD&&fcol(f)==='U')?.value;
  if(phase)phase.hidden=phases==='Trifásico';
  const inc=flowValue(FLOW_LOAD,'AN');const countHint=document.getElementById('motor-count-hint');
  if(countHint)countHint.textContent=inc==='Somar automaticamente às cargas gerais'?'As cargas gerais devem conter somente os demais equipamentos. A potência elétrica dos motores será somada automaticamente.':'Projeto anterior: os valores de cargas gerais foram preservados. Retire os motores desses valores antes de mudar para soma automática, para evitar dupla contagem.';
  const method=flowValue('ΔV_Partida_Motores','W');
  const param=flowWrap('ΔV_Partida_Motores','X');if(param)param.hidden=!METODOS_COM_PARAMETRO.has(method);
  const guides={'Direta':'Fator de corrente = 1. Não é necessário informar um percentual.',
    'Estrela-triângulo':'Fator de corrente e de conjugado = 1/3 na aproximação adotada. Confirme motor trifásico com seis terminais e tensão de operação em triângulo compatível com a rede.',
    'Soft-starter':'Informe a tensão aplicada na partida (% da tensão nominal), conforme o ajuste do equipamento. O modelo usa uma aproximação proporcional para corrente; o desempenho depende da carga e da rampa.',
    'Reator série':'Escolha a tensão efetiva no motor durante a partida (% da nominal), conforme o projeto do reator. O modelo calcula os fatores de corrente e conjugado.',
    'Inversor de frequência':'Informe o limite de corrente como percentual da corrente de partida direta, conforme o modelo de cálculo. Exemplo: limite de 150% de In com Ip/In = 6 corresponde a 25% aqui. O conjugado depende do controle do inversor.'};
  const guide=document.getElementById('starting-guide');if(guide)guide.textContent=guides[method]||'Escolha um método de partida na lista.';
  const issues=document.getElementById('motor-issues');if(issues)issues.innerHTML=(data.workflow?.motor_issues||[]).map(x=>`<div class="notice">${esc(x)}</div>`).join('');
  if(typeof trechoApply==='function')trechoApply(data);
}
function initWorkflow(data){
  workflowTicket++;clearTimeout(workflowTimer);
  // Garante lista de modelos DPS mesmo quando o XLSX não fornece validação.
  const au=flowElement('DPS','AU');if(au&&au.tagName!=='SELECT'){
    const select=document.createElement('select');select.id=au.id;select.dataset.type='text';select.dataset.hasCustom='1';select.add(new Option(au.value,au.value));au.replaceWith(select);
    const input=document.createElement('input');input.id=select.id+'-custom';input.className='custom-value';input.hidden=true;input.value=au.value;select.after(input);
  }
  if(typeof initTrecho==='function')initTrecho(data);
  workflowState(data);
  // Opção vazia não é um terceiro modo.
  for(let i=0;i<(data.choice_fields||[]).length;i++){const select=document.getElementById('choice-'+i);select.querySelector('option[value=""]')?.remove();}
  $('#choice-preview').onclick=()=>previewWorkflow(data);
  $('#drawer').addEventListener('change',e=>{
    if(drawerData!==data)return;
    if(e.target.id.startsWith('choice-')){
      dirty=true;$('#save-circuit').textContent='Salvar alterações';
      if(workflowMode('protecao')==='Manual'){
        const model=protecaoCatalogByModelo[flowValue('Cálc-Prot_Cabos','AM')];if(model)protecaoClasseEscolhida=model.subclasse;
        refreshProtecaoCascade(data.fields);
      }
      if(e.target.id==='choice-1'&&workflowMode('dps')==='Manual'&&!flowValue('DPS','AU'))flowSet('DPS','AU',data.workflow?.dps_summary?.modelo);
      if(e.target.id==='choice-2'&&workflowMode('backup')==='Manual'){
        if(!flowValue('DPS','BI'))flowSet('DPS','BI','FUSÍVEL gL/gG (catálogo)');
        if(!flowValue('DPS','BP')){const select=flowElement('DPS','BP');const first=[...(select?.options||[])].find(o=>o.value);if(first)flowSet('DPS','BP',first.value);}
      }
    }
    workflowState(data);queueWorkflow(data);
  });
  $('#drawer').addEventListener('input',e=>{if(drawerData===data&&e.target.matches('input,textarea'))queueWorkflow(data);});
}
function queueWorkflow(data){clearTimeout(workflowTimer);workflowTicket++;const label=document.getElementById('choice-preview-state');if(label)label.textContent='Calculando a prévia…';workflowTimer=setTimeout(()=>previewWorkflow(data),650);}
async function previewWorkflow(data){
    if(drawerData!==data)return;
  const ticket=++workflowTicket;const label=document.getElementById('choice-preview-state');
  try{
    const changes=workflowChanges(data);if(label)label.textContent='Calculando a prévia…';
    const inst=data.installation;const installation=groupingDirty&&inst?.reference?{id:data.id,reference:inst.reference,settings:cleanSettings(inst.settings)}:undefined;
    const next=await api('/api/choices/preview',{id:data.id,changes,installation});
    if(ticket!==workflowTicket||drawerData!==data)return;
    data.workflow=next.workflow;
    const lookup=new Map(next.groups.flatMap(g=>g.fields).map(f=>[f.sheet+'!'+f.address,f]));
    for(const f of data.fields){const latest=lookup.get(f.sheet+'!'+f.address);if(!latest)continue;
      if(f.formula){f.value=latest.value;const idx=data.fields.indexOf(f);const output=document.getElementById('field-'+idx);if(output&&output.tagName==='OUTPUT')output.innerHTML=num(latest.value,5);}
    }
    const mg=data.groups.find(g=>g.key==='motores'),sg=data.groups.find(g=>g.key==='partida');
    if(document.getElementById('motor-values'))document.getElementById('motor-values').innerHTML=motorValuesHTML(data);
    if(document.getElementById('starting-results')&&sg)document.getElementById('starting-results').innerHTML=partidaResumoHTML(sg.fields);
    const total=document.getElementById('motor-total');if(total&&mg){const val=c=>mg.fields.find(f=>f.sheet===FLOW_LOAD&&fcol(f)===c)?.value;total.innerHTML=`<div class="guided-values"><div><span>Total dos motores</span><b>${num(val('AD'))} cv</b></div><div><span>Potência elétrica</span><b>${num(val('AP'))} W</b></div><div><span>Corrente dos motores</span><b>${num(val('AF'))} A</b></div></div>`;}
    // Sincroniza só campos sob controle automático, sem alterar a base de
    // comparação do formulário; Manual conserva os valores digitados.
    for(const f of data.fields){if(!f.workflowIgnore||f.formula)continue;const latest=lookup.get(f.sheet+'!'+f.address);if(latest)flowSet(f.sheet,fcol(f),latest.value);}
    const prot=next.groups.find(g=>g.key==='protecao');const summary=document.getElementById('protecao-resumo');if(summary&&prot)summary.outerHTML=protecaoResumoHTML(prot);
    const sections=next.groups.find(g=>g.key==='secoes');
    const currentSections=data.groups.find(g=>g.key==='secoes');
    if(sections&&currentSections){
      currentSections.comparacao=sections.comparacao;
      currentSections.comparacao_aviso=sections.comparacao_aviso;
      const comparison=document.getElementById('secoes-comparacao');
      if(comparison)comparison.outerHTML=secoesComparacaoHTML(sections.comparacao,sections.comparacao_aviso);
    }
    for(const key of ['trecho','dps']){const fresh=next.groups.find(g=>g.key===key),cur=data.groups.find(g=>g.key===key);if(fresh&&cur){if(key==='trecho')cur.trecho=fresh.trecho;else cur.dps_montante=fresh.dps_montante;}}
    const freshIntegrated=next.groups.find(g=>g.key==='integrada'),currentIntegrated=data.groups.find(g=>g.key==='integrada');
    if(freshIntegrated&&currentIntegrated){
      currentIntegrated.protection=freshIntegrated.protection;currentIntegrated.link=freshIntegrated.link;currentIntegrated.outgoing=freshIntegrated.outgoing;
      const target=document.querySelector('.integrated-results');
      if(target){const holder=document.createElement('div');holder.innerHTML=integratedGroupHTML(currentIntegrated,data);const result=holder.querySelector('.integrated-results');if(result)target.replaceWith(result);}
    }
    for(const tab of next.info||[]){const panel=document.querySelector(`[data-dpane="${tab.key}"] .info-grid`);if(panel)panel.innerHTML=tab.sections.map(infoSectionHTML).join('');}
    // As listas de backup dependem do fabricante e modelo acabados de escolher.
    for(const col of ['BP','BM']){const idx=flowFind('DPS',col);if(idx<0)continue;const latest=lookup.get('DPS!'+data.fields[idx].address),el=flowElement('DPS',col);if(latest&&el&&el.tagName==='SELECT'){
      const current=el.value;el.innerHTML='<option value="">Selecione</option>'+latest.options.map(x=>`<option value="${esc(x)}">${esc(latest.option_labels?.[x]||x)}</option>`).join('');if(current&&!latest.options.includes(current))el.add(new Option(current+' (revisar)',current));el.value=current;
    }}
    workflowState(data);if(label)label.textContent='Prévia atualizada · alterações ainda não salvas';
  }catch(error){if(ticket===workflowTicket&&label)label.textContent=error.message;}
}

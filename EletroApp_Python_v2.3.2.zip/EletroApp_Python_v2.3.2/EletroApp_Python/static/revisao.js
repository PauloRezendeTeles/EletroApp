'use strict';
/* EletroApp v2.3.1 — Comentários de revisão do aplicativo.
 *
 * Cada aba ganha, no fim da página, o bloco "Comentários de revisão": tipo, prioridade, referência,
 * autor e texto. No formulário do circuito o bloco aparece no fim de cada etapa (Informações gerais,
 * Cargas, Motores, Instalação, Condutores, Curto-circuito, Proteções, DPS), com o circuito aberto
 * registrado como contexto. A aba "Comentários de revisão" reúne todos, com filtros e exportação
 * em Markdown, CSV ou JSON para servir de base à próxima revisão do aplicativo.
 *
 * Os comentários ficam no banco local (pasta projetos), fora dos projetos: não entram no .eletro,
 * não criam revisão do projeto e não alteram nenhum cálculo. Usa as funções globais de app.js
 * ($, $$, esc, api, toast, heading, state, drawerData, currentView).
 */
(function () {
  const RV = { items: [], meta: null, loaded: false, loading: null, drafts: new Map(), open: new Set(), editing: null,
    filter: { q: '', view: '', status: 'Aberto', kind: '', project: false } };
  const LS_AUTHOR = 'eletroapp.review.author', LS_OPEN = 'eletroapp.review.open';
  const lsGet = (k) => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* armazenamento indisponível */ } };
  try { JSON.parse(lsGet(LS_OPEN) || '[]').forEach((k) => RV.open.add(k)); } catch (e) { /* ignora */ }

  const DEFAULTS = { tipos: ['Erro de cálculo', 'Erro de interface', 'Critério normativo', 'Melhoria', 'Dúvida', 'Texto e termos'],
    prioridades: ['Alta', 'Média', 'Baixa'], situacoes: ['Aberto', 'Resolvido', 'Descartado'] };
  const meta = (k) => (RV.meta && RV.meta[k]) || DEFAULTS[k];
  const KIND_CLASS = { 'Erro de cálculo': 'red', 'Erro de interface': 'amber', 'Critério normativo': 'blue', 'Melhoria': 'green' };
  const PRI_CLASS = { 'Alta': 'red', 'Média': 'amber' };
  const STATUS_CLASS = { 'Aberto': 'amber', 'Resolvido': 'green' };
  const code = (c) => 'C-' + String(c.id).padStart(3, '0');
  const fmtTs = (ts) => { const m = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})/.exec(String(ts || '')); return m ? `${m[3]}/${m[2]}/${m[1]} ${m[4]}:${m[5]}` : String(ts || ''); };
  const opts = (list, sel) => list.map((x) => `<option value="${esc(x)}" ${x === sel ? 'selected' : ''}>${esc(x)}</option>`).join('');
  const viewNow = () => (typeof currentView !== 'undefined' && currentView) || location.hash.slice(1) || 'overview';

  /* ---------------- dados ---------------- */
  function load(force) {
    if (RV.loaded && !force) return Promise.resolve(RV.items);
    if (RV.loading) return RV.loading;
    RV.loading = api('/api/review/comments').then((d) => { RV.items = d.itens || []; RV.meta = d; RV.loaded = true; refreshAll(); return RV.items; })
      .catch((e) => { toast('Comentários de revisão: ' + e.message, true); return RV.items; })
      .finally(() => { RV.loading = null; });
    return RV.loading;
  }
  function updateNav() {
    const b = document.getElementById('nav-review'); if (!b) return;
    const n = RV.items.filter((c) => c.status === 'Aberto').length;
    b.textContent = n; b.hidden = !n;
  }

  /* ---------------- contexto da aba ---------------- */
  function plainText(el, drop) {
    if (!el) return '';
    const c = el.cloneNode(true); c.querySelectorAll(drop).forEach((x) => x.remove());
    return c.textContent.replace(/\s+/g, ' ').trim();
  }
  function navLabel(view) { return plainText(document.querySelector(`#nav a[data-view="${view}"]`), 'span,b,i') || view; }
  function activeSubtab() {
    const main = $('#main'); if (!main) return '';
    const parts = [];
    const tab = main.querySelector('[role="tab"][aria-selected="true"], [role="tab"].active');
    if (tab) parts.push(plainText(tab, '.tag'));
    if (viewNow() === 'tables' && window.tablesSelected) parts.push('Tabela ' + window.tablesSelected);
    return parts.filter(Boolean).join(' · ');
  }
  function contextText(panel) {
    const s = panel._reviewScope, bits = [];
    if (typeof state !== 'undefined' && state) bits.push(`projeto «${state.title}» (rev. ${state.revision})`);
    if (s.circuit && s.circuit.name) bits.push('circuito ' + s.circuit.name);
    const sub = s.area === 'main' ? activeSubtab() : '';
    if (sub) bits.push('sub-aba ' + sub);
    bits.push('v' + ((RV.meta && RV.meta.versao) || '2.3.1'));
    return 'Registra junto: ' + bits.join(' · ');
  }

  /* ---------------- bloco da aba ---------------- */
  function formHTML(c, edit) {
    const author = c ? (c.author || '') : (lsGet(LS_AUTHOR) || (window.reviewerState && window.reviewerState()?.nome) || '');
    return `<div class="review-row">
      <label>Tipo<select data-rf="kind">${opts(meta('tipos'), c ? c.kind : 'Erro de cálculo')}</select></label>
      <label>Prioridade<select data-rf="priority">${opts(meta('prioridades'), c ? c.priority : 'Média')}</select></label>
      ${edit ? `<label>Situação<select data-rf="status">${opts(meta('situacoes'), c.status)}</select></label>` : ''}
      <label class="grow">Referência <small>campo, circuito, valor ou item da norma — opcional</small><input data-rf="ref" maxlength="300" autocomplete="off" value="${esc(c ? c.ref || '' : '')}" placeholder="Ex.: Ik mín. do QDFL-01 = 2,1 kA"></label>
      ${edit ? '' : `<label>Autor<input data-rf="author" maxlength="80" autocomplete="off" value="${esc(author)}" placeholder="Opcional"></label>`}
    </div>
    <label class="review-text">Comentário<textarea data-rf="text" rows="3" maxlength="5000" placeholder="O que aconteceu, o que era esperado e, se souber, o cálculo ou a referência normativa correta.">${esc(c ? c.text : '')}</textarea></label>
    ${edit ? `<label class="review-text">Resolução <small>opcional — versão em que foi corrigido, decisão tomada</small><textarea data-rf="resolution" rows="2" maxlength="1000">${esc(c.resolution || '')}</textarea></label>` : ''}`;
  }
  function createPanel(scope, options = {}) {
    const d = document.createElement('details');
    d.className = 'review-panel ux-noseg' + (scope.area === 'drawer' ? ' in-drawer' : '');
    d.dataset.reviewKey = scope.key; d._reviewScope = scope; d._reviewOptions = options;
    if (RV.open.has(scope.key) || options.open) d.open = true;
    d.innerHTML = `<summary><span class="review-ic" aria-hidden="true">✎</span><span class="review-title"><b>Comentários de revisão</b><small>${esc(scope.label)}</small></span><span class="review-counts" data-review-counts></span><span class="review-chev" aria-hidden="true">⌄</span></summary>
      <div class="review-body">
        <p class="review-help">Anote erros, dúvidas e melhorias desta aba. Os comentários ficam neste computador, fora do projeto, e servem de base para a próxima revisão do aplicativo — não alteram cálculos.</p>
        <div class="review-form" data-review-form>${formHTML(null, false)}
          <div class="review-actions"><span class="review-context" data-review-context></span><button type="button" class="btn small" data-review-clear>Limpar</button><button type="button" class="btn primary small" data-review-add>Adicionar comentário</button></div>
        </div>
        ${options.noList ? '' : '<div class="review-list" data-review-list></div><div class="review-foot"><a href="#review" class="tiny-link">Todos os comentários, filtros e exportação ↗</a></div>'}
      </div>`;
    const draft = RV.drafts.get(scope.key);
    if (draft) Object.entries(draft).forEach(([k, v]) => { const el = d.querySelector(`.review-form [data-rf="${k}"]`); if (el) el.value = v; });
    // Digitar aqui não pode marcar o circuito como alterado nem ser lido pelos formulários do projeto.
    const stop = (e) => {
      if (e.type === 'input' && e.target.closest('[data-review-form]')) saveDraft(d);
      e.stopPropagation();
    };
    d.addEventListener('input', stop); d.addEventListener('change', stop);
    d.addEventListener('focusin', (e) => {   // a sub-aba ativa pode ter mudado desde a montagem
      if (!e.target.closest('[data-review-form]')) return;
      const ctx = d.querySelector('[data-review-context]'); if (ctx) ctx.textContent = contextText(d);
    });
    d.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      if (e.target.matches('input')) { e.preventDefault(); return; }   // não envia o formulário do circuito
      if (e.target.matches('textarea') && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        const form = e.target.closest('[data-review-form]'); if (form) addFrom(d);
        const ed = e.target.closest('[data-review-edit-form]'); if (ed) saveEdit(ed);
      }
    });
    d.addEventListener('toggle', () => {
      if (d.open) { RV.open.add(scope.key); load().then(() => paint(d)); } else RV.open.delete(scope.key);
      lsSet(LS_OPEN, JSON.stringify([...RV.open]));
      syncChip();
    });
    paint(d);
    return d;
  }
  function saveDraft(panel) {
    const out = {};
    panel.querySelectorAll('.review-form [data-rf]').forEach((el) => { out[el.dataset.rf] = el.value; });
    RV.drafts.set(panel.dataset.reviewKey, out);
  }
  function itemsFor(key) {
    const rank = { 'Aberto': 0, 'Resolvido': 1, 'Descartado': 2 };
    return RV.items.filter((c) => c.view === key).sort((a, b) => (rank[a.status] ?? 3) - (rank[b.status] ?? 3) || b.id - a.id);
  }
  function countsHTML(list) {
    const n = (s) => list.filter((c) => c.status === s).length, a = n('Aberto'), r = n('Resolvido');
    if (!list.length) return '<span class="tag">nenhum</span>';
    return (a ? `<span class="tag amber">${a} aberto${a > 1 ? 's' : ''}</span>` : '') + (r ? `<span class="tag green">${r} resolvido${r > 1 ? 's' : ''}</span>` : '')
      + (!a && !r ? `<span class="tag">${list.length} descartado${list.length > 1 ? 's' : ''}</span>` : '');
  }
  function paint(panel) {
    const key = panel.dataset.reviewKey, list = itemsFor(key);
    const counts = panel.querySelector('[data-review-counts]'); if (counts) counts.innerHTML = RV.loaded ? countsHTML(list) : '';
    const ctx = panel.querySelector('[data-review-context]'); if (ctx) ctx.textContent = contextText(panel);
    const box = panel.querySelector('[data-review-list]');
    if (box) box.innerHTML = !RV.loaded ? '<p class="review-empty">Carregando…</p>'
      : list.length ? list.map((c) => itemHTML(c, { inPanel: true, circuit: panel._reviewScope.circuit })).join('')
      : '<p class="review-empty">Nenhum comentário nesta aba.</p>';
  }
  function itemHTML(c, o = {}) {
    if (RV.editing === c.id) {
      return `<article class="review-item editing" data-review-id="${c.id}"><div class="review-edit" data-review-edit-form data-id="${c.id}">
        <div class="review-item-head"><b class="review-code">${code(c)}</b><span class="muted">Editando</span></div>
        ${formHTML(c, true)}
        <div class="review-actions"><span></span><button type="button" class="btn small" data-review-act="cancel" data-id="${c.id}">Cancelar</button><button type="button" class="btn primary small" data-review-act="save" data-id="${c.id}">Salvar</button></div></div></article>`;
    }
    const sameProject = typeof state !== 'undefined' && state && c.project_id === state.project_id;
    const here = o.circuit && c.circuit_id && o.circuit.id === c.circuit_id;
    // Cada parte já sai escapada (nomes e textos vêm do banco e do projeto).
    const ctx = [esc(fmtTs(c.created)), c.author ? esc(c.author) : '',
      c.circuit_name ? (sameProject && c.circuit_id && !o.inPanel
        ? `<button type="button" class="link-btn" data-edit="${esc(c.circuit_id)}" title="Abrir o circuito">${esc(c.circuit_name)}</button>` : esc(c.circuit_name)) + (here ? ' (este circuito)' : '') : '',
      c.project_title ? `projeto ${esc(c.project_title)} · rev. ${esc(c.project_revision)}` : '',
      c.subtab ? 'sub-aba ' + esc(c.subtab) : '', c.app_version ? 'v' + esc(c.app_version) : '']
      .filter(Boolean);
    const act = (a, label, cls = '') => `<button type="button" class="tiny-link ${cls}" data-review-act="${a}" data-id="${c.id}">${label}</button>`;
    return `<article class="review-item st-${esc(String(c.status).toLowerCase())}" data-review-id="${c.id}">
      <div class="review-item-head"><b class="review-code">${code(c)}</b><span class="tag ${KIND_CLASS[c.kind] || ''}">${esc(c.kind)}</span><span class="tag ${PRI_CLASS[c.priority] || ''}">${esc(c.priority)}</span><span class="tag ${STATUS_CLASS[c.status] || ''}">${esc(c.status)}</span>${o.showView ? `<span class="review-where">${esc(c.view_label || c.view)}</span>` : ''}</div>
      <p class="review-item-text">${esc(c.text)}</p>
      ${c.ref ? `<p class="review-item-ref"><b>Referência:</b> ${esc(c.ref)}</p>` : ''}
      ${c.resolution ? `<p class="review-item-ref"><b>Resolução:</b> ${esc(c.resolution)}</p>` : ''}
      <div class="review-item-foot"><small>${ctx.join(' · ')}</small><span class="review-item-actions">
        ${c.status === 'Aberto' ? act('resolve', '✓ Resolvido') + act('discard', 'Descartar') : act('reopen', '↺ Reabrir')}${act('edit', 'Editar')}${act('delete', 'Excluir', 'danger')}</span></div>
    </article>`;
  }
  function readForm(root) {
    const out = {};
    root.querySelectorAll('[data-rf]').forEach((el) => { out[el.dataset.rf] = el.value.trim(); });
    return out;
  }
  async function addFrom(panel) {
    const form = panel.querySelector('[data-review-form]'), f = readForm(form), s = panel._reviewScope;
    if (!f.text) { toast('Escreva o comentário antes de adicionar.', true); form.querySelector('[data-rf="text"]').focus(); return; }
    const btn = form.querySelector('[data-review-add]'); btn.disabled = true;
    try {
      const r = await api('/api/review/add', { ...f, view: s.key, view_label: s.label, subtab: s.area === 'main' ? activeSubtab() : '',
        circuit_id: s.circuit ? s.circuit.id : null });
      if (f.author !== undefined) lsSet(LS_AUTHOR, f.author);
      RV.items.unshift(r.comentario); RV.drafts.delete(s.key);
      const author = f.author;
      form.querySelectorAll('[data-rf]').forEach((el) => { if (el.dataset.rf === 'text' || el.dataset.rf === 'ref') el.value = ''; });
      const a = form.querySelector('[data-rf="author"]'); if (a) a.value = author || '';
      refreshAll();
      toast(`Comentário ${code(r.comentario)} registrado em ${s.label}.`);
    } catch (e) { if (!e.conflict) toast(e.message, true); } finally { btn.disabled = false; }
  }
  async function update(id, body, message) {
    try {
      const r = await api('/api/review/update', { id, ...body });
      RV.items = RV.items.map((c) => (c.id === id ? r.comentario : c));
      RV.editing = null; refreshAll(); if (message) toast(message);
    } catch (e) { if (!e.conflict) toast(e.message, true); }
  }
  function saveEdit(box) {
    const id = Number(box.dataset.id), f = readForm(box);
    if (!f.text) { toast('O comentário não pode ficar vazio.', true); return; }
    update(id, f, 'Comentário ' + code({ id }) + ' atualizado.');
  }
  function refreshAll() {
    updateNav();
    $$('.review-panel').forEach(paint);
    syncChip();
    if (viewNow() === 'review' && $('#review-list')) paintReviewView();
  }

  document.addEventListener('click', async (e) => {
    const add = e.target.closest('[data-review-add]');
    if (add) { addFrom(add.closest('.review-panel')); return; }
    const clr = e.target.closest('[data-review-clear]');
    if (clr) {
      const panel = clr.closest('.review-panel'); RV.drafts.delete(panel.dataset.reviewKey);
      panel.querySelectorAll('.review-form [data-rf="text"], .review-form [data-rf="ref"]').forEach((el) => { el.value = ''; });
      return;
    }
    const jump = e.target.closest('[data-review-jump]');
    if (jump) {
      const panel = $('#main > .review-panel'); if (!panel) return;
      panel.open = true; panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setTimeout(() => panel.querySelector('.review-form [data-rf="text"]')?.focus({ preventScroll: true }), 350);
      return;
    }
    const b = e.target.closest('[data-review-act]'); if (!b) return;
    const id = Number(b.dataset.id), c = RV.items.find((x) => x.id === id); if (!c) return;
    const a = b.dataset.reviewAct;
    if (a === 'resolve') return update(id, { status: 'Resolvido' }, `${code(c)} marcado como resolvido.`);
    if (a === 'discard') return update(id, { status: 'Descartado' }, `${code(c)} descartado.`);
    if (a === 'reopen') return update(id, { status: 'Aberto' }, `${code(c)} reaberto.`);
    if (a === 'edit') { RV.editing = id; refreshAll(); return; }
    if (a === 'cancel') { RV.editing = null; refreshAll(); return; }
    if (a === 'save') { saveEdit(b.closest('[data-review-edit-form]')); return; }
    if (a === 'delete') {
      if (!confirm(`Excluir o comentário ${code(c)}? Para manter o registro, prefira "Descartar".`)) return;
      try { await api('/api/review/delete', { id }); RV.items = RV.items.filter((x) => x.id !== id); refreshAll(); toast(`${code(c)} excluído.`); }
      catch (err) { if (!err.conflict) toast(err.message, true); }
    }
  });

  /* ---------------- montagem nas abas ---------------- */
  function syncChip() {
    const main = $('#main'); if (!main) return;
    const head = main.querySelector('.page-heading .heading-actions'), panel = main.querySelector(':scope > .review-panel');
    if (!head || !panel) return;
    let chip = head.querySelector('[data-review-jump]');
    if (!chip) {
      chip = document.createElement('button'); chip.type = 'button'; chip.className = 'btn small review-chip'; chip.dataset.reviewJump = '1';
      chip.title = 'Comentários de revisão desta aba'; head.appendChild(chip);
    }
    const n = itemsFor(panel.dataset.reviewKey).filter((c) => c.status === 'Aberto').length;
    const html = `✎ Comentários${n ? ` <b>${n}</b>` : ''}`;
    if (chip.innerHTML !== html) chip.innerHTML = html;
  }
  function mountMain() {
    const main = $('#main'); if (!main) return;
    const view = viewNow();
    if (view === 'review' || !main.querySelector('.page-heading')) return;
    let panel = main.querySelector(':scope > .review-panel');
    // Não reposiciona um bloco já montado: mover o elemento tiraria o foco de quem está digitando.
    if (panel && panel.dataset.reviewKey === view) { syncChip(); return; }
    if (panel) panel.remove();
    main.appendChild(createPanel({ key: view, label: navLabel(view), area: 'main' }));
    syncChip();
  }
  function tabLabel(tab) { return plainText(tab, '.ux-n'); }
  function mountDrawer() {
    const dr = $('#drawer');
    if (!dr || dr.hidden || typeof drawerData === 'undefined' || !drawerData || !drawerData.id) return;
    const circuit = { id: drawerData.id, name: drawerData.name };
    const panes = $$('.dpane', dr);
    if (panes.length) {
      panes.forEach((pane) => {
        const key = 'circuito-' + pane.dataset.dpane;
        const existing = pane.querySelector(':scope > .review-panel');
        if (existing && existing._reviewScope.circuit?.id === circuit.id) return;
        if (existing) existing.remove();
        const tab = dr.querySelector(`.dtab[data-dtab="${pane.dataset.dpane}"]`);
        const panel = createPanel({ key, label: 'Circuito › ' + (tab ? tabLabel(tab) : pane.dataset.dpane), area: 'drawer', circuit });
        const nav = pane.querySelector(':scope > .ux-stepnav');
        if (nav) pane.insertBefore(panel, nav); else pane.appendChild(panel);
      });
    } else {
      const body = $('.drawer-body', dr) || dr;
      const existing = body.querySelector(':scope > .review-panel');
      if (existing && existing._reviewScope.circuit?.id === circuit.id) return;
      if (existing) existing.remove();
      body.appendChild(createPanel({ key: 'circuito', label: 'Formulário do circuito', area: 'drawer', circuit }));
    }
  }
  let pending = false;
  function run() { pending = false; try { mountMain(); mountDrawer(); } catch (e) { console.error('[revisao]', e); } }
  const schedule = () => { if (!pending) { pending = true; requestAnimationFrame(run); } };
  new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['hidden'] });
  window.addEventListener('hashchange', schedule);
  document.addEventListener('DOMContentLoaded', () => { load(); schedule(); });

  /* ---------------- aba "Comentários de revisão" ---------------- */
  function filtered() {
    const f = RV.filter, q = f.q.toLowerCase();
    return RV.items.filter((c) => (!f.view || c.view === f.view) && (!f.status || c.status === f.status) && (!f.kind || c.kind === f.kind)
      && (!f.project || (typeof state !== 'undefined' && state && c.project_id === state.project_id))
      && (!q || [c.text, c.ref, c.author, c.circuit_name, c.view_label, c.project_title, code(c)].join(' ').toLowerCase().includes(q)));
  }
  function exportHref(format) {
    const p = new URLSearchParams({ format });
    if (RV.filter.status) p.set('status', RV.filter.status);
    if (RV.filter.view) p.set('view', RV.filter.view);
    return '/api/review/export?' + p;
  }
  function paintReviewView() {
    const list = filtered(), all = RV.items;
    const n = (s) => all.filter((c) => c.status === s).length;
    const k = $('#review-kpis');
    if (k) k.innerHTML = [['Em aberto', n('Aberto'), 'attention'], ['Alta prioridade em aberto', all.filter((c) => c.status === 'Aberto' && c.priority === 'Alta').length, ''],
      ['Resolvidos', n('Resolvido'), ''], ['Registrados', all.length, '']]
      .map(([l, v, cls]) => `<div class="kpi ${cls}"><div class="label">${l}</div><div class="number">${String(v).padStart(2, '0')}</div></div>`).join('');
    const views = [...new Map(all.map((c) => [c.view, c.view_label || c.view])).entries()];
    const sel = $('#review-f-view');
    if (sel) {
      const cur = RV.filter.view;
      sel.innerHTML = '<option value="">Todas as abas</option>' + views.map(([v, l]) => `<option value="${esc(v)}" ${v === cur ? 'selected' : ''}>${esc(l)}</option>`).join('');
    }
    ['md', 'csv', 'json'].forEach((f) => { const a = $('#review-export-' + f); if (a) a.href = exportHref(f); });
    const groups = new Map();
    list.forEach((c) => { if (!groups.has(c.view)) groups.set(c.view, []); groups.get(c.view).push(c); });
    const navOrder = $$('#nav a[data-view]').map((a) => a.dataset.view);
    const pos = (v) => { const base = v.startsWith('circuito') ? 'circuits' : v; const i = navOrder.indexOf(base); return i < 0 ? 999 : i + (v.startsWith('circuito') ? 0.5 : 0); };
    const box = $('#review-list');
    if (!box) return;
    box.innerHTML = list.length ? [...groups.entries()].sort((a, b) => pos(a[0]) - pos(b[0]) || a[0].localeCompare(b[0])).map(([v, cs]) => {
      const go = v === 'geral' ? '' : `<a class="tiny-link" href="#${v.startsWith('circuito') ? 'circuits' : esc(v)}">Ir para a aba ↗</a>`;
      return `<section class="panel review-group"><div class="panel-head"><div><h2>${esc(cs[0].view_label || v)}</h2><p>${cs.length} comentário(s)</p></div>${go}</div><div class="review-list">${cs.map((c) => itemHTML(c)).join('')}</div></section>`;
    }).join('') : `<section class="panel"><p class="review-empty pad">${all.length ? 'Nenhum comentário corresponde aos filtros.' : 'Nenhum comentário registrado ainda. Abra qualquer aba e use o bloco <b>Comentários de revisão</b> no fim da página.'}</p></section>`;
  }
  window.renderReviewView = async function (main) {
    main.innerHTML = heading('Comentários de revisão',
      'Observações registradas nas abas do aplicativo, para a próxima revisão. Ficam guardadas neste computador, fora dos projetos, e não alteram nenhum cálculo.',
      `<a class="btn small dark" id="review-export-md" href="/api/review/export?format=md" download>Exportar Markdown</a><a class="btn small" id="review-export-csv" href="/api/review/export?format=csv" download>CSV</a><a class="btn small" id="review-export-json" href="/api/review/export?format=json" download>JSON</a>`,
      'REVISÃO DO APLICATIVO')
      + '<div class="kpis review-kpis" id="review-kpis"></div>'
      + '<div class="notice blue"><b>Como usar.</b> Em cada aba, o bloco <b>Comentários de revisão</b> fica no fim da página (o botão ✎ no topo leva até ele). No formulário do circuito, há um bloco no fim de cada etapa, que registra o circuito aberto. Para pedir a revisão, use <b>Exportar Markdown</b> (com o filtro de situação desejado) e envie o arquivo junto com o pacote do aplicativo. Quando a versão corrigida chegar, marque cada item como <b>Resolvido</b> e anote a resolução.</div>'
      + '<div id="review-general"></div>'
      + `<div class="toolbar"><input id="review-f-q" class="search" placeholder="Buscar no texto, referência, circuito, autor ou código (C-001)…" aria-label="Buscar comentário" value="${esc(RV.filter.q)}">
        <select id="review-f-view" class="input" aria-label="Aba"><option value="">Todas as abas</option></select>
        <select id="review-f-status" class="input" aria-label="Situação"><option value="">Todas as situações</option>${opts(meta('situacoes'), RV.filter.status)}</select>
        <select id="review-f-kind" class="input" aria-label="Tipo"><option value="">Todos os tipos</option>${opts(meta('tipos'), RV.filter.kind)}</select>
        <label class="review-check"><input type="checkbox" id="review-f-project" ${RV.filter.project ? 'checked' : ''}> Só o projeto atual</label></div>`
      + '<div id="review-list"><div class="loading-card">Carregando comentários…</div></div>';
    $('#review-general').appendChild(createPanel({ key: 'geral', label: 'Geral — aplicativo como um todo', area: 'review' }, { noList: true }));
    const bind = (id, key, ev = 'change', val = (el) => el.value) => { const el = $(id); el.addEventListener(ev, () => { RV.filter[key] = val(el); paintReviewView(); }); };
    bind('#review-f-q', 'q', 'input'); bind('#review-f-view', 'view'); bind('#review-f-status', 'status'); bind('#review-f-kind', 'kind');
    bind('#review-f-project', 'project', 'change', (el) => el.checked);
    await load(true);
    paintReviewView();
  };
})();

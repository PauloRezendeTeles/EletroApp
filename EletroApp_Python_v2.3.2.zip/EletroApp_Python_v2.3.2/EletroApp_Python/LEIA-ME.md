# EletroApp — dimensionamento de instalações elétricas de baixa tensão

Aplicativo local para dimensionar circuitos, condutores, proteções e DPS de instalações de baixa tensão, com cálculo rastreável variável a variável.

O cálculo e o salvamento são feitos em **Python**, sem dependências externas; a interface abre no navegador do computador. Funciona sem Excel, sem chave de API, sem mensalidade e sem acesso à internet durante o uso.

## Versão 2.3.2 — condutores em paralelo no neutro e no PE

- **Quantidade própria de condutores em paralelo no neutro/PEN e no PE** (aba Condutores do circuito). Vazio = igual às fases, que era o único comportamento possível até a 2.3.1. Use 1 no PE para um PE único comum aos paralelos. Em TN-C, o PEN segue a quantidade do neutro.
- **Seção térmica do PE por condutor:** S = Ik·√t/(k·Nc_PE), coerente com a impedância do PE e com o neutro. Até a 2.3.1, a impedância tratava o PE como Nc condutores em paralelo, mas a seção térmica usava a corrente total.
- **Tabelas 48 e 58 com quantidades diferentes:** a seção mínima do neutro e a do PE passam a considerar a seção total das fases e são repartidas entre os condutores informados, com arredondamento para a seção superior (critério interno). Exemplo: 2×240 mm² nas fases com um PE único exige PE de 240 mm².
- **Correção de divisão dupla por Nc:** na queda de tensão da partida de motores, na parcela da fonte da queda do sistema e na queda do neutro (diagnóstico). No QGBT-01 com Nc = 2, a queda na partida passa de 1,84 % (errado) para 3,68 %.
- **Alertas:** neutro com quantidade diferente das fases gera o aviso da NBR 5410, 6.2.5.7.2 (cada grupo deve conter todas as fases e o neutro). A notação mostra o que fica fora do grupo, ex.: `2x{3#240mm²(240mm²)} + 1xPE120mm²`.

Com os campos novos vazios e Nc = 1, nenhum resultado muda. Os projetos salvos mostram o aviso de base de cálculo diferente: confira em **Integridade → Comparar e decidir** e adote a nova base no modo revisor. Detalhes e comparação numérica em `docs/VALIDACAO_v2.3.2.md`.

## Histórico: versão 2.3.1 — comentários de revisão em cada aba

- **Comentários de revisão:** cada aba tem, no fim da página, o bloco **Comentários de revisão** (o botão ✎ no topo leva até ele). No formulário do circuito há um bloco no fim de cada etapa, que registra o circuito aberto. Tipo, prioridade, referência, autor e texto; código sequencial (C-001…) e situação Aberto / Resolvido / Descartado.
- **Aba Comentários de revisão:** reúne todos, com filtros por aba, situação, tipo e projeto, e exporta em **Markdown** (para enviar junto com o pedido de revisão do aplicativo), CSV ou JSON. Também em **Exportar → Comentários de revisão (.md)**.
- **Isolamento:** os comentários ficam no banco local (pasta `projetos`), fora dos projetos. Não entram no `.eletro`, não criam revisão do projeto e não alteram cálculos. Nenhum arquivo de `core/` mudou: as regras de cálculo e a base dos projetos continuam as da 2.3.0.
- **Correção:** o formulário do circuito voltou a abrir. Na 2.3.0 o servidor não entregava `protecao-integrada.js` (404), o que interrompia a abertura do circuito e ocultava o bloco de proteção a montante do ramal em Entrada e fontes.

Detalhes em `docs/COMENTARIOS_REVISAO_v2.3.1.md`. Para atualizar, siga **Atualizar com seus projetos** abaixo; copiando a pasta `projetos`, os projetos e os comentários vêm junto.

## Histórico: versão 2.3.0 — proteção da entrada, alimentadores e gerador

- **Entrada MT:** seleção do elo fusível H/K/T/Outro com corrente nominal e curvas documentadas; ou disjuntor MT com funções 50, 51, 50N e 51N. O campo de interrupção do disjuntor é separado do tempo do relé e somado uma única vez.
- **Rede BT:** o trecho até a medição aparece como não verificável com os dados da concessionária ausentes. Os circuitos a jusante continuam sujeitos às suas verificações.
- **Gerador:** cadastro do disjuntor do quadro de transferência, cálculo I(t) e integral térmica. O cabo até o quadro fica a cargo do fabricante do gerador. O curto inicial continua disponível quando faltam dados temporais; a atuação temporizada fica **não verificada**.
- **Quadro precedente:** cada proteção de saída pertence ao quadro que alimenta o circuito. Um vínculo explícito permite reutilizar o disjuntor de chegada do quadro precedente quando ele é o mesmo dispositivo físico, sem duplicá-lo no unifilar ou na seletividade.
- **Projetos anteriores:** dados, fórmulas particulares e históricos são preservados. Os novos campos não recebem ajustes fictícios; preencha os dados dos equipamentos antes de concluir as verificações.

Comece em **Entrada e fontes**; depois abra o circuito → **Proteções → Vínculo e proteção do alimentador**. Veja `docs/PROTECOES_v2.3.0.md` para o preenchimento, os formatos das curvas e o alcance dos métodos. As correções de UTF-8 e queda de tensão da 2.2.1 estão mantidas.

Extraia o ZIP completo e execute `INICIAR_WINDOWS.bat`. Para atualizar, siga **Atualizar com seus projetos** abaixo. Ensaios: `docs/VALIDACAO_v2.3.0.md` e `RESULTADO_TESTES.txt`.

## Histórico: versão 2.2.1 — abertura no Windows e verificação da queda pendente

- **Abertura no Windows:** leitura de `installation_rules.json` com UTF-8 explícito. Elimina o `UnicodeDecodeError` no byte `0x9d` quando o Python usa CP1252 como codificação padrão.
- **Queda de tensão:** as verificações da queda total e do trecho só comparam valores numéricos. Enquanto faltar o cálculo ou o limite, aparece **PENDENTE**, com a indicação do dado ausente. No exemplo, QDFL-01 e QDFL-03 deixam de indicar falsamente que a queda total excedeu o limite.
- **Rastreabilidade:** a correção está nas fórmulas consultáveis do modelo. Fórmulas originais de projetos legados são reconhecidas na conversão; edições particulares continuam preservadas. Projetos já salvos podem informar mudança da base em **Integridade → Comparar e decidir**.

Extraia o ZIP completo e execute `INICIAR_WINDOWS.bat`. Se já usa outra versão, siga **Atualizar com seus projetos**, abaixo, para conservar a pasta `projetos`. Os testes e o escopo desta correção estão em `docs/VALIDACAO_v2.2.1.md` e `RESULTADO_TESTES.txt`.

## Histórico: versão 2.2.0 — base técnica conferida com a NBR 5410 e a NBR 5419

Revisão das tabelas usadas pelo aplicativo, conferidas com o exemplar da NBR 5410:2004 (versão corrigida 2008) e com a NBR 5419:2026, partes 1 a 4. Cada correção, o exemplo antes e depois e os testes estão em `docs/VALIDACAO_v2.2.0.md`.

- **Valores corrigidos:** Tabela 39 (630 mm², 1936 → 1196 A), Tabela 37 (630 mm², 1112 → 1122 A), Tabela F.1 (1,63 → 1,73), Tabela 48 até 400 mm², correntes convencionais de disjuntores e fusíveis pela norma de cada produto, Uc e Up da biblioteca Siemens nas colunas certas e resistências dos cabos com 4 algarismos significativos. Na Base técnica, cada célula corrigida aparece marcada, com o valor anterior, a fonte e o motivo.
- **Todas as tabelas acessíveis:** a Base técnica passa de 18 para 35 tabelas. Tempos de seccionamento (Tabela 25), fatores k (Tabelas 30 e 53 a 57), Uw (Tabela 31), temperaturas (Tabela 35), condutores carregados (Tabela 46), seção mínima (Tabela 47), limites de queda (6.2.7) e os critérios de DPS e da NBR 5419 deixam de estar escritos dentro das fórmulas. As Tabelas 41 a 45 e a matriz de métodos aparecem a partir das regras que o cálculo usa, com a origem de cada linha (NBR ou extensão).
- **Critérios da norma completados:** Tabela 25 com as situações 1 e 2 e a regra dos 5 s de 5.1.2.2.4.1 c; Uw e Up pela tensão do sistema; Iimp do DPS Classe I pela NBR 5419-1; mínimos de In e Iimp por modo; condutor do DPS pela NBR 5419-4 quando há SPDA; limite de queda pelo tipo de atendimento; circuitos sem neutro; PE fora do cabo; corrente de projeto com a 3ª harmônica; I2 ≤ Iz com sobrecarga prolongada. Sem resposta, cada pergunta nova fica no caso mais comum (situação 1, PE no mesmo cabo ou conduto, com neutro, sem sobrecarga prolongada, falha não crítica).
- **Vista normativa:** mapa das tabelas por norma, Tabelas 36 a 39 na forma da norma com o uso de cada circuito e o gráfico Iz × seção, células lidas pelo cálculo de qualquer circuito, fichas dos modelos de fabricante e conferência guiada das referências pelo revisor.
- **No exemplo:** Ik e quedas mudam menos de 1% (até 2,5% na queda do ramal); QDFL-01 e QDFL-02 passam a ser verificados com 0,8 s (Tabela 25) e atendem; Up máximo e Uw de 127/220 V passam a 1,5 kV; o condutor do DPS do QM-01 e do QGBT-01 passa a 6 mm²; o DPS do ramal fica com Uc 350 V e Up 1,5 kV. A lista completa está em `docs/exemplo_antes_depois_v2.2.0.csv`.

Projetos gravados na 2.1.2 abrem com o aviso de base de cálculo diferente: em **Integridade → Comparar e decidir**, confira os componentes alterados e, no modo revisor, adote a nova base. Como o código das regras também mudou, o aplicativo não recalcula o projeto com a base antiga e avisa que a comparação de resultados fica incompleta. Para ter os resultados lado a lado, exporte o CSV de resultados na 2.1.2 antes de atualizar. Entradas com o método 28 (forro falso ou piso elevado) passam ao método 21 ao abrir, com o registro no projeto. O procedimento para transferir seus projetos está abaixo, em **Atualizar com seus projetos**.

## Histórico: versão 2.1.2 — instalação, ampacidade e atualização da prévia

- **Ampacidade:** um arranjo de impedância ainda não preenchido ou incompatível mantém o circuito pendente, mas a ampacidade é calculada quando os dados térmicos estão completos. Agrupamento, geometria, temperatura, material, cabo e tabela continuam sendo conferidos.
- **Prévia:** o quadro de critérios e seções passa a acompanhar os resultados recalculados. Alterações de fases também atualizam as escolhas de disposição e arranjo; condições geométricas novas continuam exigindo confirmação.
- **Mensagens:** a consulta informa a pendência efetiva ou a corrente/seção sem correspondência na tabela. O método G com dois condutores carregados é identificado como condição sem coluna cadastrada na base.
- **Rastreabilidade:** as expressões continuam visíveis e editáveis. Fórmulas personalizadas e históricos são preservados; a importação reconhece as expressões originais da versão anterior.
- **Cobertura:** 32 tipos de linha, 94 relações montagem/cabo, dois e três condutores carregados, cobre/alumínio, todas as isolações oferecidas e disposições/arranjos disponíveis. A matriz detalhada está em `docs/matriz_instalacoes_v2.1.2.csv`; o escopo dos testes e as condições de referência estão em `docs/VALIDACAO_v2.1.2.md`.

## Histórico: versão 2.1.1 — correções da análise técnica da 2.1.0

Corrige os nove problemas reproduzidos na análise de 08/10/2026 e acrescenta controles para Icu e Ii instantâneo. Os casos estão em `tests/test_v211.py`; o detalhamento e os limites estão em `docs/VALIDACAO_v2.1.1.md`.

- **Coordenação:** ausência de pontos não comprova não atuação; o envelope de montante precisa cobrir a faixa analisada do jusante. O importador conserva I²t, rejeita cabeçalhos incorretos e exige a condição ON/OFF para dispositivos ajustáveis que possuem esse ajuste. Ii é confrontado com o disparo instantâneo efetivo. Icu declarado que diverge do catálogo impede a verificação daquela tabela.
- **Base histórica:** novos retratos incluem as regras de instalação, agrupamento e as demais bases operacionais. Cada revisão registra também a base efetivamente usada no cálculo. Comparações usam esses retratos; base ausente, retrato incompleto ou código antigo indisponível produzem aviso explícito, sem conclusão de ausência de impacto.
- **Migração:** valores fixos e fórmulas da fonte são preservados; expressões sem conversão ficam pendentes. Históricos restaurados para a fórmula original também são mantidos. Projetos nativos da 2.0 preservam o efeito das edições antigas na raiz, com migração registrada.
- **Escopos:** histórico e catálogo mostram alterações por circuito e na raiz. A duplicação conserva fórmulas particulares, histórico e condições de instalação, mantendo visíveis edições externas ou adulteradas.

### Atualizar com seus projetos

1. No aplicativo anterior, crie uma cópia de segurança do banco e exporte os projetos importantes em `.eletro`.
2. Feche o aplicativo anterior. Extraia esta versão em **uma nova pasta**.
3. Para conservar projetos, revisões e bases arquivadas, copie a pasta **`projetos` inteira** da instalação anterior para a nova. O pacote não contém banco nem projetos pessoais.
4. Execute `INICIAR_WINDOWS.bat` ou `python app.py`. Confira os avisos em **Integridade**, **Base de cálculo** e **Coordenação** antes de adotar a nova base.

Tabelas de seletividade importadas anteriormente podem precisar de nova importação: a 2.1.0 descartava I²t no CSV. Bases antigas sem regras completas não podem ser reconstruídas automaticamente. Para recuperar valores ou históricos já perdidos numa conversão anterior, reimporte o arquivo original ou restaure uma revisão anterior à conversão; dados ausentes não são inventados.

As referências e tabelas normativas continuam com o estado de verificação declarado na base. Esta atualização corrige o programa; não certifica a conferência normativa integral dos dados.

## Histórico: versão 2.1.0 — análise técnica da 2.0.0

Introduziu correções para os 13 achados da análise de 07/10/2026, com testes em `tests/test_v21.py` e registro em `docs/VALIDACAO_v2.1.md`. A versão 2.1.1 complementa essas correções nos casos descritos acima. A documentação da 2.1.0 registrou 31 diferenças conhecidas na comparação com a v1.12.

- **Coordenação com o dispositivo efetivo (1).** In, característica e curva B/C/D vêm do modelo escolhido no catálogo (no exemplo, o MDW-C80-2 do QDFL-01 passa a usar 80 A, e não os 500 A do campo antigo). Quando o In ou o tipo informados divergem do modelo, o circuito mostra a pendência **Dados do dispositivo da origem**. No exemplo, os cinco quadros com disjuntor têm essa divergência: corrija o campo In para que o dimensionamento use o mesmo valor.
- **Comparação de curvas rigorosa (2, 3, 4).** O montante precisa do tempo mínimo e o jusante do tempo máximo; a falta de um deles deixa o par indeterminado. Nada é extrapolado: acima do último ponto importado, o resultado fica **verificado só até o limite indicado**. A comparação percorre todos os vértices e segmentos das duas curvas (não mais 61 amostras) e localiza o cruzamento. Na região instantânea do montante (< 10 ms), curvas não demonstram seletividade; vale a tabela do fabricante.
- **Condições de validade dos dados de fabricante (5).** Tabelas e curvas guardam tensão, ajustes (Ir, Isd, tsd, Ii) e I²t. O nível verificado só é atribuído quando essas condições existem e conferem com o projeto: mudar a tensão ou o Ir retira a verificação. A tensão é obrigatória nas tabelas. `T` passa a significar seletividade até a capacidade de interrupção do jusante (no exemplo, 5 kA do MDW-C80-2, abaixo do Ik de 8,93 kA → parcial).
- **Todos os dispositivos em série (6).** Um circuito com dispositivo na origem e disjuntor de manutenção ganha o par **origem × manutenção**, além do par com o montante.
- **Conversão de projetos antigos circuito a circuito (7).** Uma fórmula alterada só em um circuito vira versão daquele circuito; alteração em todos vira versão comum; valor fixo no lugar da fórmula é preservado. O que não tem equivalente nativo vai para a integridade como **conversão pendente** (o revisor registra a conferência). O histórico completo de edições da v1.x é preservado.
- **Base de cálculo fixada por projeto (8).** Cada projeto guarda a identificação verificável da base (variáveis, cada tabela, regras e código) e o aplicativo guarda o retrato de cada base usada. Se a base em uso mudar, a integridade aponta a diferença; o revisor compara os resultados recalculados com a base anterior e adota a nova, com o registro da atualização.
- **Integridade dos dados de fabricante (9).** Curvas e tabelas importadas recebem selo; um registro alterado fora do aplicativo aparece na integridade e deixa de sustentar o nível verificado.
- **Variante dos circuitos ligados à fonte versionada à parte (10).** Editar a expressão comum não substitui mais a variante desses circuitos; ela tem edição, histórico e restauração próprios.
- **Tabelas operacionais × documentais (11).** A base técnica indica o que cada tabela alimenta. A Tabela 33 e a ajuda de métodos são consulta (a seleção usa a matriz de instalação, registrada na base) e não podem ser editadas; em tabelas operacionais, posições que nenhum cálculo lê também não.
- **Identificadores únicos (12).** Arquivo com identificador ou nome de circuito repetido é recusado na abertura.
- **Regras em Python com saídas e efeitos (13).** Cada regra lista o que grava ou valida e pode ser consultada aplicada a um circuito.

## Versão 2.0.0 — modelo nativo, independente da planilha r42

A partir desta versão o aplicativo não depende mais da planilha `Dimensionamento_de_circuitos_eletricosv1_r42.xlsx`: a planilha, o JSON da planilha, o exemplo embutido nela, a importação de XLSX no formato r42 e a tela “Conferência com r42” foram removidos. O método de cálculo foi preservado: a migração foi conferida com o motor da v1.12 em 7 cenários (6.301 a 8.353 valores cada), sem diferenças além dos subtítulos que a planilha guardava em linhas de dados (`docs/VALIDACAO_v2.0.md`).

- **Motor próprio com variáveis nomeadas (itens 1 e 2).** Cada cálculo é uma variável com nome (`corrente.i_r_a`, `protecao.ir_a`, `icc.ik_max_ka`…), rótulo, unidade, expressão e dependências explícitas — por circuito, 925 cálculos e 101 dados de entrada; na fonte, 139 variáveis; no projeto, 6 verificações (1.033 cálculos ao todo), em `data/modelo`. As expressões usam nomes, nunca endereços de célula: `CIRCUITOS(x)` lê a variável em todos os circuitos, `ANTERIOR(x)` no circuito anterior e `FAIXA(a,b)` um bloco do mesmo circuito. As 62 variações de fórmula entre linhas que a planilha tinha foram unificadas e documentadas (`docs/MIGRACAO_MODELO.md`); a única variante mantida é a de circuitos ligados diretamente à fonte.
- **Estrutura dinâmica (item 3).** Sem limite de 100 circuitos e sem posições fixas de entrada e medição: ramal e medição são circuitos como os demais, podem ser editados ou excluídos, e qualquer circuito pode ser ligado diretamente à fonte ou ao transformador, inclusive com carga própria. Cada circuito tem um identificador próprio; a posição é só a ordem atual (montante antes de jusante).
- **Catálogo completo e rastreável (item 4).** O **Catálogo de cálculos** lista as variáveis com grupo, unidade, expressão em uso, expressão do modelo, dados usados, quem usa a variável, justificativa normativa e histórico de versões. As **regras implementadas em Python** (instalação, agrupamento, neutro, seleção, ajustes, topologia, trecho, coordenação e motores) aparecem no mesmo catálogo com módulo, dados usados, resultados produzidos, versão, autoria e referências normativas editáveis. A edição de expressões continua controlada (modo revisor, simulação em todos os circuitos, justificativa, bloqueio de erros novos, histórico e restauração). A trilha de cálculo navega variável a variável, com a substituição numérica no circuito escolhido.
- **Base técnica versionada (item 13).** As 18 tabelas técnicas ficam em `data/tabelas`, cada uma com título, categoria (norma, fabricante, referência, listas), fonte, edição, revisão da base, condições de uso e referências normativas (`data/tabelas/_metadados.json`). Tabelas cuja fonte não está documentada aparecem como **“fonte a confirmar”** (impedâncias de cabos, transformadores, concessionária, motores) — nada foi inventado. A página **Base técnica** mostra cada tabela; o revisor edita valores no projeto informando a fonte do novo valor e a justificativa, com simulação, bloqueio de erros novos e restauração da base. O registro normativo passou a ter 34 localizadores (NBR 5410, NBR 5419-4, IEC 60909-0, IEC 60947-2, IEC 60898-1), sem texto da norma e marcados como não verificados até a conferência por um revisor.
- **Coordenação das proteções em três níveis (item 14).** A página **Coordenação** avalia cada dispositivo contra o dispositivo a montante, na corrente de curto máxima do ponto de instalação, e informa o nível de evidência:
  - **verificado com dados do fabricante** — só quando o revisor importa a tabela de seletividade ou as curvas tempo × corrente do fabricante, com documento, edição e página; o aplicativo não traz nem estima dados de fabricante;
  - **aproximado** — faixas genéricas a partir dos ajustes adotados: correntes convencionais de atuação e não atuação, faixa magnética do catálogo (fixos) ou das curvas B/C/D, tolerância de ±20% dos disparadores ajustáveis, curto retardo e relação 1,6:1 entre fusíveis gG; resulta em seletiva, parcial (com o limite aproximado) ou não seletiva;
  - **pré-verificação** — a razão de correntes do modelo, quando faltam dados para a aproximação.
  O relatório ganhou a seção *Coordenação das proteções* e a lista da base técnica usada.
- **Integridade com selo.** O projeto guarda só o que difere do modelo: dados de entrada, versões de expressões, edições de tabelas e dados de fabricante. Cada versão registrada recebe um selo; expressões ou tabelas sem selo válido (editadas no arquivo, no banco ou herdadas de um projeto antigo) aparecem em **Integridade**, na trilha de cálculo, no catálogo e no relatório. O revisor pode assumir uma expressão alterada, com justificativa, ou voltar ao modelo.
- **Desempenho.** Leituras das tabelas e subexpressões que não dependem do circuito são calculadas uma vez por recálculo, operações numéricas sobre tabelas são vetorizadas e uma alteração recalcula só o que depende dela. O exemplo de 6 circuitos recalcula em cerca de 1 s; com 126 circuitos, o recálculo completo leva cerca de 9 s e uma alteração com reseleção automática, cerca de 2 s.

**Projetos da versão 1.x** são convertidos automaticamente ao abrir (`core/migracao.py`): dados de entrada viram variáveis, fórmulas editadas no catálogo viram versões registradas (com autor, data e justificativa), fórmulas diferentes sem registro são preservadas e marcadas como alteradas fora do aplicativo, e diferenças nas tabelas viram edições do projeto. Antes da conversão, o banco recebe uma cópia de segurança (`projetos/backups/*antes-conversao-v2*`); as revisões antigas continuam no histórico e podem ser comparadas e restauradas. Arquivos `.eletro` antigos também são convertidos ao importar.

**Limites desta versão:** as tabelas de norma foram herdadas da base anterior e precisam de conferência célula a célula contra a edição vigente; a coordenação “verificada” depende dos dados que o revisor importar; o selo de integridade detecta alterações fora do fluxo de revisão, mas não é uma assinatura digital. Esquemas TT e IT continuam fora do modelo.

## Abrir no Windows

1. Instale **Python 3.10 ou superior**, caso ainda não tenha: <https://www.python.org/downloads/>. Habilite a opção **Add Python to PATH** quando disponível.
2. **Extraia todo o ZIP** para uma pasta, por exemplo `Documentos\EletroApp`. Não execute diretamente de dentro do ZIP.
3. Dê dois cliques em **INICIAR_WINDOWS.bat**.
4. O navegador abrirá o aplicativo. Mantenha a janela do terminal aberta enquanto estiver usando.

Se o navegador não abrir automaticamente, copie o endereço mostrado no terminal, normalmente `http://127.0.0.1:8765`.

Alternativa pelo terminal, dentro da pasta extraída:

```bash
python app.py
```

## Linux e macOS

Com Python 3.10 ou superior instalado:

```bash
python3 app.py
```

Também é possível executar `sh iniciar.sh`. Nenhuma instalação via `pip` é necessária.

Opcional (v1.12): para ler PDF e imagens na importação de quadros de cargas, defina `ANTHROPIC_API_KEY` antes de iniciar. Sem essa variável, o aplicativo continua funcionando sem internet.


## Primeiro uso

O aplicativo abre com o **projeto de exemplo** (ramal de entrada, medição, QGBT e três QDFLs). São dados de demonstração, não um dimensionamento aprovado. Em **Novo projeto** é possível começar do exemplo completo, do exemplo sem disjuntor na origem dos trechos de entrada ou só com o ramal e a medição.

## Escolha da instalação

As combinações de linha elétrica, montagem, tipo de cabo e tabelas de ampacidade
são filtradas em cascata pela matriz extraída do guia Prysmian consultado durante
a revisão. Por exemplo, **eletroduto embutido em parede isolante** oferece apenas
os métodos **A1 (1)** e **A2 (2)**; A1 admite condutor isolado ou cabo unipolar,
enquanto A2 admite cabo multipolar. Combinações incompatíveis não são salvas nem
entram como cálculo válido. A resistividade do solo fica disponível somente para
instalações enterradas (método D). O PDF usado como referência não é distribuído
nem anexado ao aplicativo.

1. Em **Entrada e fontes**, confira atendimento, tensões, transformador, impedâncias e critérios gerais.
2. Em **Quadros e circuitos**, abra um circuito e revise as condições de instalação, cargas por fase, motores e seções escolhidas.
3. Clique em **Salvar e recalcular** para aplicar as mudanças. Campos calculados são somente leitura.
4. Em **Proteções**, escolha o modo Automático ou Manual e confira modelo ativo, Ir, Ii/Im, capacidade de interrupção e confirmações.
5. Em **DPS** e **Verificações**, leia as pendências do modelo.
6. Use **Exportar** para gerar backup editável, CSV de resultados ou relatório para impressão/PDF.


## Unifilar e cadastro

- O unifilar é gerado pelos vínculos reais do projeto. Clique em um cartão para editar.
- Para transferir um circuito, altere **Circuito a montante**. A ordem de cálculo é reorganizada automaticamente (montante antes de jusante).
- Para desvincular, selecione **Desvinculado**. Resultados que dependem da alimentação precisam de revisão enquanto o vínculo estiver ausente.
- Nomes duplicados, montantes inexistentes e ciclos são rejeitados.
- Ao renomear um quadro, as referências dos filhos são atualizadas.
- Um circuito com filhos só pode ser excluído depois de transferir ou desvincular os filhos.
- Circuitos novos começam com carga zero e parâmetros iniciais editáveis. A duplicação copia os dados, mas mantém a confirmação da proteção como pendente.
- Alterações de dados reabrem as confirmações dos dispositivos de proteção para revisão.


## Projetos e backups

O banco `projetos/eletroapp.sqlite3` é criado na pasta do aplicativo e guarda os projetos e o histórico de revisões. As gravações ocorrem ao salvar o formulário ou concluir ações de cadastro.

**Para backup:** escolha **Exportar → Projeto editável (.eletro)**. O arquivo contém os dados de entrada, os identificadores dos circuitos, as versões de expressões e as edições de tabelas do projeto, os dados de fabricante importados e as configurações. O modelo de cálculo e a base técnica não são copiados para o arquivo: vêm do aplicativo.

**Para abrir um backup:** clique em **Importar projeto** e selecione o arquivo `.eletro` (inclusive de versões 1.x, convertidos ao abrir). A importação cria outro projeto e preserva os existentes. Planilhas XLSX não são abertas como projeto; quadros de carga em CSV, XLSX, PDF ou imagem entram por **Importar quadro de cargas**, sem executar fórmulas.

**Relatório PDF:** escolha **Exportar → Relatório / PDF** e, na nova página, clique em **Imprimir / salvar em PDF**.

## Como o cálculo é organizado

- `data/modelo/circuito.json`, `fonte.json`, `projeto.json` e `nomes.json` — variáveis do modelo (id, grupo, rótulo, unidade, expressão, variantes, listas de opções).
- `data/tabelas/tab_*.json` e `_metadados.json` — base técnica versionada.
- `data/normrefs/` — registro de referências normativas (localizadores, sem texto da norma).
- `core/motor.py` — motor nativo: avalia as expressões por nome, com cache, detecção de ciclos e invalidação seletiva. As funções disponíveis nas expressões (SE, PROCV, SOMARPRODUTO, números complexos…) são as do interpretador `core/formula.py`.
- `core/project.py` — projeto, circuitos, formulários, validação e resultados; `core/installation.py`, `core/grouping.py`, `core/selection.py`, `core/trecho.py`, `core/ajustes.py`, `core/topologia.py` e `core/curvas.py` — regras em Python.
- `core/normativa.py` — vista normativa da Base técnica: mapa por norma, Tabelas 36 a 39, uso por circuito, fichas de fabricante e conferência guiada. Só lê o projeto, exceto a marcação de conferência, que fica no projeto e não altera o cálculo.

O modelo foi gerado uma única vez a partir da planilha r42 (`tools/gerar_modelo.py`) e conferido com o motor anterior (`tools/paridade.py`). Esses dois utilitários de desenvolvimento só funcionam com os arquivos da v1.x, que não acompanham o aplicativo.

## Limites e conferência

- Sem limite fixo de circuitos; o tempo de recálculo cresce com a quantidade.
- Os esquemas disponíveis no modelo são **TN-S e TN-C**. Não há cálculo para TT ou IT.
- O cálculo **não é uma validação normativa independente** nem uma revisão dos dados de catálogo. As tabelas da NBR 5410 e da NBR 5419 foram conferidas com o exemplar na versão 2.2.0, com a página indicada na Base técnica. Tabelas de outras normas (IEC 60909-0, IEC 60898-1, IEC 60947-2, IEC 60269, NBR NM 280) e de fabricante devem ser conferidas contra o documento vigente indicado na Base técnica.
- A coordenação “aproximada” usa faixas genéricas e não substitui a curva ou a tabela de seletividade do fabricante.
- Não foi gerado executável `.exe`: este pacote contém o código-fonte executável com Python.
- O aplicativo é local e atende apenas o próprio computador.

## Estrutura do código

```text
app.py                      Servidor local, API, relatórios, SQLite e histórico
core/motor.py               Motor nativo (variáveis nomeadas, cache e invalidação seletiva)
core/formula.py             Funções e semântica das expressões
core/expressao.py           Leitura e escrita de expressões
core/project.py             Projeto, circuitos, topologia, formulários e resultados
core/catalog.py             Catálogo de cálculos e regras em Python, trilha, edição segura, referências
core/integridade.py         Selos, integridade e conferência da base de cálculo
core/versoes.py             Escopos das versões de expressão (comum, fonte, circuito)
core/tabelas.py             Base técnica: consulta, edição versionada e restauração
core/normativa.py           Vista normativa da Base técnica e conferência guiada
core/curvas.py              Coordenação em três níveis e dados de fabricante
core/historico.py           Revisões, diferenças e comparação
core/migracao.py            Conversão de projetos da v1.x
core/importacao.py          Importação de quadros de carga (CSV, XLSX, PDF/imagem com IA opcional)
core/advisor.py             Sugestões locais de proteção, seletividade e DPS (consultivo)
data/modelo/                Variáveis do modelo (e variações da r42 reconhecidas na conversão)
data/tabelas/               Base técnica versionada
data/exemplos/exemplo.json  Projeto de exemplo (somente dados de entrada)
data/normrefs/              Registro normativo
static/                     Interface (HTML, CSS e JavaScript)
tests/                      Testes automatizados (tests/fixtures: projeto da v1.x para os testes de conversão)
tools/                      Utilitários de desenvolvimento (geração do modelo e paridade)
docs/                       Validação, migração e histórico
```

Para executar os testes:

```bash
python -m unittest discover -s tests -v
```

Opções de execução:

```bash
python app.py --no-browser
python app.py --port 8800
python app.py --data-dir "C:\MeusProjetosEletricos"
```

Se a porta estiver ocupada, o programa tenta as próximas 19 portas e mostra o endereço escolhido. Para encerrar, feche o terminal ou pressione `Ctrl+C`.

Referência da infraestrutura Python: <https://docs.python.org/3/library/http.server.html>. O servidor incluído foi configurado para uso local; não é uma configuração de hospedagem pública.



# Histórico de versões anteriores

As notas abaixo descrevem as versões 1.x, que ainda interpretavam a planilha r42; referências a abas, células, `data/r42.json.gz` e `referencia/` valem só para essas versões.

## Versão 1.12.0 — integridade, revisões, ajustes no servidor e importação

- **Fórmulas alteradas fora do aplicativo:** ao abrir um projeto, cada fórmula é comparada com a referência do próprio EletroApp e com o histórico de edições do catálogo. Uma expressão diferente deixa de aparecer como original só porque não há edição registrada. As divergências aparecem na visão geral, em **Conferência e integridade › Integridade das fórmulas**, no catálogo, na trilha de cálculo e no relatório.
- **Edição de fórmula com novos erros é bloqueada:** a simulação e a comparação continuam disponíveis, mas a confirmação é recusada se surgirem erros novos nos cálculos obrigatórios (resultados dos circuitos e verificações). O ensaio `=1/0` faz parte dos testes. A restauração para a fórmula original nunca é bloqueada.
- **Seleção automática sincronizada:** editar ou restaurar uma fórmula e excluir um circuito disparam de novo a escolha automática de disjuntores, DPS e backups. As mensagens antigas são substituídas.
- **Ajustes das proteções conferidos no servidor:** Ir, Ii/Im, Isd e tsd precisam existir no modelo escolhido (posição do dial, faixa, valor fixo) e ser coerentes entre si (Ir ≤ In, Ir ≤ Isd ≤ Ii). Um ajuste inexistente não é gravado e, se já estiver no projeto, o dispositivo aparece como **✗ Ajustes fora do catálogo**, nunca como compatível. Isso vale também para o disjuntor de manutenção.
  - *Efeito no exemplo r42:* os disjuntores ACW400H-ETS400-3 do ramal, do QM-01 e do QGBT-01 têm Ii = 1.600 A, mas o catálogo informa Ii fixo de 4.400 A (11 × In). Por isso passam a aparecer com pendência. No formulário, o Ii já aparece travado em 4.400 A; basta salvar o circuito.
- **Proteção contra abas desatualizadas:** toda gravação leva o projeto e a revisão em que a tela se baseou. Se outra aba ou janela tiver gravado antes, ou se a aba estiver com outro projeto, nada é gravado e o aplicativo pede para atualizar a página.
- **Histórico do projeto inteiro:** cada gravação gera uma revisão com cargas, vínculos, cabos, dispositivos, fórmulas e tabelas, guardada como diferença em relação à anterior. Na página **Histórico do projeto** é possível comparar duas revisões (entradas, fórmulas e resultados por circuito) e restaurar uma delas, o que cria uma nova revisão sem apagar as outras. Uma cópia de segurança do banco é criada ao iniciar, antes de cada restauração e sob demanda, em `projetos/backups` (ficam as 10 mais recentes).
- **Topologia elétrica:** o vínculo montante → jusante passa a conferir as fases disponíveis, o neutro, o PE/PEN, a compatibilidade TN-C/TN-S (depois de separados, N e PE não voltam a se reunir), a seção mínima do PEN e a proibição de seccionar o PEN. Uma ligação incompatível deixa de mostrar “✓ Topologia válida”.
- **Números e botões − / +:** cada campo tem incremento, limites e casas decimais próprios. Contagens só aceitam inteiros. A leitura segue o formato brasileiro: `1.000,00` é mil, e não 1. A mesma regra vale no servidor.
- **Textos tratados com segurança:** nomes e conteúdos importados entram na interface como texto. A navegação entre circuitos (`ux.js`) foi refeita sem HTML montado com dados do projeto, e identificadores inválidos em projetos importados são substituídos.
- **Importar quadro de cargas:** botão no topo. Aceita um ou mais documentos (quadro de cargas, unifilar ou ambos) em CSV ou XLSX. Mostra a coluna e a linha de origem de cada valor, as ausências e os conflitos (montante inexistente, fases incompatíveis, ciclos, divergência entre documentos, limite de 100 circuitos). Permite revisar e corrigir antes de gravar. Os resultados são recalculados pelo EletroApp; as fórmulas de um XLSX importado nunca são executadas.
  - *PDF e imagens* são lidos pela extração assistida por IA, **desligada por padrão**. Para ligar, defina a variável de ambiente `ANTHROPIC_API_KEY` antes de iniciar (opcionalmente `ELETROAPP_IA_MODELO`). Nesse caso o documento é enviado à API da Anthropic. A IA só interpreta o documento e os dados passam pela mesma revisão. DXF fica para uma etapa posterior.

**O que não muda nesta versão:** o motor de cálculo continua sendo a r42 interpretada, com o limite de 100 circuitos e as posições de entrada e medição. A independência total da planilha (itens 1–3), a base técnica própria (13), o catálogo completo das regras em Python (4) e a coordenação com curvas de fabricante (14) exigem migração por etapas, descrita em `docs/ROTEIRO_INDEPENDENCIA_r42.md`. A validação desta versão está em `docs/VALIDACAO_v1.12.md`.

**Atualização:** preserve a pasta `projetos`. Projetos anteriores abrem normalmente e começam o histórico com o estado em que foram abertos.

## Versão 1.11.0 — visual e usabilidade

- **Novo visual "Azul técnico"**, com mais contraste e botões maiores.
- **Mais botões, menos preenchimento:** listas curtas (até 6 opções) viram botões de escolha com um clique. Campos numéricos ganham botões − / +.
- **Formulário do circuito em etapas numeradas:** botões *Anterior* e *Próxima etapa* no fim de cada aba (ou Alt+← / Alt+→), e botões para ir ao circuito anterior ou ao próximo sem fechar o formulário.
- **Visão geral com atalhos:** uma barra com as etapas do projeto (Entrada, Circuitos, Proteções, DPS, Verificações, Unifilar, Relatório).
- **Lista de circuitos:** botão *Abrir* em cada linha.
- Os cálculos não foram alterados: a camada nova está em `static/ux.js` e no fim de `static/style.css`.

## Versão 1.10.0 — dispositivos do trecho, disjuntor de manutenção e DPS opcional

- **Trecho sem dispositivo na origem:** em **Proteções → Dispositivos do trecho**, escolha **Sem dispositivo próprio** para trechos como transformador → quadro ou padrão de entrada → medição. Informe a justificativa, confirme as condições da dispensa (linha executada com risco mínimo de curto-circuito e afastada de material combustível) e o tempo em que a proteção a montante elimina uma falta no fim do trecho. O aplicativo verifica o trecho em três frentes:
  - **curto-circuito:** dispensa justificada (NBR 5410, 5.3.5.3) ou pendência;
  - **sobrecarga:** disjuntor de manutenção na extremidade ou, quando a cadeia não tem derivações, o primeiro dispositivo a jusante (5.3.4.2.2), sempre com Ir ≤ Iz do cabo; sem nenhum deles, alerta de 5.3.4.3;
  - **seccionamento automático:** tempo da proteção a montante comparado ao tempo máximo. O PE pelo critério adiabático usa esse tempo; sem ele, segue a tabela 58.

  Nesses trechos, a escolha automática do disjuntor da origem fica suspensa. Os dados do dispositivo continuam guardados, caso ele volte a ser previsto.
- **Disjuntor de manutenção (jusante):** é o disjuntor instalado na chegada do quadro. Funciona em modo Automático ou Manual, com o catálogo WEG por classe, família e modelo e os ajustes Ir, Ii, Isd e tsd. O aplicativo verifica:
  - Ib ≤ Ir, e também Ir ≤ Iz quando não há dispositivo na origem;
  - faixa de ajuste, Icu ≥ Ik no quadro, tensão e polos;
  - partida de motores e eliminação de faltas no quadro.

  Com dispositivo na origem, mostra também a pré-verificação de seletividade entre os dois. Os circuitos alimentados pelo quadro passam a ter o disjuntor de manutenção como dispositivo a montante, e o diagrama unifilar o desenha na chegada do quadro.
- **DPS opcional por quadro:** em **DPS neste quadro**, mantenha a regra da r42 (origem e distribuição recebem DPS; circuito final, não), dispense o DPS ou fixe Tipo 2 ou Tipo 1+2. Os quadros a jusante coordenam com o DPS mais próximo a montante. Se houver SPDA, o primeiro DPS da instalação passa a Tipo 1+2.
- **Seletividade:** a pré-verificação compara os dispositivos efetivos. Pode ser o da origem, o disjuntor de manutenção ou, quando um trecho não tem dispositivo, o primeiro dispositivo a montante.
- **Novo ponto de partida:** *Exemplo r42 — transformador e medição sem disjuntor na origem*. Ramal de entrada, QM-01 e QGBT-01 ficam sem disjuntor e sem DPS na origem. O disjuntor geral (de manutenção) ACW400H-ETS400-3 fica na chegada do QGBT-01, que também recebe o primeiro DPS. As confirmações físicas ficam pendentes de propósito.
- **Correção do Icu/Ics da origem:** a r42 comparava o Icu e o Ics do disjuntor da origem com o Ik do fim do próprio cabo. Agora a comparação usa o Ik do quadro onde o disjuntor está instalado (ou dos terminais do transformador), também na escolha automática. No exemplo r42, o MDW-C80-2 do QDFL-01 (Icu 5 kA) passa a reprovar: o Ik no QGBT-01 é 8,93 kA, e não 2,71 kA. Projetos existentes podem ter resultados diferentes ao abrir.
- **Relatório e CSV:** novas colunas de proteção na origem, disjuntor de manutenção e DPS. O relatório ganhou a seção *Dispositivos do trecho*.

### Usabilidade

- **Rótulos de situação:** são curtos e legíveis (por exemplo, *✓ Pelo disjuntor de manutenção de QGBT-01*). O texto completo aparece logo abaixo ou ao passar o mouse.
- **Pendências:** nas páginas Proteções, DPS e Verificações, cada pendência abre o circuito no grupo e no campo correspondentes. As pendências que dependem da instalação ficam agrupadas. O diagnóstico de fórmulas fica recolhido e organizado por circuito.
- **Formulário do circuito:**
  - está mais largo e mostra a situação e a lista de pendências no topo;
  - as abas rolam em telas estreitas;
  - a escolha Automático/Manual fica dentro de cada grupo, com o efeito explicado;
  - os endereços das células ficam ocultos; marque **Células da planilha** para exibi-los.
- **Campos:** os que não se aplicam deixam de aparecer (por exemplo, Isd, tsd e o tempo de abertura do catálogo só aparecem para disjuntores eletrônicos). Os valores padrão aparecem com nome, como *Siemens (padrão)*, e os campos que costumam gerar dúvida têm uma orientação curta.
- **Correções:**
  - a opção *Distribuição* do filtro de circuitos não existia;
  - o DPS do QM-01 ficava *sem modelo compatível* depois de salvar;
  - no celular, **Novo projeto** não era acessível; agora está no menu lateral.

**Compatibilidade:** projetos anteriores abrem com dispositivo na origem, sem disjuntor de manutenção e com o DPS pela regra da r42. Fora a correção abaixo, os resultados são idênticos aos da versão 1.9.0: no exemplo r42, nenhuma das 5.339 células de fórmula conferidas mudou. Ao abrir um projeto, o aplicativo acrescenta a aba `Dispositivos_Trecho` e envolve as fórmulas afetadas com `TRECHO_SE(condição; variante; fórmula original)`. O catálogo de fórmulas continua a reconhecer, editar e restaurar a fórmula original. Os itens da NBR 5410:2004 citados nas mensagens devem ser conferidos na edição vigente. O arquivo `data/r42.json.gz` e a planilha em `referencia/` não foram alterados.

A validação desta revisão está em `docs/VALIDACAO_v1.10.md`.

## Versão 1.9.0 — agrupamento, paralelos e neutro

- Agrupamento **Automático ou Manual**, com contagem física única por trecho e soma automática dos paralelos. Informe somente os conjuntos dos demais circuitos; o total também pode ser manual.
- **292 relações de consulta** ligadas ao cálculo. NBR 5410 e extensões do guia são identificadas separadamente; as extensões são opcionais. As quatro divergências numéricas do guia foram corrigidas.
- Escolhas guiadas de disposição, camadas, distâncias e distribuição nos dutos. Teto usa sua correção inclusive com um circuito. Combinações fora das tabelas ficam pendentes e admitem fator manual com fonte e justificativa.
- Fases, neutro e Iz recebem o mesmo FCA, sem segundo fator para paralelos. A redução da seção do neutro exige as condições da norma. O piso interno de corrente de 15% é opcional.
- Semelhança dos cabos, menor classe térmica, afastamento >2De e exclusão por baixa carga são tratados explicitamente. O fator 1/√n não é mais usado automaticamente por ultrapassar oito conjuntos.
- Projetos antigos podem pedir a confirmação da contagem física e das condições do grupo. Preserve a pasta `projetos` ao atualizar.

Validação e limites: `docs/VALIDACAO_v1.9.md`.


## Versão 1.8.0 — relações de instalação e consulta

- **Tabelas de instalação:** nova opção no menu Referência, também acessível dentro do circuito. Reúne as 32 condições de instalação e 94 relações entre montagem, cabo e método de referência, com pesquisa e filtro. Inclui disposições, isolação, classe térmica e afastamentos E/F/G.
- **Uma base de regras:** tabelas, imagens, listas do formulário e validação usam `data/installation_rules.json` e as condições de `core/installation.py`. Os outros dois JSON de métodos são espelhos para consulta; não comandam o aplicativo.
- **NBR 5410 prevalece:** nos métodos 22, 24 e 41, adota-se B2 para `1,5De ≤ V < 20De` e B1 para `V ≥ 20De`. O limite de 5De divergente no guia não foi adotado; o teto artificial de 500De foi removido. A tabela 33 da NBR 5410:2004, versão corrigida 2008, foi consultada para esta decisão.
- **Escolhas compatíveis:** corrigidos os nomes com espaços finais que liberavam indevidamente todos os métodos. Uma instalação desconhecida não libera a galeria completa. A troca entre unipolar e multipolar conserva todas as alternativas compatíveis com a montagem selecionada.
- **Disposição dos condutores:** as opções F/G aparecem ao mudar a montagem, inclusive no método 17. Ao mudar para um método sem disposição específica, o campo passa a N/A, sem deixar um ajuste incompatível escondido.
- **Condições físicas guiadas:** quando necessário, confirme os afastamentos e a faixa geométrica da instalação ou informe as medidas. Para E/F/G, os limites seguem 6.2.5.1.2, notas 5 e 6. A bandeja do método 13 exige pelo menos 30% de área perfurada. Mudanças de montagem, cabo, isolação ou disposição exigem nova conferência.
- **LSHF/A e HEPR:** disponíveis nos tipos de cabo correspondentes do guia. Os cálculos usam, respectivamente, a classe de 70 °C do PVC e a classe de 90 °C do EPR, preservando o nome escolhido. Essa correspondência alcança os fatores térmicos, ampacidade, impedância e curto-circuito, inclusive após salvar/reabrir ou revisar fórmulas.

Os modos Automático/Manual de disjuntor, DPS e backup, e a aba Motores, permanecem disponíveis conforme a versão 1.7.0 abaixo.

**Projetos existentes:** os nomes e códigos antigos das faixas continuam reconhecidos. Não é presumida uma confirmação física que ainda não foi informada: projetos com E/F/G podem apresentar pendência até a conferência no formulário. Na atualização, preserve a pasta `projetos`; também é possível exportar e importar o projeto editável `.eletro`. Os arquivos da planilha de referência não foram alterados e os PDFs consultados não foram anexados ao aplicativo.

A validação desta revisão está em `docs/VALIDACAO_v1.8.md`.

## Versão 1.7.0 — escolhas guiadas e motores

- **Automático ou Manual desde o início:** escolha separadamente o modo do disjuntor, do DPS e do backup do DPS ao criar um projeto e no início do formulário de cada circuito. Projetos novos começam com os três modos automáticos. É possível mudar cada modo a qualquer momento.
- **Disjuntor:** o modo automático procura no catálogo um modelo com corrente, ajustes, polos e capacidade de interrupção compatíveis com os dados calculados. No modo manual, há uma lista rápida de modelos compatíveis, além do catálogo por classe e família. Se nenhum candidato atender, o aplicativo mostra a pendência.
- **DPS e backup:** a lista apresenta os dados do modelo e identifica incompatibilidades. O modo automático considera os critérios do circuito e o catálogo disponível. O backup automático escolhe um fusível de catálogo dentro do limite do DPS e com capacidade de interrupção suficiente; também pode ser informado manualmente. Declarações e coordenação dependentes do fabricante continuam pendentes até serem comprovadas.
- **Aba Motores:** cadastre o maior motor e o somatório dos demais, separados de **Cargas gerais**. Potência e polos permitem buscar os parâmetros disponíveis na tabela r42. Abra **Dados de placa / entrada manual** para substituir parâmetros ou preencher os que faltam; a corrente é calculada quando há dados suficientes. O somatório dos demais motores pede os valores médios de fp e rendimento somente quando há outros motores.
- **Partida na aba Motores:** escolha o método por lista. Os campos e a orientação mudam conforme a partida. Direta e estrela-triângulo dispensam percentual; os demais métodos oferecem valores guiados e entrada manual.
- **Prévia antes de salvar:** os resultados se atualizam durante a edição. Clique em **Salvar e recalcular** para gravar as escolhas.

### Atualizar e abrir projetos anteriores

Feche a versão anterior, extraia o novo ZIP e **preserve a pasta `projetos`**, que contém os projetos salvos. Se instalar em outra pasta, copie também essa pasta para junto de `app.py`. Mantenha uma cópia dos arquivos `.eletro` exportados.

Abrir um projeto anterior preserva suas escolhas e cargas. Na aba Motores, ele começa com **Já incluídos nas cargas gerais**, pois os motores podem já estar somados aos valores existentes. Para usar **Somar automaticamente às cargas gerais**, retire antes a parcela dos motores das cargas gerais. Em circuitos novos, essa soma já é automática. Cadastre em cada circuito somente seus próprios motores; os alimentadores recebem automaticamente a contribuição dos circuitos vinculados.

A planilha XLSX e os dados originais em `referencia` permanecem intactos. A seleção automática usa os dados disponíveis e não confirma, por conta própria, curvas, seletividade ou declarações de fabricante. Veja o registro desta revisão em `docs/VALIDACAO_v1.7.md`. As notas de versões anteriores abaixo são mantidas como histórico.


## Novidades da v1.4 — catálogo de fórmulas rastreável

Implementa a "Proposta revisada — fórmulas r42 como catálogo rastreável, editável e justificado normativamente". O interpretador `core/formula.py` continua sendo o único motor de cálculo; a v1.4 só acrescenta uma camada de auditoria.

- **Catálogo de fórmulas** (menu *Catálogo de fórmulas*, antigo "Dados e fórmulas"): as 95.140 fórmulas da r42 viram **1.450 templates de coluna** (`data/formula_catalog.json`, gerado por `python -m core.catalog`). Cada entrada tem id estável, aba, faixa, expressão literal, descrição, parâmetros (rótulo, unidade, origem), saída, referências normativas, baseline (`r42-v1.2`) e status. Busca por texto/id, filtro por aba, status e norma. A planilha original de 58 abas continua na aba *Planilha r42*.
- **Ver cálculo** (🔍 nos campos calculados, nas seções escolhidas e no topo do formulário; também em qualquer célula da conferência): gaveta *Trilha de cálculo* com a fórmula exata da célula, árvore de precedentes clicável e expansível (valor atual e origem: entrada do usuário / outra fórmula / tabela), substituição numérica e três valores lado a lado — cache do Excel, recalculado pelo interpretador e versão editada. API: `GET /api/trace?circuito=<id>&campo=<Aba!Endereço>`.
- **Edição segura** (modo revisor): botão *Editar fórmula* no catálogo, liberado só com senha local de revisor (definida no primeiro uso; fica como hash PBKDF2 no SQLite). A edição nunca apaga o baseline; a nova expressão é compilada e executada em **todos** os circuitos ativos, e o app mostra o diff campo a campo (quantos circuitos mudam, quanto, novos erros). Só grava com **justificativa obrigatória** (mín. 15 caracteres) e confirmação explícita; grava versão (autor, data, justificativa, impacto), **reabre as confirmações de proteção** (CF = PENDENTE, mesmo padrão de qualquer alteração) e permite **rollback** para qualquer versão, inclusive o baseline. APIs: `POST /api/formula/edit` (só simula), `/api/formula/confirm`, `/api/formula/rollback`.
- **Justificativa normativa**: registro em `data/normrefs/*.json` (norma, item, tabela, condições, trecho, `verbatim`, `verificado_em`, `verificado_por`). Regra de honestidade: o app **não inventa citação** — sem trecho verificado mostra paráfrase sinalizada ou apenas item/tabela; referência sem carimbo aparece como "não verificada"; nada é associado automaticamente. O registro embarcado só traz a Tabela 33 da NBR 5410 (identificador que o próprio app já usava), sem trecho e sem verificação. O revisor cadastra referências e as associa fórmula a fórmula (fase B da proposta); fórmulas sem associação aparecem como *sem justificativa atribuída* e não impedem o uso.
- **Conferência com r42 → aba "Fórmulas fora do baseline"**: edições ativas, autores, justificativas, diff acumulado contra o baseline e histórico completo.
- **Relatório/PDF**: o anexo *Base de cálculo* lista o catálogo usado (baseline, templates, fórmulas, quantas têm justificativa), as versões divergentes do baseline com autor e justificativa e as referências normativas atribuídas (verificadas ou não).
- **Correção — imagens dos métodos de instalação não apareciam no formulário do circuito**: ao montar as opções de "Montagem da instalação", o backend reaproveitava o nome `key` e o grupo *Método de instalação* chegava ao navegador com a chave `"6"` em vez de `"metodo"`; o JavaScript só monta a galeria de fotos quando a chave é `metodo`. Corrigido em `core/project.py`, com teste de regressão (`tests/test_catalog.py`).

Diferenças em relação ao texto da proposta, por escolha de implementação: (1) o registro normativo e o catálogo são JSON, não YAML, para manter o app sem dependências externas; (2) o histórico de versões fica em `meta` do próprio projeto (portanto vai no `.eletro` exportado e acompanha cada projeto) em vez de uma tabela SQLite separada; (3) as cinco colunas que a camada de instalação (`core/installation.py`) substitui por funções Python aparecem no catálogo com a expressão r42 original, mas **não são editáveis** como fórmula de planilha.

## Novidades desta versão (r43)

- **Tipo de condutor e seção restritos pela NBR 5410 real:** o Tipo de condutor só mostra as opções que a Tabela 33 (e correlatas) da NBR 5410 realmente permite para o Método de instalação já escolhido, e a seção do condutor é restrita da mesma forma por Método+Tipo. Uma combinação salva que deixa de ser válida após trocar o Método gera aviso, nunca apagamento silencioso.
- **"Ajuste requerido para este método" por clique:** o antigo campo de texto livre (ex.: "Trifólio") virou uma galeria de blocos clicáveis com as opções reais do método em uso.
- **"Seção escolhida" com múltiplos critérios à vista:** o campo mostra, lado a lado, a seção por ampacidade, por queda de tensão, pela seção mínima normativa e pela térmica de curto-circuito, adota a maior entre elas como referência, e avisa em vermelho quando a seção escolhida pelo projetista fica abaixo do mínimo calculado — sem jamais substituir a escolha do projetista.
- **Partida de motores:** partida direta, estrela-triângulo, soft-starter, reator série e inversor de frequência, cada um com seu parâmetro próprio. A tela compara a queda de tensão na rede e no motor entre a partida direta (pior caso) e o método escolhido.
- **Proteção por catálogo real, em três classes:** antes de escolher família e modelo do disjuntor, a tela pede a classe — Disjuntor fixo, Disjuntor ajustável ou Fusível — e filtra família/modelo pelas combinações que realmente existem no catálogo `Biblioteca_Proteções_WEG` (567 linhas, 33 famílias). Um disjuntor ajustável mostra, junto do modelo, a faixa e o passo real de ajuste de Ir e de Ii/Im extraídos do catálogo, para orientar a escolha — e os campos "Ir adotado"/"Ii/Im adotado" passam a ser uma lista desses passos reais (em vez de número livre) quando o modelo é ajustável.
- **Navegação reordenada:** a barra lateral segue agora a sequência do próprio fluxo de dimensionamento — Visão geral → Entrada e fontes → Quadros e circuitos → Diagrama unifilar → Proteções → DPS → Verificações — com Dados e fórmulas / Conferência com r42 / Como usar reunidos à parte, como referência.
- **Listas com opção manual:** todo campo de seleção populado por uma lista (nativa da planilha ou reforçada pelo aplicativo) agora tem sempre a opção **"Outro (digitar manualmente)…"**, que revela um campo de texto. Nada da lista original é escondido; a opção manual só existe para quando o valor desejado não estiver nela.
- **Pista quando a lista depende de outra escolha:** alguns campos (ex.: modelo do disjuntor) têm lista em cascata na planilha original — só existem depois de outra escolha estar feita (ex.: a família do disjuntor). Quando isso acontece, o aplicativo explica o motivo em vez de mostrar um campo vazio sem contexto.
- **Ilustrações do método de instalação:** o formulário do circuito mostra a imagem da Tabela 33 (NBR 5410) correspondente ao método atualmente calculado, com um catálogo navegável de todos os métodos ilustrados disponíveis na planilha de origem.
- **Esquema TN-S/TN-C:** um esquemático simplificado (não normativo, apenas ilustrativo) aparece junto da escolha do esquema de aterramento do circuito.
- **Sugestões locais de proteção, seletividade e DPS:** em Proteções e DPS, um botão "Ver sugestões" abre uma análise heurística **100% local e offline** (sem internet, sem IA generativa, sem chave de API) que: (1) lista os modelos de disjuntor da família escolhida compatíveis com Ib ≤ Ir ≤ Iz, ordenados do menor para o maior, sempre pedindo conferência manual do Icu; (2) faz uma pré-verificação conservadora de seletividade com o circuito a montante, usando somente o vocabulário já previsto no escopo do projeto ("Pré-verificação atendida", "Seletividade provável", "Critério instantâneo atendido", "Verificar curva/tabela do fabricante" — nunca "seletividade total"); (3) lista candidatos de DPS do catálogo compatíveis com o esquema de aterramento do circuito. **É estritamente consultivo:** só preenche o campo escolhido para revisão; nunca decide nem salva sozinho.
- **Método de instalação por clique na foto, restrito em cascata:** em Quadros e circuitos, o método de instalação agora é escolhido clicando diretamente na foto correspondente — o número mostrado sempre corresponde exatamente à foto clicada. A galeria mostra somente os métodos compatíveis com a "Instalação" já escolhida para aquele circuito, usando a própria tabela de referência da planilha (`Metodos_Inst_Ajuda`), nunca uma lista arbitrária. A sequência **Instalação → Métodos → Condutores** é explícita na tela: pular uma etapa mostra um aviso claro em vez de uma lista vazia ou incorreta, e limpar uma escolha anterior nunca apaga silenciosamente uma escolha posterior já feita.
- **Hierarquia em Entrada e fontes:** a tela organiza os dados da fonte em blocos (rede MT com dados, transformador sem dados de rede, rede BT direta, gerador), e o **Tipo de atendimento** escolhido decide quais blocos participam do cálculo — os demais ficam recolhidos e marcados "não se aplica", mas os dados continuam guardados, nunca apagados. Selecionar, por exemplo, "Gerador BT" deixa visíveis apenas os campos realmente usados pelo cálculo do gerador, mais o bloco geral (aterramento e choque).


## Novidades da v1.5
- **Diagrama unifilar** com simbologia gráfica (IEC 60617; ABNT NBR 12520/12523), modos Vertical, Horizontal e Cartões, seleção das informações exibidas (atalhos Mínimo/Padrão/Completo), foco em um quadro, zoom e exportação SVG.
- **Quadro de cargas** (aba do Diagrama): P, Q, S por fase e total, fp e fator de simultaneidade, em carga própria ou total.
- **Visão geral**: Resumo dos circuitos com esquema de ligação, In_Ir, condutores agrupados, ΔV total, Icc (6 valores), corrente nominal/máxima e Iz.
- **Quadros e circuitos**: formulário em abas (Informações gerais, Cargas e correntes, Instalação, Condutores, Curto-circuito, Proteções, DPS).
- Atenção: as normas ABNT não puderam ser consultadas diretamente; confira a simbologia na edição vigente antes de emitir o projeto.

## Correções da v1.5.1
- Painel **Agrupamento e condições de instalação** (disposição, distância, profundidade, camadas) na aba Instalação; os dados agora são salvos.
- Valores salvos fora da lista permanecem visíveis como "incompatível" (nada é limpo ao abrir o formulário); listas atualizam ao editar condutores e ambiente.
- Pendências mostram o motivo real da instalação em vez de "Combinação isolação/método inválida".
- Unifilar/resumo: em TN-C o PEN usa o maior valor entre neutro e PE, como o motor de cálculo.
- Conexões SQLite são fechadas após cada operação (corrige travamento de arquivo no Windows).

## v1.5.2 — alumínio por ocupação (NBR 5410:2004, 6.2.3.8)
- Entrada e fontes › Informações gerais: **tipo de ocupação**, **densidade de ocupação (BD1–BD4)** e **pessoas qualificadas (BA5)**; também exibidos na aba Informações gerais do circuito.
- Residencial, público/outros e locais BD4: o alumínio deixa de ser oferecido como material e é bloqueado ao salvar.
- Comercial: exige BD1, pessoas qualificadas e seção da fase de pelo menos 50 mm². Industrial: exige alimentação por transformador/subestação ou fonte própria (não Rede BT direta), pessoas qualificadas e seção de pelo menos 16 mm².
- Sem tipo de ocupação informado, o alumínio fica pendente até o preenchimento.
- Ao atualizar, não sobrescreva a pasta `projetos/` (guarda seus projetos). Este pacote não a contém.

## v1.6

**Condutores por polo (Nc) corrigido.** A planilha r42 aplicava o Nc na ampacidade e nas impedâncias, mas não na seção por queda de tensão, no critério de curto-circuito (Icc e seção térmica do neutro), na Iz do grupo de condutores nem na Iz usada em Temp_Operacional. O módulo `core/nc_patch.py` reescreve essas fórmulas ao carregar o modelo (idempotente). Com Nc = 1 os resultados são idênticos aos da r42 (verificado em todos os circuitos de exemplo). Com Nc ≥ 2: Iz do grupo = Iz × Nc × fator de paralelismo (quando os condutores estão no mesmo conduto); seção por queda e Icc calculadas por condutor (corrente ÷ Nc). Premissa: divisão igual de corrente (NBR 5410, 6.2.5.7.1 a / 6.2.5.7.2).
Alertas da norma na aba Condutores quando Nc ≥ 2: 6.2.5.7.1 e 6.2.5.7.2 (a/b/c, conforme cabo multipolar, unipolar até 50 mm² Cu / 70 mm² Al ou unipolar maior), 6.2.10.4 (grupos com um condutor de cada fase) e 5.3.5.4 (proteção contra curto-circuito de condutores em paralelo).
Observação: com Nc ≥ 2, alguns circuitos ainda podem ficar PENDENTE quando não existe In comercial entre Ib e Iz da seção mínima (mesmo comportamento da r42 com Nc = 1, ex.: QM-01).

**Aba Proteções reorganizada.** Seleção em cascata Classe (fixo, ajustável termomagnético, ajustável eletrônico, fusível) > Família > Modelo; os modelos de uma classe não aparecem em outra. Parâmetros mostrados conforme o tipo (fixo e fusível sem ajustes; termomagnético só Ir e Im; eletrônico com Ir, Ii, Isd, tsd e I²t). Listas de ajuste vêm do catálogo (passos do dial), sem "Outro (digitar)"; ajuste contínuo mostra a faixa. In nominal e Ii fixo preenchidos e travados pelo catálogo. Campos em três blocos: hardware, parametrização e resultados.

**Visão geral.** A origem (rede MT/transformador, rede BT ou gerador) é clicável no unifilar: abre painel lateral de edição; ao passar o mouse aparecem engrenagem (editar) e troca (mudar o tipo de atendimento). Selo de status (pendente/revisar) na origem, com as pendências no hover. Texto: "Clique em qualquer elemento para editar".

Testes novos: `tests/test_nc.py`, `tests/test_protecao.py`, `tests/test_origem.py`.

### Dados de exemplo completados (v1.6)
O exemplo agora traz instalação compatível com a Tabela 33 e agrupamento definido, então os 6 circuitos calculam (antes ficavam "#N/A" por combinação método/cabo incompatível). Só entradas foram alteradas (8 células + disposição de agrupamento); nenhuma fórmula. Os valores originais da r42 em `data` não eram reproduzíveis com a validação estrita; o arquivo original está em `referencia/r42_dados_originais.json.gz`. Os valores esperados em `tests/test_app.py` foram atualizados para o exemplo completado. Circuitos novos (botão Novo circuito) agora também já saem com instalação compatível e agrupamento definido. Suíte: 60 testes, todos passando.

## v1.6.1

**Troca de modelo de proteção.** Ao escolher outro modelo, os ajustes do modelo anterior (Ir, Ii/Im, Isd, tsd, I²t) são substituídos por valores válidos do novo: In e Ir do catálogo (Ir = menor passo ≥ Ib, dentro de Iz quando possível), Ii/Isd pelos passos do catálogo, tsd 100 ms e I²t OFF em eletrônico, "N/A" em fixo/termomagnético. O que você editar na mesma gravação prevalece. (Antes ficavam ajustes de um modelo eletrônico num fixo, gerando "Ir fora da faixa" e "não respeita o passo".)

**Icu/Ics do catálogo WEG.** `core/catalog_icu.py` preenche Icu/Ics aplicáveis e a tensão do registro (colunas AA/AB/AC da Biblioteca_Proteções_WEG) a partir do texto do catálogo: valor declarado a 220 V; sem 220 V, o de 380 V (limite conservador, pois o Icu cai com a tensão), com a tensão do registro indicada. Ics: valor explícito ou % do Icu. Menor valor quando há versões/classes distintas; linhas com aviso de exceção/estimativa ficam vazias. Linhas já verificadas não são alteradas. É extração automática: **confira no datasheet antes de usar em projeto**. Sem Ics declarado continua "ICS NÃO DECLARADO".

**DPS: fabricante, backup e declaração do fabricante** (`core/dps_patch.py`). Novas entradas na aba DPS: fabricante do DPS (SIEMENS padrão, ou CLAMPER), tipo de backup (fusível do catálogo ou disjuntor por equivalência), Icu do backup (opcional), declaração do fabricante recebida (SIM/NÃO) e documento.
- Catálogo Siemens 5SD7: backup gL/gG máximo por modelo (315/125/25 A), Isccr do conjunto DPS+backup (Tipo 1: 50 kA; Tipo 1+2 e Tipo 2: 25 kA; manual de configuração Siemens). O manual Siemens e o da Clamper só indicam fusível ("preferir fusível a disjuntor"); nenhum lista disjuntor como backup.
- Backup por **fusível** (padrão): nova biblioteca `Biblioteca_Fusiveis_NH` (NH gG de 6 a 630 A). Poder de corte 120 kA a 500 V AC, conferido nas fichas Siemens SENTRON 3NA3 (250 A e 400 A: gG, 500 V AC, 120 kA) e Hager NH000 32 A; as demais correntes seguem o nominal da série NH gG (IEC 60269-2) e devem ser confirmadas na ficha do fusível comprado. O app adota o menor In ≥ In dimensionado (≤ máximo do fabricante) com Icu ≥ Ik; o campo "Fusível de backup" permite escolher outro. "Icu do backup" (opcional) substitui o valor do catálogo. As fichas Siemens bloquearam o acesso direto (403) na pesquisa, então os valores vieram de espelhos (TME, Hager).
- Backup por disjuntor: ver abaixo (catálogo WEG), com equivalência pendente de declaração do fabricante.
- Status: Ik acima do Isccr do conjunto ou Icu do backup < Ik → ✗; pendências de Icu informado, coordenação entre estágios e equivalência listadas; declaração do fabricante = SIM → "✓ CONFIRMADO POR DECLARAÇÃO DO FABRICANTE".
- Backup por **disjuntor**: ao escolher "DISJUNTOR (equivalência)" o app sugere um modelo do catálogo WEG (campo "Modelo do disjuntor de backup"): mesmos polos do DPS, In entre o In dimensionado e o máximo do fabricante, Icu aplicável ≥ Ik no ponto, preferindo curva C. In e Icu passam a vir do catálogo (não mais o Icu genérico). A lista mostra In, curva e Icu de cada candidato; modelo fora do catálogo é recusado.
- "Declaração escrita do fabricante recebida?": em branco = NÃO (os menus do app mostram "Não informado" para campo vazio). SIM = o fabricante confirmou por escrito coordenação entre estágios, Icu do backup e, no caso de disjuntor, a equivalência com o fusível.
- O campo "Dispositivo de desacoplamento instalado?" só é relevante com DPS a montante.

Testes novos: `tests/test_v161.py`.


"""v2.1.1: casos da análise independente e preservação de dados em operações reais.

Todos os dados de coordenação são sintéticos; não especificam equipamentos.
"""
import copy
import gzip
import json
import secrets
import sys
import tempfile
import threading
import unittest
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import Handler, Store, example_data
from core.project import Project, unpack
from core.catalog import Catalog
from core.motor import Model, model
from core import curvas, historico, integridade, migracao


def load():
    return Project(copy.deepcopy(example_data()))


def legacy():
    return json.loads(gzip.decompress((ROOT / 'tests/fixtures/projeto_v1.json.gz').read_bytes()))


def pair(p, name='QDFL-01'):
    return next(x for x in curvas.coordination(p)['pares'] if x['circuito'] == name and x.get('aplicavel'))


ADJUST = {'ir_a': 320, 'isd_a': 1600, 'tsd_ms': 100, 'ii_a': 4400, 'i2t': 'OFF'}
HEAD = 'montante;jusante;limite_ka;tensao_v;ir_montante_a;isd_montante_a;tsd_montante_ms;ii_montante_a;i2t_montante'


def table(p, tail='OFF', ii=4400, extra_header='', extra_row='', down='AGW100N-DX100-3', limit='20'):
    return curvas.import_data(p, {'tipo': 'tabela_seletividade', 'fabricante': 'Ensaio', 'documento': 'Tabela sintética',
        'conteudo': HEAD + extra_header + '\n' + f'ACW400H-ETS400-3;{down};{limit};220;320;1600;100;{ii};{tail}' + extra_row}, 'Rev')


def curve(p, name, data, adj=None):
    return curvas.import_data(p, {'tipo': 'curva', 'fabricante': 'Ensaio', 'documento': 'Curva sintética',
        'modelo': name, 'conteudo': 'corrente_a;t_min_s;t_max_s\n' + data, 'ajustes': adj or {}}, 'Rev')


class CoordinationRegression(unittest.TestCase):
    def test_disjoint_envelopes_cannot_verify_selectivity(self):
        p = load()
        curve(p, 'ACW400H-ETS400-3', '10000;1;2\n20000;0.1;0.2', ADJUST)
        curve(p, 'MDW-C80-2', '100;0.02;0.04\n9000;0.01;0.02')
        x = pair(p)
        self.assertNotEqual(x['nivel'], 'verificado')
        self.assertTrue(any('primeiro ponto' in s for s in x['detalhes']))

    def test_missing_lower_domain_is_not_documented_non_operation(self):
        p = load()
        curve(p, 'ACW400H-ETS400-3', '500;20;30\n10000;1;2', ADJUST)
        curve(p, 'MDW-C80-2', '100;0.5;1\n10000;0.01;0.02')
        self.assertNotEqual(pair(p)['nivel'], 'verificado')

    def test_upstream_start_below_downstream_does_not_prove_overlap(self):
        p = load()
        curve(p, 'ACW400H-ETS400-3', '50;200;300\n10000;1;2', ADJUST)
        curve(p, 'MDW-C80-2', '100;0.5;1\n10000;0.01;0.02')
        x = pair(p)
        self.assertEqual((x['nivel'], x['situacao']), ('verificado', 'seletiva'))

    def test_i2t_mismatch_is_kept_sealed_and_rejected(self):
        p = load();table(p, tail='ON')
        item = p.meta['curvas'][0]
        self.assertEqual(item['linhas'][0]['condicoes']['montante']['i2t'], 'ON')
        self.assertTrue(curvas._sealed(item))
        x = pair(p, 'QDFL-02')
        self.assertNotEqual(x['nivel'], 'verificado')
        self.assertTrue(any('I²t' in s and 'ON' in s and 'OFF' in s for s in x['detalhes']))
        q = load();v = q.model.by_id['protecao.i2t_on_off'];q.put(v.sheet, v.col + '4', 'ON')
        table(q, tail='OFF')
        self.assertNotEqual(pair(q, 'QDFL-02')['nivel'], 'verificado')

    def test_i2t_absent_and_old_imports_do_not_claim_verification(self):
        p = load();table(p, tail='')
        self.assertNotEqual(pair(p, 'QDFL-02')['nivel'], 'verificado')
        self.assertTrue(any('não informa a condição de I²t' in s for s in pair(p, 'QDFL-02')['detalhes']))

    def test_headers_reject_duplicate_unknown_and_invalid_i2t(self):
        for header, row in [(';it_montante', ';ON'), (';i2t_montante', ';OFF'), (';i2t_jusante', ';INVALIDO')]:
            p = load()
            with self.assertRaises(ValueError):
                table(p, extra_header=header, extra_row=row)
            self.assertEqual(p.meta.get('curvas', []), [])
        # Unicode ² normalizes to 2, instead of deleting the condition.
        self.assertEqual(curvas._rows('i²t_montante;x\nON;a')[0][0], 'i2t_montante')

    def test_downstream_i2t_is_preserved(self):
        p = load();table(p, extra_header=';i2t_jusante', extra_row=';ON')
        self.assertEqual(p.meta['curvas'][0]['linhas'][0]['condicoes']['jusante']['i2t'], 'ON')
        self.assertNotEqual(pair(p, 'QDFL-02')['nivel'], 'verificado')

    def test_i2t_matching_and_effective_instantaneous_setting(self):
        p = load();table(p)
        self.assertEqual(pair(p, 'QDFL-02')['nivel'], 'verificado')
        d = curvas._device(p, 4, 'origem')
        self.assertEqual((d['ii_informado'], d['ii_inst'], d['ii']), (1600, 4400, 4400))
        q = load();table(q, ii=1600)
        self.assertNotEqual(pair(q, 'QDFL-02')['nivel'], 'verificado')

    def test_total_selectivity_does_not_override_conflicting_icu(self):
        p = load();table(p, extra_header=';icu_jusante_ka', extra_row=';25', down='MDW-C80-2', limit='T')
        self.assertNotEqual(pair(p)['nivel'], 'verificado')
        self.assertTrue(any('Icu' in s and '25' in s and '5' in s for s in pair(p)['detalhes']))
        q = load();table(q, extra_header=';icu_jusante_ka', extra_row=';5', down='MDW-C80-2', limit='T')
        self.assertEqual((pair(q)['nivel'], pair(q)['situacao'], pair(q)['limite_ka']), ('verificado', 'parcial', 5))


class MigrationRegression(unittest.TestCase):
    def test_fixed_source_value_is_preserved_and_flagged(self):
        d = legacy();d['sheets']['Padrão de entrada']['cells']['B138'] = {'value': 123.456, 'formula': False}
        p = Project(d)
        self.assertEqual(p.get('Padrão de entrada', 'B138'), 123.456)
        self.assertEqual(integridade.formula_status(p, 'fonte.x1_sistema'), 'alterada')
        self.assertEqual(Project(unpack(p.packed())).get('Padrão de entrada', 'B138'), 123.456)

    def test_unconvertible_source_formula_is_reviewable(self):
        d = legacy();formula = "='Corrente nominal'!P40*2"
        d['sheets']['Padrão de entrada']['cells']['B138'] = {'value': formula, 'formula': True}
        p = Project(d);pending = p.meta['migracao']['nao_convertidas']
        self.assertEqual([(x['variavel'], x['formula_original']) for x in pending], [('fonte.x1_sistema', formula)])
        migracao.acknowledge(p, 'fonte.x1_sistema', '', 'Rev', 'Conferida a fórmula antiga da fonte.')
        self.assertEqual(integridade.report(p)['contagem']['conversao_pendente'], 0)

    def test_registered_source_formula_preserves_author_and_history(self):
        d = legacy();d['sheets']['Padrão de entrada']['cells']['B138'] = {'value': '=123.456', 'formula': True}
        d['meta']['formula_versions'] = {'padrao-de-entrada-B-L138': {'ativa': 1, 'versoes': [
            {'versao': 1, 'template': '=123.456', 'autor': 'Ana', 'ts': '2026-01-01', 'justificativa': 'Edição registrada na fonte.'}]}}
        p = Project(d);slot = p.doc['formulas']['fonte.x1_sistema']
        self.assertEqual(slot['versoes'][0]['autor'], 'Ana')
        self.assertEqual(integridade.formula_status(p, 'fonte.x1_sistema'), 'editada')

    def test_restored_legacy_history_is_not_dropped(self):
        d = legacy();original = d['sheets']['Corrente nominal']['cells']['P4']['value']
        history = {'corrente-nominal-P': {'ativa': 0, 'versoes': [
            {'versao': 1, 'template': original[:-1] + '*1.2)', 'autor': 'Ana', 'ts': '2026-01-01', 'justificativa': 'Ensaio anterior.'}]}}
        d['meta']['formula_versions'] = copy.deepcopy(history)
        p = Project(d);slot = p.doc['formulas']['corrente.i_r_a']
        self.assertEqual(slot['ativa'], 0)
        self.assertEqual(slot['versoes'][0]['autor'], 'Ana')
        self.assertEqual(p.meta['historico_legado'], history)
        self.assertEqual(p.get('Corrente nominal', 'P5'), load().get('Corrente nominal', 'P5'))
        self.assertEqual(integridade.report(p)['problemas'], 0)

    def test_unconvertible_inactive_history_keeps_the_original(self):
        d = legacy();history = {'corrente-nominal-P': {'ativa': 0, 'versoes': [
            {'versao': 1, 'template': "='Corrente nominal'!P40", 'autor': 'Ana', 'justificativa': 'Histórico sem equivalente.'}]}}
        d['meta']['formula_versions'] = copy.deepcopy(history)
        p = Project(d)
        self.assertEqual(p.meta['historico_legado'], history)
        self.assertEqual(len(p.meta['migracao']['nao_convertidas']), 1)

    def test_v20_common_edit_keeps_its_effect_on_root_once(self):
        d = copy.deepcopy(example_data());vid = 'imp.reatancia_fase_a_montante'
        entry = integridade.stamp('formula', vid, {'versao': 1, 'expressao': '=0', 'tipo': 'edicao', 'autor': 'Rev', 'justificativa': 'Edição nativa da v2.0.'})
        d['formulas'] = {vid: {'ativa': 1, 'versoes': [entry]}}
        p = Project(d);v = p.model.by_id[vid]
        self.assertEqual(p.get(v.sheet, v.col + '2'), 0)
        self.assertEqual(integridade.formula_status(p, vid, 'raiz'), 'editada')
        self.assertEqual(len(p.meta['migracoes_escopos']), 1)
        q = Project(unpack(p.packed()))
        self.assertEqual(q.doc, p.doc)
        self.assertEqual(q.get(v.sheet, v.col + '2'), 0)

    def test_v21_semantics_are_preserved_when_recorded(self):
        d = copy.deepcopy(example_data());vid = 'imp.reatancia_fase_a_montante'
        d['base'] = {'app': '2.1.0'}
        d['formulas'] = {vid: {'ativa': 1, 'versoes': [{'versao': 1, 'expressao': '=0', 'tipo': 'externa'}]}}
        p = Project(d);v = p.model.by_id[vid]
        self.assertGreater(p.get(v.sheet, v.col + '2'), 0)
        self.assertNotIn('raiz', p.doc['formulas'][vid])

    def test_native_migration_does_not_reseal_external_edits(self):
        d = copy.deepcopy(example_data());vid = 'imp.reatancia_fase_a_montante'
        d['formulas'] = {vid: {'ativa': 1, 'versoes': [{'versao': 1, 'expressao': '=0', 'tipo': 'externa'}]}}
        p = Project(d)
        self.assertEqual(integridade.formula_status(p, vid, 'raiz'), 'alterada')


class ScopedOperationsRegression(unittest.TestCase):
    def edited(self):
        p = load();uid = p.meta['ids']['5'];vid = 'corrente.i_r_a';before = copy.deepcopy(p.doc)
        Catalog(p).commit_edit(p, vid, '=123.456', 'Rev', 'Valor de ensaio no próprio circuito.', escopo='circuito:' + uid)
        return p, uid, vid, before

    def test_history_reports_actual_expression_and_circuit(self):
        p, uid, vid, before = self.edited();diff = historico.compare_data(before, p.doc)
        self.assertEqual(diff['n_formulas'], 1)
        x = diff['formulas'][0]
        self.assertEqual((x['circuito'], x['escopo'], x['depois']), ('QDFL-01', 'circuito:' + uid, '=123.456'))
        self.assertNotEqual(x['antes'], x['depois'])

    def test_root_history_uses_root_baseline(self):
        p = load();vid = 'imp.reatancia_fase_a_montante';before = copy.deepcopy(p.doc)
        Catalog(p).commit_edit(p, vid, '=0', 'Rev', 'Ensaio da variante da fonte.', escopo='raiz')
        rows = historico.compare_data(before, p.doc)['formulas']
        self.assertEqual(len(rows), 1)
        self.assertEqual((rows[0]['escopo'], rows[0]['antes'], rows[0]['depois']), ('raiz', p.model.by_id[vid].variants['raiz'], '=0'))

    def test_catalog_filter_includes_local_edits(self):
        p, uid, vid, _ = self.edited();cat = Catalog(p)
        entry = cat.entry_view(cat.get(vid))
        self.assertEqual((entry['status'], entry['integridade']), ('editada', 'editada'))
        self.assertIn(vid, [x['id'] for x in cat.list(status='editada')['entradas']])
        detail = cat.trace(uid, vid)
        self.assertEqual(detail['editada'], 123.456)

    def test_duplicate_keeps_formula_and_independent_history(self):
        p, uid, vid, _ = self.edited()
        new = p.add('Cópia QDFL-01', 'QGBT-01', duplicate=uid)
        self.assertEqual(p.get('Corrente nominal', 'P' + str(p.row_for(new))), 123.456)
        self.assertEqual(integridade.formula_status(p, vid, 'circuito:' + new), 'editada')
        Catalog(p).rollback(p, vid, 0, 'Rev', escopo='circuito:' + new)
        self.assertEqual(p.get('Corrente nominal', 'P' + str(p.row_for(uid))), 123.456)
        self.assertAlmostEqual(p.get('Corrente nominal', 'P' + str(p.row_for(new))), 69.128)

    def test_duplicate_keeps_tampering_visible(self):
        p, uid, vid, _ = self.edited()
        p.doc['formulas'][vid]['circuitos'][uid]['versoes'][0]['expressao'] = '=321'
        p.engine.clear()
        new = p.add('Cópia externa', 'QGBT-01', duplicate=uid)
        self.assertEqual(integridade.formula_status(p, vid, 'circuito:' + new), 'alterada')


class ArchivedRulesRegression(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.tmp.name) / 'p.sqlite3', backup=False)
        self.original_rules = copy.deepcopy(model().rules)
        self.original_code = model().code_hash

    def tearDown(self):
        model().rules = self.original_rules
        model().code_hash = self.original_code
        self.tmp.cleanup()

    def change_rule(self):
        p = self.store.project;values = p.installation.values(4)
        line = p.installation.line(values['line'])
        item = next(x for x in line['variants'] if str(x['method']) == str(values['method']) and x['cable'] == values['cable'])
        item['reference'] = 'A1'
        self.store.project = Project(copy.deepcopy(p.doc))

    def test_snapshot_replays_its_own_operational_rules(self):
        self.assertEqual(self.store.project.installation.method_ref(4), 'B2')
        self.change_rule();s = self.store;old = s.base_model(s.project.doc['base']['hash'])
        previous = Project(copy.deepcopy(s.project.doc), base_model=old)
        self.assertEqual(previous.installation.method_ref(4), 'B2')
        self.assertEqual(s.project.installation.method_ref(4), 'A1')
        status = s.base_status()
        self.assertTrue(status['comparacao_completa'])
        self.assertTrue(any(f['campo'] == 'Método de referência' and f['antes'] == 'B2' and f['depois'] == 'A1'
                            for c in status['resultados'] for f in c['campos']))

    def test_rule_edit_in_model_copy_does_not_mutate_source(self):
        snapshot = model().serialize();before = copy.deepcopy(snapshot)
        other = Model(snapshot);other.rules['installation_rules.json']['lines'][0]['name'] = 'Ensaio'
        self.assertEqual(snapshot, before)

    def test_missing_rules_are_not_compared_with_current_rules(self):
        s = self.store;key = s.project.doc['base']['hash'];snap = s.project.model.serialize();snap.pop('regras')
        with s.db() as db:
            db.execute('UPDATE bases SET data=? WHERE hash=?', (gzip.compress(json.dumps(snap).encode()), key))
        self.change_rule();status = s.base_status()
        self.assertFalse(status['comparacao_completa'])
        self.assertIsNone(status['resultados'])
        self.assertIn('não contém as regras', status['aviso_comparacao'])

    def test_code_change_does_not_claim_historical_reproduction(self):
        model().code_hash = 'outro-codigo'
        status = self.store.base_status()
        self.assertFalse(status['comparacao_completa'])
        self.assertTrue(status['codigo_diferente'])
        self.assertIsNone(status['resultados'])
        self.store.adopt_base('Rev')
        entry = self.store.project.meta['atualizacoes_base'][-1]
        self.assertIsNone(entry['circuitos_com_resultados_diferentes'])
        self.assertFalse(entry['comparacao_completa'])

    def test_history_uses_the_calculation_base_of_each_revision(self):
        s = self.store;before = s.revision;self.change_rule()
        s.save(prev_data=s.reconstruct(before), summary='Ensaio de atualização de regra')
        cmp = s.compare(before, s.revision)
        self.assertTrue(cmp['comparacao_completa'])
        self.assertTrue(any(f['campo'] == 'Método de referência' for c in cmp['resultados'] for f in c['campos']))


class HttpRegression(unittest.TestCase):
    def test_base_and_history_contract_with_missing_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp:
            server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
            server.store = Store(Path(tmp) / 'p.sqlite3', backup=False)
            server.token = secrets.token_urlsafe(24);server.lock = threading.RLock();server.daemon_threads = True
            base = f'http://127.0.0.1:{server.server_port}'
            thread = threading.Thread(target=server.serve_forever, daemon=True);thread.start()
            try:
                s = server.store;rec = s.project.doc['base'];rec['hash'] = 'base-ausente'
                client = urllib.request.build_opener(urllib.request.ProxyHandler({}))
                with client.open(base + '/api/base') as response:
                    data = json.load(response)
                self.assertFalse(data['comparacao_completa'])
                self.assertIsNone(data['resultados'])
                self.assertIn('não está guardada', data['aviso_comparacao'])
                s.project.meta['base_calculada'] = copy.deepcopy(rec)
                with s.db() as db:
                    db.execute('UPDATE revisions SET data=? WHERE project_id=? AND revision=?', (s.project.packed(), s.active_id, s.revision))
                with client.open(base + f'/api/history/compare?a={s.revision}&b={s.revision}') as response:
                    cmp = json.load(response)
                self.assertFalse(cmp['comparacao_completa'])
                self.assertIsNone(cmp['resultados'])
            finally:
                server.shutdown();server.server_close();thread.join()


if __name__ == '__main__':
    unittest.main()

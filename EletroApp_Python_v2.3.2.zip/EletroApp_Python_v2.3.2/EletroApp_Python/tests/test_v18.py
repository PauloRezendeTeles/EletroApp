"""Regressões das relações de instalação e da norma prevalente."""
import copy
import gzip
import json
import unittest
from pathlib import Path
from core.project import Project, unpack
from core.installation import FIELDS, RULES, catalogs, consultation, normalized
from core.catalog import Catalog

BASE=json.loads((Path(__file__).resolve().parents[1]/'data'/'exemplos'/'exemplo.json').read_text(encoding='utf-8'))

class InstallationRelations(unittest.TestCase):
    def setUp(self):
        self.p=Project(copy.deepcopy(BASE));self.row=4;self.uid=self.p.meta['ids']['4']
    def put(self,**values):
        for key,value in values.items():
            sh,col=FIELDS[key];self.p.put(sh,col+'4',value)
        self.p.engine.clear()
    def config(self,**values):
        state=self.p.installation.state(4)
        settings=self.p.meta.setdefault('installation_settings',{}).setdefault(self.uid,{})
        settings.update(geometry_signature=state['geometry']['signature'],**values)
        self.p.engine.clear()
        return self.p.installation.state(4)
    def prepare(self,line,method,cable):
        self.put(line=line,method=method,cable=cable,material='Cobre',insulation='PVC',
                 voltage='450/750V' if cable=='Condutor isolado' else '0,6/1kV',circuits=1,parallel=1,separate='Sim')
        s=self.p.installation.state(4)
        self.put(adjustment=s['options']['adjustment'][0])
        s=self.p.installation.state(4)
        self.put(arrangement=s['options']['arrangement'][0])
        return self.config(geometry_mode='confirmed')

    def test_all_94_variants_match_table_and_keep_alternatives(self):
        for line in RULES['lines']:
            for v in line['variants']:
                with self.subTest(line=line['name'],method=v['method'],cable=v['cable']):
                    s=self.prepare(line['name'],v['method'],v['cable'])
                    expected={x['cable'] for x in line['variants'] if x['method']==v['method']}
                    self.assertEqual(set(s['options']['cable']),expected)
                    self.assertEqual(s['reference'],v['reference'])
                    self.assertTrue(s['valid'],s['issues'])
                    self.assertIsInstance(self.p.get('Cálc_Seç-Ampacidade','N4'),str)

    def test_all_lines_resolve_after_ui_trim_and_unknown_is_absent(self):
        _,mapping=catalogs()
        self.assertEqual(len(consultation()['lines']),32)
        for line in RULES['lines']:
            for value in [line['name']]+line.get('aliases',[]):
                self.assertIn(normalized(value.strip()),mapping)
                self.assertEqual(self.p.installation.line(value.strip())['name'],line['name'])
        self.assertNotIn(normalized('instalação inexistente'),mapping)

    def test_numeric_ranges_follow_nbr_with_no_500_limit(self):
        self.prepare('Eletroduto em espaço de construção (1,5De <=  V < 20De)','22_1,5-20De','Condutor isolado')
        for ratio in (1.5,5,10,19.999):
            self.assertTrue(self.config(geometry_mode='dimensions',space_ratio=ratio)['valid'])
        self.assertFalse(self.config(geometry_mode='dimensions',space_ratio=20)['valid'])
        # Projeto legado: nome e código antigos continuam reconhecidos.
        self.prepare('Eletroduto em espaço de construção (20De <= V < 500De)','24_20-500De','Condutor isolado')
        for ratio in (20,500,900):self.assertTrue(self.config(geometry_mode='dimensions',space_ratio=ratio)['valid'])
        self.assertFalse(self.config(geometry_mode='dimensions',space_ratio=19.999)['valid'])
        self.assertNotIn('500',self.p.installation.state(4)['values']['line'])

    def test_transition_f_to_c_resets_unused_adjustment(self):
        self.prepare('Bandejas perfuradas (horizontal ou vertical)',13,'Cabo unipolar')
        self.p.update([{'sheet':FIELDS['line'][0],'address':'B4','value':'Bandejas não perfuradas ou prateleiras'},
                       {'sheet':FIELDS['method'][0],'address':'B4','value':12}])
        s=self.p.installation.state(4)
        self.assertTrue(s['valid'],s['issues']);self.assertEqual(s['values']['adjustment'],'N/A')

    def test_spacing_required_and_rechecked_after_cable_change(self):
        self.prepare('Bandejas perfuradas (horizontal ou vertical)',13,'Cabo multipolar')
        s=self.config(geometry_mode='dimensions',diameter=10,surface_gap=3)
        self.assertTrue(s['valid'])
        self.assertFalse(self.config(geometry_mode='dimensions',diameter=10,surface_gap=2.9)['valid'])
        self.put(cable='Cabo unipolar',adjustment='Justapostos')
        self.assertIsNone(self.p.installation.state(4)['geometry']['mode'])
        self.put(arrangement=self.p.installation.state(4)['options']['arrangement'][0])
        self.assertFalse(self.config(geometry_mode='dimensions',diameter=10,surface_gap=3)['valid'])
        self.assertTrue(self.config(geometry_mode='dimensions',diameter=10,surface_gap=10)['valid'])

    def test_g_needs_surface_and_cable_gaps(self):
        self.prepare('Sobre isoladores',18,'Cabo unipolar')
        self.assertFalse(self.config(geometry_mode='dimensions',diameter=12,surface_gap=12,cable_gap=11)['valid'])
        self.assertTrue(self.config(geometry_mode='dimensions',diameter=12,surface_gap=12,cable_gap=12)['valid'])
        self.assertFalse(self.config(geometry_mode='dimensions',diameter=float('nan'))['valid'])

    def test_geometry_confirmation_roundtrip(self):
        self.prepare('Afastado da parede ou suspenso por cabo de suporte',17,'Cabo unipolar')
        restored=Project(unpack(self.p.packed()))
        self.assertTrue(restored.installation.state(4)['valid'])
        self.assertEqual(restored.installation.state(4)['geometry']['mode'],'confirmed')

    def test_insulation_aliases_affect_thermal_chain_consistently(self):
        pairs=[('PVC','LSHF/A','Condutor isolado',7),('EPR','HEPR','Cabo unipolar',7)]
        for canonical,alias,cable,method in pairs:
            self.prepare('Eletroduto embutido em alvenaria',method,cable)
            self.put(insulation=canonical)
            fields=[('Corrente-Calc_Ampacidade ','I4'),('Cálc_Seç-Ampacidade','N4'),('Cálc_Seç-Icc_Cond_Sugerido','C4'),
                    ('Temp_Operacional','F4'),('Cálc_Imp-Cond_Escolhido','BR4')]
            expected=[self.p.get(sh,a) for sh,a in fields]
            self.put(insulation=alias)
            self.assertTrue(self.p.installation.state(4)['valid'])
            self.assertEqual([self.p.get(sh,a) for sh,a in fields],expected)
            restored=Project(unpack(self.p.packed()))
            self.assertEqual(restored.raw('Dados dos condutores ','I4'),alias)
            self.assertEqual([restored.get(sh,a) for sh,a in fields],expected)

    def test_forbidden_types_still_rejected(self):
        self.prepare('Eletroduto embutido em parede isolante',2,'Cabo multipolar')
        self.put(cable='Condutor isolado')
        with self.assertRaises(ValueError):self.p.installation.verify(4)

    def test_legacy_geometry_is_not_silently_confirmed(self):
        s=self.p.installation.state(5)
        self.assertTrue(s['geometry']['required'])
        self.assertIsNone(s['geometry']['mode'])
        self.assertFalse(s['valid'])
        self.assertTrue(any('condições geométricas' in x for x in s['issues']))

    def test_thermal_alias_preserves_formula_review_and_rollback(self):
        self.prepare('Eletroduto embutido em alvenaria',7,'Condutor isolado')
        self.put(insulation='LSHF/A')
        sheet='Corrente-Calc_Ampacidade ';cell='I4'
        cat=Catalog(self.p);entry=cat.entry_view(self.p.var_at(sheet,cell))
        self.assertIsNotNone(entry)
        before=self.p.get(sheet,cell)
        edited='=('+entry['expressao'].lstrip('=')+')&" / ensaio"'
        cat.commit_edit(self.p,entry['id'],edited,'Teste','Conferência do fator térmico e dos aliases.')
        self.assertEqual(self.p.get(sheet,cell),before+' / ensaio')
        self.assertEqual(self.p.var_at(sheet,cell).id,entry['id'])
        Catalog(self.p).rollback(self.p,entry['id'],0,'Teste')
        self.assertEqual(self.p.get(sheet,cell),before)
        self.assertEqual(self.p.raw('Dados dos condutores ','I4'),'LSHF/A')

    def test_catalog_mirrors_match_authoritative_rules(self):
        root=Path(__file__).resolve().parents[1]/'data'
        methods,lines=catalogs()
        self.assertEqual(json.loads((root/'metodos_instalacao.json').read_text(encoding='utf-8')),methods)
        self.assertEqual(json.loads((root/'metodos_por_linha.json').read_text(encoding='utf-8'))['mapa'],lines)

    def test_pending_cable_does_not_erase_compatible_wire_inputs(self):
        self.prepare('Eletroduto embutido em parede isolante',2,'Cabo multipolar')
        self.put(method=1)
        s=self.p.installation.state(4,reconcile=True)
        self.assertIsNone(s['values']['cable'])
        self.assertEqual(s['values']['material'],'Cobre')
        self.assertEqual(s['values']['insulation'],'PVC')
        self.put(**s['values']);self.put(cable='Condutor isolado')
        s=self.p.installation.state(4,reconcile=True)
        self.assertEqual(s['values']['voltage'],'450/750V')
        self.assertEqual(s['values']['material'],'Cobre')
        self.assertEqual(s['values']['insulation'],'PVC')

if __name__=='__main__':unittest.main()

"""Regressões das escolhas guiadas, motores e preservação dos projetos."""
import copy
import gzip
import json
import math
import unittest
from pathlib import Path
import os,sys;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)));from forcar import force
from core.project import Project, IDENT, unpack
from core import selection, motors

ROOT=Path(__file__).resolve().parents[1]
BASE=json.loads((Path(__file__).resolve().parents[1]/'data'/'exemplos'/'exemplo.json').read_text(encoding='utf-8'))

def load():return Project(copy.deepcopy(BASE))
def change(p,s,**values):
    p.update([{'sheet':s,'address':a,'value':v} for a,v in values.items()],validate_installation=False)
def set_mode(p,r,key,value):
    uid=p.meta['ids'][str(r)]
    change(p,selection.SHEET,**{key+':'+uid:value})

class GuidedSelection(unittest.TestCase):
    def test_legacy_values_untouched_on_open(self):
        p=load()
        self.assertEqual(p.summary()['p_w'],76700)
        self.assertEqual(p.raw(selection.P,'AM4'),'ACW400H-ETS400-3')
        self.assertEqual(selection.modes(p,4)['protecao'],selection.MANUAL)
        self.assertEqual(p.raw(motors.LOAD,'AN4'),motors.INCLUDED)

    def test_auto_adopts_actual_candidate_and_reacts_to_cable(self):
        p=load();set_mode(p,4,'protecao',selection.AUTO)
        model=p.get(selection.P,'DN4')
        chosen=next(x for x in selection.breaker_candidates(p,4)['items'] if x['modelo']==model)
        self.assertGreaterEqual(chosen['ir'],p.get(selection.P,'D4'))
        self.assertLessEqual(chosen['ir'],p.get(selection.P,'F4'))
        self.assertGreaterEqual(chosen['icu'],p.get('Cálc_Icc-Cond_Escolhido','S4'))
        self.assertEqual(p.raw(selection.P,'CF4'),'PENDENTE')
        change(p,'Seleção-Seção_Condutor',T4=2.5)
        self.assertFalse(p.get(selection.P,'DN4'))
        self.assertIn('capacidade',p.meta['selection_results'][p.meta['ids']['4']]['protecao'])

    def test_manual_preserves_choice_and_reopens(self):
        p=load();set_mode(p,4,'protecao',selection.AUTO)
        set_mode(p,4,'protecao',selection.MANUAL)
        old=p.raw(selection.P,'AM4')
        change(p,motors.LOAD,D4=19000)
        self.assertEqual(p.raw(selection.P,'AM4'),old)
        restored=Project(unpack(p.packed()))
        self.assertEqual(selection.modes(restored,4)['protecao'],selection.MANUAL)
        self.assertEqual(restored.raw(selection.P,'AM4'),old)

    def test_explicit_manual_api_edit_takes_priority(self):
        p=load();set_mode(p,4,'protecao',selection.AUTO)
        change(p,selection.P,AM4='ACW400H-ETS400-3')
        self.assertEqual(selection.modes(p,4)['protecao'],selection.MANUAL)

    def test_modes_follow_id_on_reorder_and_duplicate(self):
        p=load();uid=p.meta['ids']['5'];set_mode(p,5,'protecao',selection.AUTO)
        change(p,IDENT,D5='QDFL-03',M7='Distribuição')
        self.assertEqual(selection.modes(p,p.row_for(uid))['protecao'],selection.AUTO)
        new=p.add('Cópia teste','QGBT-01',uid)
        self.assertEqual(selection.modes(p,p.row_for(new))['protecao'],selection.AUTO)

    def test_voltage_above_catalog_is_not_adopted(self):
        p=load();force(p,'Padrão de entrada','B135',690)
        self.assertFalse(selection.breaker_candidates(p,4)['items'])
        self.assertFalse(p.backup_fusivel(4)['candidatos'])
        self.assertFalse(p.backup_disjuntor(4)['candidatos'])

    def test_backup_auto_recalculates_and_manual_is_retained(self):
        p=load();set_mode(p,2,'backup',selection.AUTO)
        first=p.raw('DPS','BP2')
        self.assertTrue(first.startswith('NH gG'))
        change(p,'DPS',BH2='CLAMPER')
        self.assertLessEqual(p.get('DPS','R2'),100)
        change(p,'DPS',BP2='NH gG 100 A')
        self.assertEqual(selection.modes(p,2)['backup'],selection.MANUAL)
        change(p,'Dados dos circuitos',F2=15)
        self.assertEqual(p.raw('DPS','BP2'),'NH gG 100 A')

    def test_dps_list_and_selection_validate_units_and_topology(self):
        p=load();catalog=selection.dps_catalog(p,2)
        selected=next(x for x in catalog if x['compatible'])
        self.assertEqual(selected['modelo'],'5SD7 443-1')
        self.assertEqual((selected['uc'],selected['up'],selected['corrente']),(350,1.5,25))
        set_mode(p,2,'dps',selection.MANUAL)
        change(p,'DPS',AU2='5SD7 444-1')
        self.assertIn('Pendente',selection.dps_status(p,2))
        change(p,'DPS',AU2=None)
        self.assertFalse(p.get('DPS','AV2'))
        set_mode(p,2,'dps',selection.AUTO)
        self.assertEqual(p.get('DPS','AV2'),'5SD7 443-1')

    def test_backup_does_not_confirm_document(self):
        p=load();set_mode(p,2,'backup',selection.AUTO)
        self.assertNotEqual(p.raw('DPS','BK2'),'SIM')
        self.assertFalse(p.raw('DPS','BL2'))

    def test_blank_manual_backup_is_not_an_automatic_selection(self):
        p=load();set_mode(p,2,'backup',selection.MANUAL)
        change(p,'DPS',BP2=None)
        self.assertEqual(p.get('DPS','AF2'),'—')
        self.assertIn('backup no modo manual',selection.dps_status(p,2))

class GuidedMotors(unittest.TestCase):
    def test_groups_are_separate(self):
        p=load();f=p.form(p.meta['ids']['4'])
        groups={g['key']:g for g in f['groups']}
        self.assertEqual([x['address'] for x in groups['cargas']['fields']],['D4','E4','H4','I4','L4','M4'])
        self.assertEqual(next(t for t in f['info'] if t['key']=='motores')['groups'],['motores','partida'])
        self.assertEqual(len(f['choice_fields']),4)  # v1.10: + disjuntor de manutenção

    def test_manual_nameplate_drives_current_starting_and_fault(self):
        p=load()
        change(p,motors.LOAD,V4=17,AG4=.8,AH4=90,AI4=6,AK4=12000)
        expected=round(12000/(math.sqrt(3)*220*.8*.9),2)
        self.assertAlmostEqual(p.get(motors.CALC,'H4'),expected)
        self.assertAlmostEqual(p.get(motors.CALC,'I4'),round(expected*6,2))
        change(p,motors.LOAD,AJ4=50)
        self.assertEqual(p.get(motors.CALC,'H4'),50)
        self.assertEqual(p.get(motors.CALC,'I4'),300)
        self.assertFalse(motors.issues(p,4))

    def test_new_motor_load_counts_once_and_aggregates(self):
        p=load();uid=p.add('Motor dedicado','QGBT-01');r=p.row_for(uid)
        change(p,IDENT,**{f'E{r}':'Trifásico'})
        change(p,motors.LOAD,**{f'V{r}':10,f'AK{r}':7360,f'AG{r}':.8,f'AH{r}':80,f'AI{r}':6,
                              f'Y{r}':5,f'AA{r}':.9,f'AB{r}':90})
        expected=7360/.8+5*736/.9
        self.assertAlmostEqual(p.get(motors.LOAD,f'AP{r}'),expected,places=2)
        self.assertAlmostEqual(p.get('Carga nos circuitos',f'Y{r}'),expected,delta=.02)
        self.assertAlmostEqual(p.summary()['p_w'],76700+expected,delta=.03)
        change(p,motors.LOAD,**{f'AN{r}':motors.INCLUDED})
        self.assertAlmostEqual(p.summary()['p_w'],76700,places=2)

    def test_zero_motor_ignores_old_plate_overrides(self):
        p=load();change(p,motors.LOAD,AJ4=50,AI4=8)
        change(p,motors.LOAD,V4=0,Y4=0)
        self.assertFalse(p.get(motors.CALC,'H4'))
        self.assertEqual(p.get(motors.LOAD,'AP4'),0)

    def test_manual_values_survive_persistence_and_clear_to_catalog(self):
        p=load();change(p,motors.LOAD,AJ4=40)
        restored=Project(unpack(p.packed()))
        self.assertEqual(restored.get(motors.CALC,'H4'),40)
        change(restored,motors.LOAD,AJ4=None)
        self.assertEqual(restored.get(motors.CALC,'H4'),45)

    def test_missing_data_exposes_issue_and_blocks_auto(self):
        p=load();change(p,motors.LOAD,V5=19)
        self.assertTrue(motors.issues(p,5))
        set_mode(p,4,'protecao',selection.AUTO)
        self.assertFalse(p.raw(selection.P,'AM4'))

    def test_invalid_values_rejected_and_valid_starting_roundtrip(self):
        for col,val in [('AG4',1.1),('AH4',110),('AI4',-2),('Y4',-1),('T4',3)]:
            with self.subTest(col=col),self.assertRaises(ValueError):change(load(),motors.LOAD,**{col:val})
        p=load()
        change(p,motors.START,W4='Soft-starter',X4='65')
        self.assertEqual(p.get(motors.START,'Y4'),.65)
        self.assertEqual(p.get(motors.START,'Z4'),.4225)
        change(p,motors.START,W4='Direta')
        self.assertEqual(p.raw(motors.START,'X4'),'N/A')
        self.assertEqual(p.get(motors.START,'Y4'),1)
        with self.assertRaises(ValueError):change(p,motors.START,X4=110)

if __name__=='__main__':unittest.main()

import copy
import gzip
import io
import json
from pathlib import Path
import secrets
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.parse
import urllib.request
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from http.server import ThreadingHTTPServer
from app import Handler, Store


class HttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        cls.server.store=Store(Path(cls.tmp.name)/'projects.sqlite3')
        cls.server.token=secrets.token_urlsafe(24);cls.server.lock=threading.RLock()
        cls.server.daemon_threads=True
        cls.base=f'http://127.0.0.1:{cls.server.server_port}'
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
        cls.client=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.tmp.cleanup()
    def get(self,path):return self.client.open(self.base+path,timeout=60).read()
    def post(self,path,data=None,raw=None,extra=None):
        body=raw if raw is not None else json.dumps(data or {}).encode()
        headers={'X-Eletro-Project':self.server.store.active_id,'X-Eletro-Revision':str(self.server.store.revision),'X-Eletro-Token':self.server.token,'Content-Type':'application/json',**(extra or {})}
        req=urllib.request.Request(self.base+path,data=body,headers=headers,method='POST')
        return json.loads(self.client.open(req,timeout=60).read())
    def test_api_forms_and_report(self):
        state=json.loads(self.get('/api/state'))
        self.assertEqual(state['p_w'],76700)
        uid=state['circuits'][3]['id']
        form=json.loads(self.get('/api/form?id='+uid))
        self.assertEqual(form['name'],'QDFL-01')
        self.assertGreater(sum(len(g['fields']) for g in form['groups']),70)
        self.assertGreater(len(json.loads(self.get('/api/source'))),30)
        tab=json.loads(self.get('/api/table?'+urllib.parse.urlencode({'id':'tab_weg_protecoes','count':20})))
        self.assertEqual(len(tab['linhas_def']),20);self.assertIn('Catálogos WEG',tab['fonte'])
        self.assertEqual(len(json.loads(self.get('/api/tables'))['tabelas']),35)  # v2.2.0: 17 tabelas novas (antes escritas em fórmulas e código, ou de critérios novos)
        coord=json.loads(self.get('/api/coordination'));self.assertTrue(coord['pares'])
        with self.assertRaises(urllib.error.HTTPError):self.get('/api/sheet?name=Tabela_Concess')
        self.assertIn('Potência na origem',self.get('/report').decode())
        self.assertIn('EletroApp',self.get('/').decode())
        self.assertIn('Circuito',self.get('/api/export?format=csv').decode('utf-8-sig'))
    def test_backup_import_and_rejected_mutation(self):
        backup=self.get('/api/export')
        decoded=json.loads(gzip.decompress(backup))
        self.assertEqual(decoded['formato'],'eletroapp-projeto');self.assertNotIn('sheets',decoded)
        self.assertEqual(len(decoded['circuitos']),6);self.assertLess(len(backup),60000,'o projeto guarda só dados de entrada e edições')
        before=self.server.store.active_id
        self.post('/api/import',raw=backup,extra={'X-Filename':'meu_projeto.eletro'})
        self.assertNotEqual(before,self.server.store.active_id)
        previous=self.server.store.project.raw('Levantamento de carga','E4')
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.post('/api/changes',{'changes':[{'sheet':'Levantamento de carga','address':'E4','value':1.5}]})
        self.assertEqual(ctx.exception.code,400)
        self.assertEqual(self.server.store.project.raw('Levantamento de carga','E4'),previous)
    def test_source_permissions_and_csrf(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.post('/api/projects/new',{'name':'blocked'},extra={'X-Eletro-Token':'wrong'})
        self.assertEqual(ctx.exception.code,403)

    def test_grouping_preview_save_and_consultation(self):
        catalog=json.loads(self.get('/api/installation/catalog'))
        self.assertEqual(len(catalog['grouping']['rows']),292)
        self.assertIn('/agrupamento.js',self.get('/').decode())
        self.assertIn('data-group-key',self.get('/agrupamento.js').decode())
        uid=self.server.store.project.meta['ids']['4']
        form=json.loads(self.get('/api/form?id='+uid));settings=form['installation']['settings']
        settings.update(group_mode='manual',manual_factor=.75,manual_source='Memorial teste',
                        manual_reason='Fator documentado para configuração física de teste.',other_units=0)
        preview=self.post('/api/installation/preview',{'id':uid,'settings':settings})
        self.assertTrue(preview['valid'],preview['issues']);self.assertEqual(preview['grouping']['factor'],.75)
        self.post('/api/changes',{'changes':[],'installation':{'id':uid,'reference':preview['reference'],'settings':settings}})
        saved=json.loads(self.get('/api/form?id='+uid))
        self.assertEqual(saved['installation']['grouping']['factor'],.75)
        self.assertIn('Memorial teste',self.get('/report').decode())
        settings['manual_factor']=0
        with self.assertRaises(urllib.error.HTTPError):
            self.post('/api/changes',{'changes':[],'installation':{'id':uid,'reference':preview['reference'],'settings':settings}})
        self.assertEqual(self.server.store.project.installation.group_factor(4),.75)
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.post('/api/projects/new',{'name':'blocked'},extra={'Origin':'https://example.org'})
        self.assertEqual(ctx.exception.code,403)


if __name__=='__main__':unittest.main()

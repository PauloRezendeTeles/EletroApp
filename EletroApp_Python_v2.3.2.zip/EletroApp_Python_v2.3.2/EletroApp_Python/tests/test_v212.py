"""v2.1.2: ampacidade, transições, erros e todas as combinações do catálogo."""
import copy
import gzip
import itertools
import json
import secrets
import shutil
import subprocess
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

from app import Handler, Store
from core.project import Project, unpack
from core.installation import FIELDS, RULES
from core.formula import Error
from core.catalog import Catalog
from core import integridade
from tests.installation_matrix import BASE, ROOT, configure, run_matrix

LINE=next(x for x in RULES['lines'] if x['name']=='Eletrocalha')
VARIANT=next(x for x in LINE['variants'] if x['method']==31 and x['cable']=='Cabo unipolar')

def prepared():
    p=Project(copy.deepcopy(BASE));r=configure(p,LINE,VARIANT,3)
    p.put(FIELDS['arrangement'][0],'L4',p.installation.state(r)['options']['arrangement'][0]);p.engine.clear()
    return p

class AmpacityRegression(unittest.TestCase):
    def test_missing_and_stale_arrangement_only_block_impedance_and_completion(self):
        p=prepared();expected=p.get('Cálc_Seç-Ampacidade','O4');iz=p.get('Corrente_Max-Cond_Escolhido','K4')
        for arr in (None,'3 - condutores em cabo multipolar'):
            with self.subTest(arr=arr):
                p.put(FIELDS['arrangement'][0],'L4',arr);p.engine.clear();s=p.installation.state(4)
                self.assertTrue(s['ampacity_valid'],s['ampacity_issues']);self.assertFalse(s['valid'])
                self.assertEqual(p.get('Cálc_Seç-Ampacidade','O4'),expected)
                self.assertEqual(p.get('Corrente_Max-Cond_Escolhido','K4'),iz)
                self.assertIsInstance(p.installation.arrangement_code(4),Error)
                with self.assertRaisesRegex(ValueError,'Arranjo para cálculo de impedância'):p.installation.verify(4)

    def test_thermal_constraints_still_prevent_numeric_ampacity(self):
        mutations=[('method',999),('cable','Cabo multipolar'),('insulation','inexistente'),('parallel',0),('circuits',0)]
        for key,value in mutations:
            with self.subTest(key=key):
                p=prepared();s,c=FIELDS[key];p.put(s,c+'4',value);p.engine.clear()
                self.assertFalse(p.installation.state(4)['ampacity_valid'])
                self.assertIsInstance(p.installation.amp_table(4),Error)
                self.assertEqual(p.get('Cálc_Seç-Ampacidade','O4')['error'],'#N/A')
        p=prepared();p.put('Dados dos circuitos','E4',2);p.engine.clear()
        self.assertFalse(p.installation.state(4)['ampacity_valid'])
        p=prepared();p.put('Dados dos condutores ','F4','Alumínio');p.meta['ocupacao']['densidade']='BD4';p.engine.clear()
        self.assertFalse(p.installation.state(4)['ampacity_valid'])
        line=next(l for l in RULES['lines'] if l['name']=='Bandejas perfuradas (horizontal ou vertical)')
        v=next(v for v in line['variants'] if v['cable']=='Cabo unipolar')
        p=prepared();configure(p,line,v,3,adjustment='Justapostos')
        p.meta['installation_settings'][p.meta['ids']['4']]={};p.engine.clear()
        self.assertFalse(p.installation.state(4)['ampacity_valid'])
        self.assertIn('geométricas',p.get('Cálc_Seç-Ampacidade','O4')['detail'])

    def test_cause_survives_phase_neutral_and_capacity_chain(self):
        p=prepared();p.put(FIELDS['method'][0],'B4',999);p.engine.clear()
        for sheet,cols in [('Cálc_Seç-Ampacidade','OPQR'),('Corrente_Max-Cond_Escolhido','FKMO')]:
            for col in cols:
                with self.subTest(sheet=sheet,col=col):
                    error=p.get(sheet,col+'4');self.assertEqual(error['error'],'#N/A')
                    self.assertIn('Montagem da instalação',error['detail']);self.assertIn('999',error['detail'])

    def test_section_outside_table_has_specific_diagnostic(self):
        p=prepared();p.put('Seleção-Seção_Condutor','T4',666);p.engine.clear()
        error=p.get('Corrente_Max-Cond_Escolhido','K4')
        self.assertEqual(error['error'],'#N/A');self.assertIn('seção de 666 mm²',error['detail'])

    def test_current_outside_table_has_specific_diagnostic(self):
        p=prepared();vid=p.var_at('Cálc_Seç-Ampacidade','F4').id
        p.doc['formulas'][vid]={'ativa':1,'versoes':[{'versao':1,'expressao':'=1000000000','tipo':'ensaio'}]};p.engine.clear()
        error=p.get('Cálc_Seç-Ampacidade','O4')
        self.assertEqual(error['error'],'#N/A');self.assertIn('corrente de dimensionamento',error['detail'])
        self.assertNotIn('isolação/método inválida',error['detail'])
        p.put(FIELDS['arrangement'][0],'L4',None);p.engine.clear()
        group=next(g for g in p.form(p.meta['ids']['4'])['groups'] if g['key']=='secoes')
        self.assertIn('corrente de dimensionamento',group['comparacao'][0]['criterios'][0]['value']['detail'])

    def test_changing_phases_reconciles_disposition_and_arrangement(self):
        p=prepared();line=next(l for l in RULES['lines'] if l['name']=='Bandejas perfuradas (horizontal ou vertical)')
        variant=next(v for v in line['variants'] if v['cable']=='Cabo unipolar')
        r=configure(p,line,variant,3,adjustment='Trifólio')
        p.put(FIELDS['arrangement'][0],'L4',p.installation.state(r)['options']['arrangement'][0]);p.engine.clear()
        p.update([{'sheet':'Identificação dos circuitos','address':'E4','value':'Monofásico'}],validate_installation=False)
        state=p.installation.state(4,reconcile=True)
        self.assertEqual(state['loaded'],2);self.assertEqual(state['values']['adjustment'],'Justapostos')
        self.assertEqual(state['values']['arrangement'],'2 - condutores unipolares/isolados - próximos')
        self.assertIsNone(state['geometry']['mode'])  # confirmar a nova geometria continua obrigatório

    def test_custom_formula_is_preserved_and_standard_formula_remains_editable(self):
        p=prepared();vid='amp_secao.secao_fase';entry=Catalog(p).entry_view(p.model.by_id[vid])
        self.assertFalse(entry['gerida_por_instalacao'])
        p.doc['formulas'][vid]={'ativa':1,'versoes':[{'versao':1,'expressao':'=777','tipo':'externa'}]};p.engine.clear()
        q=Project(unpack(p.packed()));self.assertEqual(q.get('Cálc_Seç-Ampacidade','O4'),777)
        self.assertEqual(integridade.formula_status(q,vid),'alterada')

    def test_original_legacy_formulas_adopt_corrected_diagnostics(self):
        d=json.loads(gzip.decompress((ROOT/'tests/fixtures/projeto_v1.json.gz').read_bytes()))
        p=Project(d)
        for vid in ('amp_secao.secao_fase','amp_secao.iz_neutro','iz.iz_tabela_fase_bruto','sug_iz.iz_tabela_neutro_bruto'):
            self.assertNotIn(vid,p.doc['formulas'])
            self.assertIn('AMPACITYERROR',p.model.by_id[vid].expr)

class FullInstallationMatrix(unittest.TestCase):
    def test_all_supported_combinations_and_independent_table_lookup(self):
        records=run_matrix();errors=[x for x in records if x['resultado']=='FALHA']
        self.assertEqual(errors,[],json.dumps(errors[:5],ensure_ascii=False))
        self.assertEqual(len(records),1816)
        self.assertEqual(sum(x['resultado']=='BLOQUEIO_ESPERADO' for x in records),72)

    def test_every_invalid_line_method_cable_combination_is_rejected(self):
        p=prepared();methods=list(dict.fromkeys(v['method'] for l in RULES['lines'] for v in l['variants']))
        count=0
        for line,method,cable in itertools.product(RULES['lines'],methods,('Condutor isolado','Cabo unipolar','Cabo multipolar')):
            if any(str(v['method'])==str(method) and v['cable']==cable for v in line['variants']):continue
            count+=1;configure(p,line,{'method':method,'cable':cable},3)
            s=p.installation.state(4)
            with self.subTest(line=line['name'],method=method,cable=cable):
                self.assertFalse(s['ampacity_valid'])
                self.assertTrue(any('Montagem da instalação' in e or 'Tipo de condutor' in e or 'montagem e o tipo' in e for e in s['ampacity_issues']))
                self.assertIsInstance(p.installation.amp_table(4),Error)
        # v2.2.0: forro falso e piso elevado usam o método 21 (Tabela 33, nota 5); o 28 deixou de ser um método à parte.
        self.assertEqual(count,5090)

class QuietHandler(Handler):
    def log_message(self,*args):pass

class InstallationHTTP(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.server=ThreadingHTTPServer(('127.0.0.1',0),QuietHandler)
        cls.server.store=Store(Path(cls.tmp.name)/'p.sqlite3',backup=False)
        cls.server.token=secrets.token_urlsafe(24);cls.server.lock=threading.RLock();cls.server.daemon_threads=True
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
        cls.client=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join();cls.tmp.cleanup()
    def post(self,path,data):
        store=self.server.store
        request=urllib.request.Request(f'http://127.0.0.1:{self.server.server_port}'+path,data=json.dumps(data).encode(),
            headers={'Content-Type':'application/json','X-Eletro-Token':self.server.token,
                     'X-Eletro-Project':store.active_id,'X-Eletro-Revision':str(store.revision)},method='POST')
        try:
            with self.client.open(request,timeout=60) as response:return response.status,json.load(response)
        except urllib.error.HTTPError as error:return error.code,json.load(error)
    def test_all_94_relations_with_two_and_three_loaded_conductors_via_api(self):
        baseline=self.server.store.project;checked=0
        for line in RULES['lines']:
            for variant,n in itertools.product(line['variants'],(2,3)):
                p=baseline.fork();ref=variant['reference'];adjustment='Horizontal' if ref=='G' else 'Justapostos' if ref=='F' else 'N/A'
                r=configure(p,line,variant,n,adjustment=adjustment);uid=p.meta['ids'][str(r)]
                arr=p.installation.state(r)['options']['arrangement'];p.put(FIELDS['arrangement'][0],f'L{r}',arr[0] if arr else None);p.engine.clear()
                changes=[{'sheet':sh,'address':f'{col}{r}','value':p.raw(sh,f'{col}{r}')} for sh,col in FIELDS.values()]
                settings=p.installation.settings(r)
                with self.subTest(line=line['name'],method=variant['method'],cable=variant['cable'],n=n):
                    status,result=self.post('/api/installation/preview',{'id':uid,'changes':changes,'settings':settings,'reconcile':True})
                    self.assertEqual(status,200,result)
                    expected=not(ref=='G' and n==2)
                    self.assertEqual(result['valid'],expected,result['issues']);self.assertEqual(result['ampacity_valid'],expected)
                    status,form=self.post('/api/choices/preview',{'id':uid,'changes':changes,'installation':{'id':uid,'reference':ref,'settings':settings}})
                    self.assertEqual(status,200,form)
                    sections=next(g for g in form['groups'] if g['key']=='secoes');amp=sections['comparacao'][0]['criterios'][0]['value']
                    if expected:self.assertIsInstance(amp,(int,float))
                    else:self.assertEqual(amp['error'],'#N/A')
                    checked+=1
        self.assertEqual(checked,188)
    def test_save_rejects_incomplete_arrangement_then_accepts_complete_inputs(self):
        p=self.server.store.project;uid=p.meta['ids']['4'];revision=self.server.store.revision
        values=dict(line='Eletrocalha',method=31,cable='Cabo unipolar',adjustment='N/A',arrangement=None)
        changes=[{'sheet':FIELDS[k][0],'address':FIELDS[k][1]+'4','value':v} for k,v in values.items()]
        status,data=self.post('/api/changes',{'changes':changes});self.assertEqual(status,400)
        self.assertIn('Arranjo para cálculo de impedância',data['error']);self.assertEqual(self.server.store.revision,revision)
        changes[-1]['value']='3 - condutores unipolares/isolados - próximos'
        status,data=self.post('/api/changes',{'changes':changes});self.assertEqual(status,200,data)
        self.assertIsInstance(self.server.store.project.get('Corrente_Max-Cond_Escolhido','K4'),(int,float))

class PreviewJavaScript(unittest.TestCase):
    @unittest.skipUnless(shutil.which('node'),'Node necessário somente para o teste de interface')
    def test_actual_preview_refreshes_sections_and_discards_stale_responses(self):
        p=prepared();uid=p.meta['ids']['4'];after=p.form(uid)
        p.put(FIELDS['method'][0],'B4',999);p.engine.clear();before=p.form(uid)
        with tempfile.TemporaryDirectory() as tmp:
            fixture=Path(tmp)/'forms.json';fixture.write_text(json.dumps({'before':before,'after':after}),encoding='utf-8')
            result=subprocess.run(['node',str(ROOT/'tests/preview_v212.js'),str(fixture)],cwd=ROOT,text=True,encoding='utf-8',capture_output=True)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)

if __name__=='__main__':unittest.main()

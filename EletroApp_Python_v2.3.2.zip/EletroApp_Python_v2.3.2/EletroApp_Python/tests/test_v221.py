"""v2.2.1: leitura UTF-8 no Windows e queda de tensão ainda não calculada.

Execute: python -m unittest tests.test_v221 -v
"""
import copy
import gzip
import json
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import example_data, report  # noqa: E402
from core.formula import Engine, Error, parse, scalar  # noqa: E402
from core.motor import model  # noqa: E402
from core.project import Project, unpack  # noqa: E402


CHECKS = (
    ('queda.dv_v_instalacao_ok', 'queda.acumulada_pct', 'queda.limite_total_de_projeto_pct', 'INSTALAÇÃO'),
    ('queda.dv_v_trecho_ok', 'queda.trecho_pct', 'queda.limite_por_trecho_pct', 'TRECHO'),
)


def check(check_spec, value, limit, circuit_id=1):
    """Avalia a fórmula distribuída com entradas controladas, sem reescrevê-la."""
    vid, measured, maximum, _ = check_spec
    engine = Engine({
        'sheets': {'Entrada': {'cells': {
            'A1': {'value': circuit_id}, 'A2': {'value': value}, 'A3': {'value': limit},
        }}},
        'names': {'queda.id': 'Entrada!A1', measured: 'Entrada!A2', maximum: 'Entrada!A3'},
    })
    return scalar(engine.evaluate(parse(model().by_id[vid].expr), 'Entrada', 'B1'))


class WindowsEncodingTests(unittest.TestCase):
    def test_cp1252_startup_api_and_report(self):
        # O arquivo real reproduz o erro informado; não é uma amostra sintética.
        with self.assertRaises(UnicodeDecodeError):
            (ROOT / 'data/installation_rules.json').read_bytes().decode('cp1252')
        script = r'''
import json
from pathlib import Path
import secrets
import tempfile
import threading
from unittest.mock import patch
import urllib.request
from http.server import ThreadingHTTPServer

original = Path.read_text
def windows_read_text(path, encoding=None, errors=None, **kwargs):
    return original(path, encoding=encoding if encoding is not None else 'cp1252',
                    errors=errors, **kwargs)

with patch.object(Path, 'read_text', windows_read_text):
    from app import Handler, Store
    from core.installation import RULES
    from core.motor import APP_VERSION
    assert any(line['name'] == 'Bandejas não perfuradas ou prateleiras' for line in RULES['lines'])
    with tempfile.TemporaryDirectory() as tmp:
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        server.store = Store(Path(tmp) / 'eletroapp.sqlite3')
        server.token = secrets.token_urlsafe(24)
        server.lock = threading.RLock()
        server.daemon_threads = True
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        client = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        url = 'http://127.0.0.1:' + str(server.server_port)
        def get(path):
            with client.open(url + path, timeout=45) as response:
                assert response.status == 200
                return response.read()
        try:
            assert ('v' + APP_VERSION).encode() in get('/')
            state = json.loads(get('/api/state'))
            assert len(state['circuits']) == 6
            for circuit in state['circuits']:
                if circuit['name'] in ('QDFL-01', 'QDFL-03'):
                    issue = next(x for x in circuit['issues'] if x['label'] == 'Queda de tensão (instalação)')
                    assert issue['value'] == '⏳ PENDENTE — queda total não calculada'
            html = get('/report').decode('utf-8')
            assert '⏳ PENDENTE — queda total não calculada' in html
            assert '✗ INSTALAÇÃO EXCEDE' not in html
            assert json.loads(get('/api/installation/catalog'))['lines']
            assert len(json.loads(get('/api/tables'))['tabelas']) == 35
            reopened = Store(Path(tmp) / 'eletroapp.sqlite3')
            assert len(reopened.project.circuits_doc) == 6
            print(json.dumps({'version': APP_VERSION, 'circuits': 6, 'encoding': 'cp1252'}))
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)
'''
        run = subprocess.run(
            [sys.executable, '-X', 'utf8=0', '-X', 'warn_default_encoding',
             '-W', 'error::EncodingWarning', '-c', script],
            cwd=ROOT, capture_output=True, text=True, encoding='utf-8', timeout=100,
        )
        self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
        self.assertEqual(json.loads(run.stdout)['circuits'], 6)


class VoltageDropTests(unittest.TestCase):
    def assert_pending(self, result):
        self.assertIsInstance(result, str)
        self.assertTrue(result.startswith('⏳ PENDENTE'), result)
        self.assertNotIn('EXCEDE', result)
        self.assertNotIn('OK', result)

    def test_uncalculated_values_are_pending(self):
        for spec in CHECKS:
            for value in (None, '', 'N/A — TOPOLOGIA', 'PENDENTE', '3.2', False, True,
                          Error('#N/A', 'Instalação pendente'), Error('#DIV/0!')):
                with self.subTest(check=spec[0], value=value):
                    result = check(spec, value, 4)
                    self.assert_pending(result)
                    self.assertIn('queda', result)

    def test_uncalculated_limits_are_pending(self):
        for spec in CHECKS:
            for limit in (None, '', 'N/A — tipo de atendimento sem limite em 6.2.7', '4', False,
                          True, Error('#N/A'), Error('#VALUE!')):
                with self.subTest(check=spec[0], limit=limit):
                    result = check(spec, 2.5, limit)
                    self.assert_pending(result)
                    self.assertIn('limite', result)

    def test_numeric_results_keep_limit_boundary_and_zero(self):
        for spec in CHECKS:
            for value, limit, expected in ((0, 4, 'OK'), (3.999, 4, 'OK'), (4, 4, 'OK'),
                                           (4.001, 4, 'EXCEDE'), (6, 7, 'OK'), (7.001, 7, 'EXCEDE'),
                                           (0, 0, 'OK'), (0.001, 0, 'EXCEDE')):
                with self.subTest(check=spec[0], value=value, limit=limit):
                    symbol = '✓' if expected == 'OK' else '✗'
                    self.assertEqual(check(spec, value, limit), f'{symbol} {spec[3]} {expected}')

    def test_inactive_rows_stay_empty(self):
        for spec in CHECKS:
            self.assertEqual(check(spec, 'N/A — TOPOLOGIA', 4, circuit_id=''), '')

    def test_example_pending_summary_and_report(self):
        project = Project(example_data())
        for circuit in project.circuits():
            if circuit['name'] not in ('QDFL-01', 'QDFL-03'):
                continue
            issues = {item['label']: item['value'] for item in circuit['issues']}
            self.assert_pending(issues['Queda de tensão (trecho)'])
            self.assert_pending(issues['Queda de tensão (instalação)'])
            self.assertIn('Instalação pendente', circuit['dv_total']['detail'])
        html = report(project)
        self.assertIn('PENDENTE — queda total não calculada', html)
        self.assertNotIn('✗ INSTALAÇÃO EXCEDE', html)

    def test_recalculates_after_completion_exceedance_and_new_pending(self):
        project = Project(example_data())
        for row in project.active_rows():
            installation = project.installation.state(row)
            settings = project.meta.setdefault('installation_settings', {}).setdefault(project.meta['ids'][str(row)], {})
            settings.update(other_units=int(installation['values']['circuits']) - 1, homogeneity='similar')
            if installation['underground']:
                settings['duct_layout'] = 'one_cable' if installation['values']['cable'] == 'Cabo multipolar' else 'one_conductor'
            if installation['geometry']['required']:
                settings.update(geometry_mode='confirmed', geometry_signature=installation['geometry']['signature'])
        project.engine.clear()
        rows = {c['name']: c['row'] for c in project.circuits()}
        sheet = 'Queda_Tens-Cond_Escolhido'
        for name, expected in (('QDFL-01', 3.261), ('QDFL-03', 3.231)):
            row = rows[name]
            self.assertAlmostEqual(project.get(sheet, f'W{row}'), expected, places=3)
            self.assertEqual(project.get(sheet, f'AB{row}'), '✓ INSTALAÇÃO OK')
        row = rows['QDFL-01']
        project.put('Dados dos circuitos', f'F{row}', 500)
        self.assertGreater(project.get(sheet, f'W{row}'), 7)
        self.assertEqual(project.get(sheet, f'AB{row}'), '✗ INSTALAÇÃO EXCEDE')
        project.meta['installation_settings'][project.meta['ids'][str(row)]].pop('other_units')
        project.engine.clear()
        self.assert_pending(project.get(sheet, f'AB{row}'))

    def test_legacy_standard_formulas_migrate_to_corrected_model(self):
        data = json.loads(gzip.decompress((ROOT / 'tests/fixtures/projeto_v1.json.gz').read_bytes()))
        project = Project(data)
        for spec in CHECKS:
            self.assertNotIn(spec[0], project.doc['formulas'])
        restored = Project(unpack(project.packed()))
        row = next(c['row'] for c in restored.circuits() if c['name'] == 'QDFL-01')
        self.assert_pending(restored.get('Queda_Tens-Cond_Escolhido', f'AB{row}'))

    def test_native_custom_formula_is_preserved(self):
        data = copy.deepcopy(example_data())
        data['formulas'][CHECKS[0][0]] = {
            'ativa': 1, 'versoes': [{'versao': 1, 'expressao': '="Verificação personalizada"'}],
        }
        project = Project(data)
        restored = Project(unpack(project.packed()))
        self.assertEqual(restored.get('Queda_Tens-Cond_Escolhido', 'AB5'), 'Verificação personalizada')


if __name__ == '__main__':
    unittest.main()

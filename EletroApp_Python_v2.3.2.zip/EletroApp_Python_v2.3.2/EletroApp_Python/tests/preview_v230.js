/* Formulários reais e DOM mínimo. Valida comportamento, não substitui QA visual no navegador. */
'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const data=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const nodes={},listeners={};
const esc=v=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const context={state:data.normal.state,drawerData:data.generator.form,dirty:false,sourceDirty:false,
  esc,num:(v,d=2)=>typeof v==='number'?v.toFixed(d):String(v??'—'),isError:v=>v&&typeof v==='object'&&v.error,
  formatBR:v=>String(v).replace('.',','),localStorage:{getItem:()=>null},
  liveValue:(i,p)=>nodes[p+i]?.value??null,trechoSemOrigem:()=>false,trechoComMB:()=>false,
  document:{getElementById:id=>nodes[id]||null,querySelectorAll:()=>[],addEventListener:(name,fn)=>(listeners[name]??=[]).push(fn)}};
vm.createContext(context);
const app=fs.readFileSync('static/app.js','utf8');
vm.runInContext(app.split('\n').find(s=>s.startsWith('function fieldHTML(')),context);
vm.runInContext(fs.readFileSync('static/protecao-integrada.js','utf8'),context);
function controls(fields,prefix){
 fields.forEach((f,i)=>{const wrap={hidden:false};nodes[prefix+i]={value:f.value??'',closest:()=>wrap};});
}
const fields=data.normal.source;controls(fields,'source-');
function sourceSet(k,value){const i=fields.findIndex(f=>f.protection_key===k);nodes['source-'+i].value=value;}
const typeIndex=fields.findIndex(f=>f.block==='tipo');
const visible=k=>!nodes['source-'+fields.findIndex(f=>f.protection_key===k)].closest().hidden;
sourceSet('tipo','Automático pelo atendimento');
for(const [type,fuse,relay,gen,bt] of [
 ['Rede MT/Trafo sem dados',true,false,false,false],['Rede MT/Trafo com dados',false,true,false,false],
 ['Rede BT Direta',false,false,false,true],['Gerador BT',false,false,true,false]]){
 nodes['source-'+typeIndex].value=type;context.protectionSourceVisibility(fields);
 assert.strictEqual(visible('fusivel_tipo'),fuse);assert.strictEqual(visible('interrupcao_ms'),relay);
 assert.strictEqual(visible('qta'),gen);assert.strictEqual(visible('medicao'),bt);
}
nodes['source-'+typeIndex].value='Rede MT/Trafo com dados';sourceSet('51_ativa','NÃO');
context.protectionSourceVisibility(fields);assert(!visible('51_corrente'));assert(visible('51_ativa'));
sourceSet('51_ativa','SIM');context.protectionSourceVisibility(fields);assert(visible('51_corrente'));
const csv=fields.find(f=>f.protection_key==='fusivel_curva');
const html=context.fieldHTML({...csv,value:'corrente_a;t_fusao_min_s;t_eliminacao_max_s\n10;1;2\n100;.1;.2'},'curve');
assert(html.includes('<textarea'));assert(html.includes('\n10;1;2'));
const qta=data.generator.source.find(f=>f.protection_key==='qta');
assert(context.fieldHTML(qta,'qta').includes('QM-01'));

context.state=data.generator.state;const form=data.generator.form;controls(form.fields,'field-');
nodes['prot-origem-conteudo']={hidden:false};context.integratedRefresh(form);
assert(nodes['prot-origem-conteudo'].hidden);
const linkIdx=form.fields.findIndex(f=>f.protection_key==='vinculo');
const openingIdx=form.fields.findIndex(f=>f.sheet==='Cálc-Prot_Cabos'&&f.address.replace(/\d+$/,'')==='CX');
assert(openingIdx>=0);assert(nodes['field-'+openingIdx].closest().hidden);
nodes['field-'+linkIdx].value='Saída própria no quadro precedente';context.integratedRefresh(form);
assert(!nodes['prot-origem-conteudo'].hidden);assert(!nodes['field-'+openingIdx].closest().hidden);
const group=form.groups.find(g=>g.key==='integrada');
const rendered=context.integratedGroupHTML(group,form);
assert(rendered.includes('QM-01'));assert(rendered.includes('0.1600'));assert(rendered.includes('∫I²dt'));
assert(!rendered.includes('NaN'));assert(!rendered.includes('undefined'));
const hostile=context.integratedGroupHTML({...group,link:{descricao:'<script>alert(1)</script>'}},form);
assert(!hostile.includes('<script>'));assert(hostile.includes('&lt;script&gt;'));

vm.runInContext(fs.readFileSync('static/projeto.js','utf8'),context);
for(const name of ['normal','generator'])for(const mode of ['v','h']){
 const s=data[name].state;const svg=context.unifilarSVG(s.circuits,s.origem,{mode,standalone:true});
 assert(svg.startsWith('<svg'));assert(!svg.includes('NaN'));assert(!svg.includes('undefined'));
 if(name==='normal')assert(svg.includes('Chave fusível MT'));
 if(process.argv[3])fs.writeFileSync(process.argv[3]+'/'+name+'-'+mode+'.svg',svg);
}
console.log('OK: perfis, funções habilitadas, CSV, QTA, vínculo, abertura do disjuntor, escape HTML, resultados e SVG vertical/horizontal.');

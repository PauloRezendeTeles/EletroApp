import sys,unittest,json,gzip
from pathlib import Path
sys.path.insert(0,'.')
from core.project import Project,_parse_passos

class Protecao(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p=Project(json.loads((Path(__file__).resolve().parents[1]/'data'/'exemplos'/'exemplo.json').read_text(encoding='utf-8')))
        cls.cat={r['modelo']:r for r in cls.p.weg_catalog()}
    def test_quatro_classes_sem_mistura(self):
        subs={r['subclasse'] for r in self.cat.values()}
        self.assertEqual(subs,{'fixo','termomagnetico','eletronico'})
        fam=self.p.weg_familias_por_classe()
        self.assertNotIn('ACW400H_630H',fam['fixo'])      # modelo ETS400 nunca aparece em "Disjuntor fixo"
        self.assertIn('ACW400H_630H',fam['eletronico'])
    def test_modelo_eletronico_ets400(self):
        m=self.cat['ACW400H-ETS400-3']
        self.assertEqual(m['subclasse'],'eletronico');self.assertEqual(m['in_nominal'],400);self.assertEqual(m['ii_fixo'],4400)
        self.assertEqual(m['ir_ajuste']['valores'],[160,180,200,220,240,260,280,300,320,340,360,380,400])
        self.assertEqual(m['im_ajuste']['tipo'],'discreto_ir')   # Isd = múltiplos de Ir
    def test_fixo_sem_ajuste_e_in_do_catalogo(self):
        m=self.cat['AGW100N-DX60-3']
        self.assertEqual(m['subclasse'],'fixo');self.assertEqual(m['in_nominal'],60)
        aj=Project.protecao_ajustes('fixo',m)
        self.assertFalse(any(aj[k] for k in ('ir','im','isd','tsd','i2t')));self.assertTrue(aj['in_bloqueado'])
    def test_termomagnetico_nao_tem_isd_tsd(self):
        m=self.cat['ACW100H-FMU20-3']
        aj=Project.protecao_ajustes('termomagnetico',m)
        self.assertTrue(aj['ir']);self.assertFalse(aj['isd']);self.assertFalse(aj['tsd']);self.assertFalse(aj['i2t'])
        self.assertEqual(m['ir_ajuste']['valores'],[16,18,20])    # 0,8/0,9/1,0 × In(20 A)
    def test_eletronico_tem_todos_os_ajustes(self):
        aj=Project.protecao_ajustes('eletronico',self.cat['ACW400H-ETS400-3'])
        self.assertTrue(all(aj[k] for k in ('ir','im','isd','tsd','i2t')))
    def test_dial_continuo_nao_vira_lista(self):
        self.assertEqual(_parse_passos('Ajuste contínuo 0,8 a 1,0×In',None,40,50,50,'In')['tipo'],'continuo')
    def test_passos_a_partir_de_multiplicadores(self):
        r=_parse_passos('Discreto: 0,8/0,9/1,0×In',None,40,50,50,'In')
        self.assertEqual(r['valores'],[40,45,50])
    def test_form_traz_ajustes_e_passos_estritos(self):
        c=self.p.circuits()[0]
        g=next(x for x in self.p.form(c['id'])['groups'] if x['key']=='protecao')
        self.assertEqual(g['classe_atual'],'eletronico')
        y=next(f for f in g['fields'] if f['address'].startswith('Y'))
        self.assertTrue(y['strict']);self.assertIn(320,[int(o) for o in y['options']])

if __name__=='__main__':unittest.main()

"""v2.1 — regressões dos 13 achados da análise técnica da v2.0.0 (07/10/2026).

Os valores de curvas e tabelas abaixo são dados sintéticos de ensaio; não representam equipamentos reais."""
import copy
import gzip
import json
import secrets
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from http.server import ThreadingHTTPServer
from app import Handler, Store
from core.project import Project, unpack
from core.catalog import Catalog, CatalogError
from core import curvas, integridade, tabelas, trecho
from core.motor import model

EXEMPLO = json.loads((ROOT / 'data/exemplos/exemplo.json').read_text(encoding='utf-8'))
FIXTURE = ROOT / 'tests/fixtures/projeto_v1.json.gz'
ACW = {'ir_a': 320, 'isd_a': 1600, 'tsd_ms': 100, 'ii_a': 4400, 'i2t': 'OFF'}


def load():
    return Project(copy.deepcopy(EXEMPLO))


def legacy():
    return json.loads(gzip.decompress(FIXTURE.read_bytes()))


def pairs(p, name):
    return [x for x in curvas.coordination(p)['pares'] if x['circuito'] == name and x.get('aplicavel')]


def curve(p, modelo, text, ajustes=None, base_doc='Catálogo (ensaio)'):
    body = {'tipo': 'curva', 'fabricante': 'Ensaio', 'documento': base_doc, 'modelo': modelo, 'conteudo': text}
    if ajustes:
        body['ajustes'] = ajustes
    return curvas.import_data(p, body, 'Rev')


class F01EffectiveDevice(unittest.TestCase):
    def test_in_and_type_come_from_the_selected_model(self):
        p = load()
        d = curvas._device(p, 5, 'origem')  # QDFL-01, MDW-C80-2
        self.assertEqual(d['in'], 80.0)
        self.assertEqual(d['curva'], 'C')
        self.assertTrue(d['tipo'].startswith('Disjuntor_C'))
        self.assertTrue(any('500 A' in c and '80 A' in c for c in d['conflitos']))
        c = next(x for x in p.circuits() if x['name'] == 'QDFL-01')
        self.assertTrue(any(i['label'] == 'Dados do dispositivo da origem' for i in c['issues']))
        # Ponto de 10 × In da curva importada vira 800 A (e não 5.000 A).
        curve(p, 'MDW-C80-2', 'multiplo_in;t_min_s;t_max_s\n1,13;3600;\n10;0,005;0,02\n')
        item = curvas.listing(p)['itens'][0]
        full = next(x for x in p.meta['curvas'] if x['id'] == item['id'])
        env = curvas._envelope(full['pontos'], 't_max', curvas._scale(full, d))
        self.assertEqual(env[0][0], 800.0)

    def test_consistent_in_has_no_conflict(self):
        p = load()
        p.update([{'sheet': 'Cálc-Prot_Cabos', 'address': 'K5', 'value': 80}], validate_installation=False)
        self.assertEqual([c for c in curvas._device(p, 5, 'origem')['conflitos'] if 'In informado' in c], [])


class F02to04CurveComparison(unittest.TestCase):
    DOWN = 'corrente_a;t_min_s;t_max_s\n100;500;1000\n980;0,1;0,2\n1000;0,1;0,2\n1005;0,01;0,02\n10000;0,008;0,015\n'

    def test_missing_minimum_time_is_not_favorable_evidence(self):
        p = load()
        curve(p, 'ACW400H-ETS400-3', 'corrente_a;t_min_s;t_max_s\n100;;5000\n10000;;1\n', ACW)
        curve(p, 'MDW-C80-2', self.DOWN)
        x = pairs(p, 'QDFL-01')[0]
        self.assertNotEqual(x['nivel'], 'verificado')
        self.assertTrue(any('tempo mínimo' in d for d in x['detalhes']), x['detalhes'])

    def test_no_extrapolation_beyond_documented_points(self):
        p = load()
        curve(p, 'ACW400H-ETS400-3', 'corrente_a;t_min_s;t_max_s\n100;100;200\n200;50;100\n', ACW)
        curve(p, 'MDW-C80-2', 'corrente_a;t_min_s;t_max_s\n100;1;2\n200;0,5;1\n')
        x = pairs(p, 'QDFL-01')[0]
        self.assertEqual(x['nivel'], 'verificado')
        self.assertEqual(x['situacao'], 'limitada')
        self.assertEqual(x['limite_ka'], 0.2)
        self.assertTrue(any('só cobrem até 200' in d for d in x['detalhes']))

    def test_crossing_between_vertices_is_detected(self):
        p = load()
        up = 'corrente_a;t_min_s;t_max_s\n100;5000;6000\n500;100;300\n990;1;3\n995;0,1;0,3\n10000;0,05;0,1\n'
        curve(p, 'ACW400H-ETS400-3', up, ACW)
        curve(p, 'MDW-C80-2', self.DOWN)
        x = pairs(p, 'QDFL-01')[0]
        self.assertEqual(x['nivel'], 'verificado')
        self.assertEqual(x['situacao'], 'parcial')
        self.assertTrue(0.99 <= x['limite_ka'] <= 0.995, x['limite_ka'])
        # Em 997 A o montante (0,1 s) não está acima do jusante (0,2 s): conferência direta dos envelopes.
        u = curvas._envelope(curvas._usable(p)[0]['pontos'], 't_min', 1)
        d = curvas._envelope(curvas._usable(p)[1]['pontos'], 't_max', 1)
        self.assertLessEqual(curvas._at(u, 997, min), curvas._at(d, 997, max))

    def test_instantaneous_region_is_not_proven_by_curves(self):
        p = load()
        curve(p, 'ACW400H-ETS400-3', 'corrente_a;t_min_s;t_max_s\n100;5000;6000\n500;100;300\n2000;0,02;0,05\n4000;0,005;0,01\n10000;0,005;0,01\n', ACW)
        curve(p, 'MDW-C80-2', 'corrente_a;t_min_s;t_max_s\n100;500;1000\n800;0,001;0,004\n10000;0,001;0,002\n')
        x = pairs(p, 'QDFL-01')[0]
        self.assertEqual(x['situacao'], 'limitada')
        self.assertTrue(any('região instantânea' in d for d in x['detalhes']))


class F05Conditions(unittest.TestCase):
    HEAD = 'montante;jusante;limite_ka;tensao_v;ir_montante_a;isd_montante_a;tsd_montante_ms;ii_montante_a;i2t_montante\n'

    def imp(self, p, rows, **extra):
        return curvas.import_data(p, {'tipo': 'tabela_seletividade', 'fabricante': 'Ensaio', 'documento': 'Tabela (ensaio)',
                                      'conteudo': self.HEAD + rows, **extra}, 'Rev')

    def test_voltage_and_settings_must_match(self):
        p = load()
        with self.assertRaisesRegex(ValueError, 'tensão'):
            curvas.import_data(p, {'tipo': 'tabela_seletividade', 'fabricante': 'E', 'documento': 'Tabela (ensaio)',
                                   'conteudo': 'montante;jusante;limite_ka\nACW400H-ETS400-3;AGW100N-DX100-3;20\n'}, 'Rev')
        self.imp(p, 'ACW400H-ETS400-3;AGW100N-DX100-3;20;380;320;1600;100;4400;OFF\n')
        x = pairs(p, 'QDFL-02')[0]
        self.assertNotEqual(x['nivel'], 'verificado')
        self.assertTrue(any('220' in d and '380' in d for d in x['detalhes']))
        q = load()
        self.imp(q, 'ACW400H-ETS400-3;AGW100N-DX100-3;20;220;320;1600;100;4400;OFF\n')
        self.assertEqual(pairs(q, 'QDFL-02')[0]['situacao'], 'seletiva')
        # Mudar o Ir do montante retira a aplicabilidade do documento.
        q.update([{'sheet': 'Cálc-Prot_Cabos', 'address': 'Y4', 'value': 160}], validate_installation=False)
        x = pairs(q, 'QDFL-02')[0]
        self.assertNotEqual(x['nivel'], 'verificado')
        self.assertTrue(any('Ir do documento 320' in d for d in x['detalhes']), x['detalhes'])

    def test_adjustable_device_needs_declared_settings(self):
        p = load()
        curvas.import_data(p, {'tipo': 'tabela_seletividade', 'fabricante': 'E', 'documento': 'Tabela (ensaio)', 'tensao_v': '220',
                               'conteudo': 'montante;jusante;limite_ka\nACW400H-ETS400-3;AGW100N-DX100-3;20\n'}, 'Rev')
        x = pairs(p, 'QDFL-02')[0]
        self.assertNotEqual(x['nivel'], 'verificado')
        self.assertTrue(any('não informa o Ir' in d for d in x['detalhes']))

    def test_total_selectivity_is_limited_by_downstream_breaking_capacity(self):
        p = load()
        self.imp(p, 'ACW400H-ETS400-3;MDW-C80-2;T;220;320;1600;100;4400;OFF\n')
        x = pairs(p, 'QDFL-01')[0]
        self.assertEqual((x['nivel'], x['situacao'], x['limite_ka']), ('verificado', 'parcial', 5.0))


class F06SeriesPairs(unittest.TestCase):
    def test_origin_and_maintenance_breaker_pair(self):
        p = load()
        C = trecho.COL
        p.update([{'sheet': trecho.SHEET, 'address': f'{C[k]}4', 'value': v} for k, v in
                  dict(manut='SIM', mb_familia='ACW400H_630H', mb_modelo='ACW400H-ETS400-3', mb_ir=320, mb_ii=4400, mb_isd=1600, mb_tsd=100).items()],
                 validate_installation=False)
        q = pairs(p, 'QGBT-01')
        self.assertEqual([x['par'] for x in q], ['alimentacao', 'origem_manutencao'])
        inner = q[1]
        self.assertEqual(inner['dispositivo_montante']['posicao'], 'origem')
        self.assertEqual(inner['dispositivo_jusante']['posicao'], 'manutencao')
        self.assertEqual(pairs(p, 'QDFL-01')[0]['dispositivo_montante']['posicao'], 'manutencao')


class F07Migration(unittest.TestCase):
    def test_single_circuit_formula_change_is_preserved_with_scope(self):
        d = legacy()
        d['sheets']['Corrente nominal']['cells']['P5'] = {'value': 123456, 'formula': False}
        p = Project(d)
        self.assertEqual(p.get('Corrente nominal', 'P5'), 123456)
        self.assertAlmostEqual(load().get('Corrente nominal', 'P4'), p.get('Corrente nominal', 'P4'))
        rep = integridade.report(p)
        self.assertEqual(rep['problemas'], 1)
        self.assertEqual(rep['itens'][0]['circuito'], 'QDFL-01')
        self.assertEqual(rep['itens'][0]['escopo_versao'], 'circuito')

    def test_change_in_one_row_does_not_spread_to_all_circuits(self):
        d = legacy()
        c = d['sheets']['Corrente nominal']['cells']['P4']
        c['value'] = c['value'][:-1] + '*2)'
        p, ref = Project(d), load()
        self.assertAlmostEqual(p.get('Corrente nominal', 'P4'), 2 * ref.get('Corrente nominal', 'P4'))
        for r in (2, 3, 5, 6, 7):
            self.assertEqual(p.get('Corrente nominal', f'P{r}'), ref.get('Corrente nominal', f'P{r}'))
        self.assertEqual(p.meta['migracao']['formulas_particulares'], [{'variavel': 'corrente.i_r_a', 'circuito': 'QGBT-01'}])

    def test_unconvertible_formula_is_reported_not_dropped(self):
        d = legacy()
        d['sheets']['Corrente nominal']['cells']['P5']['value'] = "='Corrente nominal'!P40*2"  # referência a outra linha
        p = Project(d)
        pend = p.meta['migracao']['nao_convertidas']
        self.assertEqual([(x['variavel'], x['circuito']) for x in pend], [('corrente.i_r_a', 'QDFL-01')])
        self.assertEqual(integridade.report(p)['contagem']['conversao_pendente'], 1)
        from core import migracao
        migracao.acknowledge(p, 'corrente.i_r_a', pend[0]['circuito_id'], 'Rev', 'Fórmula antiga conferida e descartada.')
        self.assertEqual(integridade.report(p)['contagem']['conversao_pendente'], 0)

    def test_full_v1_history_is_preserved(self):
        d = legacy()
        cells = d['sheets']['Corrente nominal']['cells']
        orig = cells['P4']['value']
        v2 = orig[:-1] + '*1.5)'
        for r in range(2, 8):
            cells[f'P{r}']['value'] = cells[f'P{r}']['value'][:-1] + '*1.5)'
        d['meta']['formula_versions'] = {'corrente-nominal-P': {'ativa': 2, 'versoes': [
            {'versao': 1, 'template': orig[:-1] + '*1.2)', 'autor': 'Ana', 'ts': '2026-01-01T00:00:00', 'justificativa': 'Primeira edição.'},
            {'versao': 2, 'template': v2, 'autor': 'Bia', 'ts': '2026-02-01T00:00:00', 'justificativa': 'Segunda edição.'}]}}
        p = Project(d)
        slot = p.doc['formulas']['corrente.i_r_a']
        self.assertEqual([x['autor'] for x in slot['versoes']], ['Ana', 'Bia'])
        self.assertEqual(slot['ativa'], 2)
        self.assertEqual(integridade.formula_status(p, 'corrente.i_r_a'), 'editada')

    def test_unmodified_v1_project_converts_without_versions(self):
        p = Project(legacy())
        self.assertEqual(p.doc['formulas'], {})
        self.assertEqual(p.meta['migracao']['nao_convertidas'], [])


class F08BaseManifest(unittest.TestCase):
    def test_model_change_is_detected_and_compared(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / 'p.sqlite3', backup=False)
            self.assertIsInstance(store.project.doc.get('base'), dict)
            self.assertEqual(integridade.report(store.project)['contagem']['base_diferente'], 0)
            var = model().by_id['corrente.i_r_a']
            old = var.expr
            try:
                var.expr = '=777'
                store.project.engine.clear()
                store.project = Project(unpack(store.project.packed()))
                rep = integridade.report(store.project)
                self.assertEqual(rep['contagem']['base_diferente'], 1)
                self.assertIn('modelo.circuito', rep['itens'][-1]['componentes'])
                st = store.base_status()
                self.assertTrue(st['diferente'] and st['base_guardada'])
                self.assertTrue(any(c['circuito'] == 'QDFL-01' for c in st['resultados']))
                store.adopt_base('Rev')
                self.assertEqual(integridade.report(store.project)['contagem']['base_diferente'], 0)
                rec = store.project.meta['atualizacoes_base'][-1]
                self.assertEqual(rec['autor'], 'Rev')
                self.assertGreater(rec['circuitos_com_resultados_diferentes'], 0)
            finally:
                var.expr = old


class F09ManufacturerDataIntegrity(unittest.TestCase):
    def test_tampered_curve_is_flagged_and_not_used(self):
        p = load()
        curvas.import_data(p, {'tipo': 'tabela_seletividade', 'fabricante': 'E', 'documento': 'Tabela (ensaio)',
                               'conteudo': F05Conditions.HEAD + 'ACW400H-ETS400-3;AGW100N-DX100-3;2;220;320;1600;100;4400;OFF\n'}, 'Rev')
        self.assertEqual(pairs(p, 'QDFL-02')[0]['situacao'], 'parcial')
        self.assertEqual(integridade.report(p)['problemas'], 0)
        p.meta['curvas'][0]['linhas'][0]['limite_ka'] = 50  # alteração direta, fora do fluxo de revisão
        rep = integridade.report(p)
        self.assertEqual(rep['contagem']['fabricante_alterado'], 1)
        self.assertNotEqual(pairs(p, 'QDFL-02')[0]['nivel'], 'verificado')


class F10Variants(unittest.TestCase):
    VID = 'imp.reatancia_fase_a_montante'

    def test_common_edit_keeps_the_source_variant(self):
        p = load()
        root_before = p.get('Cálc_Imp-Cond_Escolhido', p.model.by_id[self.VID].col + '2')
        self.assertGreater(root_before, 0)
        v = p.model.by_id[self.VID]
        cat = Catalog(p)
        new = '=IFERROR(' + v.expr[1:] + ',0)'
        pv = cat.preview_edit(self.VID, new)
        self.assertIn('aviso_variante', pv)
        cat.commit_edit(p, self.VID, new, 'Rev', 'Ensaio do escopo comum da expressão.')
        self.assertEqual(p.get('Cálc_Imp-Cond_Escolhido', v.col + '2'), root_before)
        self.assertEqual(p.expression_scope(v, 2), 'raiz')
        # A variante só muda por versão própria.
        Catalog(p).commit_edit(p, self.VID, '=0', 'Rev', 'Ensaio da variante dos circuitos ligados à fonte.', escopo='raiz')
        self.assertEqual(p.get('Cálc_Imp-Cond_Escolhido', v.col + '2'), 0)
        self.assertEqual(integridade.report(Project(copy.deepcopy(p.doc)))['problemas'], 0)
        Catalog(p).rollback(p, self.VID, 0, 'Rev', escopo='raiz')
        self.assertEqual(p.get('Cálc_Imp-Cond_Escolhido', v.col + '2'), root_before)
        with self.assertRaises(CatalogError):
            Catalog(p).preview_edit('carga.p_total_w', '=1', escopo='raiz')


class F11OperationalTables(unittest.TestCase):
    def test_documentary_table_cannot_be_edited_as_if_it_fed_the_calculation(self):
        p = load()
        self.assertFalse(tabelas.usage('tab_nbr5410_t33')['operacional'])
        with self.assertRaisesRegex(ValueError, 'documental'):
            tabelas.edit(p, 'tab_nbr5410_t33', {'C7': 'A1'}, 'Rev', 'Ensaio da ligação entre dado e regra.', 'Ensaio')
        self.assertTrue(tabelas.usage('tab_impedancias')['operacional'])
        lst = tabelas.listing(p)
        self.assertTrue(lst['regras_operacionais'][0]['resumo'])
        self.assertIn('installation_rules', lst['regras_operacionais'][0]['arquivo'])


class F12DuplicateIds(unittest.TestCase):
    def test_duplicate_ids_and_names_are_refused(self):
        d = copy.deepcopy(EXEMPLO)
        d['circuitos'][4]['id'] = d['circuitos'][3]['id']
        with self.assertRaisesRegex(ValueError, 'se repete'):
            Project(d)
        d = copy.deepcopy(EXEMPLO)
        d['circuitos'][4]['entradas']['ident.nome'] = 'qdfl-01'
        with self.assertRaisesRegex(ValueError, 'se repete'):
            Project(d)


class F13PythonRules(unittest.TestCase):
    def test_every_rule_declares_results_or_effects_and_can_be_applied(self):
        p = load()
        cat = Catalog(p)
        for r in cat.list(limit=1)['regras_python']:
            self.assertTrue(r['resultados'] or r['efeitos'], r['id'])
            self.assertTrue(r['efeitos'], r['id'])
        sel = next(r for r in cat.list(limit=1)['regras_python'] if r['id'] == 'regra.selecao')
        self.assertGreater(sel['n_resultados'], 10)
        uid = p.meta['ids']['5']
        a = cat.rule_application('regra.coordenacao', uid)
        self.assertTrue(any('Montante × primeiro dispositivo' in e for e in a['efeitos']))
        a = cat.rule_application('regra.selecao', uid)
        self.assertTrue(a['resultados'])
        self.assertTrue(any(x['id'] == 'protecao.modelo' for x in a['resultados']))


class HttpV21(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        cls.server.store = Store(Path(cls.tmp.name) / 'p.sqlite3')
        cls.server.token = secrets.token_urlsafe(24); cls.server.lock = threading.RLock()
        cls.server.daemon_threads = True; cls.server.reviewer = None
        cls.base = f'http://127.0.0.1:{cls.server.server_port}'
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.client = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.tmp.cleanup()

    def get(self, path):
        return json.loads(self.client.open(self.base + path, timeout=120).read())

    def post(self, path, data=None):
        st = self.get('/api/state')
        req = urllib.request.Request(self.base + path, data=json.dumps(data or {}).encode(), method='POST', headers={
            'X-Eletro-Token': self.server.token, 'Content-Type': 'application/json',
            'X-Eletro-Project': st['project_id'], 'X-Eletro-Revision': str(st['revision'])})
        return json.loads(self.client.open(req, timeout=120).read())

    def test_scope_base_and_rule_endpoints(self):
        self.assertFalse(self.get('/api/base')['diferente'])
        uid = self.get('/api/state')['circuits'][3]['id']
        self.assertTrue(self.get(f'/api/rule?id=regra.selecao&circuito={uid}')['resultados'])
        self.post('/api/reviewer/unlock', {'nome': 'Rev', 'senha': 'segredo1'})
        vid = F10Variants.VID
        r = self.post('/api/formula/confirm', {'id': vid, 'expressao': '=0', 'justificativa': 'Ensaio do escopo raiz via HTTP.',
                                               'confirmado': True, 'escopo': 'raiz'})
        self.assertEqual(r['escopo'], 'raiz')
        e = self.get('/api/catalog/entry?id=' + vid)
        self.assertEqual([x['escopo'] for x in e['escopos']], ['raiz'])
        self.post('/api/formula/rollback', {'id': vid, 'versao': 0, 'escopo': 'raiz'})
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.post('/api/base/adopt')
        self.assertEqual(ctx.exception.code, 400)
        self.post('/api/reviewer/lock')


if __name__ == '__main__':
    unittest.main()

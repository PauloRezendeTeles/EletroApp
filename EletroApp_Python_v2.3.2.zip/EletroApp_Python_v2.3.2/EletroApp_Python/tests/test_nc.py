"""Condutores por polo (Nc): Nc=1 idêntico à r42; Nc>=2 aplica divisão de corrente."""
import sys,unittest,json,gzip,copy
from pathlib import Path
sys.path.insert(0,'.')
from core import nc_patch,installation as I
from core.project import Project

RAW=json.loads((Path(__file__).resolve().parents[1]/'data'/'exemplos'/'exemplo.json').read_text(encoding='utf-8'))
ROW=3  # QGBT-02: seção escolhida 240 mm², proteção comercial disponível

def build(nc=1,sec=None):
    p=Project(copy.deepcopy(RAW))
    for r in p.active_rows():
        st=p.installation.state(r,reconcile=True)
        for k,(s,c) in I.FIELDS.items():p.put(s,f'{c}{r}',st['values'][k])
        st=p.installation.state(r)
        g=st['group_options'][0]['value'] if st['group_options'] else None
        sp=st['spacing_options'][0] if st['spacing_options'] else None
        p.meta.setdefault('installation_settings',{})[p.meta['ids'][str(r)]]={'group':g,'spacing':sp,'depth':.7}
    p.put('Dados dos condutores ','D%d'%ROW,nc)
    if sec:p.put('Seleção-Seção_Condutor','T%d'%ROW,sec)
    p.engine.clear()
    return p

def g(p,sheet,col):
    v=p.get(sheet,f'{col}{ROW}')
    assert not isinstance(v,dict),(sheet,col,v)
    return v

class NcPatch(unittest.TestCase):
    def test_patch_idempotente(self):
        d=json.loads(gzip.decompress((Path(__file__).resolve().parent/'fixtures'/'projeto_v1.json.gz').read_bytes()))  # projeto da v1.x
        self.assertGreater(nc_patch.apply(d),0)
        self.assertEqual(nc_patch.apply(d),0)
    def test_nc1_formulas_equivalentes(self):
        """Com Nc=1 as fórmulas corrigidas dão o mesmo valor que as originais da r42."""
        a=build(1)
        orig=nc_patch.apply
        nc_patch.apply=lambda d:0
        try:b=build(1)
        finally:nc_patch.apply=orig
        for s,c in [('Cálc_Seç-Queda de tensão','N'),('Cálc_Seç-Queda de tensão','O'),('Cálc_Seç-Icc_Cond_Sugerido','G'),
                    ('Cálc_Seç-Icc_Cond_Sugerido','H'),('Corrente_Max-Cond_Escolhido','K'),('Corrente_Max-Cond_Sugerido','K'),
                    ('Temp_Operacional','J'),('Seleção-Seção_Condutor','S'),('Queda_Tens-Cond_Escolhido','U'),('Cálc-Prot_Cabos','AI')]:
            self.assertEqual(a.get(s,f'{c}{ROW}'),b.get(s,f'{c}{ROW}'),(s,c))

class Nc2(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p1=build(1,240);cls.p2=build(2,240)
    def test_iz_do_grupo_inclui_fator_unico(self):
        iz1=g(self.p1,'Corrente_Max-Cond_Escolhido','K');iz2=g(self.p2,'Corrente_Max-Cond_Escolhido','K')
        self.assertAlmostEqual(iz2,2*iz1*.8,delta=0.02) # dois conjuntos no mesmo conduto
        self.assertEqual(g(self.p2,'Cálc-Prot_Cabos','F'),iz2)
    def test_queda_secao_por_condutor(self):
        n1=g(self.p1,'Cálc_Seç-Queda de tensão','N');n2=g(self.p2,'Cálc_Seç-Queda de tensão','N')
        self.assertLess(n2,n1)
        self.assertGreaterEqual(n2,n1/2)  # a seção comercial é arredondada para cima
    def test_icc_dividida_por_nc(self):
        for p,nc in ((self.p1,1),(self.p2,2)):
            total=g(p,'Cálc_Icc-Cond_Sugerido','R');crit=g(p,'Cálc_Seç-Icc_Cond_Sugerido','G')
            self.assertAlmostEqual(crit,total/nc,places=6)
    def test_dimensiona_sem_travar(self):
        s=g(self.p2,'Seleção-Seção_Condutor','S')
        self.assertIsInstance(s,(int,float))
        self.assertLess(s,g(self.p1,'Seleção-Seção_Condutor','S'))
    def test_queda_trecho_conta_manual(self):
        """ΔV = √3·I_total·(R/Nc·cosφ + X/Nc·senφ)·100/V, com R e X já do feixe."""
        p=self.p2;s='Queda_Tens-Cond_Escolhido'
        F,G,H,I,M,N,E=[g(p,s,c) for c in 'FGHIMNE']
        self.assertAlmostEqual(g(p,s,'U'),F*(G*M+H*N)*I*100/E,delta=0.002)
        self.assertEqual(I,g(p,'Cálc-Prot_Cabos','D'))  # corrente total, não por condutor
    def test_temp_operacional_por_condutor(self):
        i2=g(self.p2,'Temp_Operacional','I');iz=g(self.p2,'Temp_Operacional','J')
        self.assertAlmostEqual(iz*2,g(self.p2,'Corrente_Max-Cond_Escolhido','K'),delta=0.02)
        self.assertLessEqual(g(self.p2,'Temp_Operacional','K'),1)
        self.assertAlmostEqual(i2*2,g(self.p2,'Cálc-Prot_Cabos','D'),delta=0.02)

class AvisosNorma(unittest.TestCase):
    def avisos(self,n,cabo,sec,mat='Cobre'):
        return Project.avisos_paralelo({'n_polo':n,'sec_f':sec},{'cable':cabo,'material':mat})
    def test_sem_paralelo_sem_alerta(self):
        self.assertEqual(self.avisos(1,'Cabo multipolar',95),[])
    def test_multipolar(self):
        refs=[a['ref'] for a in self.avisos(2,'Cabo multipolar',240)]
        self.assertIn('NBR 5410, 6.2.5.7.2 a',refs);self.assertIn('NBR 5410, 6.2.10.4',refs);self.assertIn('NBR 5410, 5.3.5.4',refs)
    def test_unipolar_ate_50_cobre(self):
        self.assertIn('NBR 5410, 6.2.5.7.2 b',[a['ref'] for a in self.avisos(2,'Condutores isolados',50)])
    def test_unipolar_acima_de_50_cobre(self):
        self.assertIn('NBR 5410, 6.2.5.7.2 c',[a['ref'] for a in self.avisos(2,'Cabo unipolar',95)])
    def test_aluminio_limite_70(self):
        self.assertIn('NBR 5410, 6.2.5.7.2 b',[a['ref'] for a in self.avisos(2,'Cabo unipolar',70,'Alumínio')])
        self.assertIn('NBR 5410, 6.2.5.7.2 c',[a['ref'] for a in self.avisos(2,'Cabo unipolar',95,'Alumínio')])

if __name__=='__main__':unittest.main()

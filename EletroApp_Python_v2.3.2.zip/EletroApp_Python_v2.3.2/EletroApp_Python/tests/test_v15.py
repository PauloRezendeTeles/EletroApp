import sys,unittest,urllib.request
sys.path.insert(0,'.')
import json
from pathlib import Path
from core.project import Project,esquema_ligacao,condutores_agrupados

class V15(unittest.TestCase):
    def test_esquema(self):
        self.assertEqual(esquema_ligacao('3F+N+T'),'3F+N+PE')
        self.assertEqual(esquema_ligacao('3F+PEN'),'3F+PEN')
    def test_condutores_agrupados(self):
        self.assertEqual(condutores_agrupados('3F+PEN',1,240,120,None),'1x{3#240mm²(PEN120mm²)}')
        self.assertEqual(condutores_agrupados('3F+N+T',1,240,120,120),'1x{3#240mm²(120mm²)PE120mm²}')
    def test_pen_usa_maior_entre_neutro_e_pe(self):
        self.assertEqual(condutores_agrupados('3F+PEN',1,240,70,120),'1x{3#240mm²(PEN120mm²)}')
        self.assertEqual(condutores_agrupados('3F+PEN',1,240,120,70),'1x{3#240mm²(PEN120mm²)}')

class Agrupamento(unittest.TestCase):
    def test_salvar_agrupamento_libera_ampacidade(self):
        import json
        from pathlib import Path
        from core.project import Project, unpack
        import gzip
        proj=Project(json.loads((Path(__file__).resolve().parents[1]/'data'/'exemplos'/'exemplo.json').read_text(encoding='utf-8')))
        c=next(x for x in proj.circuits() if x['name']=='QDFL-01')
        proj.meta['installation_settings'].pop(c['id'],None)  # o exemplo já traz o agrupamento definido
        inst=proj.installation.state(c['row'])
        self.assertIn('Escolha a disposição física do agrupamento.',inst['issues'])
        proj.update([],installation={'id':c['id'],'reference':inst['reference'],'settings':{'group':'feixe',
            'geometry_mode':'confirmed','geometry_signature':inst['geometry']['signature'],
            'other_units':int(inst['values']['circuits'])-1,'homogeneity':'similar'}})
        c2=next(x for x in proj.circuits() if x['name']=='QDFL-01')
        self.assertIsInstance(c2['iz'],(int,float))

class Aluminio(unittest.TestCase):
    def setUp(self):
        import gzip
        self.p=Project(json.loads((Path(__file__).resolve().parents[1]/'data'/'exemplos'/'exemplo.json').read_text(encoding='utf-8')))
        self.c=next(x for x in self.p.circuits() if x['name']=='QDFL-02')
    def ocup(self,**kw):
        from core.project import OCUPACAO_SHEET
        self.p.update([{'sheet':OCUPACAO_SHEET,'address':k,'value':v} for k,v in kw.items()])
    def al(self):
        return self.p.update([{'sheet':'Dados dos condutores ','address':f"F{self.c['row']}",'value':'Alumínio'}])
    def test_residencial_bloqueia(self):
        self.ocup(tipo='Residencial')
        self.assertIn('residenciais',self.p.aluminio_regras()[0])
        with self.assertRaises(ValueError):self.al()
    def test_bd4_bloqueia_qualquer_tipo(self):
        self.ocup(tipo='Industrial',densidade='BD4',qualificado='Sim')
        with self.assertRaises(ValueError):self.al()
    def test_sem_ocupacao_exige_informar(self):
        self.assertIn('informe o tipo de ocupação',self.p.aluminio_regras()[0])
        with self.assertRaises(ValueError):self.al()
    def test_comercial_exige_bd1_e_qualificados(self):
        self.ocup(tipo='Comercial',densidade='BD2',qualificado='Não')
        self.assertEqual(len(self.p.aluminio_regras()),2)
        self.ocup(densidade='BD1',qualificado='Sim')
        self.assertEqual(self.p.aluminio_regras(),[])
        self.assertEqual(self.p.aluminio_secao_minima('Comercial'),50)
    def test_industrial_permite_com_trafo(self):
        self.ocup(tipo='Industrial',densidade='BD1',qualificado='Sim')
        self.assertEqual(self.p.aluminio_regras(),[])
        self.assertEqual(self.p.aluminio_secao_minima('Industrial'),16)
        self.al()
        c=next(x for x in self.p.circuits() if x['name']=='QDFL-02')
        self.assertEqual(c['instalacao']['material'],'Alumínio')
    def test_cobre_nao_e_afetado(self):
        self.ocup(tipo='Residencial')
        self.assertEqual(self.c['instalacao']['material'],'Cobre')

if __name__=='__main__':unittest.main()

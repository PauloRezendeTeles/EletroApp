"""v2.0 — modelo nativo independente da planilha r42: variáveis nomeadas, estrutura
dinâmica de circuitos, base técnica versionada, coordenação em três níveis,
conversão de projetos antigos e invalidação seletiva do cálculo."""
import copy
import gzip
import json
import random
import secrets
import sqlite3
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from http.server import ThreadingHTTPServer
from app import Handler, Store, report
from core.project import Project, unpack
from core.catalog import Catalog
from core import curvas, integridade, selection, tabelas, historico
from core.motor import APP_VERSION, model

EXEMPLO = json.loads((ROOT / 'data/exemplos/exemplo.json').read_text(encoding='utf-8'))
FIXTURE = ROOT / 'tests/fixtures/projeto_v1.json.gz'
IDENT = 'Identificação dos circuitos'


def load():
    return Project(copy.deepcopy(EXEMPLO))


def ch(sheet, address, value):
    return {'sheet': sheet, 'address': address, 'value': value}


def snapshot(p):
    out = {}
    for v in p.model.circuit:
        if v.kind == 'formula':
            for r in p.active_rows():
                out[(v.id, r)] = p.get(v.sheet, f'{v.col}{r}')
    for v in p.model.fonte + p.model.project:
        if v.kind == 'formula':
            out[(v.id, None)] = p.get(v.sheet, v.addr)
    return out


def same(a, b):
    if isinstance(a, float) and isinstance(b, float):
        return abs(a - b) <= 1e-9 * max(1, abs(a))
    return a == b


class Independence(unittest.TestCase):
    def test_no_spreadsheet_in_the_application(self):
        for path in ('data/r42.json.gz', 'data/formula_catalog.json', 'referencia', 'docs/conferencia_r42.csv'):
            self.assertFalse((ROOT / path).exists(), path)
        doc = load().doc
        self.assertEqual(doc['formato'], 'eletroapp-projeto')
        self.assertNotIn('sheets', doc)
        self.assertNotIn('sheets', EXEMPLO)
        # O exemplo guarda só dados de entrada: nenhuma expressão.
        self.assertEqual(EXEMPLO['formulas'], {})
        for c in EXEMPLO['circuitos']:
            for vid in c['entradas']:
                self.assertEqual(model().by_id[vid].kind, 'entrada', vid)

    def test_model_variables_have_names_units_and_dependencies(self):
        m = model()
        self.assertGreater(len(m.circuit), 1000)
        ids = [v.id for v in m.by_id.values()]
        self.assertEqual(len(ids), len(set(ids)))
        p = load()
        t = Catalog(p).trace(p.meta['ids']['4'], 'corrente.i_r_a')
        self.assertTrue(all(x['ref'] in m.by_id or x['tipo'] in ('tabela', 'nome') for x in t['precedentes']))
        self.assertEqual(t['unidade'], m.by_id['corrente.i_r_a'].unit)

    def test_python_rules_are_traceable(self):
        rules = Catalog(load()).list(limit=1)['regras_python']
        grp = next(r for r in rules if r['id'] == 'regra.agrupamento')
        self.assertTrue(grp['resultados'] and grp['parametros'])
        self.assertEqual(grp['versao'], APP_VERSION)
        self.assertTrue(grp['refs_normativas'])


class DynamicStructure(unittest.TestCase):
    def test_more_than_100_circuits(self):
        p = load()
        for i in range(100):
            p.add(f'C-{i:03d}', 'QDFL-01' if i % 2 else 'QGBT-01', reselect=False)
        selection.apply(p)
        self.assertEqual(len(p.active_rows()), 106)
        cs = p.circuits()
        last = cs[-1]
        self.assertEqual(last['row'], 107)
        self.assertIsInstance(last['ib'], (int, float))
        self.assertIsInstance(last['icc_max'], (int, float))
        # Vetores alcançam todos os circuitos (o QDFL-01 alimenta 50 deles além dos existentes).
        filhos = p.get('Dispositivos_Trecho', p.model.by_id['trecho.filhos'].col + '5')
        self.assertEqual(filhos, 50)
        self.assertEqual(load().summary()['capacity'], None)

    def test_no_fixed_entrance_positions_and_several_roots(self):
        p = load()
        # QGBT-01 passa a ser alimentado direto pelo transformador; ramal e medição deixam de existir.
        p.update([ch(IDENT, 'D4', 'Transformador')], validate_installation=False)
        p.delete(p.meta['ids'][str(p.active_rows()[1])])  # QM-01
        p.delete(p.meta['ids'][str(p.active_rows()[0])])  # Ramal de entrada
        names = [x['name'] for x in p.circuits()]
        self.assertEqual(names[0], 'QGBT-01')
        c = p.circuits()[0]
        self.assertEqual(c['parent'], 'Transformador')
        self.assertIsInstance(c['icc_max'], (int, float))
        self.assertGreater(c['icc_max'], load().circuits()[2]['icc_max'], 'sem os cabos de entrada, o Ik no QGBT aumenta')
        # Um circuito com carga própria ligado diretamente à fonte, em qualquer posição.
        uid = p.add('Bomba externa', 'Transformador')
        r = p.row_for(uid)
        p.update([ch('Levantamento de carga', f'D{r}', 3000)], validate_installation=False)
        x = next(c for c in p.circuits() if c['id'] == uid)
        self.assertEqual(x['parent'], 'Transformador')
        self.assertAlmostEqual(x['p_w'], 3000)
        self.assertIsInstance(x['ib'], (int, float))
        self.assertGreater(x['ib'], 0)

    def test_identity_survives_reordering(self):
        p = load()
        uid = p.meta['ids']['7']  # QDFL-03
        p.update([ch(IDENT, 'D7', 'QM-01')], validate_installation=False)
        self.assertEqual(p.raw(IDENT, f'B{p.row_for(uid)}'), 'QDFL-03')

    def test_selective_invalidation_matches_full_recalculation(self):
        p = load()
        for i in range(12):
            p.add(f'X-{i}', 'QDFL-02', reselect=False)
        selection.apply(p)
        random.seed(7)
        for _ in range(5):
            r = random.choice(p.active_rows()[3:])
            p.update([ch('Levantamento de carga', f'D{r}', random.randint(100, 9000)),
                      ch('Dados dos circuitos', f'F{r}', random.randint(5, 80))], validate_installation=False)
            selection.apply(p)
            p.circuits()
        a, b = snapshot(p), snapshot(Project(copy.deepcopy(p.doc)))
        self.assertEqual([k for k in a if not same(a[k], b[k])], [])
        q = p.fork()
        q.update([ch('Levantamento de carga', 'D5', 4321)], validate_installation=False)
        self.assertNotEqual(q.get('Carga nos circuitos', 'Y5'), p.get('Carga nos circuitos', 'Y5'))
        c, d = snapshot(q), snapshot(Project(copy.deepcopy(q.doc)))
        self.assertEqual([k for k in c if not same(c[k], d[k])], [])


class TechnicalBase(unittest.TestCase):
    def test_every_table_has_source_edition_and_conditions(self):
        listing = tabelas.listing(load())['tabelas']
        self.assertEqual(len(listing), 35)  # v2.2.0: 17 tabelas novas (antes escritas em fórmulas e código, ou de critérios novos)
        for t in listing:
            self.assertTrue(t['fonte'], t['id'])
            self.assertIn(t['categoria'], tabelas.CATEGORIES)
            # v2.2.0: revisão 2 nas tabelas corrigidas ou reorganizadas na auditoria; 1 nas demais e nas novas.
            self.assertIn(t['revisao_base'], (1, 2), t['id'])
            self.assertIn(t['situacao_fonte'], tabelas.SITUATIONS)
        amp = next(t for t in listing if t['id'] == 'tab_ampacidade_3c')
        self.assertIn('NBR5410-T36', [r['id'] for r in amp['refs_detalhe']])
        weg = next(t for t in listing if t['id'] == 'tab_weg_protecoes')
        self.assertEqual(weg['origem_por_linha'], ['W', 'X'])

    def test_edit_restore_seal_and_gate(self):
        p = load()
        before = p.get('Cálc-Prot_Cabos', 'K4')
        with self.assertRaisesRegex(ValueError, 'Justificativa'):
            tabelas.edit(p, 'tab_secao_pe', {'B10': 50}, 'Rev', 'curta', 'NBR 5410 Tabela 58')
        with self.assertRaisesRegex(ValueError, 'fonte'):
            tabelas.edit(p, 'tab_secao_pe', {'B10': 50}, 'Rev', 'Ajuste de ensaio documentado.', '')
        with self.assertRaisesRegex(ValueError, 'cabeçalhos'):
            tabelas.edit(p, 'tab_secao_pe', {'A1': 'x'}, 'Rev', 'Ajuste de ensaio documentado.', 'Ensaio')
        old = p.raw('tab_secao_pe', 'B10')
        r = tabelas.edit(p, 'tab_secao_pe', {'B10': '50,0'}, 'Rev', 'Ajuste de ensaio documentado.', 'Memorial de ensaio, rev. A')
        self.assertEqual(r['versao'], 1)
        self.assertEqual(p.raw('tab_secao_pe', 'B10'), 50.0)
        self.assertEqual(integridade.table_status(p, 'tab_secao_pe'), 'tabela_editada')
        reloaded = Project(unpack(p.packed()))
        self.assertEqual(integridade.report(reloaded)['problemas'], 0)
        view = tabelas.view(reloaded, 'tab_secao_pe', 1, 30)
        cell = view['linhas_def'][9]['celulas'][1]
        self.assertTrue(cell['editada'])
        self.assertEqual(cell['base'], old)
        # Edição fora do aplicativo é detectada.
        tampered = copy.deepcopy(reloaded.doc)
        tampered['tabelas']['tab_secao_pe']['celulas']['B10'] = {'v': 70}
        self.assertEqual(integridade.table_status(Project(tampered), 'tab_secao_pe'), 'tabela_alterada')
        tabelas.restore(reloaded, 'tab_secao_pe', 'Rev', 'Volta à base.')
        self.assertEqual(reloaded.raw('tab_secao_pe', 'B10'), old)
        self.assertIsNone(integridade.table_status(reloaded, 'tab_secao_pe'))
        self.assertEqual(len(reloaded.doc['tabelas']['tab_secao_pe']['versoes']), 2)
        # Texto em célula numérica é recusado; apagar a tabela de ampacidade cria erros obrigatórios: bloqueado.
        q = load()
        with self.assertRaisesRegex(ValueError, 'número'):
            tabelas.edit(q, 'tab_ampacidade_3c', {'B5': 'abc'}, 'Rev', 'Ensaio de bloqueio por erro.', 'Ensaio')
        t = q.model.tables['tab_ampacidade_3c']
        cells = {a: None for a in t.cells if int(''.join(x for x in a if x.isdigit())) >= 3}
        with self.assertRaisesRegex(ValueError, 'bloqueada'):
            tabelas.edit(q, 'tab_ampacidade_3c', dict(list(cells.items())[:500]), 'Rev', 'Ensaio de bloqueio por erro.', 'Ensaio')
        self.assertEqual(load().get('Cálc-Prot_Cabos', 'K4'), before)
        self.assertIn('Base técnica utilizada', report(p))


class Coordination(unittest.TestCase):
    # Condições declaradas (tensão e ajustes do montante ajustável) — dados sintéticos de ensaio, não de fabricante.
    TABLE = ('montante;jusante;limite_ka;tensao_v;ir_montante_a;isd_montante_a;tsd_montante_ms;ii_montante_a;i2t_montante\n'
             'ACW400H-ETS400-3;MDW-C80-2;T;220;320;1600;100;4400;OFF\n'
             'ACW400H-ETS400-3;AGW100N-DX100-3;3,5;220;320;1600;100;4400;OFF\n')

    def test_levels_and_manufacturer_data(self):
        p = load()
        c = curvas.coordination(p)
        by = {x['circuito']: x for x in c['pares']}
        # v2.3: o par MT × primeiro disjuntor passa a existir, sem dados inventados.
        self.assertTrue(by['Ramal de entrada']['aplicavel'])
        self.assertEqual(by['Ramal de entrada']['nivel'],'sem_dados')
        self.assertEqual(by['QDFL-01']['nivel'], 'aproximado')
        self.assertEqual(c['contagem']['verificado'], 0, 'sem dados importados, nada é “verificado”')
        with self.assertRaisesRegex(ValueError, 'documento'):
            curvas.import_data(p, {'tipo': 'tabela_seletividade', 'fabricante': 'WEG', 'documento': '', 'conteudo': self.TABLE}, 'Rev')
        curvas.import_data(p, {'tipo': 'tabela_seletividade', 'fabricante': 'WEG', 'documento': 'Guia de seletividade (ensaio)',
                               'edicao': '2025', 'pagina': '12', 'conteudo': self.TABLE}, 'Rev')
        by = {x['circuito']: x for x in curvas.coordination(p)['pares']}
        self.assertEqual(by['QDFL-01']['nivel'], 'verificado')
        # T = seletividade até a capacidade de interrupção do jusante (Icu 5 kA do MDW-C80-2 < Ik 8,93 kA no QGBT).
        self.assertEqual(by['QDFL-01']['situacao'], 'parcial')
        self.assertEqual(by['QDFL-01']['limite_ka'], 5.0)
        self.assertIn('Guia de seletividade', by['QDFL-01']['fonte'])
        self.assertEqual(by['QDFL-02']['nivel'], 'verificado')
        self.assertEqual(by['QDFL-02']['situacao'], 'parcial')  # 3,5 kA < Ik no QGBT
        self.assertEqual(by['QDFL-03']['nivel'], 'aproximado')
        self.assertIn('Verificado com dados do fabricante', report(p))

    def test_time_current_curves(self):
        p = load()
        up = 'corrente_a;t_min_s;t_max_s\n116;5000;6000\n400;1000;3000\n1000;60;200\n1300;0,1;0,2\n20000;0,08;0,15\n'
        down = 'multiplo_in;t_min_s;t_max_s\n1,13;3600;\n1,45;;3600\n5;0,5;10\n10;0,005;0,02\n300;0,003;0,01\n'
        with self.assertRaisesRegex(ValueError, 'Cabeçalho'):
            curvas.import_data(p, {'tipo': 'curva', 'fabricante': 'WEG', 'documento': 'Catálogo X', 'modelo': 'MDW-C80-2',
                                   'conteudo': 'i;t\n1;2\n'}, 'Rev')
        curvas.import_data(p, {'tipo': 'curva', 'fabricante': 'WEG', 'documento': 'Catálogo ACW (ensaio)', 'modelo': 'ACW400H-ETS400-3',
                               'conteudo': up, 'ajustes': {'ir_a': 320, 'isd_a': 1600, 'tsd_ms': 100, 'ii_a': 4400, 'i2t': 'OFF'}}, 'Rev')
        curvas.import_data(p, {'tipo': 'curva', 'fabricante': 'WEG', 'documento': 'Catálogo MDW (ensaio)', 'modelo': 'MDW-C80-2', 'conteudo': down}, 'Rev')
        by = {x['circuito']: x for x in curvas.coordination(p)['pares']}
        x = by['QDFL-01']
        self.assertEqual(x['nivel'], 'verificado')
        # Jusante em múltiplos de In = 80 A (o In do modelo, não o campo antigo de 500 A): envelopes separados até Ik = 8,93 kA.
        self.assertEqual(x['situacao'], 'seletiva')
        self.assertIsNone(x['limite_ka'])
        self.assertIn('Catálogo MDW', x['fonte'])
        item = curvas.listing(p)['itens'][0]
        curvas.delete(p, item['id'])
        self.assertEqual(len(curvas.listing(p)['itens']), 1)


class LegacyStore(unittest.TestCase):
    def test_legacy_database_project_is_converted_with_history(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'p.sqlite3'
            legacy = gzip.compress(gzip.decompress(FIXTURE.read_bytes()))
            with sqlite3.connect(path) as db:
                db.execute('CREATE TABLE projects (id TEXT PRIMARY KEY, name TEXT NOT NULL, data BLOB NOT NULL, updated TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)')
                db.execute('CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT)')
                db.execute("INSERT INTO projects(id,name,data) VALUES('old','Antigo',?)", (legacy,))
                db.execute("INSERT INTO settings(key,value) VALUES('active','old')")
            store = Store(path)
            self.assertEqual(store.active_id, 'old')
            self.assertEqual(store.project.doc['formato'], 'eletroapp-projeto')
            hist = store.history()
            self.assertEqual(hist[0]['resumo'], 'Conversão para o modelo nativo (EletroApp 2.0)')
            self.assertEqual(len(hist), 2)
            cmp = store.compare(hist[1]['revisao'], hist[0]['revisao'])
            self.assertEqual(cmp['n_entradas'], 0)
            self.assertIsNone(cmp['resultados'])
            self.assertFalse(cmp['comparacao_completa'])  # a revisão v1.x não identifica a base histórica
            store.transactional(lambda p: p.update([ch('Levantamento de carga', 'D5', 1234)], validate_installation=False), summary='x')
            self.assertEqual(store.history()[0]['tipo'], 'delta')
            self.assertEqual(store.reconstruct(store.revision)['circuitos'][3]['entradas']['cargas.p_r_w'], 1234)
            self.assertTrue(list((Path(tmp) / 'backups').glob('*antes-conversao-v2*.sqlite3')))
            # Restaurar a revisão da v1.x devolve o projeto já convertido.
            store.restore(hist[1]['revisao'])
            self.assertEqual(store.project.doc['formato'], 'eletroapp-projeto')


class HttpV20(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        cls.server.store = Store(Path(cls.tmp.name) / 'p.sqlite3')
        cls.server.token = secrets.token_urlsafe(24); cls.server.lock = threading.RLock()
        cls.server.daemon_threads = True; cls.server.reviewer = None
        cls.base = f'http://127.0.0.1:{cls.server.server_port}'
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.client = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.tmp.cleanup()

    def get(self, path):
        return json.loads(self.client.open(self.base + path, timeout=120).read())

    def post(self, path, data=None):
        st = self.get('/api/state')
        req = urllib.request.Request(self.base + path, data=json.dumps(data or {}).encode(), method='POST', headers={
            'X-Eletro-Token': self.server.token, 'Content-Type': 'application/json',
            'X-Eletro-Project': st['project_id'], 'X-Eletro-Revision': str(st['revision'])})
        return json.loads(self.client.open(req, timeout=120).read())

    def status(self, *a):
        try:
            self.post(*a)
            return 200
        except urllib.error.HTTPError as e:
            return e.code

    def test_reviewer_gated_table_and_curve_endpoints(self):
        body = {'id': 'tab_in_comercial', 'celulas': {'A5': 21}, 'justificativa': 'Corrente nominal de ensaio.', 'fonte': 'Catálogo de ensaio p. 3'}
        self.assertEqual(self.status('/api/table/edit', body), 403)
        self.post('/api/reviewer/unlock', {'nome': 'Rev', 'senha': 'segredo1'})
        r = self.post('/api/table/edit', body)
        self.assertEqual(r['versao'], 1)
        t = self.get('/api/table?id=tab_in_comercial&count=10')
        self.assertTrue(t['linhas_def'][4]['celulas'][0]['editada'])
        self.assertEqual(self.get('/api/state')['integridade']['problemas'], 0)
        self.post('/api/table/restore', {'id': 'tab_in_comercial'})
        imp = self.post('/api/curves/import', {'tipo': 'tabela_seletividade', 'fabricante': 'WEG', 'documento': 'Guia (ensaio)',
                                               'conteudo': Coordination.TABLE})
        self.assertTrue(imp['id'])
        coord = self.get('/api/coordination')
        self.assertEqual(coord['contagem']['verificado'], 2)
        self.post('/api/curves/delete', {'id': imp['id']})
        self.assertEqual(self.get('/api/coordination')['contagem']['verificado'], 0)
        hist = self.get('/api/history')['revisoes']
        self.assertIn('Dados do fabricante removidos', hist[0]['resumo'])
        cmp = self.get(f"/api/history/compare?a={hist[3]['revisao']}&b={hist[2]['revisao']}")
        self.assertTrue(cmp['tabelas'])
        self.post('/api/reviewer/lock')

    def test_z_new_blank_project_and_import_of_spreadsheet_is_refused(self):
        self.post('/api/projects/new', {'name': 'Branco', 'blank': True})
        st = self.get('/api/state')
        self.assertEqual([c['name'] for c in st['circuits']], ['Ramal de entrada', 'QM-01'])
        self.assertIsNone(st['capacity'])
        req = urllib.request.Request(self.base + '/api/import', data=b'PK\x03\x04', method='POST', headers={
            'X-Eletro-Token': self.server.token, 'X-Filename': 'planilha.xlsx'})
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.client.open(req, timeout=60)
        self.assertEqual(ctx.exception.code, 400)
        self.assertIn('.eletro', json.loads(ctx.exception.read())['error'])


if __name__ == '__main__':
    unittest.main()

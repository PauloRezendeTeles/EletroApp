"""v2.2.0: base técnica conferida com a NBR 5410:2004 e a NBR 5419:2026.

Um teste por correção da base (achados E e C), os critérios novos (achados I), a vista normativa da Base técnica,
a conferência guiada e a conversão de projetos antigos sem falsos alertas.
"""
import copy
import gzip
import json
import secrets
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import Handler, Store, example_data  # noqa: E402
from core.project import Project, unpack  # noqa: E402
from core.motor import model  # noqa: E402
from core.installation import METHOD_RENAMES, RULES, catalogs, migrate_inputs  # noqa: E402
from core import grouping, normativa, selection, topologia  # noqa: E402
from core.catalog import normref_registry  # noqa: E402


def load():
    return Project(copy.deepcopy(example_data()))


def legacy():
    return json.loads(gzip.decompress((ROOT / 'tests/fixtures/projeto_v1.json.gz').read_bytes()))


def cell(tid, a):
    c = model().tables[tid].cells.get(a)
    return None if c is None else c.get('v', c.get('f'))


def val(p, vid, r=None):
    v = p.model.by_id[vid]
    return p.get(v.sheet, f'{v.col}{r}' if v.scope == 'circuito' else v.addr)


def put(p, vid, r, value):
    v = p.model.by_id[vid]
    p.put(v.sheet, f'{v.col}{r}' if v.scope == 'circuito' else v.addr, value)
    p.engine.clear()


def row(p, name):
    return next(r for r in p.active_rows() if p.get('Identificação dos circuitos', f'B{r}') == name)


class BaseCorrections(unittest.TestCase):
    """Valores da base técnica corrigidos (cada um com a página do exemplar da NBR 5410)."""

    def test_e1_e11_tabelas_37_e_39_630mm2(self):
        self.assertEqual(cell('tab_ampacidade_2c', 'P5'), 1196)   # Tabela 39, E, 2 condutores, cobre EPR/XLPE (p. 105)
        self.assertEqual(cell('tab_ampacidade_2c', 'N5'), 1122)   # Tabela 37, C, 2 condutores, cobre EPR/XLPE (p. 102)
        self.assertLess(cell('tab_ampacidade_2c', 'P5'), cell('tab_ampacidade_2c', 'P4'))  # 630 mm² < 800 mm²

    def test_e3_fh_tabela_f1_acima_de_66(self):
        self.assertEqual(cell('tab_secao_neutro', 'E18'), 1.73)
        self.assertEqual(cell('tab_secao_neutro', 'E19'), 1.73)

    def test_e16_fh_por_faixa_e_nao_por_valor_exato(self):
        p = load();r = row(p, 'QGBT-01')
        for taxa, fh in ((0, 1), (20, 1), (34, 1.15), (38, 1.19), (44, 1.24), (48, 1.35), (53, 1.45), (58, 1.55), (63, 1.64), (70, 1.73)):
            with self.subTest(taxa=taxa):
                put(p, 'dados.taxa_de_3o_hamonico', r, taxa)
                self.assertEqual(val(p, 'amp_corrente.fc_3oh', r), fh)

    def test_c2_tabela_48_termina_em_400(self):
        self.assertIsNone(cell('tab_secao_neutro', 'A22'))
        self.assertEqual(cell('tab_secao_neutro', 'A21'), 400)
        self.assertEqual(model().names['Neutro_Reduzido'], 'tab_secao_neutro!$A$2:$B$21')

    def test_e10_correntes_convencionais_por_norma_de_produto(self):
        for r in range(9, 15):
            self.assertEqual((cell('tab_disjuntores_ref', f'D{r}'), cell('tab_disjuntores_ref', f'E{r}')), (1.13, 1.45))
        for r in range(15, 20):
            self.assertEqual((cell('tab_disjuntores_ref', f'D{r}'), cell('tab_disjuntores_ref', f'E{r}')), (1.05, 1.3))
        self.assertEqual((cell('tab_disjuntores_ref', 'A20'), cell('tab_disjuntores_ref', 'D20'), cell('tab_disjuntores_ref', 'E20')),
                         ('Fusível_gG - In <= 4A', 1.5, 2.1))
        self.assertEqual((cell('tab_disjuntores_ref', 'D21'), cell('tab_disjuntores_ref', 'E21')), (1.5, 1.9))

    def test_e8_siemens_uc_e_up_nas_colunas_certas(self):
        for r in range(2, 21):
            uc, up = str(cell('tab_dps_siemens', f'K{r}')), str(cell('tab_dps_siemens', f'L{r}'))
            with self.subTest(r=r):
                self.assertTrue(uc == '—' or ' V' in uc and 'kV' not in uc, uc)
                self.assertIn('kV', up)
        p = load();t = p.model.tables['tab_dps_siemens']
        self.assertEqual((p.get(t.legacy, 'W6'), p.get(t.legacy, 'X6')), (350, 1.5))  # 5SD7 443-1

    def test_e8_iimp_e_in_por_polo_lidos_do_catalogo(self):
        p = load();s = p.model.tables['tab_dps_siemens'];c = p.model.tables['tab_dps_clamper']
        self.assertEqual(p.get(s.legacy, 'Y6'), 25)    # 75 kA total (25 kA por polo)
        self.assertEqual(p.get(s.legacy, 'Y2'), 25)    # 25 kA/polo (100 kA combinado)
        self.assertEqual(p.get(s.legacy, 'Z15'), 20)   # 20 kA por fase
        self.assertEqual(p.get(c.legacy, 'Z12'), 6)    # 6 kA por modo (12 kA total)
        self.assertEqual(p.get(s.legacy, 'Y8'), '')    # 12,5 kA; 50 kA combinado: sem valor único
        r = row(p, 'Ramal de entrada')
        item = next(x for x in selection.dps_catalog(p, r) if x['modelo'] == '5SD7 443-1')
        self.assertEqual(item['corrente'], val(p, 'dps.iimp_in_real_do_modelo_ativo_ka', r))  # seleção e fórmula leem o mesmo valor
        names = {c['letra']: c['nome'] for c in s.columns}
        for col in 'WXYZ':  # a linha 1 da aba de origem repete o nome da coluna
            self.assertEqual(s.cells[col + '1']['v'], names[col])
        self.assertIn('por polo/modo', names['Y'])
        self.assertEqual(normativa.correction_for(s, 'Y1')['achado'], 'E8')

    def test_e13_extensao_da_tabela_45_limitada_a_080(self):
        multi = RULES['group_duct_multi']
        self.assertEqual(multi[4][3], 0.8)  # 6 circuitos, 1,0 m (Tabela 45, p. 110)
        self.assertTrue(all(r[3] <= 0.8 for r in multi[5:]))

    def test_tabela_42_um_valor_para_9_ou_mais_circuitos(self):
        # Página 108: nas linhas 2 a 5, a célula do fator abrange de “9 a 11” a “≥ 20” — valor da NBR, não extensão.
        for key, value in (('parede', 0.7), ('teto', 0.61), ('bandeja', 0.72), ('leito', 0.78)):
            self.assertEqual(RULES['group_air'][key][8:], [value] * 4)
        self.assertNotIn('air_extension', RULES['grouping_sources'])
        rows = grouping.consultation(RULES)['rows']
        self.assertFalse(any(r['extensao'] for r in rows if r['table'] == '42'))
        self.assertTrue(all(r['extensao'] for r in rows if r['table'] in ('15', '16', '17')))

    def test_tabela_41_e_extensoes_do_solo(self):
        soil = {x['resistividade']: x for x in grouping.consultation(RULES)['soil']}
        self.assertEqual([soil[k]['dutos'] for k in (1, 1.5, 2, 2.5, 3)], [1.18, 1.1, 1.05, 1.0, 0.96])
        self.assertFalse(soil[1]['extensao_dutos']);self.assertTrue(soil[0.5]['extensao_dutos']);self.assertTrue(soil[1]['extensao_direto'])

    def test_c4_bitola_336_4_kcmil(self):
        self.assertEqual(cell('tab_ampacidade_2c', 'AN10'), 336.4)
        self.assertEqual(cell('tab_ampacidade_3c', 'AZ10'), 336.4)

    def test_c5_impedancias_com_quatro_algarismos(self):
        self.assertEqual(cell('tab_impedancias', 'B5'), 14.48)  # 1,5 mm² Cu: 12,1 Ω/km × [1 + 0,00393 × (70 − 20)]

    def test_c1_bloco_de_agrupamento_antigo_removido(self):
        t = model().tables['tab_fatores_correcao']
        self.assertFalse([a for a in t.cells if a[0] in 'ABCDEFGHIJK' and a[1:].isdigit() and int(a[1:]) <= 10 and len(a) <= 3])

    def test_c10_forro_falso_e_piso_elevado_sao_metodo_21(self):
        lines = [x for x in RULES['lines'] if x['name'].startswith('Forro falso ou piso elevado')]
        self.assertEqual({v['method'] for x in lines for v in x['variants']}, {'21_1,5-5De', '21_5-50De'})
        self.assertTrue(all('28_' + str(v['method']).split('_', 1)[1] in v['method_aliases'] for x in lines for v in x['variants']))
        self.assertEqual(METHOD_RENAMES, {'28_1,5-5De': '21_1,5-5De', '28_5-50De': '21_5-50De'})
        doc = copy.deepcopy(example_data());c = doc['circuitos'][5]
        c['entradas']['metodo.nro_do_metodo_de_instalacao'] = '28_5-50De'
        self.assertEqual(migrate_inputs(doc)[0]['para'], '21_5-50De')
        self.assertEqual(c['entradas']['metodo.nro_do_metodo_de_instalacao'], '21_5-50De')
        self.assertEqual(doc['meta']['migracoes_entradas'][0]['versao'], '2.2.0')

    def test_c12_notas_da_tabela_33_junto_do_metodo(self):
        methods = {m['codigo']: m for m in catalogs()[0]}
        self.assertTrue(any('NBR 11301' in n for n in methods['63']['notas']))
        self.assertTrue(any('6.2.11.4.1' in n for n in methods['12']['notas']))
        self.assertTrue(any('6.2.11.6.1' in n for n in methods['61A']['notas']))
        self.assertTrue(any('verticais' in n for n in methods['13_Cabo multipolar']['notas']))
        self.assertFalse(methods['31']['notas'])
        self.assertEqual(model().tables['tab_nbr5410_t33'].columns[4]['nome'], 'Notas da Tabela 33 (resumo)')

    def test_correcoes_registradas_por_celula(self):
        p = load()
        prev = normativa.previous(p, 'tab_ampacidade_2c')
        self.assertEqual(prev['P5'], [1936])
        t = p.model.tables['tab_ampacidade_2c']
        self.assertEqual(normativa.correction_for(t, 'P5')['achado'], 'E1')
        self.assertEqual(normativa.correction_for(p.model.tables['tab_secao_neutro'], 'E19')['achado'], 'E3')
        self.assertEqual(normativa.correction_for(p.model.tables['tab_disjuntores_ref'], 'AA9')['achado'], 'E10')  # entrada “*”

    def test_regra_do_pen_cita_os_itens_certos(self):
        reg = normref_registry()
        self.assertIn('6.4.3.4.1', reg['NBR5410-6.4.3.4']['condicoes'][0])
        self.assertEqual((reg['NBR5410-6.4.3.4']['pagina'], reg['NBR5410-5.6.2.2']['pagina']), ('p. 151', 'p. 73'))
        self.assertIn('TN-C-S', reg['NBR5410-5.4.3.6']['condicoes'][0])
        src = Path(topologia.__file__).read_text(encoding='utf-8')
        self.assertIn('6.4.3.4.1', src);self.assertIn('5.6.2.2', src);self.assertNotIn('5.4.3.6 — conferir', src)

    def test_registro_normativo_com_pagina_e_conferencia(self):
        reg = normref_registry()
        for rid in ('NBR5410-T36', 'NBR5410-T25', 'NBR5410-5.3.5.5', 'NBR5419-1-T3', 'NBR5419-4-C.2.1'):
            with self.subTest(rid=rid):
                self.assertTrue(reg[rid]['pagina']);self.assertTrue(reg[rid]['verificado_por'])
        for rid in ('IEC60909-0', 'NBRNM280', 'IEC60269-1'):  # documentos que a auditoria não teve em mãos
            self.assertIsNone(reg[rid]['verificado_por'])


class NewTables(unittest.TestCase):
    def test_nomes_das_tabelas_novas_resolvem(self):
        m = model()
        for name in ('T25_Uo', 'T25_Sit1', 'T25_Sit2', 'T25_Max_5s', 'T30_k', 'T31_II', 'T35_Chave', 'T46_Tipo', 'T47_Chave', 'T5357_k',
                     'PESep_Protecao', 'Queda_Chave', 'DPSCrit_Chave', 'NP_Pico', 'Coord_Chave', 'IEC_Chave', 'Mot_Chave', 'Mat_Rho'):
            with self.subTest(name=name):
                self.assertIn(name, m.names)
                self.assertIsNotNone(m.table(m.names[name].split('!')[0]))

    def test_tabela_25_e_31(self):
        p = load()
        for name, expected in (('T25_Uo', [115, 120, 127, 220, 254, 277, 400]), ('T25_Sit1', [0.8, 0.8, 0.8, 0.4, 0.4, 0.4, 0.2]),
                               ('T25_Sit2', [0.35, 0.35, 0.35, 0.2, 0.2, 0.2, 0.05])):
            g = p.engine.evaluate(('name', name), 'DPS', 'A2')
            self.assertEqual([g.at(i, 0) for i in range(g.rows)], expected)
        self.assertEqual(p.engine.evaluate(('name', 'T25_Max_5s'), 'DPS', 'A2').at(), 5)


class Criteria(unittest.TestCase):
    """Critérios da NBR 5410 e da NBR 5419 que entraram no cálculo."""

    def test_i1_tabela_25_situacao_e_5_s(self):
        p = load();r = row(p, 'QDFL-02')
        self.assertEqual(val(p, 'choque.tempo_maximo_de_seccionamento_tn_aplicavel_s', r), 0.8)   # 127 V, situação 1
        put(p, 'choque.situacao_tabela_c1', r, 'Situação 2')
        self.assertEqual(val(p, 'choque.tempo_maximo_de_seccionamento_tn_aplicavel_s', r), 0.35)
        put(p, 'choque.criterio_tn_confirmado_pelo_projetista', r, 'SIM — 5 s APLICÁVEL')
        self.assertEqual(val(p, 'choque.tempo_maximo_de_seccionamento_tn_aplicavel_s', r), 5)
        self.assertEqual(val(p, 'choque.tempo_maximo_de_seccionamento_tn_aplicavel_s', row(p, 'QGBT-01')), 5)  # distribuição

    def test_i1_e9_tensao_220_380(self):
        p = load();put(p, 'fonte.trafo_tensao_secundario_v', None, 380)
        self.assertEqual(val(p, 'choque.tempo_maximo_de_seccionamento_tn_aplicavel_s', row(p, 'QDFL-02')), 0.4)
        r = row(p, 'Ramal de entrada')
        self.assertEqual(val(p, 'dps.up_de_ref_minimo_exigido_kv', r), 2.5)   # Tabela 31, categoria II, 220/380 V
        self.assertEqual(val(p, 'dps.uc_minimo_exigido_v', r), 242)           # 1,1 × 220 V (Tabela 49)
        q = load()
        self.assertEqual(val(q, 'dps.up_de_ref_minimo_exigido_kv', r), 1.5)   # 127/220 V

    def test_i11_circuito_sem_neutro(self):
        p = load()
        for name, tipo in (('QDFL-02', '2F+T'), ('QGBT-01', '3F+T')):
            r = row(p, name);put(p, 'ident.neutro_distribuido', r, 'Não')
            with self.subTest(name=name):
                self.assertEqual(val(p, 'ident.tipo_calculo', r), tipo)
                self.assertEqual(val(p, 'condutores.no_de_condutores_carregados', r), int(tipo[0]))
                self.assertEqual(val(p, 'amp_secao.iz_neutro', r), 'N/A')

    def test_i10_corrente_de_projeto_com_3a_harmonica(self):
        p = load();r = row(p, 'QGBT-01');before = val(p, 'corrente.i_r_a', r)
        put(p, 'dados.taxa_de_3o_hamonico', r, 30)
        self.assertEqual(val(p, 'corrente.fator_ib_harmonicas', r), 1.044)
        self.assertAlmostEqual(val(p, 'corrente.i_r_a', r), before * 1.044, delta=0.002)

    def test_i9_motivo_do_fator_do_neutro(self):
        p = load();r = row(p, 'QGBT-01');put(p, 'dados.taxa_de_3o_hamonico', r, 50)
        self.assertIn('0,86', val(p, 'amp_corrente.motivo_do_fator_do_neutro', r))

    def test_i12_e15_pe_fora_do_cabo(self):
        p = load();r = row(p, 'QDFL-03')
        g = lambda name: [p.engine.evaluate(('name', name), 'DPS', 'A2').at(i, 0) for i in range(2)]  # noqa: E731
        self.assertEqual((g('PESep_Protecao'), g('PESep_Cu'), g('PESep_Al')),
                         (['Com proteção mecânica', 'Sem proteção mecânica'], [2.5, 4], [16, 16]))   # 6.4.3.1.4
        termico = {}
        for option, tab in (('No mesmo cabo ou conduto das fases', 'T55'), ('Separado, com proteção mecânica', 'T53'),
                            ('Separado, sem proteção mecânica', 'T53')):
            with self.subTest(option=option):
                put(p, 'condutores.pe_instalacao', r, option)
                self.assertEqual(val(p, 'sug_pe.tipo_pe_cabo_isolado', r), tab)  # cabo multipolar com PE separado: Tabela 53
                termico[option] = val(p, 'sug_pe.s_pe_termico_mm2', r)
        self.assertLess(termico['Separado, com proteção mecânica'], termico['No mesmo cabo ou conduto das fases'])  # k 143 > 115
        expr = model().by_id['sug_pe.s_pe_min_adotado_mm2'].expr
        self.assertIn('PESep_Cu', expr);self.assertIn('condutores.pe_instalacao', expr)

    def test_c13_tabela_58_mais_proxima_ou_superior(self):
        p = load();r = row(p, 'QDFL-01');put(p, 'secoes.fase_mm2', r, 150)
        self.assertEqual(val(p, 'sug_pe.s_pe_tab_3_25_mm2', r), 70)   # S/2 = 75 → seção padronizada mais próxima
        put(p, 'fonte.pe_tabela58_arredondamento', None, 'Seção imediatamente superior')
        self.assertEqual(val(p, 'sug_pe.s_pe_tab_3_25_mm2', r), 95)

    def test_i13_sobrecarga_prolongada(self):
        p = load();r = row(p, 'QGBT-01')
        self.assertAlmostEqual(val(p, 'protecao.v_1_45_x_iz_a', r), 1.45 * val(p, 'protecao.iz_a', r))
        put(p, 'protecao.sobrecarga_prolongada', r, 'SIM')
        self.assertEqual(val(p, 'protecao.v_1_45_x_iz_a', r), val(p, 'protecao.iz_a', r))

    def test_i6_limites_de_queda(self):
        p = load();r = row(p, 'QDFL-02')
        self.assertEqual(val(p, 'queda.limite_6_2_7_pct', r), 7)
        put(p, 'fonte.queda_limite_projeto_pct', None, 5)
        self.assertEqual(val(p, 'queda.limite_total_de_projeto_pct', r), 5)
        put(p, 'dados.queda_de_tensao_maxima_permitida_para_este', r, 6)
        self.assertEqual(val(p, 'secao_queda.dv_v_max_pct', r), 4)      # circuito terminal: no máximo 4% (6.2.7.2)
        q = load();d = row(q, 'QGBT-01');put(q, 'dados.queda_de_tensao_maxima_permitida_para_este', d, 6)
        self.assertEqual(val(q, 'secao_queda.dv_v_max_pct', d), 6)

    def test_i2_iimp_pela_nbr_5419(self):
        p = load();r = row(p, 'Ramal de entrada')
        self.assertEqual(val(p, 'dps.iimp_cl_i_ou_in_cl_ii_iii_minimo_exigido', r), 12.5)  # NP não informado
        put(p, 'dps.np_spda', r, 'I');put(p, 'dps.n_linhas_estrutura', r, 1)
        self.assertEqual(val(p, 'dps.iimp_por_condutor_nbr5419_ka', r), 25)   # ke·I/(n·n’) = 0,5 × 200 / (1 × 4)
        self.assertEqual(val(p, 'dps.iimp_cl_i_ou_in_cl_ii_iii_minimo_exigido', r), 25)
        put(p, 'dps.np_spda', r, 'III');put(p, 'dps.n_linhas_estrutura', r, 2)
        self.assertEqual(val(p, 'dps.iimp_por_condutor_nbr5419_ka', r), 6.25)

    def test_i3_i4_dps_minimos_e_secao(self):
        p = load();r = row(p, 'QM-01')
        self.assertEqual(val(p, 'dps.in_iimp_minimo_norma_ka', r), 5)
        self.assertEqual(val(p, 'dps.iimp_cl_i_ou_in_cl_ii_iii_minimo_exigido', r), 20)  # critério de projeto, separado do mínimo
        self.assertEqual(val(p, 'dps.secao_min_cabo_dps_mm2', r), 6)       # com SPDA: NBR 5419-4, Tabela 1
        put(p, 'dps.possui_spda_externo', r, 'Não')
        self.assertEqual(val(p, 'dps.secao_min_cabo_dps_mm2', r), 4)       # sem SPDA: NBR 5410
        self.assertIn('20', val(p, 'dps.modulo_n_pe_exigido', row(p, 'QGBT-01')))

    def test_e14_c219_usa_a_distancia_ate_o_dps_que_protege(self):
        expr = model().by_id['dps.avaliacao_c_2_1_9_comprimento_x_up_f_vs_uw'].expr
        self.assertIn('dps.distancia_real_ao_dps_montante_m', expr)
        self.assertIn('dps.falha_critica', expr)
        self.assertNotIn('dps.compr_max_recom_cabo_m>', expr)

    def test_dps_status_explica_valor_a_confirmar(self):
        p = load();selection.apply(p);p.engine.clear()
        status = selection.dps_status(p, row(p, 'QGBT-01'))
        self.assertTrue(status.startswith('Pendente: Uc a confirmar, Up a confirmar.'), status)
        self.assertIn('ficha técnica', status)


class NormativeView(unittest.TestCase):
    def test_mapa(self):
        d = normativa.mapa(load())
        fams = [g['familia'] for g in d['grupos']]
        self.assertEqual(fams[:2], ['nbr5410', 'nbr5419'])
        items = {i['id']: i for g in d['grupos'] for i in g['itens']}
        self.assertEqual(items['tab_ampacidade_2c']['vista'], 'ampacidade')
        self.assertEqual(items['tab_ampacidade_2c']['corrigidas'], 3)
        self.assertEqual(items['regra.agrupamento']['vista'], 'regras')
        self.assertEqual(items['tab_nbr5410_t25']['conferencia']['estado'], 'conferida')
        self.assertEqual(d['resumo']['total'], len(model().tables) + len(normativa.RULE_ITEMS))
        # “nesta versão”: tabelas novas e regras alteradas também aparecem, não só as células corrigidas
        self.assertEqual((items['tab_nbr5410_t25']['nova_em'], items['tab_ampacidade_2c']['nova_em']), ('2.2.0', None))
        self.assertIn('IEC 60364-4-41', items['tab_nbr5410_t25']['revisao_nota'])
        self.assertEqual(d['resumo']['novas'], 17)
        self.assertIn('0,80', items['regra.agrupamento']['mudancas'])

    def test_tabelas_36_a_39_na_forma_da_norma(self):
        p = load()
        d = normativa.ampacidade(p, '39', 'Cu')
        self.assertEqual([c['grupo'] for c in d['colunas']], ['E', 'E', 'F', 'F', 'F', 'G', 'G'])
        line = next(l for l in d['linhas'] if l['secao'] == 630)
        self.assertEqual(line['celulas'][0]['v'], 1196)
        self.assertEqual(line['celulas'][0]['anterior'], [1936])
        self.assertEqual(line['celulas'][0]['correcao']['achado'], 'E1')
        d = normativa.ampacidade(p, '36', 'Al')
        self.assertEqual(len(d['colunas']), 12)
        self.assertEqual(d['linhas'][0]['secao'], 16)  # alumínio a partir de 16 mm²

    def test_uso_por_circuito_na_tabela_36_a_39(self):
        p = load();d = normativa.ampacidade(p, '37', 'Cu')
        used = {(l['secao'], d['colunas'][i]['rotulo']): c['uso'] for l in d['linhas'] for i, c in enumerate(l['celulas']) if c and c.get('uso')}
        self.assertIn('QDFL-02', [u['circuito'] for u in used[(70, 'D, 3 condutores carregados')]])
        ramal = next(u for u in d['uso_circuitos'] if u['circuito'] == 'Ramal de entrada')
        self.assertEqual((ramal['fase']['tabela_norma'], ramal['fase']['secao'], ramal['fase']['valor']), ('37', 240, 346))

    def test_uso_em_qualquer_tabela_segue_os_ramos_tomados(self):
        p = load();uid = p.meta['ids'][str(row(p, 'QDFL-02'))]
        u = normativa.uso(p, 'tab_nbr5410_t25', uid)
        self.assertEqual(list(u['celulas']), ['B4'])        # 127 V, situação 1
        q = load();put(q, 'choque.situacao_tabela_c1', row(q, 'QDFL-02'), 'Situação 2')
        self.assertEqual(list(normativa.uso(q, 'tab_nbr5410_t25', uid)['celulas']), ['C4'])
        u = normativa.uso(p, 'tab_fatores_correcao', p.meta['ids'][str(row(p, 'QDFL-01'))])
        self.assertTrue(any('FCT' in x['rotulo'] for xs in u['celulas'].values() for x in xs))
        u = normativa.uso(p, 'tab_weg_protecoes', p.meta['ids'][str(row(p, 'QGBT-01'))])
        self.assertTrue(u['linhas'])

    def test_fichas_de_fabricante(self):
        p = load()
        d = normativa.fichas(p, 'dps_siemens', usados=True)
        self.assertEqual(d['total'], 3)
        f = next(x for x in d['fichas'] if x['titulo'] == '5SD7 443-1')
        self.assertEqual(f['usado_por'], ['Ramal de entrada'])
        iimp = next(x for x in f['pares'] if x['rotulo'].startswith('Iimp'))
        self.assertEqual((iimp['calculo'], iimp['a_confirmar']), (25, False))
        self.assertTrue(normativa.fichas(p, 'weg', usados=True)['fichas'])

    def test_conferencia_guiada_fica_no_projeto(self):
        p = load();before = p.model.manifest()['hash']
        r = normativa.verificar(p, 'NBR5419-4', 'Revisora', 'p. 31', 'Conferido no exemplar')
        self.assertTrue(r['conferida'])
        item = next(i for g in normativa.conferencia(p)['grupos'] for i in g['itens'] if i['id'] == 'NBR5419-4')
        self.assertEqual(item['conferencia_projeto']['por'], 'Revisora')
        self.assertEqual(p.model.manifest()['hash'], before)          # não altera a base de cálculo
        q = Project(unpack(p.packed()))
        self.assertIn('NBR5419-4', q.meta['normref_overrides'])         # gravado no projeto
        normativa.verificar(q, 'NBR5419-4', 'Revisora', desfazer=True)
        self.assertNotIn('NBR5419-4', q.meta['normref_overrides'])
        # referência já conferida na base: a conferência do revisor aparece separada e o desfazer volta à base
        normativa.verificar(q, 'NBR5410-T36', 'Revisora', 'p. 101')
        item = next(i for g in normativa.conferencia(q)['grupos'] for i in g['itens'] if i['id'] == 'NBR5410-T36')
        self.assertTrue(item['conferencia_base']['por'].startswith('Auditoria'))
        normativa.verificar(q, 'NBR5410-T36', 'Revisora', desfazer=True)
        item = next(i for g in normativa.conferencia(q)['grupos'] for i in g['itens'] if i['id'] == 'NBR5410-T36')
        self.assertIsNone(item['conferencia_projeto']);self.assertTrue(item['verificado_por'].startswith('Auditoria'))

    def test_grade_marca_celulas_corrigidas(self):
        from core import tabelas
        p = load();d = tabelas.view(p, 'tab_ampacidade_2c', 1, 10)
        c = d['linhas_def'][4]['celulas'][15]  # P5
        self.assertEqual((c['v'], c['anterior'], c['correcao']['achado']), (1196, [1936], 'E1'))
        self.assertEqual(d['corrigidas'], 3)


class Conversion(unittest.TestCase):
    def test_projeto_v1_nao_ve_as_correcoes_da_base_como_edicao(self):
        p = Project(legacy())
        changed = set(p.meta['migracao']['tabelas_alteradas'])
        for tid in ('tab_ampacidade_2c', 'tab_ampacidade_3c', 'tab_secao_neutro', 'tab_dps_siemens', 'tab_dps_clamper',
                    'tab_disjuntores_ref', 'tab_impedancias', 'tab_fatores_correcao', 'tab_nbr5410_t33', 'tab_metodos', 'tab_listas'):
            self.assertNotIn(tid, changed)
        self.assertEqual(p.meta['migracao']['formulas_alteradas'], [])


class QuietHandler(Handler):
    def log_message(self, *args):
        pass


class NormativeHTTP(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory();cls.server = ThreadingHTTPServer(('127.0.0.1', 0), QuietHandler)
        cls.server.store = Store(Path(cls.tmp.name) / 'p.sqlite3', backup=False)
        cls.server.token = secrets.token_urlsafe(24);cls.server.lock = threading.RLock();cls.server.daemon_threads = True
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True);cls.thread.start()
        cls.client = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join();cls.tmp.cleanup()

    def request(self, path, data=None):
        store = self.server.store
        headers = {'X-Eletro-Token': self.server.token, 'Host': f'127.0.0.1:{self.server.server_port}'}
        if data is not None:
            headers.update({'Content-Type': 'application/json', 'X-Eletro-Project': store.active_id, 'X-Eletro-Revision': str(store.revision)})
        req = urllib.request.Request(f'http://127.0.0.1:{self.server.server_port}' + path, headers=headers,
                                     data=None if data is None else json.dumps(data).encode(), method='GET' if data is None else 'POST')
        try:
            with self.client.open(req, timeout=60) as response:
                return response.status, json.load(response)
        except urllib.error.HTTPError as error:
            return error.code, json.load(error)

    def test_endpoints_da_vista_normativa(self):
        uid = self.server.store.project.meta['ids']['6']
        for path in ('/api/norm/map', '/api/norm/amp?tab=38&mat=Al', '/api/norm/conferencia', '/api/norm/fichas?tipo=weg&usados=1',
                     f'/api/norm/uso?tabela=tab_nbr5410_t25&id={uid}', '/api/norm/fichas?tipo=nh&q=gG'):
            with self.subTest(path=path):
                status, data = self.request(path)
                self.assertEqual(status, 200, data)
        status, data = self.request('/api/norm/amp?tab=99')
        self.assertEqual(status, 400)

    def test_conferencia_exige_revisor(self):
        status, data = self.request('/api/normref/verify', {'id': 'NBR5410-T36', 'pagina': 'p. 101'})
        self.assertNotEqual(status, 200)
        self.assertIn('revisor', data['error'].lower())


if __name__ == '__main__':
    unittest.main()

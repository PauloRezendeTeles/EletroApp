/* Funções originais, respostas reais e DOM mínimo: não substitui QA visual. */
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const fixture=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const app=fs.readFileSync('static/app.js','utf8'),workflow=fs.readFileSync('static/workflow.js','utf8');
const render=app.slice(app.indexOf('function secoesComparacaoHTML('),app.indexOf('async function ensureProtecaoData('));
const preview=workflow.slice(workflow.indexOf('async function previewWorkflow('));
function setup(){
 const before=structuredClone(fixture.before),after=structuredClone(fixture.after);
 before.fields=before.groups.flatMap(g=>g.fields);
 const nodes={'choice-preview-state':{textContent:''}};
 for(const [i,f] of before.fields.entries())if(f.formula)nodes['field-'+i]={tagName:'OUTPUT',innerHTML:JSON.stringify(f.value)};
 const context={drawerData:before,workflowTicket:0,groupingDirty:false,
   document:{getElementById:id=>nodes[id]||null,querySelector:()=>null},api:async()=>after,
   workflowChanges:()=>[],flowFind:()=>-1,workflowState:()=>{},num:v=>JSON.stringify(v),esc:v=>String(v??'')};
 vm.createContext(context);vm.runInContext(render,context);vm.runInContext(preview,context);
 const sections=before.groups.find(g=>g.key==='secoes');
 const old=context.secoesComparacaoHTML(sections.comparacao,sections.comparacao_aviso);
 nodes['secoes-comparacao']={outerHTML:old};
 return {before,after,nodes,context,old};
}
(async()=>{
 // A mudança de ligação deve refazer a cascata, mesmo fora do grupo de cabos.
 const listenerStart=app.indexOf("$('#drawer').oninput=")+"$('#drawer').oninput=".length;
 const listenerEnd=app.indexOf(";$('#close-drawer').onclick",listenerStart);
 assert(listenerEnd>listenerStart);
 const events=[],phaseData={fields:[{sheet:'Identificação dos circuitos',address:'E4'}]};
 const phaseContext={data:phaseData,dirty:false,$:()=>({textContent:''}),indexFromElId:()=>0,
   refreshInstallationPreview:(fields,reconcile)=>events.push({fields,reconcile})};
 vm.createContext(phaseContext);
 vm.runInContext('('+app.slice(listenerStart,listenerEnd)+')',phaseContext)({target:{id:'field-0'}});
 assert.strictEqual(events.length,1);assert.strictEqual(events[0].reconcile,true);
 const a=setup();await a.context.previewWorkflow(a.before);
 const group=a.after.groups.find(g=>g.key==='secoes');
 assert.strictEqual(a.nodes['secoes-comparacao'].outerHTML,a.context.secoesComparacaoHTML(group.comparacao,group.comparacao_aviso));
 assert.notStrictEqual(a.nodes['secoes-comparacao'].outerHTML,a.old);
 assert.strictEqual(a.before.groups.find(g=>g.key==='secoes').comparacao_aviso,undefined);
 assert(a.nodes['choice-preview-state'].textContent.startsWith('Prévia atualizada'));
 for(const change of [s=>{s.context.workflowTicket++},s=>{s.context.drawerData={id:'outro'}}]){
  const b=setup();let release;
  b.context.api=()=>new Promise(resolve=>release=resolve);
  const pending=b.context.previewWorkflow(b.before);change(b);release(b.after);await pending;
  assert.strictEqual(b.nodes['secoes-comparacao'].outerHTML,b.old,'resposta obsoleta alterou o quadro');
 }
 console.log('Quadro de seções atualizado; respostas obsoletas descartadas.');
})().catch(error=>{console.error(error);process.exitCode=1});

"""Regressões independentes da auditoria de agrupamento NBR 5410."""
import copy
import gzip
import json
import math
import unittest
from pathlib import Path
import os,sys;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)));from forcar import force
from core.project import Project,unpack
from core.installation import FIELDS,RULES,consultation
from core import grouping
from core.catalog import Catalog,CatalogError

BASE=json.loads((Path(__file__).resolve().parents[1]/'data'/'exemplos'/'exemplo.json').read_text(encoding='utf-8'))

def example(method=11,cable='Cabo multipolar',nc=1,others=0,**settings):
    p=Project(copy.deepcopy(BASE));r=4
    line=next(l for l in RULES['lines'] if any(str(v['method'])==str(method) and v['cable']==cable for v in l['variants']))
    values=dict(line=line['name'],method=method,cable=cable,material='Cobre',insulation='PVC',
                voltage='450/750V' if cable=='Condutor isolado' else '0,6/1kV',circuits=others+1,
                parallel=nc,separate='Não',soil=2.5)
    for k,v in values.items():s,c=FIELDS[k];p.put(s,c+'4',v)
    p.engine.clear()
    for k in ('adjustment','arrangement'):
        choices=p.installation.state(4)['options'][k];s,c=FIELDS[k];p.put(s,c+'4',choices[0]);p.engine.clear()
    sig=p.installation.state(4)['geometry']['signature']
    p.meta['installation_settings'][p.meta['ids']['4']]={'geometry_mode':'confirmed','geometry_signature':sig,
        'other_units':others,'homogeneity':'similar',**settings}
    p.engine.clear();return p

class GroupingTables(unittest.TestCase):
    def test_150_nbr_values(self):
        air=[[1,.8,.7,.65,.6,.57,.54,.52,.50,.45,.41,.38],
             [1,.85,.79,.75,.73,.72,.72,.71,.70,.70,.70,.70],
             [.95,.81,.72,.68,.66,.64,.63,.62,.61,.61,.61,.61],
             [1,.88,.82,.77,.75,.73,.73,.72,.72,.72,.72,.72],
             [1,.87,.82,.80,.80,.79,.79,.78,.78,.78,.78,.78]]
        for k,row in zip(('feixe','parede','teto','bandeja','leito'),air):self.assertEqual(RULES['group_air'][k],row)
        self.assertEqual(RULES['group_layers'],[[.68,.62,.60,.58,.56],[.62,.57,.55,.53,.51],[.60,.55,.52,.51,.49],[.58,.53,.51,.49,.48],[.56,.51,.49,.48,.46]])
        direct=[[.75,.80,.85,.90,.90],[.65,.70,.75,.80,.85],[.60,.60,.70,.75,.80],[.55,.55,.65,.70,.80],[.50,.55,.60,.70,.80]]
        for n,row in enumerate(direct,2):self.assertEqual(RULES['group_direct'][str(n)],row)
        self.assertEqual(RULES['group_duct_multi'][:5],[[.85,.90,.95,.95],[.75,.85,.90,.95],[.70,.80,.85,.90],[.65,.80,.85,.90],[.60,.80,.80,.80]])
        self.assertEqual(RULES['group_duct_single'][:5],[[.80,.90,.90,.95],[.70,.80,.85,.90],[.65,.75,.80,.90],[.60,.70,.80,.90],[.60,.70,.80,.90]])
    def test_guide_four_corrections_and_source_counts(self):
        for n,f in [(11,.70),(17,.65),(19,.64),(20,.63)]:self.assertEqual(RULES['group_duct_single'][n-2][2],f)
        rows=consultation()['grouping']['rows']
        self.assertEqual(len(rows),292)
        self.assertEqual(sum(r['source']==grouping.NBR for r in rows),150)
        self.assertEqual(sum(r['source']==grouping.GUIDE for r in rows),142)

class GroupingCalculation(unittest.TestCase):
    def factor(self,p,expected):
        s=p.installation.state(4);self.assertTrue(s['valid'],s['issues'])
        self.assertAlmostEqual(p.get('Corrente-Calc_Ampacidade ','O4'),expected)
        self.assertEqual(p.get('Cálc_Seç-Ampacidade','D4'),1)
    def test_ceiling_inferred_even_one_and_bad_old_wall_choice(self):
        self.factor(example('11A'),.95)
        p=example('11A',others=1,group='parede');self.factor(p,.81)
        self.assertNotIn('parede',[x['value'] for x in p.installation.state(4)['group_options']])
        self.factor(example('11A',group='feixe'),.95)
    def test_wall_and_tray_keep_bundle_layers(self):
        for method in (11,12):
            p=example(method,others=3,group='camadas',layers=2,per_layer=2)
            self.factor(p,.68)
            self.assertIn('feixe',[x['value'] for x in p.installation.state(4)['group_options']])
    def test_parallel_counts_are_combined_once(self):
        self.factor(example(14,nc=2,group='leito'),.87)
        self.factor(example(63,nc=2,group='direto',spacing='0'),.75)
        p=example(11,nc=2,others=2,group='parede');self.factor(p,.75)
        self.assertEqual(p.installation.state(4)['grouping']['physical_count'],4)
    def test_nine_parallel_and_twenty_air_use_table(self):
        self.factor(example(11,nc=9,group='parede'),.70)
        p=example(11,nc=20,group='feixe');self.factor(p,.38)
        self.assertNotIn('Aproximação',p.get('Corrente-Calc_Ampacidade ','V4'))
    def test_ducts_distinct_do_not_remove_grouping(self):
        p=example(11,nc=2,group='parede');p.put('Dados dos condutores ','E4','Sim');p.engine.clear();self.factor(p,.85)
        cfg=p.meta['installation_settings'][p.meta['ids']['4']];cfg['parallel_layout']='independent';p.engine.clear()
        self.assertFalse(p.installation.state(4)['valid'])
        cfg['independence_basis']='Percursos separados, distâncias térmicas verificadas no memorial.';p.engine.clear();self.factor(p,1)
    def test_legacy_count_requires_physical_count_and_similarity(self):
        p=example(11,others=2,group='parede');cfg=p.meta['installation_settings'][p.meta['ids']['4']]
        del cfg['other_units'];del cfg['homogeneity'];p.engine.clear()
        self.assertFalse(p.installation.state(4)['valid'])
        cfg.update(count_mode='total',physical_count=3,homogeneity='similar');p.engine.clear();self.factor(p,.79)
    def test_duct_distribution_required(self):
        p=example('61A','Cabo unipolar',others=1,spacing='0');self.assertFalse(p.installation.state(4)['valid'])
        p.meta['installation_settings'][p.meta['ids']['4']]['duct_layout']='one_conductor';p.engine.clear();self.factor(p,.8)
    def test_buried_guide_opt_in_and_gaps(self):
        p=example(61,others=6,spacing='0',duct_layout='one_cable');self.assertFalse(p.installation.state(4)['valid'])
        p.meta['installation_settings'][p.meta['ids']['4']]['allow_guide']=True;p.engine.clear();self.factor(p,.57)
        self.assertEqual(p.installation.state(4)['grouping']['source'],grouping.GUIDE)
        p=example(63,others=9,spacing='0',allow_guide=True);self.assertFalse(p.installation.state(4)['valid'])
    def test_buried_depth_and_resistivity_limits(self):
        p=example(63,others=1,spacing='0',depth=1);self.assertFalse(p.installation.state(4)['valid'])
        p=example(63,depth=2);self.factor(p,1);self.assertAlmostEqual(p.installation.soil_factor(4),.87)
    def test_manual_g_pending_without_source_and_roundtrip(self):
        p=example(18,'Cabo unipolar',nc=2,group_mode='manual',manual_factor=.7)
        self.assertFalse(p.installation.state(4)['valid'])
        cfg=p.meta['installation_settings'][p.meta['ids']['4']];cfg.update(manual_source='Memorial 11301',manual_reason='Cálculo do trecho e das distâncias conforme memorial de engenharia.');p.engine.clear();self.factor(p,.7)
        self.factor(Project(unpack(p.packed())),.7)
    def test_mixed_temperature_uses_lowest_class(self):
        p=example(11,others=1,group='parede',homogeneity='mixed',group_temperature=70)
        p.put('Dados dos condutores ','I4','EPR');p.engine.clear();self.factor(p,.85)
        self.assertIn('PVC70g',p.installation.state(4)['table'])
        p.put('Dados dos circuitos','B4',40);p.engine.clear();self.assertEqual(p.installation.temperature_factor(4),.87)
    def test_heterogeneous_sqrt_only_with_specific_justification(self):
        p=example(11,others=3,group='parede',homogeneity='heterogeneous',group_temperature=70)
        self.assertFalse(p.installation.state(4)['valid'])
        p.meta['installation_settings'][p.meta['ids']['4']]['heterogeneous_basis']='Combinação variável de seções: cálculo específico não é viável.';p.engine.clear();self.factor(p,.5)
    def test_spacing_strictly_greater_than_two(self):
        self.factor(example(11,others=1,group='parede',air_gap_ratio=2),.85)
        self.factor(example(11,others=1,group='parede',air_gap_ratio=2.01),1)
    def test_low_load_uses_corrected_capacity(self):
        p=example(11,others=1,group='parede',low_load_count=1,low_load_ib=26,low_load_iz=100,low_load_basis='Circuito iluminação: corrente e ampacidade verificadas no memorial.')
        self.assertFalse(p.installation.state(4)['valid']) # 26 > 30%*100*.85
        p.meta['installation_settings'][p.meta['ids']['4']]['low_load_ib']=25;p.engine.clear();self.factor(p,1)
    def test_phase_neutral_capacity_and_floor_same_count(self):
        for nc in (1,2,3):
            p=example(11,nc=nc,group='parede')
            force(p,'Corrente-Calc_Ampacidade ','S4',0)
            self.assertAlmostEqual(p.get('Cálc_Seç-Ampacidade','G4')/p.get('Cálc_Seç-Ampacidade','F4'),.15)
            fca=p.installation.group_factor(4)
            for col,base in [('K','J'),('O','N')]:
                expected=round(p.get('Corrente_Max-Cond_Escolhido',base+'4')*p.installation.temperature_factor(4)*fca*nc,2)
                self.assertEqual(p.get('Corrente_Max-Cond_Escolhido',col+'4'),expected)
    def test_neutral_sections_and_harmonic_boundary(self):
        p=example();force(p,'Carga nos circuitos','D4','3F+N+T')
        self.assertEqual(p.installation.neutral_minimum(4,240),240)
        cfg=p.meta['installation_settings'][p.meta['ids']['4']];cfg.update(neutral_reduction='verified',neutral_basis='Equilíbrio, terceira harmônica e proteção do neutro verificados.');p.put('Dados dos circuitos','G4',15);p.engine.clear()
        self.assertEqual(p.installation.neutral_minimum(4,240),120);self.assertEqual(p.installation.neutral_heating(4),1)
        p.put('Dados dos circuitos','G4',33);p.engine.clear();self.assertEqual(p.installation.neutral_heating(4),.86);self.assertEqual(p.installation.neutral_minimum(4,240),240)
        force(p,'Carga nos circuitos','D4','1F+N+T');self.assertEqual(p.installation.neutral_minimum(4,240),240)
    def test_managed_formulas_trace_actual_rule(self):
        p=example();cat=Catalog(p);e=cat.entry_view(p.var_at('Cálc_Seç-Ampacidade','D4'))
        self.assertTrue(e['gerida_por_instalacao'])
        self.assertNotIn('SQRT',e['expressao'])
        with self.assertRaises(CatalogError):cat.preview_edit(e['id'],'=0.5')
    def test_saved_group_needs_reconfirmation_after_thermal_change(self):
        p=example(11,others=1,group='parede');uid=p.meta['ids']['4'];state=p.installation.state(4)
        p.update([],installation={'id':uid,'reference':state['reference'],'settings':state['settings']})
        p.put('Dados dos condutores ','I4','EPR');p.engine.clear()
        self.assertFalse(p.installation.state(4)['valid'])
        self.assertIsNone(p.installation.state(4)['settings']['homogeneity'])

if __name__=='__main__':unittest.main()

"""Ferramenta de ensaio: fixa o valor de um cálculo em um circuito (ou na fonte).

No modelo nativo um cálculo não aceita valor digitado; os ensaios que precisam de
uma condição específica criam uma versão da expressão que devolve o valor só na
posição indicada (sem selo: o relatório de integridade a acusaria)."""
import json
import re


def force(p, sheet, address, value):
    v = p.var_at(sheet, address)
    lit = json.dumps(value, ensure_ascii=False) if isinstance(value, str) else repr(value)
    if v.scope == 'circuito':
        row = int(re.sub(r'[A-Z$]', '', address))
        base = p.active_expression(v)[1:]
        expr = f'=IF(ROW()={row},{lit},{base})'
    else:
        expr = '=' + lit
    p.doc['formulas'][v.id] = {'ativa': 1, 'versoes': [{'versao': 1, 'expressao': expr, 'tipo': 'ensaio'}]}
    p.engine.clear()

"""Regressões do motor, dados reais, alterações e persistência.
Execute: python -m unittest discover -s tests -v
"""
import copy
import gzip
import json
import math
from pathlib import Path
import tempfile
import unittest
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core.formula import Engine, Error, parse, scalar
from core.project import Project, IDENT, unpack
from app import Store

ROOT=Path(__file__).resolve().parents[1]


class FormulaTests(unittest.TestCase):
    def setUp(self):
        cells={'A1':{'value':2},'A2':{'value':3},'A3':{'value':7},'B1':{'value':'pai'},
               'B2':{'value':'filho'},'B3':{'value':'neto'}}
        self.e=Engine({'sheets':{'Dados':{'cells':cells}},'names':{'Valores':'Dados!A1:A3'}})
    def calc(self,f):return scalar(self.e.evaluate(parse(f),'Dados','C9'))
    def test_excel_rounding_and_complex(self):
        self.assertEqual(self.calc('=ROUND(2.675,2)'),2.68)
        self.assertEqual(self.calc('=ROUND(-2.5,0)'),-3)
        self.assertEqual(self.calc('=IMABS(COMPLEX(3,4))'),5)
    def test_arrays_lookups_and_dynamic_range(self):
        self.assertEqual(self.calc('=SUMPRODUCT((Valores>2)*Valores)'),10)
        self.assertEqual(self.calc('=INDEX(Valores,MATCH(3,Valores,0))'),3)
        self.assertEqual(self.calc('=LARGE(INDIRECT("A1"):INDIRECT("A3"),1)'),7)
        self.assertEqual(self.calc('=INDEX(Dados!$B:$B,2)'),'filho')
    def test_lazy_condition_and_visible_error(self):
        self.assertEqual(self.calc('=IF(FALSE,1/0,8)'),8)
        self.assertEqual(self.calc('=IFERROR(1/0,"pendente")'),'pendente')
        self.assertIsInstance(self.calc('=1/0'),Error)
        self.e.data['sheets']['Dados']['cells']['D1']={'value':'=SUMIF(B1:B3,"filho",D1:D3)','formula':True}
        self.e.data['sheets']['Dados']['cells']['D2']={'value':12}
        self.assertEqual(self.e.get('Dados','D1'),12)


class ProjectTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = json.loads((ROOT/'data'/'exemplos'/'exemplo.json').read_text(encoding='utf-8'))
    def project(self):return Project(copy.deepcopy(self.base))
    def confirm_example_geometry(self,p):
        # A regressão numérica pressupõe as condições físicas do exemplo verificadas.
        for row in p.active_rows():
            inst=p.installation.state(row)
            cfg=p.meta.setdefault('installation_settings',{}).setdefault(p.meta['ids'][str(row)],{})
            cfg.update(other_units=int(inst['values']['circuits'])-1,homogeneity='similar')
            if inst['underground']:cfg['duct_layout']='one_cable' if inst['values']['cable']=='Cabo multipolar' else 'one_conductor'
            if inst['geometry']['required']:
                p.meta.setdefault('installation_settings',{}).setdefault(p.meta['ids'][str(row)],{}).update(
                    geometry_mode='confirmed',geometry_signature=inst['geometry']['signature'])
        p.engine.clear()
    def test_reference_main_results(self):
        p=self.project();self.confirm_example_geometry(p);s=p.summary()
        self.assertEqual(len(s['circuits']),6)
        self.assertAlmostEqual(s['p_w'],76700,places=2)
        self.assertAlmostEqual(s['s_va'],math.sqrt(76700**2+49861.51**2),places=2)
        # Valores do exemplo com a instalação completada (método/cabo/arranjo compatíveis com a Tabela 33 e
        # agrupamento definido). Os valores originais da r42 (.580/.580/14.426 etc.) vinham de combinações
        # incompatíveis com a Tabela 33 e não são reproduzíveis com a validação estrita.
        # v1.9: temperatura operacional usa a corrente física, sem corrigir Ib uma segunda vez.
        # v2.2.0: resistências da tabela de impedâncias com 4 algarismos significativos (NBR NM 280, achado C5);
        # ex.: 240 mm² Cu EPR passou de 0,10 para 0,09614 Ω/km — queda e Ik dos alimentadores mudam na 3ª casa.
        expected=[(.541,.541,14.712),(1.115,1.656,10.546),(.697,2.353,8.939),(.908,3.261,2.716),(1.120,3.473,4.269),(.878,3.231,1.400)]
        for c,(dv,total,icc) in zip(s['circuits'],expected):
            self.assertAlmostEqual(c['dv'],dv,places=3)
            self.assertAlmostEqual(c['dv_total'],total,places=3)
            self.assertAlmostEqual(c['icc_max'],icc,places=3)
        self.assertFalse(s['diagnostics'])
    def test_change_length_recalculates_drop_and_short_circuit(self):
        p=self.project();self.confirm_example_geometry(p);before=p.summary()['circuits'][-1]
        p.update([{'sheet':'Dados dos circuitos','address':'F7','value':60}])
        after=p.summary()['circuits'][-1]
        self.assertGreater(after['dv'],before['dv']*1.9)
        self.assertLess(after['icc_max'],before['icc_max'])
        self.assertEqual(p.raw('Cálc-Prot_Cabos','CF7'),'PENDENTE')
    def test_rename_preserves_children(self):
        p=self.project();old=p.summary()['p_w']
        p.update([{'sheet':IDENT,'address':'B4','value':'QUADRO PRINCIPAL'}])
        s=p.summary()
        self.assertEqual(s['p_w'],old)
        self.assertTrue(all(c['parent']=='QUADRO PRINCIPAL' for c in s['circuits'][3:]))
    def test_transfer_to_later_parent_reorders_inputs_and_recalculates(self):
        p=self.project();uid=p.meta['ids']['5']
        p.update([{'sheet':IDENT,'address':'D5','value':'QDFL-03'},
                  {'sheet':IDENT,'address':'M7','value':'Distribuição'}])
        s=p.summary();items={c['name']:c for c in s['circuits']}
        self.assertLess(items['QDFL-03']['row'],items['QDFL-01']['row'])
        self.assertEqual(items['QDFL-01']['id'],uid)
        self.assertEqual(items['QDFL-01']['length'],35)
        self.assertAlmostEqual(s['p_w'],75620,places=2)
    def test_add_edit_remove_and_roundtrip(self):
        p=self.project();uid=p.add('Iluminação nova','QGBT-01');r=p.row_for(uid)
        p.update([{'sheet':'Levantamento de carga','address':f'D{r}','value':1000},
                  {'sheet':'Levantamento de carga','address':f'E{r}','value':.92}])
        s=p.summary();c=next(c for c in s['circuits'] if c['id']==uid)
        self.assertAlmostEqual(s['p_w'],77700,places=2)
        self.assertGreater(c['ib'],0)
        self.assertIsInstance(c['dv'],(int,float))
        self.assertIsInstance(c['icc_max'],(int,float))
        restored=Project(unpack(p.packed()))
        self.assertAlmostEqual(restored.summary()['p_w'],77700,places=2)
        restored.delete(uid)
        self.assertAlmostEqual(restored.summary()['p_w'],76700,places=2)
    def test_reject_cycle_duplicate_and_invalid_fp(self):
        cases=[(IDENT,'D4','QDFL-01'),(IDENT,'B5','QDFL-02'),('Levantamento de carga','E4',1.2)]
        for s,a,v in cases:
            with self.subTest(a=a):
                p=self.project()
                with self.assertRaises(ValueError):p.update([{'sheet':s,'address':a,'value':v}])
    def test_store_rollback_and_persistence(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'test.sqlite3');before=store.project.raw(IDENT,'B4')
            with self.assertRaises(ValueError):
                store.transactional(lambda p:p.update([{'sheet':IDENT,'address':'B4','value':'QDFL-01'}]))
            self.assertEqual(store.project.raw(IDENT,'B4'),before)
            store.transactional(lambda p:p.update([{'sheet':IDENT,'address':'B4','value':'Novo QGBT'}]))
            reopened=Store(Path(tmp)/'test.sqlite3')
            self.assertEqual(reopened.project.raw(IDENT,'B4'),'Novo QGBT')


if __name__=='__main__':unittest.main()

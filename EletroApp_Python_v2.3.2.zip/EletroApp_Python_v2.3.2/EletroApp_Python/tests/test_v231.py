"""v2.3.1 — comentários de revisão do aplicativo em cada aba."""
import csv
import io
import json
from pathlib import Path
import secrets
import sqlite3
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from http.server import ThreadingHTTPServer
from app import Handler, Store, APP_UI_VERSION, review_export
from core import integridade as integrity

ROOT = Path(__file__).resolve().parents[1]


class ReviewCommentsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        cls.server.store = Store(Path(cls.tmp.name) / 'projects.sqlite3')
        cls.server.token = secrets.token_urlsafe(24); cls.server.lock = threading.RLock()
        cls.server.daemon_threads = True
        cls.base = f'http://127.0.0.1:{cls.server.server_port}'
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True); cls.thread.start()
        cls.client = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.tmp.cleanup()

    def get(self, path):
        return self.client.open(self.base + path, timeout=60).read()

    def post(self, path, data, token=None):
        req = urllib.request.Request(self.base + path, data=json.dumps(data).encode(), method='POST',
                                     headers={'X-Eletro-Token': token or self.server.token, 'Content-Type': 'application/json'})
        return json.loads(self.client.open(req, timeout=60).read())

    def post_error(self, path, data, token=None):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.post(path, data, token)
        return ctx.exception.code, json.loads(ctx.exception.read() or b'{}')

    def setUp(self):
        with self.server.store.db() as db:
            db.execute('DELETE FROM review_comments')

    def test_interface_has_panel_script_nav_and_export(self):
        html = self.get('/').decode()
        self.assertIn('/revisao.js', html)
        self.assertIn('data-view="review"', html)
        self.assertIn('/api/review/export?format=md', html)
        self.assertIn('v' + APP_UI_VERSION, html)
        from core.motor import APP_VERSION
        self.assertIn('v' + APP_VERSION, html)  # versão das regras de cálculo
        js = self.get('/revisao.js').decode()
        for marker in ('review-panel', 'circuito-', 'renderReviewView', 'stopPropagation', '/api/review/add'):
            self.assertIn(marker, js)
        self.assertIn("'review'].includes(currentView)", self.get('/app.js').decode())
        self.assertIn('.review-panel', self.get('/style.css').decode())

    def test_every_script_and_style_in_index_is_served(self):
        """Na 2.3.0, /protecao-integrada.js voltava 404 e o formulário do circuito não abria."""
        import re
        html = self.get('/').decode()
        refs = re.findall(r'<script[^>]+src="(/[^"]+)"', html) + re.findall(r'<link[^>]+href="(/[^"]+)"', html)
        self.assertIn('/protecao-integrada.js', refs)
        for ref in refs:
            resp = self.client.open(self.base + ref, timeout=60)
            ctype = resp.headers.get('Content-Type', '')
            self.assertEqual(resp.status, 200, ref)
            self.assertTrue(ctype.startswith('text/javascript' if ref.endswith('.js') else 'text/css'), (ref, ctype))
            self.assertEqual(resp.read(), (ROOT / 'static' / ref.lstrip('/')).read_bytes(), ref)

    def test_add_list_update_delete_without_touching_project(self):
        store = self.server.store
        rev, pid, data_before = store.revision, store.active_id, json.dumps(store.project.data, sort_keys=True, default=str)
        uid = store.project.meta['ids']['4']
        from core.project import IDENT
        expected = store.project.raw(IDENT, 'B4')
        r = self.post('/api/review/add', {'view': 'circuito-protecoes', 'view_label': 'Circuito › Proteções', 'kind': 'Erro de cálculo',
                                          'priority': 'Alta', 'text': 'Ik mín. parece alto\nconferir Rhot', 'ref': 'Ik mín. QDFL-01',
                                          'author': 'Paulo', 'circuit_id': uid, 'circuit_name': 'nome forjado'})
        c = r['comentario']
        self.assertEqual(c['status'], 'Aberto'); self.assertEqual(c['circuit_name'], expected); self.assertTrue(expected)  # nome lido do projeto, não do navegador
        self.assertEqual(c['project_id'], pid); self.assertEqual(c['project_revision'], rev); self.assertEqual(c['app_version'], APP_UI_VERSION)
        self.post('/api/review/add', {'view': 'overview', 'view_label': 'Visão geral', 'text': 'Mostrar Ik por fase', 'circuit_id': 'inexistente'})
        lst = json.loads(self.get('/api/review/comments'))
        self.assertEqual(len(lst['itens']), 2); self.assertIn('Critério normativo', lst['tipos'])
        geral = [x for x in lst['itens'] if x['view'] == 'overview'][0]
        self.assertIsNone(geral['circuit_id']); self.assertEqual(geral['kind'], 'Melhoria'); self.assertEqual(geral['priority'], 'Média')
        self.assertEqual(len(json.loads(self.get('/api/review/comments?view=overview'))['itens']), 1)
        u = self.post('/api/review/update', {'id': c['id'], 'status': 'Resolvido', 'resolution': 'Corrigido na 2.3.2', 'view': 'help'})['comentario']
        self.assertEqual(u['status'], 'Resolvido'); self.assertEqual(u['view'], 'circuito-protecoes')  # a aba não muda na edição
        self.assertEqual(len(json.loads(self.get('/api/review/comments?status=Aberto'))['itens']), 1)
        self.post('/api/review/delete', {'id': geral['id']})
        self.assertEqual(len(json.loads(self.get('/api/review/comments'))['itens']), 1)
        # O projeto não muda: nenhuma revisão nova, mesmos dados, nenhum alerta de base.
        self.assertEqual(store.revision, rev)
        self.assertEqual(json.dumps(store.project.data, sort_keys=True, default=str), data_before)
        self.assertIsNone(integrity.base_check(store.project))
        self.assertNotIn('review', json.dumps(store.project.data, default=str).lower().replace('preview', ''))

    def test_validation_and_csrf(self):
        code, err = self.post_error('/api/review/add', {'view': 'overview', 'text': '   '})
        self.assertEqual(code, 400); self.assertIn('Escreva', err['error'])
        self.assertEqual(self.post_error('/api/review/add', {'view': '../x', 'text': 'a'})[0], 400)
        self.assertEqual(self.post_error('/api/review/add', {'view': 'overview', 'text': 'a', 'kind': 'Inventado'})[0], 400)
        self.assertEqual(self.post_error('/api/review/add', {'view': 'overview', 'text': 'a'}, token='errado')[0], 403)
        self.assertEqual(self.post_error('/api/review/update', {'id': 99999, 'status': 'Aberto'})[0], 400)
        c = self.post('/api/review/add', {'view': 'overview', 'text': 'x' * 6000})['comentario']
        self.assertEqual(len(c['text']), 5000)
        self.assertEqual(self.post_error('/api/review/update', {'id': c['id'], 'text': ''})[0], 400)

    def test_exports(self):
        self.post('/api/review/add', {'view': 'source', 'view_label': 'Entrada e fontes', 'kind': 'Critério normativo', 'priority': 'Alta',
                                      'text': 'Linha 1\n\nLinha | 3', 'ref': 'NBR 5410 6.4.3'})
        self.post('/api/review/add', {'view': 'overview', 'view_label': 'Visão geral', 'text': '=SOMA(A1)', 'status': 'Resolvido'})
        md = self.get('/api/review/export?format=md').decode()
        self.assertIn('# Comentários de revisão — EletroApp ' + APP_UI_VERSION, md)
        self.assertLess(md.index('## Visão geral'), md.index('## Entrada e fontes'))  # ordem do menu
        self.assertIn('> Linha 1\n>\n> Linha | 3', md)
        self.assertIn('| Entrada e fontes | 1 | 0 | 0 | 1 |', md)
        self.assertIn('C-', md); self.assertIn('- Referência: NBR 5410 6.4.3', md)
        only_open = self.get('/api/review/export?format=md&status=Aberto').decode()
        self.assertIn('Entrada e fontes', only_open); self.assertNotIn('=SOMA', only_open); self.assertIn('situação Aberto', only_open)
        rows = list(csv.reader(io.StringIO(self.get('/api/review/export?format=csv').decode('utf-8-sig')), delimiter=';'))
        self.assertEqual(rows[0][0], 'Código'); self.assertEqual(len(rows), 3)
        self.assertTrue(any(r[6] == "'=SOMA(A1)" for r in rows[1:]))  # sem injeção de fórmula no Excel
        js = json.loads(self.get('/api/review/export?format=json'))
        self.assertEqual(js['formato'], 'eletroapp-comentarios-revisao'); self.assertEqual(len(js['itens']), 2)
        self.assertEqual(self._status('/api/review/export?status=X'), 400)
        self.assertIn('Nenhum comentário', review_export([], 'md')[0].decode())

    def _status(self, path):
        try:
            return self.client.open(self.base + path, timeout=60).status
        except urllib.error.HTTPError as e:
            return e.code

    def test_comments_survive_restart_and_old_database(self):
        # Banco de uma versão anterior (sem a tabela) ganha a tabela ao abrir; comentários persistem entre execuções.
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'eletroapp.sqlite3'
            s1 = Store(path, backup=False)
            with sqlite3.connect(path) as db:
                db.execute('DROP TABLE review_comments')
            s2 = Store(path, backup=False)
            c = s2.review_add({'view': 'audit', 'text': 'Pendência sem link'})
            s3 = Store(path, backup=False)
            self.assertEqual([x['id'] for x in s3.review_list()], [c['id']])
            self.assertEqual(s1.active_id, s3.active_id)


if __name__ == '__main__':
    unittest.main()

import sys,unittest,json,gzip
from pathlib import Path
sys.path.insert(0,'.')
from core.project import Project

class Origem(unittest.TestCase):
    def setUp(self):
        self.p=Project(json.loads((Path(__file__).resolve().parents[1]/'data'/'exemplos'/'exemplo.json').read_text(encoding='utf-8')))
    def ch(self,a,v):self.p.update([{'sheet':'Padrão de entrada','address':a,'value':v}])
    def test_entrada_completa(self):
        # v2.3: exemplo não inventa o elo/curva da proteção MT, agora obrigatórios.
        o=self.p.origem();self.assertEqual(o['status'],'pending')
        self.assertTrue(all('elo' in m for m in o['pendencias']))
        self.assertIn('Gerador BT',o['tipos'])
    def test_trafo_sem_potencia_fica_pendente(self):
        self.ch('B75',None)
        o=self.p.origem();self.assertEqual(o['status'],'pending');self.assertTrue(any('transformador' in m for m in o['pendencias']))
    def test_troca_de_tipo_usa_obrigatorios_do_novo_tipo(self):
        self.ch('B2','Rede BT Direta');self.assertEqual(self.p.origem()['status'],'ok')
        self.ch('B34',None);o=self.p.origem()
        self.assertEqual(o['status'],'pending');self.assertTrue(any('disjuntor de medição' in m for m in o['pendencias']))
    def test_mt_com_dados_exige_campos_do_modo(self):
        self.ch('B2','Rede MT/Trafo com dados');self.ch('B11','Pcc (kVA)');self.ch('B14',None)
        self.assertEqual(self.p.origem()['status'],'pending')
    def test_sem_tipo(self):
        self.ch('B2',None);o=self.p.origem()
        self.assertEqual(o['status'],'pending');self.assertIn('tipo de atendimento',o['pendencias'][0])
if __name__=='__main__':unittest.main()

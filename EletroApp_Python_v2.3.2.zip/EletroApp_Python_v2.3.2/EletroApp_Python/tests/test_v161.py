"""v1.6.1: Icu/Ics do catálogo, troca de modelo, DPS com Siemens/Clamper, backup fusível/disjuntor."""
import sys,unittest,json,gzip,copy
from pathlib import Path
sys.path.insert(0,'.')
from core.project import Project
from core import catalog_icu
RAIZ=Path(__file__).resolve().parent.parent
def carregar():return Project(json.loads((Path(__file__).resolve().parents[1]/'data'/'exemplos'/'exemplo.json').read_text(encoding='utf-8')))
P='Cálc-Prot_Cabos'

class CatalogoIcu(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(catalog_icu.parse('50 kA (220/250V)','50 kA (220/250V) — 100%Icu'),(50,50,220))
        self.assertEqual(catalog_icu.parse('75 kA (220/240V)','56,25 (75% Icu — NÃO é 100%Icu) kA (220/240V)'),(75,56.25,220))
        self.assertEqual(catalog_icu.parse('120 kA (220/240V)','120 kA — Ics=100%Icu'),(120,120,220))
        self.assertEqual(catalog_icu.parse('5 kA (127/220V, IEC 60947-2) / 4 kA (230/400V, IEC 60947-2)','N/D — CONSULTAR WEG'),(5,None,220))
        self.assertEqual(catalog_icu.parse('50 kA (380V, S) / 65 kA (H)','N/D — CONSULTAR WEG'),(50,None,380))   # menor valor, 380 V = limite conservador
        self.assertIsNone(catalog_icu.parse('65 kA (690V, classe X)','65 kA (690V) — Ics=100%Icu SÓ a 690V'))
        self.assertIsNone(catalog_icu.parse('36 kA (380V, versão N) — DWB160-N tem exceção: 30kA@380V','N/D'))
    def test_modelo_agw400_deixa_de_ser_incompleto(self):
        p=carregar()
        p.update([{'sheet':P,'address':'AL4','value':'AGW400'},{'sheet':P,'address':'AM4','value':'AGW400N-DX300-3'}],validate_installation=False)
        self.assertEqual(p.get(P,'AA4'),50);self.assertEqual(p.get(P,'AB4'),50)
        self.assertNotIn('INCOMPLETOS',str(p.get(P,'BJ4')))
    def test_idempotente_e_nao_sobrescreve(self):
        d=json.loads(gzip.decompress((Path(__file__).resolve().parent/'fixtures'/'projeto_v1.json.gz').read_bytes()))  # projeto da v1.x
        catalog_icu.apply(d);antes=copy.deepcopy(d['sheets'][catalog_icu.SHEET]['cells'])
        self.assertEqual(catalog_icu.apply(d),0)
        self.assertEqual(d['sheets'][catalog_icu.SHEET]['cells']['AA59']['value'],120)    # linha já verificada intacta

class TrocaModelo(unittest.TestCase):
    def test_fixo_zera_ajustes_do_modelo_eletronico(self):
        p=carregar()
        p.update([{'sheet':P,'address':'AL4','value':'AGW400'},{'sheet':P,'address':'AM4','value':'AGW400N-DX300-3'}],validate_installation=False)
        g=lambda c:p.raw(P,c+'4')
        self.assertEqual((g('K'),g('Y'),g('Z')),(300,300,3000))
        self.assertEqual((g('BX'),g('BZ'),g('CA')),('N/A','N/A','N/A'))
        st=str(p.get(P,'BJ4'))
        for ruim in ('FORA DA FAIXA','PASSO','AJUSTES INCOMPATÍVEIS','CATÁLOGO INCOMPLETOS'):self.assertNotIn(ruim,st)
    def test_eletronico_ir_dentro_de_ib_iz(self):
        p=carregar()
        p.update([{'sheet':P,'address':'AM4','value':'AGW400N-DX300-3'}],validate_installation=False)
        p.update([{'sheet':P,'address':'AL4','value':'ACW400H_630H'},{'sheet':P,'address':'AM4','value':'ACW400H-ETS400-3'}],validate_installation=False)
        ib,iz=p.get(P,'D4'),p.get(P,'F4');y=p.raw(P,'Y4')
        self.assertGreaterEqual(y,ib);self.assertLessEqual(y,iz)
        self.assertIn(y,[160,180,200,220,240,260,280,300,320,340,360,380,400])
        self.assertEqual((p.raw(P,'BZ4'),p.raw(P,'CA4')),('100','OFF'))
    def test_servidor_aceita_na_em_isd_ao_trocar_para_fixo(self):
        p=carregar()
        p.update([{'sheet':P,'address':'AL4','value':'AGW400'},{'sheet':P,'address':'AM4','value':'AGW400N-DX300-3'},
                  {'sheet':P,'address':'Y4','value':300},{'sheet':P,'address':'Z4','value':3000},{'sheet':P,'address':'BX4','value':'N/A'},
                  {'sheet':P,'address':'BZ4','value':'N/A'},{'sheet':P,'address':'CA4','value':'N/A'}],validate_installation=False)
        self.assertEqual(p.raw(P,'BX4'),'N/A')
    def test_ajuste_enviado_junto_prevalece(self):
        p=carregar()
        p.update([{'sheet':P,'address':'AM4','value':'ACW400H-ETS400-3'},{'sheet':P,'address':'Y4','value':340}],validate_installation=False)
        self.assertEqual(p.raw(P,'Y4'),340)

class Dps(unittest.TestCase):
    def setUp(self):self.p=carregar()
    def d(self,c,r=2):return self.p.get('DPS',f'{c}{r}')
    def set(self,**kw):
        self.p.update([{'sheet':'DPS','address':k+'2','value':v} for k,v in kw.items()],validate_installation=False)
    def test_padrao_siemens_usa_catalogo_5sd7(self):
        self.assertEqual(self.d('AB'),'SIEMENS');self.assertEqual(self.d('AV'),'5SD7 443-1')
        self.assertEqual(self.d('AH'),315);self.assertEqual(self.d('AG'),'Fusível gL/gG')
        self.assertEqual(self.d('AJ'),25)                                    # Isccr do conjunto (manual Siemens)
        self.assertIn('MODELO SIEMENS CONFIRMADO',self.d('AS'))
    def test_clamper_continua_disponivel(self):
        self.set(BH='CLAMPER')
        self.assertEqual(self.d('AB'),'CLAMPER');self.assertEqual(self.d('AH'),100)
        self.assertIn('MODELO CLAMPER CONFIRMADO',self.d('AS'))
    def test_fusivel_vem_da_biblioteca_nh(self):
        self.assertEqual(self.d('AF'),'NH gG 80 A · In 80 A · Icu 120 kA (500 V AC)')     # menor In ≥ dimensionado (80 A)
        self.assertEqual((self.d('R'),self.d('AI')),(80,120));self.assertTrue(self.d('AS').startswith('✓'))
        self.set(BP='NH gG 100 A');self.assertEqual(self.d('R'),100);self.assertEqual(self.d('AF').split(' · ')[0],'NH gG 100 A')
        self.set(BP='NH gG 315 A');self.assertEqual(self.d('R'),315);self.assertTrue(self.d('AQ').startswith('✓'))    # = limite do fabricante
        self.set(BP='NH gG 400 A');self.assertTrue(self.d('AQ').startswith('✗'))                                      # acima de 315 A
        with self.assertRaises(ValueError):self.set(BP='NH gG 81 A')
        cand=self.p.backup_fusivel(2)['candidatos']
        self.assertTrue(all(80<=c['in']<=315 and c['icu']>=self.d('Q') for c in cand))
    def test_icu_informado_substitui_catalogo(self):
        self.set(BJ=10)
        self.assertEqual(self.d('AI'),10);self.assertTrue(self.d('T').startswith('✓') or self.d('T').startswith('✗'))
    def test_disjuntor_vem_do_catalogo_weg(self):
        self.set(BI='DISJUNTOR (equivalência)')                      # sugere automaticamente um modelo do catálogo
        bm=self.p.raw('DPS','BM2');self.assertTrue(bm)
        b=self.p.backup_disjuntor(2);self.assertEqual(b['sugerido'],bm)
        ik,lim,base=self.d('Q'),self.d('AH'),self.d('BO')
        for c in b['candidatos']:
            self.assertGreaterEqual(c['icu'],ik);self.assertTrue(base<=c['in']<=lim)   # Icu ≥ Ik; In entre o dimensionado e o máximo do fabricante
        self.assertIn(bm,self.d('AF'));self.assertTrue(self.d('AE').startswith('WEG'))
        self.assertEqual(self.d('R'),b['candidatos'][0]['in']);self.assertEqual(self.d('AI'),b['candidatos'][0]['icu'])
        self.assertTrue(self.d('AO').startswith('△'));self.assertTrue(self.d('AS').startswith('△'));self.assertIn('EQUIVALÊNCIA',self.d('AS'))
        self.set(BK='SIM',BL='Carta do fabricante 01/2026')
        self.assertTrue(self.d('AS').startswith('✓'));self.assertIn('Carta do fabricante',self.d('AS'));self.assertTrue(self.d('AP').startswith('✓'))
    def test_disjuntor_com_icu_menor_que_ik_reprova(self):
        self.set(BI='DISJUNTOR (equivalência)',BM='MDW-C80-3')      # 5 kA < Ik no ponto
        self.assertTrue(self.d('T').startswith('✗'));self.assertTrue(self.d('AS').startswith('✗'))
    def test_modelo_de_backup_inexistente_e_recusado(self):
        with self.assertRaises(ValueError):self.set(BM='XYZ-123')
    def test_declaracao_fabricante_confirma_fusivel(self):
        self.set(BK='SIM',BL='Siemens 5SD7 – doc X')
        self.assertTrue(self.d('AS').startswith('✓'));self.assertIn('DECLARAÇÃO',self.d('AS'))
    def test_backup_acima_do_limite_do_fabricante_reprova(self):
        self.set(BH='CLAMPER');lim=self.d('AH');self.assertEqual(lim,100)
        self.assertTrue(self.d('R')<=lim)

if __name__=='__main__':unittest.main()

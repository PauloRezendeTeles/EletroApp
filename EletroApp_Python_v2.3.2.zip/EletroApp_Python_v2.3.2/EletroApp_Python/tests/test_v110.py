"""v1.10 — dispositivo na origem opcional, disjuntor de manutenção na extremidade e DPS opcional."""
import copy
import gzip
import json
import re
import unittest
from pathlib import Path
from core.project import Project, IDENT, unpack
from core.formula import Engine, address
from core.catalog import Catalog
from core.advisor import selectivity_precheck
from core import trecho, selection

ROOT=Path(__file__).resolve().parents[1]
BASE=json.loads((Path(__file__).resolve().parents[1]/'data'/'exemplos'/'exemplo.json').read_text(encoding='utf-8'))
T=trecho.SHEET;C=trecho.COL

def load():return Project(copy.deepcopy(BASE))
def change(p,s,**values):
    p.update([{'sheet':s,'address':a,'value':v} for a,v in values.items()],validate_installation=False)
def tchange(p,r,**values):
    p.update([{'sheet':T,'address':f'{C[k]}{r}','value':v} for k,v in values.items()],validate_installation=False)
def set_mode(p,r,key,value):
    change(p,selection.SHEET,**{key+':'+p.meta['ids'][str(r)]:value})
def g(p,key,r):return p.get(T,f'{C[key]}{r}')
FIXTURE=Path(__file__).resolve().parent/'fixtures'/'projeto_v1.json.gz'
def legacy():return json.loads(gzip.decompress(FIXTURE.read_bytes()))
def snapshot(p):
    """Todos os cálculos de todos os circuitos, da fonte e do projeto, por variável e circuito."""
    out={}
    for v in p.model.circuit:
        if v.kind!='formula':continue
        for r in p.active_rows():out[(v.id,r)]=p.engine.get(v.sheet,f'{v.col}{r}')
    for v in p.model.fonte+p.model.project:
        if v.kind=='formula':out[(v.id,None)]=p.engine.get(v.sheet,v.addr)
    return out

def ramal_sem_origem(p,mb=True,tempo=.5,condicoes='SIM'):
    values=dict(origem=trecho.ORIGEM_NAO,justificativa=trecho.JUSTIFICATIVAS[0],condicoes=condicoes,tempo_montante=tempo)
    if mb:values.update(manut='SIM',mb_familia='ACW400H_630H',mb_modelo='ACW400H-ETS400-3',mb_ir=320,mb_ii=4400,mb_isd=1600,mb_tsd=100)
    tchange(p,2,**values)


class Regression(unittest.TestCase):
    def test_migrated_legacy_project_reproduces_native_results(self):
        """Projeto salvo pela v1.x, convertido ao abrir, dá exatamente os resultados do modelo nativo."""
        old=Project(legacy());new=load()
        self.assertEqual(old.doc['formulas'],{},'sem fórmulas alteradas no projeto da v1.x')
        a,b=snapshot(old),snapshot(new)
        self.assertEqual(set(a),set(b))
        def same(x,y):
            if isinstance(x,float) and isinstance(y,float):return abs(x-y)<=1e-9*max(1,abs(x))
            return x==y
        diffs=[k for k in a if not same(a[k],b[k])]
        self.assertEqual(diffs,[])
        self.assertGreater(len(a),5000)

    def test_patch_is_idempotent_and_survives_save(self):
        from core import migracao
        d=legacy();migracao._patch(d)
        self.assertEqual(trecho.apply(d),0)
        p=load();restored=Project(unpack(p.packed()))
        self.assertEqual(restored.get('Seletividade','V4'),p.get('Seletividade','V4'))
        self.assertIn('TRECHO_SE(',p.raw('Seletividade','V4'))
        self.assertEqual(p.var_at('Seletividade','V4').id,'seletividade.status_final_da_pre_seletividade')

    def test_trecho_se_evaluates_only_the_chosen_branch(self):
        data={'sheets':{'S':{'cells':{'A1':{'value':'=TRECHO_SE(FALSE,1/0,7)','formula':True},
                                      'A2':{'value':'=TRECHO_SE(TRUE,"x",SQRT(-1))','formula':True}}}}}
        e=Engine(data)
        self.assertEqual(e.get('S','A1'),7);self.assertEqual(e.get('S','A2'),'x')
        self.assertFalse(e.diagnostics)

    def test_catalog_still_recognizes_and_edits_wrapped_formulas(self):
        p=load();cat=Catalog(p)
        for sheet,a in [('Seletividade','V4'),('Auditoria_Checklist','I4'),('DPS','J4'),('Cálc-Prot_Cabos','BJ4')]:
            self.assertIsNotNone(cat.get(p.var_at(sheet,a).id),sheet+'!'+a)
        trace=cat.trace(p.meta['ids']['4'],'Seletividade!V4')
        self.assertTrue(trace['catalogo_id'])
        eid=p.var_at('Auditoria_Checklist','I4').id
        new=cat.entry_view(cat.get(eid))['expressao'].replace('"✓ Ib≤Ir≤Iz"','"✓ Ib ≤ Ir ≤ Iz"')
        cand=copy.deepcopy(p.data);cand=Project(cand)
        Catalog(cand).commit_edit(cand,eid,new,'Revisor','Teste do envoltório do trecho após edição.')
        self.assertTrue(cand.raw('Auditoria_Checklist','I4').startswith('=TRECHO_SE('))
        ramal_sem_origem(cand)
        self.assertTrue(cand.get('Auditoria_Checklist','I2').startswith('✓ PELO DISJUNTOR DE MANUTENÇÃO'))


class OriginIcuAtInstallationPoint(unittest.TestCase):
    """Icu/Ics do dispositivo da origem comparados ao Ik do quadro onde ele está instalado."""
    def test_ik_of_upstream_board(self):
        p=load();K=C['ik_origem'];S='Cálc_Icc-Cond_Escolhido'
        # QDFL-01 sai do QGBT-01: vale o Ik do barramento do QGBT-01, não o do fim do próprio cabo.
        self.assertEqual(p.get(T,f'{K}5'),p.get(S,'S4'))
        self.assertGreater(p.get(T,f'{K}5'),p.get(S,'S5'))
        self.assertIs(p.get('Cálc-Prot_Cabos','AF5'),False)   # MDW-C80-2, Icu 5 kA < 8,93 kA
        self.assertTrue(p.get('Auditoria_Checklist','J5').startswith('✗'))
        # Ramal ligado ao transformador: Ik nos terminais, maior que no fim do ramal.
        self.assertGreater(p.get(T,f'{K}2'),p.get(S,'S2'))
        # A seleção automática usa o mesmo Ik.
        self.assertEqual(selection.breaker_candidates(p,5)['ik'],p.get(S,'S4'))

    def test_catalog_and_old_projects(self):
        p=load();cat=Catalog(p)
        v=p.var_at('Cálc-Prot_Cabos','AF5');self.assertIsNotNone(cat.get(v.id))
        self.assertIn('trecho.ik_origem',p.raw('Cálc-Prot_Cabos','AF5'))
        # Projeto salvo numa versão anterior do envoltório recebe a correção ao ser convertido.
        data=legacy();data['meta']['trecho_version']=1
        for r in range(2,8):
            c=data['sheets']['Cálc-Prot_Cabos']['cells'].get(f'AF{r}')
            if c and c.get('formula'):c['value']=trecho.unwrap(c['value'])
        q=Project(data)
        self.assertNotIn(v.id,q.doc['formulas'])
        self.assertEqual(q.raw('Cálc-Prot_Cabos','AF5'),p.raw('Cálc-Prot_Cabos','AF5'))
        self.assertEqual(q.get('Cálc-Prot_Cabos','AF5'),p.get('Cálc-Prot_Cabos','AF5'))


class NoOriginDevice(unittest.TestCase):
    def test_transformer_link_with_maintenance_breaker(self):
        p=load();ramal_sem_origem(p)
        self.assertIs(g(p,'sem_origem',2),True)
        self.assertEqual(p.get('Cálc-Prot_Cabos','BJ2'),'N/A — SEM DISPOSITIVO NA ORIGEM')
        self.assertTrue(p.get('Auditoria_Checklist','I2').startswith('✓ PELO DISJUNTOR DE MANUTENÇÃO NA EXTREMIDADE'))
        # v2.3: justificativa física não substitui dados da proteção a montante.
        self.assertIn('NÃO VERIFICADA',p.get('Auditoria_Checklist','J2'))
        self.assertTrue(p.get('Auditoria_Checklist','K2').startswith('✓ DISJUNTOR DE MANUTENÇÃO COMPATÍVEL'))
        self.assertIn('NÃO VERIFICADA',p.get('Cálc-Prot_Choque','Z2'))
        self.assertEqual(g(p,'mb_funcao',2),'I — INSTANTÂNEA')
        # O tempo manual antigo fica preservado, mas não comprova a proteção MT.
        self.assertEqual(g(p,'tempo_montante',2),.5)
        self.assertIn('N/D',p.get('Cálc-Condutor_Terra_Sugerido','I2'))
        # O quadro a jusante passa a ser alimentado pelo disjuntor de manutenção.
        self.assertEqual(p.get('Seletividade','W3'),'Disjuntor de manutenção de Ramal de entrada')
        self.assertEqual((p.get('Seletividade','E3'),p.get('Seletividade','M3')),(400,320))
        c=p._circuit(2)
        self.assertTrue(c['origem_ausente']);self.assertIsNone(c['protecao_ajuste'])
        self.assertEqual(c['manutencao']['ajuste'],'In400A_Ir320A')
        self.assertTrue(all(x['group'] in ('trecho','integrada') for x in c['issues'] if x['address'][0] in 'IJKL'))

    def test_missing_information_stays_pending(self):
        p=load();tchange(p,3,origem=trecho.ORIGEM_NAO)
        for col in 'JL':self.assertTrue(p.get('Auditoria_Checklist',f'{col}3').startswith('⏳'))
        # A sobrecarga já se resolve pela cadeia sem derivações: na r42, o disjuntor da origem do QGBT-01
        # (Ir 320 A) não protege o cabo do QM-01 (Iz 313 A).
        self.assertTrue(p.get('Auditoria_Checklist','I3').startswith('✗ DISPOSITIVO A JUSANTE NÃO PROTEGE O CABO — dispositivo da origem de QGBT-01'))
        self.assertEqual(p.get('Auditoria_Checklist','K3'),'N/A — sem disjuntor no trecho')
        self.assertEqual(p.get('Seletividade','V3'),'N/A — SEM DISPOSITIVO NESTE TRECHO')
        # Sem tempo da proteção a montante, o PE segue a tabela 58.
        self.assertEqual(p.get('Cálc-Condutor_Terra_Sugerido','M3'),p.get('Cálc-Condutor_Terra_Sugerido','L3'))
        # QGBT-01 é alimentado pelo QM-01, que não tem dispositivo: o montante efetivo é o da origem do ramal.
        self.assertEqual(p.get('Seletividade','W4'),'Dispositivo da origem de Ramal de entrada')
        self.assertEqual(p.get('Seletividade','E4'),p.get('Cálc-Prot_Cabos','K2'))
        self.assertNotEqual(p._circuit(3)['status'],'ok')

    def test_rejected_conditions_and_slow_upstream_protection_fail(self):
        p=load();ramal_sem_origem(p,mb=False,condicoes='NÃO',tempo=6)
        self.assertTrue(p.get('Auditoria_Checklist','J2').startswith('✗ CONDIÇÕES DA DISPENSA NÃO ATENDIDAS'))
        self.assertIn('NÃO VERIFICADA',p.get('Cálc-Prot_Choque','Z2'))
        self.assertEqual(p._circuit(2)['status'],'error')
        self.assertEqual(p.get('Seletividade','V3'),'N/A — SEM DISPOSITIVO DE PROTEÇÃO A MONTANTE')
        # A sobrecarga do ramal fica com o dispositivo da origem do QM-01 (cadeia sem derivações)…
        self.assertTrue(p.get('Auditoria_Checklist','I2').startswith('✓ PELO DISPOSITIVO DA ORIGEM DE QM-01'))
        # …até surgir uma derivação no quadro alimentado pelo ramal.
        p.add('Iluminação externa','Ramal de entrada')
        self.assertTrue(p.get('Auditoria_Checklist','I2').startswith('✗ TRECHO SEM PROTEÇÃO CONTRA SOBRECARGA'))

    def test_automatic_origin_choice_is_suspended(self):
        p=load();set_mode(p,2,'protecao',selection.AUTO)
        before=p.raw('Cálc-Prot_Cabos','AM2')
        tchange(p,2,origem=trecho.ORIGEM_NAO)
        self.assertEqual(p.raw('Cálc-Prot_Cabos','AM2'),before)
        self.assertIn('não se aplica',p.meta['selection_results'][p.meta['ids']['2']]['protecao'])


class MaintenanceBreaker(unittest.TestCase):
    def test_automatic_choice_protects_cable_only_without_origin(self):
        p=load();tchange(p,4,manut='SIM');set_mode(p,4,'manutencao',selection.AUTO)
        ib,iz=p.get('Cálc-Prot_Cabos','D4'),p.get('Cálc-Prot_Cabos','F4')
        ik=p.get('Cálc_Icc-Cond_Escolhido','S4')
        model=p.raw(T,f"{C['mb_modelo']}4");ir=g(p,'mb_ir',4)
        self.assertTrue(model)
        self.assertGreaterEqual(ir,ib);self.assertGreaterEqual(g(p,'mb_icu',4),ik)
        self.assertEqual(g(p,'mb_ir_iz',4),'N/A')
        cand=selection.maintenance_candidates(p,4)
        self.assertFalse(cand['protege_cabo'])
        tchange(p,4,origem=trecho.ORIGEM_NAO,justificativa=trecho.JUSTIFICATIVAS[2],condicoes='SIM',tempo_montante=.3)
        cand=selection.maintenance_candidates(p,4)
        self.assertTrue(cand['protege_cabo'])
        self.assertTrue(all(ib<=x['ir']<=iz for x in cand['items']))
        self.assertLessEqual(g(p,'mb_ir',4),iz)

    def test_manual_choice_flags_and_resets(self):
        p=load();set_mode(p,4,'manutencao',selection.MANUAL)
        tchange(p,4,manut='SIM',mb_familia='DWB400',mb_modelo='DWB400N200-3DA')
        # Sem ajustes enviados, a troca de modelo carrega ajustes válidos do catálogo.
        self.assertEqual(g(p,'mb_ir',4),200)
        self.assertTrue(g(p,'mb_status',4).startswith('✗ Ir (200 A) MENOR QUE Ib'))
        self.assertEqual(selection.modes(p,4)['manutencao'],selection.MANUAL)
        c=p._circuit(4)
        self.assertTrue(any(x['label']=='Disjuntor de manutenção' and x['group']=='trecho' for x in c['issues']))
        with self.assertRaises(ValueError):tchange(load(),4,manut='SIM',mb_modelo='MODELO-INEXISTENTE')
        magnetic=next(m['modelo'] for m in p.weg_catalog() if m['somente_magnetico'])
        with self.assertRaises(ValueError):tchange(load(),4,manut='SIM',mb_modelo=magnetic)

    def test_existing_projects_and_new_circuits(self):
        p=load()
        self.assertEqual(selection.modes(p,4)['manutencao'],selection.AUTO)
        uid=p.meta['ids']['6'];tchange(p,6,manut='SIM',origem=trecho.ORIGEM_NAO)
        change(p,IDENT,D5='QDFL-03',M7='Distribuição')  # QDFL-03 sobe; QDFL-01 e QDFL-02 descem uma linha
        r=p.row_for(uid);self.assertEqual(r,7)
        self.assertEqual(p.raw(T,f"{C['manut']}{r}"),'SIM')
        self.assertEqual(p.raw(T,f"{C['origem']}{r}"),trecho.ORIGEM_NAO)
        new=p.add('Novo QD','QGBT-01');rn=p.row_for(new)
        self.assertTrue(all(p.raw(T,f'{c}{rn}') in (None,'') for c in trecho.INPUTS))
        dup=p.add('Cópia','QGBT-01',uid)
        self.assertEqual(p.raw(T,f"{C['manut']}{p.row_for(dup)}"),'SIM')


class OptionalSurgeProtection(unittest.TestCase):
    def test_board_without_spd_and_cascade(self):
        p=load();change(p,'DPS',BT3=trecho.DPS_NAO)
        self.assertEqual(p.get('DPS','J3'),'—');self.assertEqual(p.get('DPS','AS3'),'N/A')
        self.assertTrue(p.get('DPS','I3').startswith('✗ Não'))
        self.assertEqual(p.get('DPS','BV4'),'Ramal de entrada')
        self.assertEqual(p.get('DPS','U4'),p.get('DPS','J2'))
        self.assertTrue(p.get('DPS','V4').startswith('△ ARRANJO COERENTE'))
        self.assertEqual(p.get('DPS','AL4'),p.get('DPS','G4')-p.get('DPS','G2'))
        self.assertIn('Sem DPS neste quadro',selection.dps_status(p,3))
        c=p._circuit(3);self.assertTrue(c['dps_ausente']);self.assertFalse(c['dps_recomendado'])

    def test_first_spd_with_lightning_protection_becomes_type_1(self):
        p=load();change(p,'DPS',BT2=trecho.DPS_NAO,H3='Sim')
        self.assertEqual(p.get('DPS','J3'),'Tipo 1+2 / Classe I+II')
        self.assertEqual(p.get('DPS','V3'),'✓ PRIMEIRO DPS DA INSTALAÇÃO')
        change(p,'DPS',BT3=trecho.DPS_T2)
        self.assertTrue(p.get('DPS','V3').startswith('✗ PRIMEIRO DPS DA INSTALAÇÃO COM SPDA'))

    def test_spd_forced_in_final_circuit(self):
        p=load();change(p,'DPS',BT5=trecho.DPS_T2)
        self.assertEqual(p.get('DPS','J5'),'Tipo 2 / Classe II')
        self.assertTrue(p.get('DPS','I5').startswith('✓ SIM — definido'))

    def test_invalid_inputs_rejected(self):
        for sheet,address,value in [(T,f"{C['origem']}4",'talvez'),(T,f"{C['tempo_montante']}4",-1),
                                    (T,f"{C['condicoes']}4",'OK'),('DPS','BT4','Tipo 3')]:
            with self.subTest(address=address),self.assertRaises(ValueError):change(load(),sheet,**{address:value})


class DownstreamChain(unittest.TestCase):
    """Trechos em cadeia sem derivações protegidos contra sobrecarga pelo disjuntor de manutenção a jusante."""
    def test_entry_example_preset(self):
        p=load();p.update(trecho.exemplo_entrada(p),validate_installation=False)
        for r in (2,3):
            self.assertIs(g(p,'sem_origem',r),True)
            self.assertEqual((g(p,'jus_ir',r),g(p,'jus_desc',r)),(300,'disjuntor de manutenção de QGBT-01'))
            self.assertTrue(g(p,'trecho_sobrecarga',r).startswith('✓ PELO DISJUNTOR DE MANUTENÇÃO DE QGBT-01 — Ir 300 A ≤ Iz'))
            # As confirmações físicas ficam com o projetista.
            self.assertTrue(g(p,'trecho_curto',r).startswith('⏳'));self.assertIn('NÃO VERIFICADA',g(p,'trecho_choque',r))
            self.assertEqual(p.get('DPS',f'J{r}'),'—')
        self.assertTrue(g(p,'trecho_sobrecarga',4).startswith('✓ PELO DISJUNTOR DE MANUTENÇÃO NA EXTREMIDADE'))
        self.assertEqual(selection.modes(p,4)['manutencao'],selection.MANUAL)
        self.assertEqual(p.get('DPS','V4'),'✓ PRIMEIRO DPS DA INSTALAÇÃO')
        self.assertEqual([p.get('Seletividade',f'W{r}') for r in (5,6,7)],['Disjuntor de manutenção de QGBT-01']*3)
        self.assertFalse(p.engine.diagnostics)

    def test_chain_fails_when_breaker_exceeds_upstream_cable(self):
        p=load();p.update(trecho.exemplo_entrada(p),validate_installation=False)
        tchange(p,4,mb_ir=400)
        iz=p.get('Cálc-Prot_Cabos','F3')
        self.assertLess(iz,400)
        self.assertTrue(g(p,'trecho_sobrecarga',3).startswith('✗ DISPOSITIVO A JUSANTE NÃO PROTEGE O CABO — disjuntor de manutenção de QGBT-01 com Ir 400 A > Iz'))
        self.assertTrue(p.get('Auditoria_Checklist','I3').startswith('✗'))

    def test_derivation_breaks_the_chain(self):
        p=load();p.update(trecho.exemplo_entrada(p),validate_installation=False)
        p.add('Iluminação da medição','QM-01')  # QM-01 passa a ter duas saídas
        self.assertEqual(g(p,'filhos',3),2)
        for r in (2,3):
            self.assertEqual(g(p,'jus_ir',r),'')
            self.assertTrue(g(p,'trecho_sobrecarga',r).startswith('⏳ PENDENTE'))
        # Com a dispensa confirmada, o trecho fica com alerta (5.3.4.3), não aprovado.
        tchange(p,3,condicoes='SIM')
        self.assertTrue(g(p,'trecho_sobrecarga',3).startswith('△ SEM PROTEÇÃO CONTRA SOBRECARGA NO TRECHO'))

    def test_chain_ends_at_next_origin_device(self):
        p=load();p.update(trecho.exemplo_entrada(p),validate_installation=False)
        tchange(p,4,origem='',manut='')  # QGBT-01 volta a ter disjuntor na origem
        self.assertEqual((g(p,'jus_ir',2),g(p,'jus_ir',3)),(p.get('Cálc-Prot_Cabos','Y4'),)*2)
        self.assertEqual(g(p,'jus_desc',3),'dispositivo da origem de QGBT-01')

    def test_board_with_own_load_breaks_the_chain(self):
        p=load();p.update(trecho.exemplo_entrada(p),validate_installation=False)
        tchange(p,4,manut='')  # QGBT-01 sem dispositivo na origem e sem disjuntor de manutenção
        for uid in (p.meta['ids']['7'],p.meta['ids']['6']):p.delete(uid)
        self.assertEqual((g(p,'filhos',4),g(p,'carga_propria',4)),(1,43000))
        self.assertEqual(g(p,'jus_ir',3),'')
        # Sem carga própria no QGBT-01, a cadeia segue até o dispositivo da origem do QDFL-01.
        change(p,'Levantamento de carga',D4=0,H4=0,L4=0)
        self.assertEqual((g(p,'jus_ir',3),g(p,'jus_desc',3)),(p.get('Cálc-Prot_Cabos','Y5'),'dispositivo da origem de QDFL-01'))
        self.assertTrue(g(p,'trecho_sobrecarga',2).startswith('✓ PELO DISPOSITIVO DA ORIGEM DE QDFL-01'))


class InterfaceData(unittest.TestCase):
    def test_form_audit_and_advisor(self):
        p=load();ramal_sem_origem(p)
        f=p.form(p.meta['ids']['2'])
        groups={x['key']:x for x in f['groups']}
        self.assertEqual([x['trecho_key'] for x in groups['trecho']['fields']][:2],['origem','justificativa'])
        self.assertTrue(groups['trecho']['trecho']['sem_origem'])
        self.assertEqual(next(t for t in f['info'] if t['key']=='protecoes')['groups'],['integrada','trecho','protecao','choque'])
        # Editar diretamente o modelo do disjuntor de manutenção é uma escolha manual (mesma regra da origem).
        self.assertEqual(f['workflow']['modes']['manutencao'],selection.MANUAL)
        self.assertEqual(next(x for x in groups['dps']['fields'] if x['address']=='BH2')['empty_label'],'Siemens (padrão)')
        q=p._circuit(4)
        self.assertTrue(all(x.get('group') for x in q['issues']))
        self.assertTrue(any(x.get('focus')=={'sheet':'Cálc-Prot_Cabos','col':'CX'} for x in q['issues']))
        blocked=p._circuit(5)['issues'][0]
        self.assertTrue(blocked['blocks'] and blocked['group']=='metodo')
        self.assertIn('Disjuntor de manutenção de Ramal de entrada',selectivity_precheck(p,3)['message'])



class HttpV19(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import secrets,tempfile,threading,urllib.request,sys
        sys.path.insert(0,str(ROOT))
        from http.server import ThreadingHTTPServer
        from app import Handler,Store
        cls.tmp=tempfile.TemporaryDirectory()
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        cls.server.store=Store(Path(cls.tmp.name)/'projects.sqlite3')
        cls.server.token=secrets.token_urlsafe(24);cls.server.lock=threading.RLock();cls.server.daemon_threads=True
        cls.base=f'http://127.0.0.1:{cls.server.server_port}'
        threading.Thread(target=cls.server.serve_forever,daemon=True).start()
        cls.client=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.tmp.cleanup()
    def get(self,path):return self.client.open(self.base+path,timeout=60).read()
    def post(self,path,data):
        import urllib.request
        req=urllib.request.Request(self.base+path,data=json.dumps(data).encode(),method='POST',
                                   headers={'X-Eletro-Project':self.server.store.active_id,'X-Eletro-Revision':str(self.server.store.revision),'X-Eletro-Token':self.server.token,'Content-Type':'application/json'})
        return json.loads(self.client.open(req,timeout=120).read())
    def test_trecho_flow_over_http(self):
        self.assertIn('trechoGroupHTML',self.get('/trecho.js').decode())
        self.post('/api/projects/new',{'name':'Exemplo v1.10','blank':False})  # independente da ordem dos testes
        state=json.loads(self.get('/api/state'));uid=state['circuits'][0]['id']
        form=json.loads(self.get('/api/form?id='+uid))
        fields=next(g for g in form['groups'] if g['key']=='trecho')['fields']
        addr={f['trecho_key']:f['address'] for f in fields}
        changes=[{'sheet':T,'address':addr['origem'],'value':trecho.ORIGEM_NAO},
                 {'sheet':T,'address':addr['justificativa'],'value':'Ligação curta em barramento blindado'},
                 {'sheet':T,'address':addr['condicoes'],'value':'SIM'},{'sheet':T,'address':addr['tempo_montante'],'value':0.4},
                 {'sheet':T,'address':addr['manut'],'value':'SIM'},
                 {'sheet':selection.SHEET,'address':'manutencao:'+uid,'value':selection.AUTO}]
        preview=self.post('/api/choices/preview',{'id':uid,'changes':changes})
        self.assertTrue(next(g for g in preview['groups'] if g['key']=='trecho')['trecho']['tem_mb'])
        self.assertTrue(preview['workflow']['maintenance']['items'])
        self.post('/api/changes',{'changes':changes})
        c=json.loads(self.get('/api/state'))['circuits'][0]
        self.assertTrue(c['origem_ausente']);self.assertTrue(c['manutencao']['modelo'])
        csv=self.get('/api/export?format=csv').decode('utf-8-sig')
        self.assertIn('Disjuntor de manutenção',csv.splitlines()[0]);self.assertIn('Sem dispositivo na origem',csv)
        self.assertIn('Dispositivos do trecho',self.get('/report').decode())
    def test_new_project_with_entry_preset(self):
        self.post('/api/projects/new',{'name':'Entrada sem disjuntor','blank':False,'preset':'entrada_sem_disjuntor'})
        circuits=json.loads(self.get('/api/state'))['circuits']
        self.assertEqual([c['origem_ausente'] for c in circuits[:4]],[True,True,True,False])
        self.assertEqual(circuits[2]['manutencao']['modelo'],'ACW400H-ETS400-3')
        self.assertTrue(circuits[0]['dps_ausente'] and circuits[1]['dps_ausente'])
        with self.assertRaises(Exception):self.post('/api/projects/new',{'name':'X','preset':'outro'})
    def test_new_project_accepts_previous_clients(self):
        self.post('/api/projects/new',{'name':'Cliente anterior','blank':True,
                                       'selection_defaults':{'protecao':'Manual','dps':'Automático','backup':'Automático'}})
        p=self.server.store.project
        self.assertEqual(p.meta['selection_defaults']['manutencao'],selection.AUTO)
        self.assertEqual(p.meta['selection_defaults']['protecao'],selection.MANUAL)


if __name__=='__main__':unittest.main()

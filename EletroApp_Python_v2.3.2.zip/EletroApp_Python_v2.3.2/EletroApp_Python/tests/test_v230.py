"""Proteção física, fontes e corrente variável — ensaios sintéticos, não dados de projeto."""
import copy
import json
import math
import secrets
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
import shutil
import subprocess
from http.server import ThreadingHTTPServer
from pathlib import Path

from app import Handler, Store, report
from core.project import Project, IDENT, unpack
from core import protection as pr, fault_time as ft, protection_links as links, curvas, trecho
from core.catalog import Catalog
from core.protection_schema import *

ROOT=Path(__file__).resolve().parents[1]
BASE=json.loads((ROOT/'data/exemplos/exemplo.json').read_text(encoding='utf-8'))
def load():return Project(copy.deepcopy(BASE))
def changes(sheet,values):return [{'sheet':sheet,'address':a,'value':v} for a,v in values.items()]
def edit(p,s,**values):p.update(changes(s,values),validate_installation=False)
def source(p,**values):edit(p,SOURCE_SHEET,**{SCOL[k]:v for k,v in values.items()})
def integrated(p,r,**values):edit(p,CIRCUIT_SHEET,**{CCOL[k]+str(r):v for k,v in values.items()})
def segment(p,r,**values):edit(p,trecho.SHEET,**{trecho.COL[k]+str(r):v for k,v in values.items()})
def no_origin(p,r):segment(p,r,origem=trecho.ORIGEM_NAO,justificativa=trecho.JUSTIFICATIVAS[0],condicoes=YES)
def relay(p,delay=.3):
    source(p,**{'tipo':RELAY,'50_ativa':NO,'51_ativa':YES,'51_corrente':1,'51_tempo':delay,
               '51_curva':'Tempo definido','50N_ativa':NO,'51N_ativa':NO,'interrupcao_ms':60})
def generator(p):
    edit(p,'Padrão de entrada',B2='Gerador BT')
    segment(p,3,manut=YES,mb_familia='ACW400H_630H',mb_modelo='ACW400H-ETS400-3',
            mb_ir=320,mb_ii=4400,mb_isd=640,mb_tsd=100)
    integrated(p,3,mb_interrupcao_s=.06,mb_instantaneo_s=.01,mb_i2t='OFF')
    source(p,tipo=AUTO,qta=p.meta['ids']['3'],gerador_modo=POINT_CURVES)
    integrated(p,4,vinculo=LINK)
def curve(p,r,end=1,decay=False):
    lines=['falta;tempo_s;i_min_a;i_max_a']
    for f in pr.fault_types(p,r):
        lo=pr.static_current(p,r,f,False);hi=pr.static_current(p,r,f,True)
        lines.extend([f'{f};0;{lo:.6f};{hi:.6f}',f'{f};0.05;{100 if decay else lo:.6f};{150 if decay else hi:.6f}',
                      f'{f};{end};{100 if decay else lo:.6f};{150 if decay else hi:.6f}'])
    return '\n'.join(lines)
def add_curve(p,r,**kw):
    integrated(p,r,curva_documento='Ensaio sintético — não utilizar em projeto',curva_corrente=curve(p,r,**kw))

class TemporalPhysics(unittest.TestCase):
    def test_constant_relay_and_breaker_interruption_once(self):
        laws=[dict(name='51',pickup=100,setting=.3,curve='Tempo definido')]
        r=ft.simulate(lambda t:200,laws,.06,1)
        self.assertAlmostEqual(r['trip_s'],.3,places=9)
        self.assertAlmostEqual(r['clear_s'],.36,places=9)
        self.assertAlmostEqual(ft.energy(lambda t:200,.36),14400,places=6)
    def test_iec_coefficients_against_analytic_constant_current(self):
        for label,k,alpha in [('IEC inversa normal',.14,.02),('IEC muito inversa',13.5,1),('IEC extremamente inversa',80,2)]:
            expected=.1*k/(10**alpha-1)
            result=ft.simulate(lambda t:1000,[dict(name='51',pickup=100,setting=.1,curve=label)],.06,5)
            self.assertAlmostEqual(result['clear_s'],expected+.06,places=8)
    def test_initial_current_does_not_prove_delayed_trip(self):
        law=[dict(name='S',pickup=1000,setting=.2)]
        r=ft.simulate(lambda t:300+2000*math.exp(-t/.02),law,.06,1)
        self.assertIsNone(r['trip_s']);self.assertIsNone(r['clear_s'])
        self.assertIn('até 1 s',r['reason'])
    def test_command_latches_and_curve_must_cover_interruption(self):
        law=[dict(name='50',pickup=100,setting=.01)]
        cur=lambda t:200 if t<.02 else 0
        self.assertAlmostEqual(ft.simulate(cur,law,.06,.1,[.02])['clear_s'],.07,places=6)
        self.assertIsNone(ft.simulate(cur,law,.06,.05,[.02])['clear_s'])
    def test_reset_and_inverse_energy(self):
        law=[dict(name='51',pickup=100,setting=.03)]
        cur=lambda t:200 if t<.02 or .03<t<.05 else 0
        self.assertIsNone(ft.simulate(cur,law,.01,.1,[.02,.03,.05])['trip_s'])
        self.assertAlmostEqual(ft.energy(lambda t:100+50*t,2),2*10000+20000+2500*8/3,places=5)
    def test_curve_validation_and_no_extrapolation(self):
        pts=ft.parse_fuse('corrente_a;t_fusao_min_s;t_eliminacao_max_s\n10;1;2\n100;0,1;0,2')
        self.assertAlmostEqual(ft.interpolate(pts,math.sqrt(1000),2,True),math.sqrt(.4))
        with self.assertRaises(ft.MissingData):ft.interpolate(pts,101,2,True)
        for text in ['falta;tempo_s;i_min_a;i_max_a\n3F;0;20;10\n3F;1;2;3',
                     'falta;tempo_s;i_min_a;i_max_a\n3F;1;1;2\n3F;2;1;2']:
            with self.assertRaises(ValueError):ft.parse_time_curves(text)
    def test_parameter_limits_and_cable_impedance(self):
        args=(.12,.3,2,.02,.4)
        self.assertAlmostEqual(ft.admittance(0,*args),1/.12)
        self.assertAlmostEqual(ft.admittance(30,*args),1/2)
        i0=ft.current_from_parameters(220,1/math.sqrt(3),.1,.2,1,.1,args,0)
        self.assertAlmostEqual(i0,220/math.sqrt(3)/abs(complex(.1,.2)))
        self.assertLess(ft.current_from_parameters(220,1/math.sqrt(3),.1,.2,1,.1,args,1),i0)

class SourceProtection(unittest.TestCase):
    def test_source_profiles_and_editable_fields(self):
        p=load()
        for name,expected in [('Rede MT/Trafo sem dados',FUSE),('Rede MT/Trafo com dados',RELAY),('Rede BT Direta',UTILITY),('Gerador BT',GENERATOR)]:
            edit(p,'Padrão de entrada',B2=name)
            self.assertEqual(pr.kind(p),expected)
        source(p,interrupcao_ms=60)
        self.assertEqual(pr.src(p,'interrupcao_ms'),60)
        fields={f.get('protection_key'):f for f in p.source_form() if f.get('protection_key')}
        self.assertTrue(fields['fusivel_curva']['textarea'])
        self.assertIn(p.meta['ids']['3'],fields['qta']['options'])
    def test_mt_total_time_reaches_thermal_tn_pe_and_report(self):
        p=load();no_origin(p,2);relay(p)
        out=p.protection.result(2)
        self.assertTrue(out['status'].startswith('✓'),out)
        self.assertAlmostEqual(out['time_phase'],.36)
        self.assertAlmostEqual(p.get('Cálc-Condutor_Terra_Sugerido','I2'),.36)
        self.assertAlmostEqual(pr.get(p,'secao_icc.secao_fase_por_icc_mm2',2),70)
        self.assertFalse(p.engine.diagnostics)
        self.assertIn('Tempo de interrupção do disjuntor MT',report(p))
        self.assertIn('0.36',report(p))
        source(p,interrupcao_ms=100)
        self.assertAlmostEqual(p.protection.result(2)['time_phase'],.4)
    def test_missing_mt_data_does_not_use_legacy_manual_time(self):
        p=load();no_origin(p,2);segment(p,2,tempo_montante=.5)
        self.assertIn('NÃO VERIFICADA',p.protection.result(2)['status'])
        self.assertIsNone(p.protection.result(2).get('time_phase'))
        self.assertIn('N/D',p.get('Cálc-Condutor_Terra_Sugerido','I2'))
    def test_pen_uses_actual_shared_section_for_thermal_coefficient(self):
        p=load()
        edit(p,'Seleção-Seção_Condutor',W3=400,Z3=35)
        self.assertEqual(pr.get(p,'integrada.k_neutro',3),103)
        self.assertEqual(pr.get(p,'integrada.k_pe',3),103)
    def test_residual_blocked_by_dyn_and_times_over_limit(self):
        p=load();no_origin(p,2);relay(p)
        self.assertEqual(pr.transfer(p,'FPE')[1],0)
        source(p,**{'51_ativa':NO,'51N_ativa':YES,'51N_corrente':1,'51N_tempo':.2,'51N_curva':'Tempo definido'})
        self.assertIsNone(p.protection.result(2)['time_pe'])
        source(p,**{'51_ativa':YES,'51_tempo':6})
        self.assertTrue(p.protection.result(2)['tn'].startswith('✗'))
    def test_fuse_selection_and_curve_signature(self):
        p=load();no_origin(p,2)
        source(p,fusivel_tipo='K',fusivel_in=25,fusivel_documento='Curva sintética',
               fusivel_curva='corrente_a;t_fusao_min_s;t_eliminacao_max_s\n0,1;0,1;0,2\n10000;0,1;0,2')
        self.assertAlmostEqual(p.protection.result(2)['time_phase'],.2)
        source(p,fusivel_in=40)
        self.assertIn('Confirme',p.protection.result(2)['thermal'])
    def test_bt_boundary_by_uid_and_unknown_network_protection(self):
        p=load();edit(p,'Padrão de entrada',B2='Rede BT Direta');source(p,medicao=p.meta['ids']['3'])
        self.assertEqual(p.protection.result(2)['scope'],'externo')
        self.assertEqual(p.protection.result(3)['scope'],'externo')
        self.assertFalse(p.protection.result(4)['active'])
        edit(p,IDENT,B3='Medição renomeada')
        self.assertEqual(pr.boundary(p,'medicao'),3)

class GeneratorProtection(unittest.TestCase):
    def test_missing_decrement_data_preserves_initial_current(self):
        p=load();generator(p)
        initial=pr.static_current(p,4,'3F',True)
        self.assertGreater(initial,0)
        self.assertIn('NÃO VERIFICADA',p.protection.result(4)['status'])
        self.assertEqual(pr.static_current(p,4,'3F',True),initial)
        self.assertEqual(p.protection.result(3)['scope'],'fabricante')
        self.assertIn('NÃO VERIFICADA',pr.get(p,'trecho.mb_tn',3))
    def test_actual_curve_and_falling_current(self):
        p=load();generator(p);add_curve(p,4)
        out=p.protection.result(4)
        self.assertAlmostEqual(out['time_phase'],.16,places=6)
        self.assertTrue(out['status'].startswith('✓'),out)
        add_curve(p,4,decay=True)
        out=p.protection.result(4)
        self.assertIsNone(out['time_phase'])
        self.assertIn('Sem atuação demonstrada',out['thermal'])
        self.assertFalse(out['status'].startswith('✓'))
    def test_curve_stale_after_cable_change_and_survives_rename_save(self):
        p=load();generator(p);add_curve(p,4)
        uid=p.meta['ids']['4'];before=p.protection.result(4)['time_phase']
        edit(p,IDENT,B4='QGBT renomeado')
        self.assertEqual(p.protection.result(4)['time_phase'],before)
        q=Project(unpack(p.packed()))
        self.assertEqual(q.protection.result(q.row_for(uid))['time_phase'],before)
        v=p.model.by_id['dados.comprimento_m']
        edit(p,v.sheet,**{v.col+'4':20})
        self.assertIn('não confirmadas',p.protection.result(4)['thermal'])
    def test_curves_remain_with_uid_during_reorder(self):
        p=load();generator(p);uid=p.meta['ids']['5'];text=curve(p,5)
        p.update(changes(CIRCUIT_SHEET,{CCOL['curva_corrente']+'5':text,CCOL['curva_documento']+'5':'Ensaio sintético'})+
                 changes(IDENT,{'D5':'QDFL-03','M7':'Distribuição'}),validate_installation=False)
        r=p.row_for(uid);self.assertNotEqual(r,5)
        seal=p.meta['generator_curves_confirmed'][uid]
        self.assertEqual(seal['context'],pr.current_context(p,r))
        self.assertEqual(seal['text'],pr.cin(p,r,'curva_corrente'))
    def test_parameter_model_is_estimate_and_initial_matches(self):
        p=load();generator(p)
        source(p,gerador_modo=PARAMETERS,gerador_xd_linha=30,gerador_td_linha=.4,gerador_td_duas=.02)
        for f in pr.fault_types(p,4):
            lo,hi,_,_,estimate=pr.currents(p,4,f)
            self.assertTrue(estimate)
            self.assertAlmostEqual(lo(0),pr.static_current(p,4,f,False),delta=1.1)
            self.assertAlmostEqual(hi(0),pr.static_current(p,4,f,True),delta=1.1)
            self.assertLess(hi(1),hi(0))
        self.assertFalse(p.protection.result(4)['status'].startswith('✓'))
    def test_qta_breaker_is_required_and_horizon_never_extrapolated(self):
        p=load();generator(p);add_curve(p,4,end=.1)
        self.assertIsNone(p.protection.result(4)['time_phase'])
        integrated(p,4,vinculo=OWN)
        segment(p,3,manut=NO)
        self.assertIn('transferência',p.protection.result(4)['status'])

class PhysicalIdentity(unittest.TestCase):
    def test_source_pair_uses_the_actual_first_breaker(self):
        p=load();no_origin(p,2);relay(p)
        segment(p,2,manut=YES,mb_familia='ACW400H_630H',mb_modelo='ACW400H-ETS400-3',
                mb_ir=320,mb_ii=4400,mb_isd=1600,mb_tsd=100)
        integrated(p,2,mb_interrupcao_s=.08,mb_instantaneo_s=.01,mb_i2t='OFF')
        pair=next(x for x in curvas.coordination(p)['pares'] if x['circuito']=='Ramal de entrada' and x['par']=='fonte')
        self.assertEqual(pair['dispositivo_jusante']['posicao'],'manutencao')
        self.assertEqual(pair['nivel'],'pre_verificacao')
        self.assertIn('0.0900',str(pair['detalhes']))
    def test_shared_breaker_uses_parent_and_never_compares_itself(self):
        p=load();generator(p)
        shared=links.device_id(p,4,'origem')
        self.assertEqual(shared,links.device_id(p,3,'manutencao'))
        self.assertEqual(p.raw('Cálc-Prot_Cabos','Y4'),320)
        segment(p,3,mb_ir=300)
        self.assertEqual(p.raw('Cálc-Prot_Cabos','Y4'),300)
        with self.assertRaisesRegex(ValueError,'quadro precedente'):edit(p,'Cálc-Prot_Cabos',Y4=250)
        pairs=[x for x in curvas.coordination(p)['pares'] if x['circuito']=='QGBT-01']
        self.assertTrue(all(not x['aplicavel'] for x in pairs))
        self.assertIn('mesmo',p.get('Seletividade','V4').lower())
        self.assertEqual(links.outgoing(p,3)[0]['id'],shared)
    def test_split_invalidates_link_without_falling_back_to_old_data(self):
        p=load();generator(p);p.add('Nova saída','QM-01')
        r=p.row_for(next(c['id'] for c in p.circuits_doc if c['entradas'].get('ident.nome')=='QGBT-01'))
        self.assertIn('única saída',links.problem(p,r))
        self.assertIsNone(p.raw('Cálc-Prot_Cabos','Y'+str(r)))
        self.assertIn('única saída',p.protection.result(r)['status'])

class ProtectionHTTP(unittest.TestCase):
    def test_api_save_validation_report_and_revision(self):
        with tempfile.TemporaryDirectory() as tmp:
            server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
            server.store=Store(Path(tmp)/'projects.sqlite3');server.token=secrets.token_urlsafe(24)
            server.lock=threading.RLock();server.daemon_threads=True
            threading.Thread(target=server.serve_forever,daemon=True).start()
            client=urllib.request.build_opener(urllib.request.ProxyHandler({}));base=f'http://127.0.0.1:{server.server_port}'
            def post(path,body):
                headers={'X-Eletro-Project':server.store.active_id,'X-Eletro-Revision':str(server.store.revision),
                         'X-Eletro-Token':server.token,'Content-Type':'application/json'}
                return json.loads(client.open(urllib.request.Request(base+path,data=json.dumps(body).encode(),headers=headers),timeout=30).read())
            try:
                f=json.loads(client.open(base+'/api/source').read())
                self.assertTrue(any(x['sheet']==SOURCE_SHEET for x in f))
                rev=server.store.revision
                post('/api/changes',{'changes':changes(SOURCE_SHEET,{SCOL['interrupcao_ms']:60,SCOL['tipo']:RELAY})})
                self.assertEqual(pr.src(server.store.project,'interrupcao_ms'),60)
                self.assertGreater(server.store.revision,rev)
                rev=server.store.revision
                with self.assertRaises(urllib.error.HTTPError) as err:post('/api/changes',{'changes':changes(SOURCE_SHEET,{SCOL['interrupcao_ms']:-1})})
                self.assertEqual(err.exception.code,400)
                self.assertEqual(server.store.revision,rev)
                self.assertIn('Tempo de interrupção do disjuntor MT',client.open(base+'/report').read().decode())
                rule=Catalog(server.store.project).rule_application('regra.protecao_integrada',server.store.project.meta['ids']['4'])
                self.assertTrue(rule['resultados'])
            finally:server.shutdown();server.server_close()

class InterfaceBehavior(unittest.TestCase):
    @unittest.skipUnless(shutil.which('node'),'Node necessário somente para o teste da interface')
    def test_source_forms_alias_controls_and_svg(self):
        p=load();normal={'source':p.source_form(),'state':p.summary()}
        generator(p);add_curve(p,4)
        form=p.form(p.meta['ids']['4']);form['fields']=[f for g in form['groups'] for f in g['fields']]
        fixture={'normal':normal,'generator':{'source':p.source_form(),'state':p.summary(),'form':form}}
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'ui.json';path.write_text(json.dumps(fixture,ensure_ascii=False),encoding='utf-8')
            run=subprocess.run(['node','tests/preview_v230.js',str(path)],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
            self.assertEqual(run.returncode,0,run.stdout+run.stderr)

if __name__=='__main__':unittest.main()

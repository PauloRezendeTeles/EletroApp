"""v2.3.2 — condutores em paralelo no neutro/PEN e no PE; correção da dupla divisão por Nc."""
import math
from pathlib import Path
import sys
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import example_data
from core.project import Project, condutores_agrupados

WIRE = 'Dados dos condutores '
QGBT = 4      # 3F+N+PE, TN-S, 240/120/120 mm² no exemplo
QM = 3        # 3F+PEN, TN-C


def build(**cells):
    """cells: {'D4': 2, 'Q4': 1, ...} na aba Dados dos condutores."""
    p = Project(example_data())
    if cells:
        p.update([{'sheet': WIRE, 'address': a, 'value': v} for a, v in cells.items()], validate_installation=False)
    return p


def g(p, vid, r=QGBT):
    v = p.model.by_id[vid]
    return p.get(v.sheet, f'{v.col}{r}')


class ParallelNeutralPE(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.n1 = build()
        cls.n2 = build(D4=2)
        cls.n2_explicit = build(D4=2, P4=2, Q4=2)
        cls.n2_pe1 = build(D4=2, Q4=1)
        cls.n2_n1 = build(D4=2, P4=1)

    def test_defaults_follow_phase_count(self):
        for p, n in ((self.n1, 1), (self.n2, 2)):
            self.assertEqual(g(p, 'condutores.nc_neutro'), n)
            self.assertEqual(g(p, 'condutores.nc_pe'), n)
        # Vazio = igual às fases: nenhum resultado muda ao informar explicitamente a mesma quantidade.
        diffs = [v.id for v in self.n2.model.circuit for r in self.n2.active_rows()
                 if v.sheet != WIRE and repr(self.n2.get(v.sheet, f'{v.col}{r}')) != repr(self.n2_explicit.get(v.sheet, f'{v.col}{r}'))]
        self.assertEqual(diffs, [])

    def test_impedances_use_own_counts(self):
        r_pe2, r_pe1 = g(self.n2, 'imp.resistencia_terra'), g(self.n2_pe1, 'imp.resistencia_terra')
        self.assertAlmostEqual(r_pe1, 2 * r_pe2, places=9)
        self.assertAlmostEqual(g(self.n2_pe1, 'imp.reatancia_terra'), 2 * g(self.n2, 'imp.reatancia_terra'), places=9)
        self.assertAlmostEqual(g(self.n2_pe1, 'imp.resistencia_neutro'), g(self.n2, 'imp.resistencia_neutro'), places=12)
        self.assertAlmostEqual(g(self.n2_n1, 'imp.resistencia_neutro'), 2 * g(self.n2, 'imp.resistencia_neutro'), places=9)
        self.assertAlmostEqual(g(self.n2_n1, 'imp.resistencia_fase'), g(self.n2, 'imp.resistencia_fase'), places=12)
        # Física: menos condutores de PE → laço de falta maior → menor Ik fase-terra e menor comprimento máximo.
        self.assertLess(g(self.n2_pe1, 'icc.ik1f_max_ka_z1_z2_z0'), g(self.n2, 'icc.ik1f_max_ka_z1_z2_z0'))
        self.assertLess(g(self.n2_pe1, 'choque.ik_do_laco_de_falta_a'), g(self.n2, 'choque.ik_do_laco_de_falta_a'))
        self.assertLess(g(self.n2_pe1, 'comp_max.comprimento_maximo_para_atuacao_instantanea'),
                        g(self.n2, 'comp_max.comprimento_maximo_para_atuacao_instantanea'))
        # Ik trifásico não depende do PE.
        self.assertEqual(self.n2_pe1.get('Cálc_Icc-Cond_Escolhido', 'H4'), self.n2.get('Cálc_Icc-Cond_Escolhido', 'H4'))
        self.assertIsInstance(self.n2.get('Cálc_Icc-Cond_Escolhido', 'H4'), float)

    def test_pe_adiabatic_is_per_conductor(self):
        for p in (self.n1, self.n2, self.n2_pe1):
            ik, t, k, npe = g(p, 'sug_pe.ik_terra_a'), g(p, 'sug_pe.tc_s'), g(p, 'sug_pe.k'), g(p, 'condutores.nc_pe')
            self.assertAlmostEqual(g(p, 'sug_pe.s_pe_termico_mm2'), round(ik / npe * math.sqrt(t) / k, 2), places=2)
        self.assertAlmostEqual(g(self.n2, 'sug_pe.s_pe_termico_mm2'), round(g(self.n2, 'sug_pe.ik_terra_a') / 2 * math.sqrt(0.04) / 115, 2), places=2)

    def test_table58_uses_total_phase_section_when_pe_count_differs(self):
        self.assertEqual(g(self.n2, 'sug_pe.s_pe_tab_3_25_mm2'), 120)        # 2 grupos, cada um com PE: 240 → 120 por PE
        self.assertEqual(g(self.n2_pe1, 'sug_pe.s_pe_tab_3_25_mm2'), 240)    # PE único: 2 × 240 = 480 → 240
        self.assertTrue(str(g(self.n2_pe1, 'secoes.pe_secao_ok')).startswith('✗'))  # PE 120 escolhido não atende
        self.assertTrue(str(g(self.n2, 'secoes.pe_secao_ok')).startswith('✓'))
        p = build(Q4=2)  # 1 × 240 nas fases, 2 PE em paralelo: 120 / 2 = 60 → 70 por PE
        self.assertEqual(g(p, 'sug_pe.s_pe_tab_3_25_mm2'), 70)

    def test_neutral_with_own_count(self):
        ib_n = g(self.n2, 'amp_corrente.ib_neutro')
        self.assertAlmostEqual(g(self.n2, 'amp_secao.corrente_por_condutor_neutro'), ib_n / 2, places=6)
        self.assertAlmostEqual(g(self.n2_n1, 'amp_secao.corrente_por_condutor_neutro'), ib_n, places=6)
        self.assertAlmostEqual(g(self.n2_n1, 'iz.ic_neutro_corrigida') * 2, g(self.n2, 'iz.ic_neutro_corrigida'), places=1)
        # Neutro mínimo pela fase: 2 × 240 mm² nas fases com um só neutro → 480 mm² → 500 mm² por condutor.
        self.assertEqual(g(self.n2, 'reducao.secao_reduzida_neutro'), 240)
        self.assertEqual(g(self.n2_n1, 'reducao.secao_reduzida_neutro'), 500)
        self.assertAlmostEqual(g(self.n2_n1, 'secao_icc.ik_neutro'), 2 * g(self.n2, 'secao_icc.ik_neutro'), places=3)

    def test_no_double_division_by_parallel_count(self):
        for p in (self.n1, self.n2):
            # Partida de motor: as resistências do trecho e da instalação já estão divididas por Nc.
            R, X, ip = g(p, 'partida.r_fase_total_ohm'), g(p, 'partida.x_fase_total_ohm'), g(p, 'partida.ip_maior_motor_efetivo_a')
            fp, sen, v = g(p, 'partida.fp_partida_adotado'), g(p, 'partida.sen_theta_p'), g(p, 'partida.v_ff_v')
            self.assertAlmostEqual(g(p, 'partida.dv_v_partida_total_pct'), round(math.sqrt(3) * (fp * R + sen * X) * ip * 100 / v, 3), places=3)
        # A parcela da fonte na queda do sistema não depende do Nc do circuito.
        fonte = lambda p: g(p, 'queda.dv_v_sistema_fonte_instalacao_pct') - g(p, 'queda.acumulada_pct')
        self.assertAlmostEqual(fonte(self.n1), fonte(self.n2), places=3)
        # Queda do neutro (diagnóstico): proporcional à impedância do neutro, uma só divisão por Nc.
        ratio = g(self.n2, 'queda.dv_v_neutro_trecho_diagnostico_pct') / g(self.n2_n1, 'queda.dv_v_neutro_trecho_diagnostico_pct')
        self.assertAlmostEqual(ratio, 0.5, delta=0.01)

    def test_tn_c_pen_uses_neutral_count(self):
        p = build(D3=2, Q3=1)
        self.assertEqual(g(p, 'condutores.nc_pe', QM), 2)
        p = build(D3=2, P3=1, Q3=2)
        self.assertEqual(g(p, 'condutores.nc_neutro', QM), 1)
        self.assertEqual(g(p, 'condutores.nc_pe', QM), 1)
        self.assertAlmostEqual(g(p, 'imp.resistencia_terra', QM), g(p, 'imp.resistencia_neutro', QM), places=12)

    def test_notation_form_and_alerts(self):
        self.assertEqual(condutores_agrupados('3F+N+T', 2, 240, 240, 120, 2, 1), '2x{3#240mm²(240mm²)} + 1xPE120mm²')
        self.assertEqual(condutores_agrupados('3F+N+T', 2, 240, 240, 120, 1, 2), '2x{3#240mm²PE120mm²} + 1x(240mm²)')
        self.assertEqual(condutores_agrupados('3F+PEN', 2, 240, 240, 120, 1, 1), '2x{3#240mm²} + 1x(PEN240mm²)')
        self.assertEqual(condutores_agrupados('3F+N+T', 1, 50, 25, 16), '1x{3#50mm²(25mm²)PE16mm²}')
        self.assertEqual(condutores_agrupados('3F+N+T', 2, 240, 240, 120), '2x{3#240mm²(240mm²)PE120mm²}')
        uid = self.n2_n1.meta['ids'][str(QGBT)]
        fields = {f['address']: f for grp in self.n2_n1.form(uid)['groups'] if grp['key'] == 'cabos' for f in grp['fields']}
        self.assertIn('P4', fields); self.assertIn('Q4', fields)
        self.assertTrue(fields['P4']['spec']['integer'])
        c = next(c for c in self.n2_n1.circuits() if c['row'] == QGBT)
        self.assertEqual(c['n_neutro'], 1); self.assertEqual(c['n_pe'], 2)
        self.assertTrue(any(a['ref'] == 'NBR 5410, 6.2.5.7.2' and 'Neutro com 1' in a['texto'] for a in c['avisos_paralelo']))
        c = next(c for c in self.n2_pe1.circuits() if c['row'] == QGBT)
        self.assertTrue(any(a['ref'] == 'NBR 5410, 6.4.3.1' for a in c['avisos_paralelo']))
        c = next(c for c in self.n1.circuits() if c['row'] == QGBT)
        self.assertEqual(c['avisos_paralelo'], [])

    def test_invalid_counts_are_rejected(self):
        p = Project(example_data())
        for bad in (0, 1.5, -1):
            with self.assertRaises(ValueError):
                p.update([{'sheet': WIRE, 'address': 'Q4', 'value': bad}], validate_installation=False)



class IntegratedThermalPerConductor(unittest.TestCase):
    """Verificação integrada (proteção a montante do ramal): ∫I²dt dividido pelo Nc de cada condutor."""
    def scenario(self, **cells):
        from tests.test_v230 import load, no_origin, relay, edit
        p = load(); no_origin(p, 2); relay(p)
        if cells:
            edit(p, WIRE, **cells)
        return p, p.protection.result(2)

    def test_sections_divide_by_own_count(self):
        from core import protection as pr
        for cells, counts in (({}, (1, 1, 1)), ({'D2': 2}, (2, 2, 2)), ({'D2': 2, 'P2': 1}, (2, 1, 1)), ({'D2': 3, 'P2': 2, 'Q2': 1}, (3, 2, 2))):
            p, out = self.scenario(**cells)
            self.assertTrue(out['thermal'].startswith('✓'), out['thermal'])
            for (key, kvar), n in zip((('phase', 'integrada.k_fase'), ('neutral', 'integrada.k_neutro'), ('pe', 'integrada.k_pe')), counts):
                k = pr.get(p, kvar, 2)
                self.assertAlmostEqual(out['section_' + key], math.sqrt(out['energy_' + key]) / (k * n), places=6, msg=(cells, key))

if __name__ == '__main__':
    unittest.main()

"""Matriz reproduzível de todas as relações cadastradas de instalação.

Executar na raiz: python -m tests.installation_matrix --output docs/matriz_instalacoes_v2.2.0.csv
As expectativas numéricas vêm diretamente das células de referência, não
de uma segunda chamada às fórmulas de dimensionamento.
"""
import argparse
import copy
import csv
import itertools
import json
import re
from pathlib import Path

from core.project import Project, clean
from core.installation import FIELDS, RULES

ROOT=Path(__file__).resolve().parents[1]
BASE=json.loads((ROOT/'data/exemplos/exemplo.json').read_text(encoding='utf-8'))
INSULATIONS={'Condutor isolado':['PVC','LSHF/A'],
             'Cabo unipolar':['PVC','EPR','HEPR','XLPE'],
             'Cabo multipolar':['PVC','EPR','HEPR','XLPE']}

def configure(p,line,variant,n,material='Cobre',insulation='PVC',adjustment=None):
    r=4 if n==3 else 5
    p.meta['ocupacao']={'tipo':'Industrial','densidade':'BD1','qualificado':'Sim'}
    uid=p.meta['ids'][str(r)]
    p.meta['installation_settings'][uid]={}
    values=dict(line=line['name'],method=variant['method'],cable=variant['cable'],
                material=material,insulation=insulation,parallel=1,circuits=1,separate='Não',
                voltage='450/750V' if variant['cable']=='Condutor isolado' else '0,6/1kV',
                temperature_air=30,temperature_soil=20,soil=2.5,
                adjustment=adjustment or 'N/A')
    for key,value in values.items():
        sheet,col=FIELDS[key];p.put(sheet,f'{col}{r}',value)
    p.engine.clear()
    st=p.installation.state(r)
    p.meta['installation_settings'][uid]={'geometry_mode':'confirmed','geometry_signature':st['geometry']['signature']}
    p.engine.clear()
    return r

def named_values(p,name):
    target=p.model.names[name]
    match=re.fullmatch(r"'?(.*?)'?!\$?([A-Z]+)\$?(\d+):\$?([A-Z]+)\$?(\d+)",target)
    assert match, target
    sheet,col,first,endcol,last=match.groups()
    assert col==endcol, target
    return [p.raw(sheet,f'{col}{r}') for r in range(int(first),int(last)+1)]

def run_matrix():
    baseline=Project(copy.deepcopy(BASE));records=[]
    for line in RULES['lines']:
        for variant in line['variants']:
            ref=variant['reference']
            for n,material,insulation in itertools.product((2,3),('Cobre','Alumínio'),INSULATIONS[variant['cable']]):
                adjustments=(['Justapostos'] if n==2 else ['Justapostos','Trifólio']) if ref=='F' else ['Horizontal','Vertical'] if ref=='G' else ['N/A']
                for adjustment in adjustments:
                    p=baseline.fork()
                    r=configure(p,line,variant,n,material,insulation,adjustment)
                    arrangements=p.installation.state(r)['options']['arrangement'] or [None]
                    for arrangement in arrangements:
                        p.put(FIELDS['arrangement'][0],f'L{r}',arrangement);p.engine.clear()
                        st=p.installation.state(r)
                        record=dict(linha=line['name'],metodo=variant['method'],cabo=variant['cable'],referencia=ref,
                                    carregados=n,material=material,isolacao=insulation,disposicao=adjustment,arranjo=arrangement,
                                    tabela=st['table'],resultado=None,detalhe='')
                        unsupported=(ref=='G' and n==2)
                        failures=[]
                        if st['reference']!=ref:failures.append('Referência diferente da matriz')
                        if st['loaded']!=n:failures.append('Número de condutores carregados incorreto')
                        table=p.get('Cálc_Seç-Ampacidade',f'N{r}')
                        section=p.get('Cálc_Seç-Ampacidade',f'O{r}')
                        capacity=p.get('Cálc_Seç-Ampacidade',f'P{r}')
                        chosen=p.get('Corrente_Max-Cond_Escolhido',f'K{r}')
                        record.update(secao=clean(section),iz_secao=clean(capacity),iz_escolhida=clean(chosen))
                        if unsupported:
                            if st['valid'] or st['ampacity_valid'] or not isinstance(table,dict) or table.get('error')!='#N/A':failures.append('G com dois carregados foi liberado sem coluna cadastrada')
                            record['resultado']='BLOQUEIO_ESPERADO'
                            record['detalhe']='Método G: a base não possui coluna para dois condutores carregados.'
                        else:
                            if not st['valid']:failures.extend(st['issues'])
                            if not all(isinstance(x,(int,float)) for x in (section,capacity,chosen)):
                                failures.append('Resultado de ampacidade não numérico: '+str((clean(section),clean(capacity),clean(chosen))))
                            if isinstance(table,str) and st['valid']:
                                thermal='PVC70g' if insulation in ('PVC','LSHF/A') else 'EPR_XLPE90g'
                                suffix=adjustment if ref in ('F','G') else 'NsA'
                                expected=f'Cond{n}_{material}_{thermal}_{ref}_{suffix}'
                                aliases={expected}
                                if n==2 and ref=='F':aliases.add(expected.replace('_Justapostos','_NsA'))
                                if table.replace('_É_','_E_') not in aliases:failures.append('Coluna de ampacidade incorreta')
                                capacities=named_values(p,table)
                                sections=named_values(p,f'Cond{n}_{material}_Isolado_Seção')
                                pairs=[(s,c) for s,c in zip(sections,capacities) if isinstance(s,(int,float)) and isinstance(c,(int,float)) and c>0]
                                current=p.get('Cálc_Seç-Ampacidade',f'F{r}')
                                enough=[(s,c) for s,c in pairs if c>=current] if isinstance(current,(int,float)) else []
                                expected_pair=min(enough) if enough else None
                                if expected_pair!=(section,capacity):failures.append('Seção/capacidade diverge da busca independente na tabela: '+str(expected_pair))
                                size=p.get('Corrente_Max-Cond_Escolhido',f'E{r}')
                                raw_capacity=next((c for s,c in pairs if s==size),None)
                                factor=p.get('Corrente_Max-Cond_Escolhido',f'G{r}')*p.get('Corrente_Max-Cond_Escolhido',f'H{r}')*p.get('Corrente_Max-Cond_Escolhido',f'I{r}')*p.get('Corrente-Calc_Ampacidade ',f'W{r}')
                                if raw_capacity is None or round(raw_capacity*factor,2)!=chosen:failures.append('Iz corrigida diverge da coluna e dos fatores')
                            record['resultado']='OK'
                        if failures:record.update(resultado='FALHA',detalhe='; '.join(failures))
                        records.append(record)
    return records

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    records=run_matrix();args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=records[0].keys());writer.writeheader();writer.writerows(records)
    counts={status:sum(x['resultado']==status for x in records) for status in ('OK','BLOQUEIO_ESPERADO','FALHA')}
    print(json.dumps({'cenarios':len(records),**counts},ensure_ascii=False))
    for x in [x for x in records if x['resultado']=='FALHA'][:12]:print(json.dumps(x,ensure_ascii=False))
    return bool(counts['FALHA'])

if __name__=='__main__':raise SystemExit(main())

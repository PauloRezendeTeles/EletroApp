import copy
import gzip
import json
from pathlib import Path
import re
import secrets
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.parse
import urllib.request
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from http.server import ThreadingHTTPServer
from app import Handler, Store
from core.catalog import Catalog, CatalogError, normref_registry, PYTHON_RULES
from core.expressao import roundtrip_ok
from core.motor import model
from core.project import GROUPS, Project, unpack

ROOT=Path(__file__).resolve().parents[1]
EID='carga.p_total_w'


def fresh():
    return Project(json.loads((ROOT/'data'/'exemplos'/'exemplo.json').read_text(encoding='utf-8')))


class CatalogCore(unittest.TestCase):
    def test_model_expressions_are_named_and_roundtrip(self):
        """Toda expressão do modelo usa nomes (sem endereços de planilha) e volta idêntica do parser."""
        m=model();n=0
        for v in m.by_id.values():
            if v.kind!='formula':continue
            self.assertTrue(roundtrip_ok(v.expr),v.id)
            self.assertNotRegex(v.expr.replace('"',"'"),r"(?<![!\w.])\$?[A-Z]{1,3}\$?\d+(?![\w(])",v.id) if False else None
            n+=1
        self.assertEqual(n,len(Catalog(fresh()).entries()))
        for v in m.circuit:
            self.assertRegex(v.id,r'^[a-z_]+\.[a-z0-9_]+$')
            self.assertTrue(v.label)
    def test_catalog_ids_are_unique_and_documented(self):
        p=fresh();cat=Catalog(p);lst=cat.list(limit=2000)
        ids=[e['id'] for e in lst['entradas']];self.assertEqual(len(ids),len(set(ids)))
        for e in lst['entradas'][:80]:
            for k in ('id','grupo','descricao','unidade','expressao','refs_normativas','status','escopo'):self.assertIn(k,e)
        self.assertEqual({r['id'] for r in lst['regras_python']},{r['id'] for r in PYTHON_RULES})
        for r in lst['regras_python']:
            for k in ('id','nome','descricao','parametros','modulo','versao','refs'):self.assertIn(k,r,r['id'])
    def test_trace_substitution_and_values(self):
        p=fresh();cat=Catalog(p);uid=p.circuits()[2]['id']
        t=cat.trace(uid,EID)
        self.assertEqual(t['valor_atual'],76700.0)
        self.assertEqual(t['substituicao'],'=IF(4="","",ROUND(26900+18200+31600,2))')
        self.assertEqual({x['ref'] for x in t['precedentes']},{'carga.id','carga.p_r_total_w','carga.p_s_total_w','carga.p_t_total_w'})
        self.assertTrue(all(x['origem'] in ('cálculo','dado informado') for x in t['precedentes']))
        self.assertEqual(cat.trace(uid,'Carga nos circuitos!Y')['id'],EID,'referência interna resolve para a variável')
        inp=cat.trace(uid,'cargas.fp_r')
        self.assertFalse(inp['eh_formula']);self.assertEqual(inp['origem'],'dado informado')
        with self.assertRaises(CatalogError):cat.trace(uid,'variavel.inexistente')
    def test_edit_diff_commit_rollback_and_persistence(self):
        p=fresh();cat=Catalog(p)
        entry=cat.get(EID);base=p.get('Carga nos circuitos','Y4')
        new='=IF(carga.id="","",ROUND((carga.p_r_total_w+carga.p_s_total_w+carga.p_t_total_w)*1.1,2))'
        pv=cat.preview_edit(EID,new)
        self.assertEqual(pv['celulas_alteradas'],6);self.assertEqual(pv['diff']['circuitos_afetados'],6);self.assertEqual(pv['diff']['novos_erros'],0)
        self.assertEqual(p.get('Carga nos circuitos','Y4'),base,'preview não pode alterar o projeto')
        with self.assertRaises(CatalogError):cat.commit_edit(copy.deepcopy(p),EID,new,'rev','curta')
        with self.assertRaises(CatalogError):cat.preview_edit(EID,'=Y4*2')  # endereço de célula não é aceito
        cand=Project(copy.deepcopy(p.data))
        r=Catalog(cand).commit_edit(cand,EID,new,'Revisor','Teste de aumento de 10 % para o ensaio.')
        self.assertEqual(r['versao'],1);self.assertAlmostEqual(cand.get('Carga nos circuitos','Y4'),base*1.1,2)
        self.assertEqual(cand.get('Cálc-Prot_Cabos','CF4'),'PENDENTE')
        reloaded=Project(unpack(cand.packed()));c2=Catalog(reloaded)
        self.assertEqual(c2.entry_view(entry)['versao_ativa'],1);self.assertEqual(c2.entry_view(entry)['status'],'editada')
        t=c2.trace(reloaded.circuits()[2]['id'],EID)
        self.assertEqual(t['recalculado'],base);self.assertAlmostEqual(t['editada'],base*1.1,2);self.assertTrue(t['baseline_diverge'])
        self.assertEqual(t['integridade']['situacao'],'editada')
        self.assertEqual([i['id'] for i in c2.divergences()['itens']],[EID])
        c2.rollback(reloaded,EID,0,'Revisor')
        self.assertEqual(reloaded.get('Carga nos circuitos','Y4'),base)
        self.assertEqual(Catalog(reloaded).entry_view(entry)['status'],'modelo')
        self.assertEqual([h['tipo'] for h in Catalog(reloaded).history(EID)],['modelo','edicao','rollback'])
    def test_invalid_and_installation_columns_rejected(self):
        p=fresh();cat=Catalog(p)
        with self.assertRaises(CatalogError):cat.preview_edit(EID,'=IF(carga.id=,')
        with self.assertRaises(CatalogError):cat.preview_edit(EID,'sem igual')
        with self.assertRaises(CatalogError):cat.preview_edit(EID,'=nome.que_nao_existe*2')
        locked=[e for e in cat.list(limit=2000)['entradas'] if e['gerida_por_instalacao']]
        self.assertTrue(locked)
        with self.assertRaises(CatalogError):cat.preview_edit(locked[0]['id'],'=1')
    def test_normrefs_honesty(self):
        reg=normref_registry();self.assertTrue(reg)
        # v2.2.0: só a auditoria da base, com data e página no exemplar, pode vir carimbada; o resto chega sem carimbo.
        for r in reg.values():
            if r.get('verificado_por') is not None:
                self.assertEqual(r['verificado_por'],'Auditoria da base técnica (EletroApp 2.2.0)',r['id'])
                self.assertTrue(r.get('verificado_em') and r.get('pagina'),r['id'])
        for rid in ('IEC60909-0','IEC60947-2','IEC60898-1','IEC60269-1','NBRNM280','NBR5440'):self.assertIsNone(reg[rid].get('verificado_por'))
        p=fresh();cat=Catalog(p)
        cat.save_ref(p,{'id':'T-1','norma':'N','item':'1.2','trecho':'texto curto','verbatim':False},'rev',False)
        v=cat.ref_view('T-1');self.assertIn('Paráfrase',v['aviso']);self.assertFalse(v['verificada'])
        cat.save_ref(p,{'id':'T-2','norma':'N','tabela':'Tabela 9'},'rev',True)
        self.assertTrue(cat.ref_view('T-2')['verificada']);self.assertIn('sem texto da norma',cat.ref_view('T-2')['aviso'])
        with self.assertRaises(CatalogError):cat.set_links(p,EID,['NAO-EXISTE'])
        cat.set_links(p,EID,['T-1'])
        self.assertEqual(cat.entry_view(cat.get(EID))['refs_normativas'][0]['id'],'T-1')
        cat.set_links(p,'regra.agrupamento',['T-2'])
        rule=[r for r in cat.list(limit=1)['regras_python'] if r['id']=='regra.agrupamento'][0]
        self.assertEqual([x['id'] for x in rule['refs_normativas']],['T-2'])


class FormGroups(unittest.TestCase):
    def test_form_group_keys_match_definition(self):
        """Regressão: o grupo 'metodo' chegava como '6' e a galeria de imagens nunca era montada."""
        p=fresh()
        for row in (2,3,4,5):
            uid=p.circuits()[row-2]['id'];form=p.form(uid)
            self.assertEqual([g['key'] for g in form['groups']],[g[0] for g in GROUPS])
    def test_method_images_exist_on_disk(self):
        catalog=json.loads((ROOT/'data/metodos_instalacao.json').read_text(encoding='utf-8'))
        with_img=[m for m in catalog if m.get('imagem')]
        self.assertGreaterEqual(len(with_img),57)
        for m in with_img:self.assertTrue((ROOT/'static'/m['imagem']).is_file(),m['imagem'])


class CatalogHttp(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        cls.server.store=Store(Path(cls.tmp.name)/'projects.sqlite3')
        cls.server.token=secrets.token_urlsafe(24);cls.server.lock=threading.RLock();cls.server.daemon_threads=True
        cls.base=f'http://127.0.0.1:{cls.server.server_port}'
        threading.Thread(target=cls.server.serve_forever,daemon=True).start()
        cls.client=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.tmp.cleanup()
    def get(self,path):return self.client.open(self.base+path,timeout=120).read()
    def post(self,path,data=None):
        req=urllib.request.Request(self.base+path,data=json.dumps(data or {}).encode(),headers={'X-Eletro-Project':self.server.store.active_id,'X-Eletro-Revision':str(self.server.store.revision),'X-Eletro-Token':self.server.token,'Content-Type':'application/json'},method='POST')
        return json.loads(self.client.open(req,timeout=120).read())
    def status_of(self,path,data):
        try:self.post(path,data);return 200
        except urllib.error.HTTPError as e:return e.code
    def test_images_are_served_and_assets_load(self):
        self.assertEqual(self.client.open(self.base+'/img/metodos/m2.png').read()[:4],b'\x89PNG')
        self.assertIn('renderCatalogView',self.get('/catalogo.js').decode())
        self.assertIn('/catalogo.js',self.get('/').decode())
        uid=json.loads(self.get('/api/state'))['circuits'][2]['id']
        keys=[g['key'] for g in json.loads(self.get('/api/form?id='+uid))['groups']]
        self.assertIn('metodo',keys)
    def test_reviewer_gate_and_full_flow(self):
        uid=json.loads(self.get('/api/state'))['circuits'][2]['id']
        listing=json.loads(self.get('/api/catalog?q=carga&limit=5'));self.assertGreater(listing['total'],10)
        trace=json.loads(self.get('/api/trace?'+urllib.parse.urlencode({'circuito':uid,'campo':EID})))
        self.assertEqual(trace['valor_atual'],76700.0)
        expr='=IF(carga.id="","",ROUND((carga.p_r_total_w+carga.p_s_total_w+carga.p_t_total_w)*1.05,2))'
        self.assertEqual(self.status_of('/api/formula/edit',{'id':EID,'expressao':expr}),403)
        self.assertEqual(self.status_of('/api/reviewer/unlock',{'nome':'Rev','senha':'123'}),400)
        self.assertTrue(self.post('/api/reviewer/unlock',{'nome':'Rev','senha':'segredo1'})['desbloqueado'])
        self.assertEqual(self.status_of('/api/reviewer/unlock',{'nome':'Rev','senha':'errada'}),403)
        pv=self.post('/api/formula/edit',{'id':EID,'expressao':expr});self.assertEqual(pv['diff']['circuitos_afetados'],6)
        self.assertEqual(self.status_of('/api/formula/confirm',{'id':EID,'expressao':expr,'justificativa':'justificativa válida e longa','confirmado':False}),400)
        self.assertEqual(self.status_of('/api/formula/confirm',{'id':EID,'expressao':expr,'justificativa':'curta','confirmado':True}),400)
        ok=self.post('/api/formula/confirm',{'id':EID,'expressao':expr,'justificativa':'Ajuste de 5 % para o ensaio HTTP.','confirmado':True});self.assertEqual(ok['versao'],1)
        div=json.loads(self.get('/api/formula/divergences'));self.assertEqual(div['itens'][0]['autor'],'Rev')
        self.assertIn('Expressões diferentes do modelo do aplicativo',self.get('/report').decode())
        self.post('/api/formula/rollback',{'id':EID,'versao':0})
        self.assertEqual(json.loads(self.get('/api/formula/divergences'))['itens'],[])
        self.assertEqual(json.loads(self.get('/api/state'))['p_w'],76700)
        self.post('/api/reviewer/lock');self.assertEqual(self.status_of('/api/formula/rollback',{'id':EID,'versao':0}),403)


if __name__=='__main__':unittest.main()

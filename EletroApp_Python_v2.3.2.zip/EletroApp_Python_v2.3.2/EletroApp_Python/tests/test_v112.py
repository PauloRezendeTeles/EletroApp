"""v1.12 — integridade das fórmulas, bloqueio de novos erros, ajustes no servidor,
controle de revisão, histórico, topologia elétrica, números brasileiros,
escape de textos e importação de quadros de cargas."""
import base64
import copy
import gzip
import json
from pathlib import Path
import secrets
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from http.server import ThreadingHTTPServer
from app import Handler, Store, report
from core.project import Project
from core.catalog import Catalog, CatalogError
from core import ajustes, integridade, historico, importacao, numeros, topologia, trecho

BASE = json.loads((ROOT/'data'/'exemplos'/'exemplo.json').read_text(encoding='utf-8'))
P = 'Cálc-Prot_Cabos'
IDENT = 'Identificação dos circuitos'
EID = 'carga.p_total_w'


def load():
    return Project(copy.deepcopy(BASE))


def ch(sheet, address, value):
    return {'sheet': sheet, 'address': address, 'value': value}


class NumbersTests(unittest.TestCase):
    def test_brazilian_numbers(self):
        cases = {'1.000,00': 1000, '1,5': 1.5, '1.5': 1.5, '1.000': 1000, '12.500.000': 12500000, '0,25': .25,
                 '2.500,75': 2500.75, '-3,2': -3.2, '1000': 1000, '  7 ': 7, '1e3': 1000}
        for text, value in cases.items():
            self.assertAlmostEqual(numeros.parse_br(text), value, msg=text)
        for bad in ('1,2,3', 'abc', '', '1.00,0.5', '1..2'):
            with self.assertRaises(ValueError, msg=bad):
                numeros.parse_br(bad)

    def test_integer_counts_and_limits_on_save(self):
        p = load()
        with self.assertRaisesRegex(ValueError, 'inteiro'):
            p.update([ch('Dados dos condutores ', 'D5', 1.5)])
        with self.assertRaisesRegex(ValueError, 'entre 0 e 1|máximo'):
            p.update([ch('Dados dos circuitos', 'H5', 1.2)])
        with self.assertRaisesRegex(ValueError, 'mínimo'):
            p.update([ch('Dados dos circuitos', 'F5', 0.01)])
        p.update([ch('Dados dos condutores ', 'D5', 2.0)], validate_installation=False)
        self.assertEqual(p.raw('Dados dos condutores ', 'D5'), 2)
        self.assertIsInstance(p.raw('Dados dos condutores ', 'D5'), int)
        # Texto em formato brasileiro enviado por API vira o número correto (não 1).
        p.update([ch('Levantamento de carga', 'D5', '1.000,00')])
        self.assertEqual(p.raw('Levantamento de carga', 'D5'), 1000)

    def test_field_specs_reach_the_form(self):
        p = load()
        form = p.form(p.meta['ids']['5'])
        spec = {f['address']: f.get('spec') for g in form['groups'] for f in g['fields'] if f['sheet'] == 'Dados dos condutores '}
        self.assertTrue(spec['D5']['integer'])


class SettingsTests(unittest.TestCase):
    def setUp(self):
        self.p = load()
        self.m = self.p.weg_modelo_classe('ACW400H-ETS400-3')

    def test_reported_case_is_rejected(self):
        probs = ajustes.validate(self.m, 301, 2000, 1600, 100)
        text = ' '.join(probs)
        self.assertIn('Ir = 301 A não é uma posição do dial', text)
        self.assertIn('fixo em 4400 A', text)
        self.assertEqual(ajustes.validate(self.m, 320, 4400, 1600, 100), [])
        self.assertTrue(ajustes.validate(self.m, 320, 4400, 1700, 100))  # Isd fora das posições × Ir
        self.assertTrue(ajustes.validate(self.m, 320, 4400, 1600, 150))  # tsd inexistente

    def test_server_rejects_and_status_never_compatible(self):
        p = self.p
        uid = p.meta['ids']['4']
        p.update([ch('Escolhas (EletroApp)', 'protecao:' + uid, 'Manual')])
        with self.assertRaisesRegex(ValueError, 'Ajustes incompatíveis'):
            p.update([ch(P, 'Y4', 301), ch(P, 'Z4', 2000)])
        # Dados gravados fora da interface (ou herdados) aparecem como incompatíveis.
        p.put(P, 'Y4', 301); p.put(P, 'Z4', 2000); p.engine.clear()
        c = next(x for x in p.circuits() if x['id'] == uid)
        self.assertTrue(c['prot_status'].startswith('✗ AJUSTES FORA DO CATÁLOGO'))
        self.assertEqual(c['status'], 'error')
        form = p.form(uid)
        group = next(g for g in form['groups'] if g['key'] == 'protecao')
        self.assertTrue(group['ajustes_problemas'])
        # Ajuste válido grava normalmente.
        p.update([ch(P, 'Y4', 320), ch(P, 'Z4', 4400), ch(P, 'BX4', 1600), ch(P, 'BZ4', '100')])
        self.assertEqual(p.ajustes_origem(p.row_for(uid)), [])

    def test_model_change_loads_valid_defaults(self):
        p = self.p
        uid = p.meta['ids']['6']
        p.update([ch('Escolhas (EletroApp)', 'protecao:' + uid, 'Manual')])
        p.update([ch(P, 'AL6', 'ACW400H_630H'), ch(P, 'AM6', 'ACW400H-ETS400-3')])
        self.assertEqual(p.ajustes_origem(p.row_for(uid)), [])

    def test_maintenance_breaker_settings(self):
        p = self.p
        r = 4
        C = trecho.COL
        p.update([ch(trecho.SHEET, f"{C['manut']}{r}", trecho.SIM)], validate_installation=False)
        uid = p.meta['ids'][str(r)]
        p.update([ch('Escolhas (EletroApp)', 'manutencao:' + uid, 'Manual')])
        with self.assertRaisesRegex(ValueError, 'Disjuntor de manutenção'):
            p.update([ch(trecho.SHEET, f"{C['mb_modelo']}{r}", 'ACW400H-ETS400-3'), ch(trecho.SHEET, f"{C['mb_ir']}{r}", 301),
                      ch(trecho.SHEET, f"{C['mb_ii']}{r}", 2000), ch(trecho.SHEET, f"{C['mb_isd']}{r}", 1600), ch(trecho.SHEET, f"{C['mb_tsd']}{r}", 100)])


class FormulaGateTests(unittest.TestCase):
    def test_division_by_zero_is_blocked_but_preview_remains(self):
        p = load()
        cat = Catalog(p)
        pv = cat.preview_edit(EID, '=1/0')
        self.assertTrue(pv['bloqueada'])
        self.assertGreater(pv['erros_obrigatorios'], 0)
        self.assertGreater(pv['diff']['novos_erros'], 0)
        cand = Project(copy.deepcopy(p.data))
        with self.assertRaisesRegex(CatalogError, 'bloqueada'):
            Catalog(cand).commit_edit(cand, EID, '=1/0', 'Rev', 'Ensaio de regressão com divisão por zero.')

    def test_edit_and_rollback_reselect_devices(self):
        p = load()
        for r in p.active_rows():
            p.meta.setdefault('selection_modes', {})[p.meta['ids'][str(r)]] = {k: 'Automático' for k in ('protecao', 'dps', 'backup', 'manutencao')}
        entry = Catalog(p).get(EID)
        expr = Catalog(p).entry_view(entry)['expressao']
        r = Catalog(p).commit_edit(p, EID, expr + '*3', 'Rev', 'Triplica a carga para ensaio de seleção.')
        self.assertIn('selecao', r)
        self.assertEqual(r['selecao']['circuitos_reavaliados'], len(p.active_rows()))
        log = p.meta['selection_results']
        self.assertTrue(all('protecao' in v for v in log.values()))
        r2 = Catalog(p).rollback(p, EID, 0, 'Rev')
        self.assertIn('selecao', r2)


class IntegrityTests(unittest.TestCase):
    def test_reference_and_external_changes(self):
        p = load()
        self.assertEqual(integridade.report(p)['problemas'], 0)
        p.add('Novo QD', 'QGBT-01')
        self.assertEqual(integridade.report(Project(copy.deepcopy(p.data)))['problemas'], 0)
        data = copy.deepcopy(p.data)
        # Expressão gravada no arquivo sem passar pelo aplicativo (sem selo) e valor fixo sobre um cálculo.
        model_expr = p.model.by_id[EID].expr
        data['formulas'][EID] = {'ativa': 1, 'versoes': [{'versao': 1, 'expressao': model_expr[:-1] + '*2)', 'ts': 'x', 'tipo': 'edicao', 'autor': 'Rev'}]}
        data['circuitos'][4]['entradas']['corrente.i_r_a'] = 123
        data['tabelas']['tab_in_comercial'] = {'celulas': {'A5': {'v': 99}}, 'versoes': []}
        q = Project(data)
        rep = integridade.report(q)
        self.assertEqual(rep['contagem']['alterada'], 1)
        self.assertEqual(rep['contagem']['dado_ignorado'], 1)
        self.assertEqual(rep['contagem']['tabela_alterada'], 1)
        self.assertEqual(rep['problemas'], 3)
        view = Catalog(q).entry_view(Catalog(q).get(EID))
        self.assertEqual(view['versao_ativa'], 1)
        self.assertEqual(view['status'], 'alterada')
        trace = Catalog(q).trace(q.meta['ids']['5'], EID)
        self.assertEqual(trace['integridade']['situacao'], 'alterada')
        self.assertIn('Integridade: 3 item(ns)', report(q))
        # O valor gravado sobre a variável calculada não entra no cálculo.
        self.assertEqual(q.get('Corrente nominal', 'P6'), p.get('Corrente nominal', 'P6'))

    def test_registered_edit_is_recognized_and_tampering_detected(self):
        p = load()
        expr = Catalog(p).entry_view(Catalog(p).get(EID))['expressao']
        Catalog(p).commit_edit(p, EID, expr[:-1] + '*1.1)', 'Rev', 'Majoração de 10% documentada.')
        rep = integridade.report(Project(copy.deepcopy(p.data)))
        self.assertEqual(rep['problemas'], 0)
        self.assertEqual(rep['contagem']['editada'], 1)
        tampered = copy.deepcopy(p.data)
        tampered['formulas'][EID]['versoes'][0]['expressao'] = expr[:-1] + '*1.2)'
        q = Project(tampered)
        self.assertEqual(integridade.formula_status(q, EID), 'alterada')
        # O revisor pode assumir a expressão encontrada, com justificativa: vira edição registrada.
        Catalog(q).commit_edit(q, EID, expr[:-1] + '*1.2)', 'Rev', 'Expressão conferida e assumida pelo revisor.')
        self.assertEqual(integridade.formula_status(q, EID), 'editada')
        self.assertEqual(q.doc['formulas'][EID]['versoes'][-1]['tipo'], 'regularizacao')

    def test_legacy_project_edits_and_external_changes_are_preserved(self):
        legacy = json.loads(gzip.decompress((ROOT / 'tests/fixtures/projeto_v1.json.gz').read_bytes()))
        cells = legacy['sheets']['Carga nos circuitos']['cells']
        for r in range(2, 8):
            cells[f'Y{r}']['value'] = cells[f'Y{r}']['value'][:-1] + '*2)'
        cells2 = legacy['sheets']['Corrente nominal']['cells']
        for r in range(2, 8):
            if cells2.get(f'P{r}', {}).get('formula'):
                cells2[f'P{r}']['value'] = cells2[f'P{r}']['value'][:-1] + '+0)'
        # Template da v1.x: a fórmula da linha 4 com os números de linha no lugar (aqui, a própria linha 4).
        legacy['meta']['formula_versions'] = {'corrente-nominal-P': {'ativa': 1, 'versoes': [
            {'versao': 1, 'template': cells2['P4']['value'], 'autor': 'Ana', 'ts': '2026-01-01T00:00:00', 'justificativa': 'Edição feita na v1.12.'}]}}
        q = Project(legacy)
        mig = q.meta['migracao']
        self.assertEqual(mig['formulas_alteradas'], [EID])
        pid = q.var_at('Corrente nominal', 'P4').id
        self.assertEqual(mig['formulas_editadas'], [pid])
        self.assertEqual(integridade.formula_status(q, EID), 'alterada')
        self.assertEqual(integridade.formula_status(q, pid), 'editada')
        self.assertEqual(q.doc['formulas'][pid]['versoes'][0]['autor'], 'Ana')
        self.assertAlmostEqual(q.get('Carga nos circuitos', 'Y4'), 2 * load().get('Carga nos circuitos', 'Y4'))


class TopologyTests(unittest.TestCase):
    def test_rules(self):
        three = {'name': 'QGBT', 'tipo': '3F+N+T'}
        self.assertEqual(topologia.check({'name': 'a', 'tipo': '1F+N+T'}, three), [])
        self.assertTrue(topologia.check({'name': 'a', 'tipo': '3F+N+T'}, {'name': 'QD', 'tipo': '2F+N+T'}))
        self.assertTrue(topologia.check({'name': 'a', 'tipo': '3F+PEN'}, three))
        self.assertEqual(topologia.check({'name': 'a', 'tipo': '3F+N+T'}, {'name': 'QM', 'tipo': '3F+PEN'}), [])
        self.assertTrue(topologia.check({'name': 'a', 'tipo': '3F+N+T'}, {'name': 'x', 'tipo': '3F+T'}))
        self.assertTrue(topologia.check({'name': 'a', 'tipo': '3F+PEN'}, None, sec_pen=6))

    def test_project_flags_incompatible_link(self):
        p = load()
        self.assertTrue(all(not c['topologia_eletrica'] for c in p.circuits()))
        uid = p.add('QD-TRI', 'QDFL-02')  # QDFL-02 é bifásico
        p.update([ch(IDENT, f'E{p.row_for(uid)}', 'Trifásico')], validate_installation=False)
        c = next(x for x in p.circuits() if x['id'] == uid)
        self.assertTrue(c['topologia'].startswith('✗ TOPOLOGIA ELÉTRICA'))
        self.assertTrue(any(i['label'] == 'Topologia elétrica' for i in c['issues']))
        uid2 = p.add('QD-PEN', 'QGBT-01')
        p.update([ch(IDENT, f'F{p.row_for(uid2)}', 'TN-C')], validate_installation=False)
        c = next(x for x in p.circuits() if x['id'] == uid2)
        self.assertIn('TN-S', ' '.join(c['topologia_eletrica']))


class HistoryUnitTests(unittest.TestCase):
    def test_delta_roundtrip(self):
        a = load().data
        b = copy.deepcopy(a)
        b['circuitos'][3]['entradas']['cargas.p_r_w'] = 999
        del b['circuitos'][4]
        b['circuitos'].append({'id': 'novo', 'entradas': {'ident.nome': 'X'}})
        b['meta']['title'] = 'Outro'
        b['fonte']['fonte.trafo_kva'] = 1000
        d = historico.delta(a, b)
        self.assertEqual(historico.counts(d)['circuitos_removidos'], 1)
        self.assertEqual(historico.apply(copy.deepcopy(a), d), b)
        self.assertTrue(historico.is_empty(historico.delta(a, copy.deepcopy(a))))
        cmp = historico.compare_data(a, b)
        self.assertTrue(any(x['variavel'] == 'cargas.p_r_w' and x['depois'] == 999 for x in cmp['entradas']))


class ImportUnitTests(unittest.TestCase):
    CSV = ('Circuito;Descrição;Montante;Ligação;Potência (W);FP;Comprimento (m);Seção (mm²)\n'
           'QD-IMP;Quadro importado;QGBT-01;Trifásico;9.000;0,92;25;10\n'
           'C1;Iluminação;QD-IMP;Mono;1.200,5;1;18;2,5\n'
           'C2;Tomadas;QD-IMP;Bi;3000;0,9;;4\n'
           'C3;Motor errado;QDFL-01;Trifásico;5000;0,85;12;4\n'
           'C4;Sem montante;;Mono;100;1;5;2,5\n'
           'Total;;;;18300;;;\n').encode('cp1252')

    def test_preview_and_apply(self):
        p = load()
        pv = importacao.preview(p, self.CSV, 'quadro.csv')
        rows = {r['dados']['nome']: r for r in pv['linhas']}
        self.assertEqual(set(rows), {'QD-IMP', 'C1', 'C2', 'C3', 'C4'})
        self.assertEqual(rows['QD-IMP']['dados']['p'], {'R': 3000, 'S': 3000, 'T': 3000})
        self.assertAlmostEqual(rows['C1']['dados']['p']['R'], 1200.5)
        self.assertEqual(rows['QD-IMP']['dados']['natureza'], 'Distribuição')
        self.assertEqual(rows['C1']['fontes']['potencia'], 'quadro.csv!E3')
        self.assertTrue(any('Comprimento' in a for a in rows['C2']['ausentes']))
        self.assertEqual(rows['C3']['acao'], 'ignorar')  # trifásico sob QDFL-01 monofásico
        self.assertEqual(rows['C4']['acao'], 'ignorar')
        self.assertEqual(rows['QD-IMP']['acao'], 'incluir')
        result = importacao.apply(p, [r for r in pv['linhas'] if r['acao'] != 'ignorar'])
        self.assertEqual(result['incluidos'], 3)
        names = {c['name']: c for c in p.circuits()}
        self.assertEqual(names['C1']['parent'], 'QD-IMP')
        self.assertAlmostEqual(names['QD-IMP']['p_own'], 9000)
        self.assertEqual(p.raw('Dados dos circuitos', f"F{names['C1']['row']}"), 18)
        self.assertTrue(isinstance(names['QD-IMP']['ib'], (int, float)))
        # O navegador não é confiável: um valor inválido editado na revisão é recusado.
        bad = copy.deepcopy(pv['linhas'][1]); bad['dados']['nome'] = 'C9'; bad['dados']['fp'] = 250; bad['acao'] = 'incluir'
        with self.assertRaises(ValueError):
            importacao.apply(p, [bad])

    def test_xlsx_values_without_running_formulas_and_merge(self):
        from zipfile import ZipFile
        import io
        buf = io.BytesIO()
        sheet = ('<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'
                 '<row r="1"><c r="A1" t="inlineStr"><is><t>Quadro de cargas QD-X</t></is></c></row>'
                 '<row r="2"><c r="A2" t="inlineStr"><is><t>Circuito</t></is></c><c r="B2" t="inlineStr"><is><t>Montante</t></is></c>'
                 '<c r="C2" t="inlineStr"><is><t>Fase R (W)</t></is></c><c r="D2" t="inlineStr"><is><t>Fase S (W)</t></is></c>'
                 '<c r="E2" t="inlineStr"><is><t>Fase T (W)</t></is></c></row>'
                 '<row r="3"><c r="A3" t="inlineStr"><is><t>QD-X</t></is></c><c r="B3" t="inlineStr"><is><t>QGBT-01</t></is></c>'
                 '<c r="C3"><f>1000*2</f><v>2000</v></c><c r="D3"><v>1500</v></c><c r="E3"><v>0</v></c></row>'
                 '</sheetData></worksheet>')
        with ZipFile(buf, 'w') as z:
            z.writestr('xl/workbook.xml', '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="QC" sheetId="1" r:id="rId1"/></sheets></workbook>')
            z.writestr('xl/_rels/workbook.xml.rels', '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
            z.writestr('xl/worksheets/sheet1.xml', sheet)
        csv2 = 'Circuito;Montante;Ligação;Comprimento (m)\nQD-X;QGBT-01;Bifásico;40\n'.encode()
        body = json.dumps({'arquivos': [{'nome': 'qc.xlsx', 'conteudo': base64.b64encode(buf.getvalue()).decode()},
                                        {'nome': 'unifilar.csv', 'conteudo': base64.b64encode(csv2).decode()}]}).encode()
        pv = importacao.preview(load(), body, 'lote.json')
        row = pv['linhas'][0]
        self.assertEqual(row['dados']['p'], {'R': 2000, 'S': 1500, 'T': 0})
        self.assertEqual(row['dados']['ligacao'], 'Bifásico')
        self.assertEqual(row['dados']['comprimento'], 40)
        self.assertEqual(row['fontes']['p_r'], 'QC!C3')
        self.assertEqual(row['documentos'], ['qc.xlsx', 'unifilar.csv'])

    def test_ai_extraction_is_optional_and_reviewed(self):
        import os
        old = os.environ.pop('ANTHROPIC_API_KEY', None)
        try:
            with self.assertRaisesRegex(ValueError, 'desativada'):
                importacao.preview(load(), b'%PDF-1.4', 'quadro.pdf')
            os.environ['ANTHROPIC_API_KEY'] = 'teste'
            fake = {'content': [{'type': 'text', 'text': 'Segue: {"circuitos":[{"nome":"QD-IA","montante":"QGBT-01","ligacao":"Trifásico",'
                                 '"potencia_w":6000,"fp":0.9,"origem":"página 1, quadro QD-IA","confianca":0.5}],"observacoes":["ok"]}'}]}
            sent = {}
            recs, info = importacao.ai_records(b'%PDF-1.4', 'quadro.pdf', transport=lambda payload: sent.update(payload) or fake)
            self.assertEqual(sent['messages'][0]['content'][0]['type'], 'document')
            pv = importacao.build_rows(load(), recs, [info])
            row = pv['linhas'][0]
            self.assertEqual(row['dados']['p'], {'R': 2000, 'S': 2000, 'T': 2000})
            self.assertIn('(IA)', row['fontes']['potencia'])
            self.assertTrue(any('confiança baixa' in a for a in row['avisos']))
        finally:
            os.environ.pop('ANTHROPIC_API_KEY', None)
            if old is not None:
                os.environ['ANTHROPIC_API_KEY'] = old


class SanitizeTests(unittest.TestCase):
    def test_imported_ids_are_sanitized(self):
        data = copy.deepcopy(BASE)
        data['circuitos'][0]['id'] = '"><img src=x onerror=alert(1)>'
        data['circuitos'][1]['id'] = 'ok_id-3'
        p = Project(data)
        self.assertRegex(p.meta['ids']['2'], r'^[0-9a-f]{32}$')
        self.assertEqual(p.meta['ids']['3'], 'ok_id-3')

    def test_ux_layer_builds_text_with_dom(self):
        ux = (ROOT / 'static/ux.js').read_text(encoding='utf-8')
        self.assertNotIn('${p.name}', ux)
        self.assertNotIn('${n.name}', ux)
        self.assertNotIn('innerHTML=`<button', ux)


class HttpV112Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        cls.server.store = Store(Path(cls.tmp.name) / 'p.sqlite3')
        cls.server.token = secrets.token_urlsafe(24); cls.server.lock = threading.RLock()
        cls.server.daemon_threads = True; cls.server.reviewer = None
        cls.base = f'http://127.0.0.1:{cls.server.server_port}'
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.client = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.tmp.cleanup()

    def get(self, path):
        return json.loads(self.client.open(self.base + path, timeout=120).read())

    def post(self, path, data=None, project=None, revision=None, raw=None, extra=None):
        st = self.get('/api/state')
        headers = {'X-Eletro-Token': self.server.token, 'Content-Type': 'application/json',
                   'X-Eletro-Project': st['project_id'] if project is None else project,
                   'X-Eletro-Revision': str(st['revision'] if revision is None else revision), **(extra or {})}
        req = urllib.request.Request(self.base + path, data=raw if raw is not None else json.dumps(data or {}).encode(), headers=headers, method='POST')
        return json.loads(self.client.open(req, timeout=120).read())

    def status(self, *a, **k):
        try:
            self.post(*a, **k)
            return 200
        except urllib.error.HTTPError as e:
            return e.code

    def test_revision_conflicts_history_compare_and_restore(self):
        st = self.get('/api/state')
        self.assertIn('revision', st); self.assertEqual(st['integridade']['problemas'], 0)
        rev0 = st['revision']
        r = self.post('/api/changes', {'changes': [ch('Levantamento de carga', 'D5', 2500)]})
        self.assertEqual(r['revision'], rev0 + 1)
        # Aba desatualizada: revisão antiga → 409, nada gravado.
        self.assertEqual(self.status('/api/changes', {'changes': [ch('Levantamento de carga', 'D5', 1)]}, revision=rev0), 409)
        self.assertEqual(self.server.store.project.raw('Levantamento de carga', 'D5'), 2500)
        # Pedido destinado a outro projeto → 409.
        self.assertEqual(self.status('/api/changes', {'changes': []}, project='outro'), 409)
        self.assertEqual(self.status('/api/changes', {'changes': []}, project=''), 409)
        hist = self.get('/api/history')
        self.assertEqual(hist['revisoes'][0]['revisao'], rev0 + 1)
        self.assertEqual(hist['revisoes'][0]['tipo'], 'delta')
        self.assertIn('QDFL-01', hist['revisoes'][0]['resumo'])
        cmp = self.get(f'/api/history/compare?a={rev0}&b={rev0 + 1}')
        self.assertEqual(cmp['n_entradas'], 1)
        self.assertTrue(any(x['circuito'] == 'QDFL-01' for x in cmp['resultados']))
        self.post('/api/history/restore', {'revisao': rev0})
        self.assertEqual(self.server.store.project.raw('Levantamento de carga', 'D5'), BASE['circuitos'][3]['entradas'].get('cargas.p_r_w'))
        self.assertEqual(self.get('/api/state')['revision'], rev0 + 2)
        self.assertTrue(list((Path(self.tmp.name) / 'backups').glob('*antes-restauracao*.sqlite3')))
        # Reconstrução de uma revisão antiga equivale ao estado gravado na época.
        data = self.server.store.reconstruct(rev0 + 1)
        self.assertEqual(data['circuitos'][3]['entradas']['cargas.p_r_w'], 2500)

    def test_import_loads_endpoint(self):
        csv = ImportUnitTests.CSV
        pv = self.post('/api/import-loads/preview', raw=csv, extra={'X-Filename': 'quadro.csv', 'Content-Type': 'text/csv'})
        rows = [r for r in pv['linhas'] if r['acao'] != 'ignorar']
        before = len(self.get('/api/state')['circuits'])
        r = self.post('/api/import-loads/confirm', {'linhas': rows})
        self.assertEqual(r['incluidos'], 3)
        self.assertEqual(len(self.get('/api/state')['circuits']), before + 3)
        self.assertIn('Importação de quadro de cargas', self.get('/api/history')['revisoes'][0]['resumo'])


if __name__ == '__main__':
    unittest.main()

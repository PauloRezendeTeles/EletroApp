"""Identidade física dos dispositivos e vínculo da saída ao quadro precedente."""
from __future__ import annotations
from . import trecho
from .protection_schema import CIRCUIT_SHEET, CCOL, LINK

MAP = {'K':'mb_in','AL':'mb_familia','AM':'mb_modelo','Y':'mb_ir','Z':'mb_ii','AO':'mb_in',
       'BX':'mb_isd','BZ':'mb_tsd'}
SHARED = set(MAP)|{'J','CA','CX','CY'}

def requested(p,r):
    if 'integrada.vinculo' not in p.model.by_id:return False
    return p.raw(CIRCUIT_SHEET,CCOL['vinculo']+str(r)) == LINK

def parent_row(p,r):
    name=p.get('Identificação dos circuitos',f'D{r}')
    return next((k for k in p.active_rows() if p.get('Identificação dos circuitos',f'B{k}')==name and k!=r),None)

def problem(p,r):
    if not requested(p,r):return None
    par=parent_row(p,r)
    if par is None:return 'Vínculo sem quadro precedente válido.'
    if p.get(trecho.SHEET,f'{trecho.COL["tem_mb"]}{par}') is not True:
        return 'O quadro precedente não tem disjuntor de chegada cadastrado.'
    if p.get(trecho.SHEET,f'{trecho.COL["filhos"]}{par}')!=1:
        return 'O vínculo com a chegada exige uma única saída; nas derivações, cadastre a proteção própria de cada alimentador.'
    own=p.get(trecho.SHEET,f'{trecho.COL["carga_propria"]}{par}')
    if own!=0:return 'O quadro precedente tem carga própria; cadastre o disjuntor da saída deste alimentador.'
    if p.get(trecho.SHEET,f'{trecho.COL["sem_origem"]}{r}') is True:
        return 'Um alimentador vinculado possui proteção na origem; selecione “Disjuntor ou fusível”.'
    return None

def read_alias(p,var,r):
    """Os dados compartilhados têm uma origem só; entradas antigas ficam preservadas."""
    if var.sheet!='Cálc-Prot_Cabos' or var.col not in SHARED or not requested(p,r):return False,None
    if problem(p,r):return True,None
    par=parent_row(p,r)
    col=var.col
    if col in MAP:return True,p.get(trecho.SHEET,trecho.COL[MAP[col]]+str(par))
    if col in ('CA','CX'):
        key='mb_i2t' if col=='CA' else 'mb_interrupcao_s'
        return True,p.get(CIRCUIT_SHEET,CCOL[key]+str(par))
    if col=='CY':return True,0
    from . import curvas
    d=curvas._device(p,par,'manutencao')
    return True,d.get('tipo') or ('Disjuntor em caixa moldada_L  - In > 25A' if (d.get('in') or 0)>25 else 'Disjuntor em caixa moldada_L  - In <= 25A')

def device_id(p,r,kind):
    if kind=='origem' and requested(p,r) and not problem(p,r):
        return device_id(p,parent_row(p,r),'manutencao')
    return kind+':'+p.circuit_at(r)['id']

def view(p,r):
    par=parent_row(p,r)
    name=p.get('Identificação dos circuitos',f'D{r}')
    linked=requested(p,r)
    error=problem(p,r)
    owner=p.circuit_at(par)['id'] if par is not None else None
    return {'id':device_id(p,r,'origem'),'quadro_id':owner,'quadro':name,'vinculado':linked,'erro':error,
            'descricao':('Disjuntor de chegada de '+str(name)+' — compartilhado com este alimentador') if linked else 'Saída de '+str(name)+' para '+str(p.get('Identificação dos circuitos',f'B{r}')),
            'editar_id':owner if linked and not error else p.circuit_at(r)['id'],
            'editar_grupo':'trecho' if linked else 'protecao'}

def outgoing(p,r):
    name=p.get('Identificação dos circuitos',f'B{r}')
    return [{'circuito_id':p.circuit_at(k)['id'],'nome':p.get('Identificação dos circuitos',f'B{k}'),**view(p,k)}
            for k in p.active_rows() if p.get('Identificação dos circuitos',f'D{k}')==name]

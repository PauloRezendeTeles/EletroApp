"""Validação dos ajustes dos disjuntores no servidor (v1.12).

Confere, para o modelo escolhido do catálogo WEG, se os ajustes adotados
existem fisicamente no equipamento:

* Ir (longo retardo): posição do dial, faixa contínua ou valor fixo (Ir = In);
* Ii/Im (instantâneo/magnético): valor fixo do relé, posições do dial (absolutas
  ou múltiplos de Ir) ou faixa do catálogo;
* Isd e tsd (curto retardo, só relés eletrônicos): posições do dial e lista de
  tempos admitida;
* combinações: Ir ≤ In, Ir ≤ Isd ≤ Ii.

Usa somente os dados que o próprio catálogo traz (core/project.py,
``weg_catalog``). Quando o catálogo não informa um eixo (por exemplo, banda
magnética "N/D — CONSULTAR WEG"), o eixo não é reprovado aqui: a pendência
continua nas verificações da planilha.
"""
from __future__ import annotations

import math

TOL = 1e-6
TSD_PADRAO = (50, 100, 200, 300)


def number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def as_number(v):
    """Número ou None. Aceita texto numérico salvo como string ("100", "1.000,5")."""
    if number(v):
        return float(v)
    if isinstance(v, str):
        from .numeros import parse_br
        try:
            return parse_br(v)
        except ValueError:
            return None
    return None


def empty(v):
    return v is None or (isinstance(v, str) and v.strip().upper() in ('', 'N/A', '—', '-'))


def _fmt(v):
    if v is None:
        return '—'
    v = float(v)
    return (f'{v:.2f}'.rstrip('0').rstrip('.') if not v.is_integer() else str(int(v))).replace('.', ',')


def _in_list(v, values):
    return any(abs(v - float(x)) <= max(TOL, abs(float(x)) * 1e-9) for x in values)


def _list_txt(values, limit=14):
    vals = [_fmt(x) for x in values]
    return ' · '.join(vals[:limit]) + (' …' if len(vals) > limit else '')


def ir_positions(modelo):
    a = modelo.get('ir_ajuste') or {}
    return list(a.get('valores') or []) if a.get('tipo') == 'discreto' else []


def im_positions(modelo, ir):
    a = modelo.get('im_ajuste') or {}
    if a.get('tipo') == 'discreto':
        return list(a.get('valores') or [])
    if a.get('tipo') == 'discreto_ir' and ir is not None:
        return [round(m * ir, 2) for m in a.get('mult_ir') or []]
    return []


def validate(modelo, ir, ii, isd=None, tsd=None, tsd_options=TSD_PADRAO, label='Disjuntor'):
    """Lista de problemas (texto) dos ajustes de um disjuntor do catálogo.

    ``modelo`` é a linha de ``Project.weg_catalog()``; ``None`` = sem modelo
    escolhido (nada a validar aqui)."""
    if modelo is None:
        return []
    out = []
    nome = modelo.get('modelo')
    sub = modelo.get('subclasse')
    in_n = as_number(modelo.get('in_nominal'))
    pref = f'{label} {nome}: '
    v_ir, v_ii, v_isd, v_tsd = as_number(ir), as_number(ii), as_number(isd), as_number(tsd)

    # ---- Ir ------------------------------------------------------------
    if not modelo.get('somente_magnetico'):
        a = modelo.get('ir_ajuste') or {}
        lo, hi = as_number(modelo.get('ir_min')), as_number(modelo.get('ir_max'))
        if empty(ir):
            out.append(pref + 'informe o Ir adotado.')
        elif v_ir is None:
            out.append(pref + f'Ir "{ir}" não é numérico.')
        else:
            if a.get('tipo') == 'discreto' and a.get('valores'):
                if not _in_list(v_ir, a['valores']):
                    out.append(pref + f'Ir = {_fmt(v_ir)} A não é uma posição do dial. Posições do catálogo: {_list_txt(a["valores"])} A.')
            elif a.get('tipo') in ('continuo', 'faixa') and lo is not None and hi is not None:
                if not lo - TOL <= v_ir <= hi + TOL:
                    out.append(pref + f'Ir = {_fmt(v_ir)} A fora da faixa do catálogo ({_fmt(lo)} a {_fmt(hi)} A).')
            elif a.get('tipo') == 'nenhum' and in_n is not None and abs(v_ir - in_n) > TOL:
                out.append(pref + f'disparo térmico fixo: Ir deve ser igual a In = {_fmt(in_n)} A (informado {_fmt(v_ir)} A).')
            if in_n is not None and v_ir > in_n + TOL:
                out.append(pref + f'Ir = {_fmt(v_ir)} A maior que In = {_fmt(in_n)} A.')

    # ---- Ii / Im -------------------------------------------------------
    ii_fixo = as_number(modelo.get('ii_fixo'))
    im_a = modelo.get('im_ajuste') or {}
    im_lo, im_hi = as_number(modelo.get('im_min')), as_number(modelo.get('im_max'))
    if sub == 'eletronico':
        if ii_fixo is not None:
            if v_ii is None:
                out.append(pref + f'Ii instantâneo é fixo em {_fmt(ii_fixo)} A neste relé; informe esse valor.')
            elif abs(v_ii - ii_fixo) > TOL:
                out.append(pref + f'Ii instantâneo é fixo em {_fmt(ii_fixo)} A (não ajustável); informado {_fmt(v_ii)} A.')
    else:
        if not empty(ii) and v_ii is None:
            out.append(pref + f'Ii/Im "{ii}" não é numérico.')
        elif v_ii is not None:
            vals = im_positions(modelo, v_ir)
            if vals:
                if not _in_list(v_ii, vals):
                    base = ' × Ir' if im_a.get('tipo') == 'discreto_ir' else ''
                    out.append(pref + f'Ii/Im = {_fmt(v_ii)} A não é uma posição do dial{base}. Posições: {_list_txt(vals)} A.')
            elif im_lo is not None and im_hi is not None and im_a.get('tipo') in ('continuo', 'faixa', 'nenhum'):
                if not im_lo - TOL <= v_ii <= im_hi + TOL:
                    kind = 'banda magnética' if sub == 'fixo' else 'faixa'
                    out.append(pref + f'Ii/Im = {_fmt(v_ii)} A fora da {kind} do catálogo ({_fmt(im_lo)} a {_fmt(im_hi)} A).')
        elif sub != 'fixo' and (im_a.get('tipo') not in (None, 'nenhum') or (im_lo is not None and im_hi is not None and im_hi > im_lo)):
            out.append(pref + 'informe o Ii/Im adotado.')

    # ---- Isd / tsd -----------------------------------------------------
    if sub == 'eletronico':
        vals = im_positions(modelo, v_ir)
        if empty(isd):
            out.append(pref + 'informe o Isd (curto retardo) adotado.')
        elif v_isd is None:
            out.append(pref + f'Isd "{isd}" não é numérico.')
        else:
            if vals:
                if not _in_list(v_isd, vals):
                    out.append(pref + f'Isd = {_fmt(v_isd)} A não é uma posição do relé. Posições{" (× Ir)" if im_a.get("tipo") == "discreto_ir" else ""}: {_list_txt(vals)} A.')
            elif im_lo is not None and im_hi is not None and not im_lo - TOL <= v_isd <= im_hi + TOL:
                out.append(pref + f'Isd = {_fmt(v_isd)} A fora da faixa do catálogo ({_fmt(im_lo)} a {_fmt(im_hi)} A).')
            if v_ir is not None and v_isd < v_ir - TOL:
                out.append(pref + f'Isd = {_fmt(v_isd)} A menor que Ir = {_fmt(v_ir)} A.')
            ii_ref = ii_fixo if ii_fixo is not None else v_ii
            if ii_ref is not None and v_isd > ii_ref + TOL:
                out.append(pref + f'Isd = {_fmt(v_isd)} A maior que o Ii instantâneo ({_fmt(ii_ref)} A).')
        allowed = [x for x in (as_number(t) for t in tsd_options) if x is not None] or list(TSD_PADRAO)
        if empty(tsd):
            out.append(pref + 'informe o tsd (tempo de curto retardo) adotado.')
        elif v_tsd is None or not _in_list(v_tsd, allowed):
            out.append(pref + f'tsd = {tsd} ms não é uma opção do relé ({_list_txt(allowed)} ms).')
    else:
        if v_isd is not None:
            out.append(pref + 'Isd não existe neste modelo (sem relé eletrônico); use N/A.')
        if v_tsd is not None:
            out.append(pref + 'tsd não existe neste modelo (sem relé eletrônico); use N/A.')
    return out

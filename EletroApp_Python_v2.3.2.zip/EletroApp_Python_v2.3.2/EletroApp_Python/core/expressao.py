"""Expressões do motor nativo (v2.0): impressão da árvore sintática e nomes.

As expressões usam a mesma sintaxe de funções da planilha (SE/IF, PROCV/VLOOKUP,
ÍNDICE/INDEX...), mas os operandos são **variáveis nomeadas** em vez de células:

* ``corrente.i_fase_r_a``      — variável do próprio circuito;
* ``CIRCUITOS(ident.nome)``   — a mesma variável em todos os circuitos (vetor);
* ``CIRCUITOS(a, b)``         — bloco de variáveis consecutivas de todos os circuitos;
* ``FAIXA(a, b)``             — variáveis consecutivas do próprio circuito;
* ``fonte.tensao_linha_v``    — dado da fonte/entrada de energia;
* ``verificacao.topologia``   — verificação do projeto inteiro;
* ``tab_weg_protecoes!J2:J568`` — intervalo de uma tabela técnica (linhas e colunas da tabela);
* nomes definidos (``Tabela_Disjuntores``) — intervalos de tabelas técnicas.

``ROW()`` devolve a posição do circuito na ordem topológica + 1 (o primeiro
circuito é a posição 2), o que preserva as comparações de ordem montante/jusante.
"""
from __future__ import annotations

from .formula import Error, parse

PREC = {'=': 1, '<>': 1, '<': 1, '>': 1, '<=': 1, '>=': 1, '&': 2, '+': 3, '-': 3, '*': 4, '/': 4, '^': 5, ':': 7}


def _num(v):
    if isinstance(v, float) and v.is_integer() and abs(v) < 1e15:
        return str(int(v))
    r = repr(float(v))
    return r


def _sheet(s):
    if s is None:
        return ''
    if s.replace('_', '').replace('.', '').isalnum() and not s[0].isdigit():
        return s + '!'
    return "'" + s.replace("'", "''") + "'!"


def unparse(node):
    """Texto da expressão (sem o "=") a partir da árvore de ``core.formula.parse``."""
    kind = node[0]
    if kind == 'lit':
        v = node[1]
        if v is None:
            return ''
        if isinstance(v, bool):
            return 'TRUE' if v else 'FALSE'
        if isinstance(v, Error):
            return v.code
        if isinstance(v, (int, float)):
            return _num(v)
        return '"' + str(v).replace('"', '""') + '"'
    if kind == 'ref':
        a, b = node[2], node[3]
        return _sheet(node[1]) + (a if a == b else f'{a}:{b}')
    if kind == 'columns':
        return _sheet(node[1]) + f'{node[2]}:{node[3]}'
    if kind == 'name':
        return node[1]
    if kind == 'array':
        return '{' + ';'.join(','.join(unparse(x) for x in row) for row in node[1]) + '}'
    if kind == 'unary':
        op, x = node[1], node[2]
        inner = unparse(x)
        if x[0] in ('bin', 'unary'):
            inner = '(' + inner + ')'
        return inner + '%' if op == '%' else op + inner
    if kind == 'bin':
        op, a, b = node[1], node[2], node[3]
        p = PREC[op]
        left, right = unparse(a), unparse(b)
        if a[0] == 'bin' and PREC[a[1]] < p:
            left = '(' + left + ')'
        if b[0] == 'bin' and PREC[b[1]] <= p:
            right = '(' + right + ')'
        if op == ':':
            return left + ':' + right
        return left + op + right
    if kind == 'call':
        return node[1] + '(' + ','.join(unparse(a) for a in node[2]) + ')'
    raise ValueError('Nó desconhecido: ' + str(kind))


def text(node):
    return '=' + unparse(node)


def children(node):
    kind = node[0]
    if kind == 'unary':
        return [node[2]]
    if kind == 'bin':
        return [node[2], node[3]]
    if kind == 'call':
        return list(node[2])
    if kind == 'array':
        return [x for row in node[1] for x in row]
    return []


def walk(node):
    yield node
    for c in children(node):
        yield from walk(c)


def names(node):
    """Nomes (variáveis e nomes definidos) usados numa árvore."""
    return {n[1] for n in walk(node) if n[0] == 'name'}


def transform(node, fn):
    """Reconstrói a árvore aplicando ``fn`` de baixo para cima (fn devolve o nó novo)."""
    kind = node[0]
    if kind == 'unary':
        node = (kind, node[1], transform(node[2], fn))
    elif kind == 'bin':
        node = (kind, node[1], transform(node[2], fn), transform(node[3], fn))
    elif kind == 'call':
        node = (kind, node[1], tuple(transform(a, fn) for a in node[2]))
    elif kind == 'array':
        node = (kind, tuple(tuple(transform(x, fn) for x in row) for row in node[1]))
    return fn(node)


def roundtrip_ok(formula):
    t = parse(formula)
    return parse(text(t)) == t

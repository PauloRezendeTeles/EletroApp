"""Leitura OOXML somente; não altera o arquivo de origem."""
from __future__ import annotations
import hashlib
import io
import json
import posixpath
import re
from xml.etree import ElementTree as ET
from zipfile import ZipFile, BadZipFile
from .formula import col_name, col_number

NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'


def translate(formula, dr=0, dc=0):
    """Desloca referências relativas sem tocar em textos nem nomes de abas."""
    parts=re.split(r'("(?:[^"]|"")*"|\'(?:[^\']|\'\')*\')',formula)
    def move(m):
        c,absrow,r=m.groups()
        cn=col_number(c)+(0 if c.startswith('$') else dc)
        rn=int(r)+(0 if absrow else dr)
        if cn<1 or rn<1:return '#REF!'
        return ('$' if c.startswith('$') else '')+col_name(cn)+absrow+str(rn)
    for i in range(0,len(parts),2):
        parts[i]=re.sub(r'(?<![\w.])(\$?[A-Z]{1,3})(\$?)(\d+)(?![\w.])',move,parts[i])
    return ''.join(parts)


def read_xlsx(raw, filename='projeto.xlsx'):
    if hasattr(raw,'read'):raw=raw.read()
    try:
        z=ZipFile(io.BytesIO(raw))
        if sum(i.file_size for i in z.infolist())>150_000_000:
            raise ValueError('Planilha descompactada excede 150 MB.')
        workbook=ET.fromstring(z.read('xl/workbook.xml'))
        rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
    except (BadZipFile,KeyError,ET.ParseError) as e:
        raise ValueError('Arquivo XLSX inválido ou protegido por senha.') from e
    targets={r.attrib['Id']:posixpath.normpath('xl/'+r.attrib['Target']) if not r.attrib['Target'].startswith('/') else r.attrib['Target'][1:] for r in rels}
    strings=[]
    if 'xl/sharedStrings.xml' in z.namelist():
        for si in ET.fromstring(z.read('xl/sharedStrings.xml')):
            strings.append(''.join(t.text or '' for t in si.iter('{'+NS['m']+'}t')))
    formats={0:'General',1:'0',2:'0.00',9:'0%',10:'0.00%',3:'#,##0',4:'#,##0.00'}
    styles=[]
    if 'xl/styles.xml' in z.namelist():
        root=ET.fromstring(z.read('xl/styles.xml'))
        for f in root.findall('m:numFmts/m:numFmt',NS):formats[int(f.attrib['numFmtId'])]=f.attrib['formatCode']
        for xf in root.findall('m:cellXfs/m:xf',NS):
            p=xf.find('m:protection',NS)
            styles.append({'format':formats.get(int(xf.attrib.get('numFmtId','0')),'General'),
                           'locked':p is None or p.attrib.get('locked','1')!='0'})
    data={'sheets':{},'names':{},'meta':{'source':filename,'sha256':hashlib.sha256(raw).hexdigest(),'engine_version':1}}
    for n in workbook.findall('m:definedNames/m:definedName',NS):
        if 'localSheetId' not in n.attrib:data['names'][n.attrib['name']]=n.text or ''
    for sh in workbook.findall('m:sheets/m:sheet',NS):
        root=ET.fromstring(z.read(targets[sh.attrib['{'+REL+'}id']]))
        cells={}; shared={}
        for c in root.findall('m:sheetData/m:row/m:c',NS):
            a=c.attrib['r']; typ=c.attrib.get('t','n'); v=c.find('m:v',NS); f=c.find('m:f',NS)
            value=v.text if v is not None else None
            if typ=='s' and value is not None:value=strings[int(value)]
            elif typ=='inlineStr':value=''.join(t.text or '' for t in c.findall('.//m:t',NS))
            elif typ=='b':value=value=='1'
            elif typ=='n' and value is not None:
                try:
                    value=float(value)
                    if value.is_integer():value=int(value)
                except ValueError:pass
            formula=None
            if f is not None:
                formula=f.text
                if f.attrib.get('t')=='shared':
                    si=f.attrib['si']
                    if formula:shared[si]=(a,formula)
                    elif si in shared:
                        origin,base=shared[si]
                        r1=int(re.search(r'\d+',origin)[0]); c1=col_number(re.match(r'[A-Z]+',origin)[0])
                        r2=int(re.search(r'\d+',a)[0]); c2=col_number(re.match(r'[A-Z]+',a)[0])
                        formula=translate(base,r2-r1,c2-c1)
                if formula is None:raise ValueError(f'Fórmula compartilhada sem origem: {sh.attrib["name"]}!{a}')
            if value is None and formula is None:continue
            style=styles[int(c.attrib.get('s','0'))] if styles else {'format':'General','locked':True}
            cells[a]={'value':'='+formula if formula is not None else value,'cache':value,
                      'formula':formula is not None,**style}
            if typ=='e' and formula is None:cells[a]['error']=True
        validations=[]
        for dv in root.findall('m:dataValidations/m:dataValidation',NS):
            f1=dv.find('m:formula1',NS); f2=dv.find('m:formula2',NS)
            validations.append({'range':dv.attrib['sqref'],'type':dv.attrib.get('type'),
                                'f1':f1.text if f1 is not None else None,'f2':f2.text if f2 is not None else None})
        data['sheets'][sh.attrib['name']]={'cells':cells,'validations':validations,'state':sh.attrib.get('state','visible')}
    return data


def dump_gzip(data,path):
    import gzip
    with gzip.open(path,'wt',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,separators=(',',':'))

"""Coordenação (seletividade) das proteções em três níveis (v2.0).

Para cada circuito com dispositivo próprio e um dispositivo a montante, o par é
classificado pelo nível de evidência disponível — sempre o mais forte:

1. **Verificado com dados do fabricante** — tabela de seletividade ou curvas
   tempo × corrente importadas pelo revisor, com documento, edição e página
   citados. O aplicativo não traz nem inventa dados de fabricante: sem
   importação, este nível não aparece.
2. **Aproximado** — faixas genéricas construídas com os ajustes adotados e as
   tolerâncias conhecidas: correntes convencionais de atuação e não atuação
   (tabela de características convencionais da base técnica), faixa de disparo
   magnético do catálogo (dispositivos fixos) ou das curvas B/C/D, tolerância
   de ±20% dos disparadores de curto-circuito ajustáveis e relação 1,6:1 entre
   fusíveis gG. Indica um limite de seletividade aproximado, não um resultado
   de fabricante.
3. **Pré-verificação** — razão de correntes do modelo (variáveis do grupo
   Seletividade), usada quando faltam dados para a aproximação.

A corrente de comparação é a corrente de curto-circuito máxima no ponto de
instalação do dispositivo de jusante (falta logo após o dispositivo).
"""
from __future__ import annotations

import csv
import datetime as dt
import html
import io
import math
import re
import uuid

from .formula import Error
from . import numeros

ROOTS = ('Fonte', 'Transformador')
LEVELS = {'verificado': 'Verificado com dados do fabricante', 'aproximado': 'Aproximado (faixas genéricas)',
          'pre_verificacao': 'Pré-verificação (correntes ou tempos pontuais)', 'sem_dados': 'Dados insuficientes'}
STATUS = {'seletiva': 'Seletiva até o Ik máximo', 'parcial': 'Seletividade parcial', 'nao_seletiva': 'Não seletiva',
          'limitada': 'Verificada só até o limite indicado', 'indeterminada': 'Indeterminada'}
TOL_ADJ = 0.20      # tolerância dos disparadores de curto-circuito ajustáveis (IEC 60947-2)
FUSE_RATIO = 1.6    # relação de correntes nominais entre fusíveis gG (IEC 60269)
TSD_MIN_MS = 100    # retardo mínimo do montante para considerar seletividade cronométrica
MAX_ROWS = 5000


def _now():
    return dt.datetime.now().astimezone().isoformat(timespec='seconds')


def _num(v):
    return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) else None


def _val(p, vid, r):
    v = p.model.by_id[vid]
    x = p.get(v.sheet, f'{v.col}{r}')
    return None if isinstance(x, dict) else x


def _norm(s):
    return re.sub(r'\s+', '', str(s or '')).casefold()


# ------------------------------------------------------------------ dispositivos
def _type_row(p, tipo):
    """Características convencionais do tipo de dispositivo (tabela da base técnica)."""
    if not tipo:
        return None
    t = p.model.tables.get('tab_disjuntores_ref')
    for r in range(2, t.max_row + 1):
        if _norm(p.raw('tab_disjuntores_ref', f'A{r}')) == _norm(tipo):
            g = lambda c: _num(p.get('tab_disjuntores_ref', f'{c}{r}'))
            return {'nao_atua': g('D'), 'atua': g('E'), 'mag_min': g('F'), 'mag_max': g('G')}
    return None


def _library(p, idx):
    """Linha da biblioteca de disjuntores do modelo escolhido (característica, curva, In)."""
    idx = _num(idx)
    if idx is None:
        return None
    r = int(idx) + 1
    g = lambda c: p.get('tab_weg_protecoes', f'{c}{r}')
    return {'familia': g('B'), 'modelo': g('C'), 'caracteristica': str(g('P') or ''), 'curva': str(g('Q') or '').strip().upper(),
            'in': _num(g('AL'))}


def _resolve(p, d, lib, tipo_informado, in_informado):
    """Completa a descrição única do dispositivo efetivo a partir do modelo escolhido e aponta conflitos com as entradas."""
    conflicts = []
    if lib:
        car = lib['caracteristica'].casefold()
        # 'ajustavel' refere-se ao disparador de curto-circuito (faixa magnética fixa do catálogo × ajuste com tolerância).
        if car.startswith('termomagnético fixo') or re.search(r'magn[eé]tico[s]?,? fixos?|fixos', car):
            d['ajustavel'] = False
        elif 'eletr' in car or re.search(r'magn[eé]tico[s]? ajust|magn[eé]tico, ajust', car):
            d['ajustavel'] = True
        elif ' ou ' not in car and 'fixo' in car:
            d['ajustavel'] = False
        d['caracteristica'] = lib['caracteristica'] or None
        curva = lib['curva'] if lib['curva'] in ('B', 'C', 'D') else None
        d['curva'] = curva
        if curva and d.get('in'):
            d['tipo'] = f"Disjuntor_{curva} - In {'<=' if d['in'] <= 63 else '>'} 63A"
            if tipo_informado and not _norm(tipo_informado).startswith(_norm(f'Disjuntor_{curva}')):
                conflicts.append(f'Tipo de proteção informado ({tipo_informado}) difere da característica do modelo {d["modelo"]} '
                                 f'(curva {curva}); a coordenação usa a do modelo.')
        elif tipo_informado and _norm(tipo_informado).startswith('disjuntor_') and not curva:
            conflicts.append(f'Tipo de proteção informado ({tipo_informado}) indica curva B/C/D, mas o modelo {d["modelo"]} '
                             'não tem curva B/C/D no catálogo.')
    if in_informado is not None and d.get('in') is not None and abs(in_informado - d['in']) > 0.5:
        conflicts.append(f'In informado ({in_informado:g} A) difere do In do modelo {d["modelo"]} ({d["in"]:g} A); '
                         'a coordenação usa o do modelo. Corrija o campo In para que o dimensionamento use o mesmo valor.')
    d['conflitos'] = conflicts
    return d


def _device(p, r, kind):
    """Dispositivo efetivo: 'origem' (na saída do quadro a montante) ou 'manutencao' (na extremidade do circuito).

    Uma única descrição — modelo, característica, In, ajustes e Icu — resolvida a partir do modelo escolhido no
    catálogo; as entradas antigas só valem quando não há modelo, e divergências viram pendências explícitas."""
    from . import protection_links as links
    if kind=='origem' and links.requested(p,r) and not links.problem(p,r):
        return dict(_device(p,links.parent_row(p,r),'manutencao'))
    name = _val(p, 'ident.nome', r)
    if kind == 'manutencao':
        model = _val(p, 'trecho.mb_modelo', r)
        classe = str(_val(p, 'trecho.mb_classe', r) or '')
        d = {'circuito': name, 'posicao': 'manutencao', 'descricao': f'Disjuntor de manutenção de {name}', 'modelo': model or None,
             'tipo': None, 'fusivel': False, 'ajustavel': 'fixo' not in classe and classe not in ('', 'somente magnético'),
             'in': _num(_val(p, 'trecho.mb_in', r)), 'ir': _num(_val(p, 'trecho.mb_ir', r)), 'ii': _num(_val(p, 'trecho.mb_ii', r)),
             'isd': _num(_val(p, 'trecho.mb_isd', r)), 'tsd': _num(_val(p, 'trecho.mb_tsd', r)), 'ii_inst': None, 'i2t': None,
             'mag_cat': (_num(_val(p, 'trecho.mb_im_min', r)), _num(_val(p, 'trecho.mb_im_max', r))),
             'icu_ka': _num(_val(p, 'trecho.mb_icu', r)), 'ik_ka': _num(_val(p, 'icc.ik_max_ka', r))}
        _resolve(p, d, _library(p, _val(p, 'trecho.mb_idx', r)) if d['modelo'] else None, None, None)
        if 'integrada.mb_i2t' in p.model.by_id:
            setting=_val(p,'integrada.mb_i2t',r)
            d['i2t']=setting if setting in ('ON','OFF') else None
    else:
        tipo = _val(p, 'protecao.tipo_protecao', r)
        model = _val(p, 'protecao.modelo_em_uso', r)
        model = model if isinstance(model, str) and model else None
        in_sensor = _num(_val(p, 'protecao.in_sensor_a', r))
        in_frame = _num(_val(p, 'protecao.in_frame_a', r))
        in_model = in_sensor if in_sensor is not None else in_frame
        in_input = _num(_val(p, 'protecao.in_a', r))
        i2t = _val(p, 'protecao.i2t_on_off', r)
        icu = _num(_val(p, 'protecao.icu_de_catalogo_na_tensao_do_circuito_ka', r))
        d = {'circuito': name, 'posicao': 'origem', 'descricao': f'Dispositivo da origem de {name}', 'modelo': model,
             'tipo': tipo, 'fusivel': 'fus' in str(tipo or '').casefold() and not model,
             'ajustavel': _val(p, 'protecao.disparo_ajustavel_auto', r) == 'SIM',
             'in': in_model if (model and in_model is not None) else in_input,
             'ir': _num(_val(p, 'protecao.ir_a', r)), 'ii': _num(_val(p, 'protecao.ii_a', r)),
             'isd': _num(_val(p, 'protecao.isd_a', r)), 'tsd': _num(_val(p, 'protecao.tsd_ms', r)),
             'ii_inst': _num(_val(p, 'protecao.ii_instantaneo_a_auto', r)),
             'i2t': str(i2t).strip().upper() if str(i2t or '').strip().upper() in ('ON', 'OFF') else None,
             'mag_cat': (_num(_val(p, 'protecao.ii_im_minimo_permitido_a', r)), _num(_val(p, 'protecao.ii_im_maximo_permitido_a', r))),
             'icu_ka': icu if icu is not None else _num(_val(p, 'protecao.icu_ka', r)),
             'ik_ka': _num(_val(p, 'trecho.ik_origem', r))}
        lib = _library(p, _val(p, 'protecao.indice_na_biblioteca_weg_auto', r)) if model else None
        _resolve(p, d, lib, tipo, in_input if model else None)
        # O disparo instantâneo do modelo também é o usado nas faixas de atuação.
        # O campo legado pode conter Isd; não pode validar uma curva de outro Ii.
        d['ii_informado'] = d['ii']
        if d['ii_inst'] is not None:
            if d['ii'] is not None and not _match(d['ii'], d['ii_inst']):
                d['conflitos'].append(f'Ii/Im informado ({d["ii"]:g} A) difere do Ii instantâneo do modelo '
                                      f'({d["ii_inst"]:g} A); a coordenação usa o instantâneo. Confira o ajuste informado.')
            d['ii'] = d['ii_inst']
    d['conv'] = _type_row(p, d['tipo'])
    d['id']=links.device_id(p,r,kind)
    d['quadro']=name if kind=='manutencao' else _val(p,'ident.montante',r)
    return d


def device_conflicts(p, r):
    """Divergências entre as entradas e o modelo escolhido do dispositivo da origem (pendência do circuito)."""
    try:
        if _val(p, 'trecho.sem_origem', r) is True:
            return []
        return _device(p, r, 'origem')['conflitos']
    except Exception:  # noqa: BLE001 — a verificação nunca impede o cálculo do circuito
        return []


def _chain(p, r):
    """Dispositivos em série do próprio circuito, de montante para jusante (origem, manutenção)."""
    out = []
    if _val(p, 'trecho.sem_origem', r) is not True:
        out.append(_device(p, r, 'origem'))
    if _val(p, 'trecho.tem_mb', r) is True:
        out.append(_device(p, r, 'manutencao'))
    return out


def _own_device(p, r):
    """Primeiro dispositivo do próprio trecho (o que deve atuar antes do dispositivo a montante)."""
    chain = _chain(p, r)
    return chain[0] if chain else None


def _feeding_device(p, r, rows_by_name, depth=0):
    """Dispositivo que alimenta o quadro do circuito ``r`` (o último da série do circuito ou, sem nenhum, o mais a montante)."""
    if depth > 200:
        return None
    chain = _chain(p, r)
    if chain:
        return chain[-1]
    parent = _val(p, 'ident.montante', r)
    if parent in ROOTS or parent not in rows_by_name:
        return None
    return _feeding_device(p, rows_by_name[parent], rows_by_name, depth + 1)


# ------------------------------------------------------------------ faixas genéricas
def _bands(d):
    """Faixas de disparo de curto-circuito: [('inst'|'curto_retardo', mínimo A, máximo A, retardo ms)]."""
    out, notes = [], []
    if d['fusivel']:
        return out, notes
    if d['ajustavel']:
        if d['isd'] and d['tsd'] and d['tsd'] > 0:
            out.append(('curto_retardo', d['isd'] * (1 - TOL_ADJ), d['isd'] * (1 + TOL_ADJ), d['tsd']))
            notes.append(f"Curto retardo Isd {d['isd']:g} A ±20% com tsd {d['tsd']:g} ms")
            inst = d['ii_inst'] or (d['ii'] if d['ii'] and d['ii'] != d['isd'] else None)
            if inst:
                out.append(('inst', inst * (1 - TOL_ADJ), inst * (1 + TOL_ADJ), 0))
                notes.append(f'Instantâneo {inst:g} A ±20%')
        elif d['ii']:
            out.append(('inst', d['ii'] * (1 - TOL_ADJ), d['ii'] * (1 + TOL_ADJ), 0))
            notes.append(f"Instantâneo Ii {d['ii']:g} A ±20% (tolerância dos disparadores ajustáveis)")
        return out, notes
    lo, hi = d['mag_cat']
    if lo and hi and lo <= hi:
        out.append(('inst', lo, hi, 0))
        notes.append(f'Faixa magnética do catálogo {lo:g}–{hi:g} A')
    elif d['conv'] and d['conv']['mag_min'] and d['conv']['mag_max'] and d['in']:
        c = d['conv']
        out.append(('inst', c['mag_min'] * d['in'], c['mag_max'] * d['in'], 0))
        notes.append(f"Faixa magnética do tipo {c['mag_min']:g}–{c['mag_max']:g} × In")
    elif d['ii']:
        out.append(('inst', d['ii'] * (1 - TOL_ADJ), d['ii'] * (1 + TOL_ADJ), 0))
        notes.append(f"Disparo magnético Ii {d['ii']:g} A ±20% (faixa do catálogo não disponível)")
    return out, notes


def _approx(up, down, ik_a):
    """Classificação aproximada do par. Devolve (situação, limite em A ou None, notas) ou None se não houver base."""
    notes = []
    if up['fusivel'] or down['fusivel']:
        if up['fusivel'] and down['fusivel'] and up['in'] and down['in']:
            ratio = up['in'] / down['in']
            notes.append(f'Fusíveis: relação In montante/jusante = {ratio:.2f} (referência 1,6:1 para gG)')
            return ('seletiva' if ratio >= FUSE_RATIO else 'nao_seletiva'), None, notes
        return None
    if not (up['ir'] and down['ir']):
        return None
    # Sobrecarga: corrente convencional de não atuação do montante × de atuação do jusante.
    nt = (up['conv'] or {}).get('nao_atua') or 1.05
    at = (down['conv'] or {}).get('atua') or 1.30
    overload_ok = nt * up['ir'] >= at * down['ir']
    notes.append(f"Sobrecarga: não atuação do montante {nt:g}×{up['ir']:g} A = {nt * up['ir']:.0f} A; "
                 f"atuação do jusante {at:g}×{down['ir']:g} A = {at * down['ir']:.0f} A")
    ub, unotes = _bands(up)
    db, dnotes = _bands(down)
    notes += ['Montante: ' + n for n in unotes] + ['Jusante: ' + n for n in dnotes]
    if not db:
        notes.append('Jusante sem faixa de disparo de curto-circuito conhecida.')
        return None
    d_inst_hi = max(b[2] for b in db)
    inst = [b for b in ub if b[0] == 'inst']
    st = [b for b in ub if b[0] == 'curto_retardo']
    limit = min(b[1] for b in inst) if inst else math.inf
    if st:
        s = st[0]
        if s[3] >= TSD_MIN_MS and d_inst_hi <= s[1]:
            notes.append(f'Seletividade cronométrica: o jusante elimina a falta antes do retardo de {s[3]:g} ms do montante.')
        else:
            limit = min(limit, s[1])
            notes.append('O curto retardo do montante não garante separação de tempo com o jusante; limite pelo início da faixa.')
    elif not inst:
        notes.append('Montante sem disparo de curto-circuito informado.')
        return None
    if limit is not math.inf and limit <= d_inst_hi:
        notes.append('A faixa de disparo do montante começa antes do fim da faixa instantânea do jusante.')
    if ik_a is None:
        return ('indeterminada', None if limit is math.inf else limit, notes + ['Ik máximo no ponto não calculado.'])
    if not overload_ok:
        return 'nao_seletiva', None if limit is math.inf else limit, notes + ['As faixas de sobrecarga se sobrepõem.']
    if limit >= ik_a:
        return 'seletiva', None if limit is math.inf else limit, notes
    return 'parcial', limit, notes


# ------------------------------------------------------------------ dados do fabricante
CURVE_MIN_T = 0.01   # s — abaixo disso (região instantânea/limitadora) a comparação de curvas não demonstra seletividade
SETTING_KEYS = (('ir_a', 'ir', 'Ir'), ('isd_a', 'isd', 'Isd'), ('tsd_ms', 'tsd', 'tsd'), ('ii_a', 'ii', 'Ii'))


def _data(p):
    items = p.meta.get('curvas')
    return items if isinstance(items, list) else []


def _sealed(item):
    from .integridade import valid
    return isinstance(item, dict) and valid('dados_fabricante', str(item.get('id')), item)


def _usable(p):
    """Dados do fabricante com selo válido (os alterados fora do aplicativo não sustentam o nível verificado)."""
    return [x for x in _data(p) if _sealed(x)]


def _voltage(p):
    v = p.model.by_id['fonte.tensao_linha_v']
    return _num(p.get(v.sheet, v.addr))


def _range(text):
    """'380' → (380, 380); '380-415' → (380, 415)."""
    if text in (None, ''):
        return None
    t = str(text).strip().upper().replace('V', '').strip()
    if '/' in t:  # notação fase/linha (ex.: 220/380): vale a tensão de linha
        vals = [numeros.parse_br(x) for x in t.split('/') if x.strip()]
        return (max(vals), max(vals)) if vals else None
    parts = re.split(r'\s*(?:-|–|\bA\b)\s*', t)
    vals = [numeros.parse_br(x) for x in parts if x.strip()]
    return (min(vals), max(vals)) if vals else None


def _match(a, b):
    return a is not None and b is not None and abs(a - b) <= max(0.5, 0.01 * abs(b))


def _check_side(cond, dev, label, base=None):
    """Condições de ajuste declaradas no documento × ajustes do dispositivo. Devolve a lista de impedimentos."""
    cond = cond or {}
    issues = []
    for key, attr, nome in SETTING_KEYS:
        val = dev.get(attr)
        declared = _num(cond.get(key))
        if declared is not None:
            if not _match(val, declared):
                issues.append(f'{label}: {nome} do documento {declared:g} ≠ {nome} adotado {"—" if val is None else f"{val:g}"}.')
        elif dev.get('ajustavel') and val is not None and not (key == 'ir_a' and base == 'multiplo_ir'):
            issues.append(f'{label}: o documento não informa o {nome} para o qual vale; o dispositivo é ajustável ({nome} = {val:g}).')
    if cond.get('i2t') not in (None, ''):
        if dev.get('i2t') is None:
            issues.append(f'{label}: o documento exige I²t {cond["i2t"]}, mas o projeto não registra esse ajuste.')
        elif str(cond['i2t']).upper() != dev['i2t']:
            issues.append(f'{label}: I²t do documento ({cond["i2t"]}) ≠ ajustado ({dev["i2t"]}).')
    elif dev.get('i2t') is not None and dev.get('ajustavel'):
        issues.append(f'{label}: I²t {dev["i2t"]} no projeto e o documento não informa a condição de I²t.')
    return issues


def _check_voltage(tensao, voltage, required=True):
    rng = _range(tensao) if not isinstance(tensao, (list, tuple)) else tuple(tensao)
    if rng is None:
        return ['O documento não informa a tensão para a qual vale.'] if required else []
    if voltage is None:
        return ['Tensão do sistema não calculada.']
    if not (rng[0] * 0.99 <= voltage <= rng[1] * 1.01):
        return [f'Documento válido para {rng[0]:g}–{rng[1]:g} V; o sistema opera em {voltage:g} V.']
    return []


def _table_lookup(p, up, down):
    """(item, linha, impedimentos) da primeira combinação montante × jusante dos documentos importados."""
    if not (up.get('modelo') and down.get('modelo')):
        return None
    voltage = _voltage(p)
    found = None
    for item in _usable(p):
        if item.get('tipo') != 'tabela_seletividade':
            continue
        for row in item.get('linhas', []):
            if _norm(row.get('montante')) != _norm(up['modelo']) or _norm(row.get('jusante')) != _norm(down['modelo']):
                continue
            cond = row.get('condicoes') or {}
            issues = _check_voltage(cond.get('tensao_v') or item.get('tensao_v'), voltage)
            issues += _check_side(cond.get('montante'), up, 'Montante') + _check_side(cond.get('jusante'), down, 'Jusante')
            declared_icu = _num(cond.get('icu_jusante_ka'))
            if declared_icu is not None and down.get('icu_ka') is not None and not _match(declared_icu, down['icu_ka']):
                issues.append(f'Icu do jusante no documento ({declared_icu:g} kA) difere do catálogo na tensão do projeto '
                              f'({down["icu_ka"]:g} kA). Reconcilie a fonte e a condição de aplicação; '
                              'esta coluna não comprova capacidade reforçada por associação.')
            if not issues:
                return item, row, []
            found = found or (item, row, issues)
    return found


def _curve_for(p, d, voltage):
    """(curva aplicável, impedimentos) para o dispositivo; impedimentos quando só há curvas de outras condições."""
    if not d.get('modelo'):
        return None, []
    rejected = []
    for item in _usable(p):
        if item.get('tipo') != 'curva' or _norm(item.get('modelo')) != _norm(d['modelo']):
            continue
        issues = _check_voltage(item.get('tensao_v'), voltage, required=False)
        issues += _check_side(item.get('ajustes'), d, d['descricao'], item.get('base'))
        if item.get('base') == 'corrente_a' and d.get('ajustavel') and not item.get('ajustes'):
            issues.append(f"{d['descricao']}: curva em ampères de dispositivo ajustável sem os ajustes para os quais vale.")
        if not issues:
            return item, []
        rejected += issues
    return None, rejected


def _scale(item, d):
    base = item.get('base', 'corrente_a')
    if base == 'corrente_a':
        return 1.0
    return d['ir'] if base == 'multiplo_ir' else d['in']


def _envelope(points, key, factor):
    pts = [(x['i'] * factor, x[key]) for x in points if x.get(key) is not None]
    return sorted(pts, key=lambda t: t[0])


def _at(env, i, worst):
    """Tempo do envelope na corrente ``i`` (interpolação log-log entre vértices). None fora do domínio documentado.
    Em degraus (mesma corrente, tempos diferentes) devolve o pior caso: ``worst`` = min ou max."""
    if not env or i < env[0][0] * (1 - 1e-12) or i > env[-1][0] * (1 + 1e-12):
        return None
    exact = [t for x, t in env if abs(x - i) <= 1e-9 * max(1.0, i)]
    if exact:
        return worst(exact)
    for (i1, t1), (i2, t2) in zip(env, env[1:]):
        if i1 < i < i2:
            f = (math.log(i) - math.log(i1)) / (math.log(i2) - math.log(i1))
            return math.exp(math.log(t1) + f * (math.log(t2) - math.log(t1)))
    return None


def _crossing(u_env, d_env, a, b, test):
    """Primeira corrente em (a, b] em que ``test`` falha (bisseção em escala logarítmica; funções lineares em log-log)."""
    lo, hi = a, b
    for _ in range(60):
        mid = math.sqrt(lo * hi)
        if test(mid):
            lo = mid
        else:
            hi = mid
    return hi


def _curve_compare(u_env, d_env, ik_a):
    """Comparação exata dos envelopes: tempo mínimo do montante × tempo máximo do jusante, vértice a vértice.

    Devolve (situação, limite em A ou None, notas). Situações: seletiva, parcial, nao_seletiva, limitada (verificada só até
    o limite dos dados ou até a região instantânea), indeterminada (dados insuficientes)."""
    notes = []
    if not u_env:
        return 'indeterminada', None, ['O montante não tem tempo mínimo de atuação documentado: a ausência de dado não demonstra que ele permanece fechado.']
    if not d_env:
        return 'indeterminada', None, ['O jusante não tem tempo máximo de atuação documentado.']
    lo = d_env[0][0]
    if u_env[0][0] > lo * (1 + 1e-9):
        return 'indeterminada', None, [f'Faltam tempos mínimos do montante entre {lo:g} e {u_env[0][0]:g} A. '
                                       'O primeiro ponto não documenta não atuação abaixo dele; importe dados que cubram a faixa do jusante.']
    if ik_a is None:
        return 'indeterminada', None, ['Ik máximo no ponto não calculado.']
    if lo >= ik_a:
        return 'indeterminada', None, ['A curva do jusante começa acima do Ik máximo no ponto.']
    data_hi = min(u_env[-1][0], d_env[-1][0])
    hi = min(data_hi, ik_a)
    if hi <= lo:
        return 'indeterminada', None, ['As curvas não têm intervalo comum suficiente até o Ik máximo no ponto.']
    pts = sorted({lo, hi} | {x for x, _ in u_env + d_env if lo < x < hi})

    def ok(i):
        tu = _at(u_env, i, min)
        td = _at(d_env, i, max)
        return tu is not None and td is not None and tu > td

    def inst(i):
        tu = _at(u_env, i, min)
        return tu is not None and tu >= CURVE_MIN_T
    prev = None
    for i in pts:
        if not ok(i):
            if prev is None:
                return 'nao_seletiva', i, ['Os envelopes se sobrepõem já no início da curva do jusante.']
            x = _crossing(u_env, d_env, prev, i, ok)
            return 'parcial', x, [f'Os envelopes se sobrepõem a partir de ≈ {x:.0f} A (tempo mínimo do montante ≤ tempo máximo do jusante).']
        if not inst(i):
            x = lo if prev is None else _crossing(u_env, d_env, prev, i, inst)
            return 'limitada', x, [f'A partir de ≈ {x:.0f} A o montante está na região instantânea (< {CURVE_MIN_T * 1000:g} ms): a comparação de '
                                   'curvas não demonstra seletividade nessa faixa; use a tabela de seletividade do fabricante.']
        prev = i
    if hi < ik_a:
        return 'limitada', hi, [f'As curvas importadas só cobrem até {data_hi:g} A; acima disso (até Ik = {ik_a:g} A) a seletividade não foi verificada.']
    notes.append(f'Envelopes separados em todos os vértices e segmentos documentados de {lo:g} A até o Ik máximo no ponto.')
    return 'seletiva', None, notes


def _curve_check(p, up, down, ik_a):
    voltage = _voltage(p)
    cu, iu = _curve_for(p, up, voltage)
    cd, idn = _curve_for(p, down, voltage)
    if not (cu and cd):
        return None, iu + idn
    su, sd = _scale(cu, up), _scale(cd, down)
    if not su or not sd:
        return None, ['Curva em múltiplos de Ir/In sem o Ir/In do dispositivo.']
    st, lim, notes = _curve_compare(_envelope(cu['pontos'], 't_min', su), _envelope(cd['pontos'], 't_max', sd), ik_a)
    return (st, lim, notes, cu, cd), []


def _cite(item):
    return ' · '.join(str(x) for x in (item.get('fabricante'), item.get('documento'), item.get('edicao') and f"edição {item['edicao']}",
                                        item.get('pagina') and f"p. {item['pagina']}") if x)


# ------------------------------------------------------------------ resultado
def _dev_view(d):
    if d is None:
        return None
    return {k: d.get(k) for k in ('id','quadro','circuito', 'posicao', 'descricao', 'modelo', 'tipo', 'caracteristica', 'in', 'ir', 'ii', 'isd', 'tsd',
                                  'ii_inst', 'ii_informado', 'i2t', 'icu_ka', 'conflitos')}


def _evaluate(p, up, down, ik_ka, informed=None):
    ik_a = ik_ka * 1000 if ik_ka is not None else None
    notes_pre = [f"{d['descricao']}: {c}" for d in (up, down) for c in (d.get('conflitos') or [])]
    hit = _table_lookup(p, up, down)
    rejected = []
    if hit and not hit[2]:
        item, row, _ = hit
        lim = row.get('limite_ka')
        if lim == 'T':
            cap = _num((row.get('condicoes') or {}).get('icu_jusante_ka')) or down.get('icu_ka')
            if cap is None:
                return {'nivel': 'verificado', 'situacao': 'indeterminada', 'limite_ka': None, 'fonte': _cite(item), 'dados_id': item['id'],
                        'metodo': 'tabela', 'detalhes': notes_pre + [f"Tabela do fabricante: {up['modelo']} × {down['modelo']} = T (seletividade total "
                                                                     'até a capacidade de interrupção do jusante), mas o Icu do jusante não é conhecido.']}
            lim_ka = cap
            txt = f'T — seletividade total até a capacidade de interrupção do jusante ({cap:g} kA)'
        else:
            lim_ka = lim
            txt = f'{lim:g} kA'
        st = 'indeterminada' if ik_ka is None else ('seletiva' if ik_ka <= lim_ka else 'parcial')
        return {'nivel': 'verificado', 'situacao': st, 'limite_ka': lim_ka, 'fonte': _cite(item), 'dados_id': item['id'], 'metodo': 'tabela',
                'detalhes': notes_pre + [f"Tabela de seletividade ensaiada pelo fabricante: {up['modelo']} × {down['modelo']} — limite {txt}"
                                         + (f'; Ik máx no ponto {ik_ka:g} kA.' if ik_ka is not None else '.'),
                                         'Condições do documento (tensão e ajustes) conferidas com o projeto.']}
    if hit:
        rejected += [f"Tabela {_cite(hit[0])} não aplicável: {x}" for x in hit[2]]
    cc, why = _curve_check(p, up, down, ik_a)
    rejected += [f'Curva não aplicável: {x}' for x in why]
    if cc:
        st, lim_a, notes, cu, cd = cc
        if st != 'indeterminada':
            return {'nivel': 'verificado', 'situacao': st, 'limite_ka': None if lim_a is None else round(lim_a / 1000, 3),
                    'fonte': _cite(cu) + ' | ' + _cite(cd), 'dados_id': cu['id'], 'metodo': 'curvas',
                    'detalhes': notes_pre + notes + ['Comparação de curvas tempo × corrente (não considera limitação de energia; '
                                                     'na região instantânea vale a tabela de seletividade do fabricante).']}
        rejected += ['Curvas importadas insuficientes: ' + ' '.join(notes)]
    ap = _approx(up, down, ik_a)
    if ap:
        st, lim_a, notes = ap
        if informed is not None:
            notes.append(f'Limite informado pelo projetista sem documento importado: {informed:g} kA (não verificado pelo aplicativo).')
        return {'nivel': 'aproximado', 'situacao': st, 'limite_ka': None if lim_a is None else round(lim_a / 1000, 3), 'metodo': 'faixas',
                'detalhes': notes_pre + rejected + notes}
    return {'nivel': 'pre_verificacao', 'situacao': 'indeterminada', 'limite_ka': None, 'metodo': 'razao',
            'detalhes': notes_pre + rejected + ['Dados insuficientes para a aproximação; vale a pré-verificação por razão de correntes.']}


def coordination(p):
    rows = p.active_rows()
    by_name = {_val(p, 'ident.nome', r): r for r in rows}
    pairs = []
    for r in rows:
        name = _val(p, 'ident.nome', r)
        parent = _val(p, 'ident.montante', r)
        pre = _val(p, 'seletividade.status_final_da_pre_seletividade', r)
        informed = _num(_val(p, 'seletividade.limite_de_seletividade_do_fabricante_ka', r))
        base = {'circuito': name, 'montante': parent, 'pre_verificacao': pre if isinstance(pre, str) else None}
        chain = _chain(p, r)
        up = None if parent in ROOTS or parent not in by_name else _feeding_device(p, by_name[parent], by_name)
        source_added=False
        if up is None and chain:
            from . import protection
            source=protection.source_pair(p,r,chain[0])
            if source:
                pairs.append(source);source_added=True
        series = ([up] if up else []) + chain
        series = [d for i,d in enumerate(series) if i==0 or d.get('id')!=series[i-1].get('id')]
        if len(series) < 2:
            if source_added:continue
            pairs.append({**base, 'par': 'alimentacao', 'nivel': 'sem_dados', 'situacao': 'indeterminada',
                          'dispositivo_jusante': _dev_view(chain[0] if chain else None), 'dispositivo_montante': _dev_view(up),
                          'ik_ka': None, 'limite_ka': None, 'aplicavel': False,
                          'detalhes': ['Um único dispositivo físico: vínculo com a chegada do quadro precedente; não há par para comparar.' if up and chain and up.get('id')==chain[0].get('id') else 'Sem dispositivo próprio neste trecho.' if not chain else 'Sem dispositivo de baixa tensão a montante.']})
            continue
        for a_dev, b_dev in zip(series, series[1:]):
            internal = a_dev is not up
            ik_ka = b_dev.get('ik_ka')
            res = _evaluate(p, a_dev, b_dev, ik_ka, None if internal else informed)
            pairs.append({**base, 'par': 'origem_manutencao' if internal else 'alimentacao',
                          'trecho': 'Origem × manutenção do próprio circuito' if internal else 'Montante × primeiro dispositivo do circuito',
                          'dispositivo_jusante': _dev_view(b_dev), 'dispositivo_montante': _dev_view(a_dev), 'ik_ka': ik_ka,
                          'aplicavel': True, **res})
    counts = {k: sum(1 for x in pairs if x.get('aplicavel') and x['nivel'] == k) for k in LEVELS}
    return {'pares': pairs, 'niveis': LEVELS, 'situacoes': STATUS, 'contagem': counts, 'dados_fabricante': listing(p)['itens'],
            'nota': 'Somente o nível “verificado” usa dados do fabricante, importados pelo revisor com o documento citado e conferidos '
                    'quanto à tensão e aos ajustes para os quais valem. O nível “aproximado” usa faixas genéricas e não substitui a curva '
                    'ou a tabela de seletividade do fabricante.'}


# ------------------------------------------------------------------ importação
def listing(p):
    items = []
    for x in _data(p):
        items.append({k: x.get(k) for k in ('id', 'tipo', 'fabricante', 'documento', 'edicao', 'pagina', 'descricao', 'modelo', 'base',
                                            'importado_por', 'ts', 'tensao_v', 'ajustes')}
                     | {'n': len(x.get('linhas') or x.get('pontos') or []), 'selo_valido': _sealed(x)})
    return {'itens': items}


def _rows(text):
    text = str(text or '')
    if len(text) > 2_000_000:
        raise ValueError('Conteúdo muito grande.')
    sample = text[:4000]
    delim = max([';', '\t', ','], key=lambda d: sample.count(d))
    rows = [[c.strip() for c in r] for r in csv.reader(io.StringIO(text), delimiter=delim) if any(c.strip() for c in r)]
    if len(rows) < 2:
        raise ValueError('Informe o cabeçalho e ao menos uma linha de dados.')
    if len(rows) > MAX_ROWS:
        raise ValueError(f'No máximo {MAX_ROWS} linhas por importação.')
    head = [re.sub(r'[^a-z0-9_]', '', h.casefold().replace('²', '2').replace(' ', '_')) for h in rows[0]]
    if len(set(head)) != len(head):
        raise ValueError('Cabeçalho com colunas repetidas após normalização.')
    return head, rows[1:]


def _number(x, what, line):
    try:
        v = numeros.parse_br(x)
    except ValueError:
        raise ValueError(f'Linha {line}: {what} inválido ({x!r}).')
    if v < 0:
        raise ValueError(f'Linha {line}: {what} não pode ser negativo.')
    return v


COND_COLUMNS = {'ir_montante_a': ('montante', 'ir_a'), 'isd_montante_a': ('montante', 'isd_a'), 'tsd_montante_ms': ('montante', 'tsd_ms'),
                'ii_montante_a': ('montante', 'ii_a'), 'i2t_montante': ('montante', 'i2t'),
                'ir_jusante_a': ('jusante', 'ir_a'), 'isd_jusante_a': ('jusante', 'isd_a'), 'tsd_jusante_ms': ('jusante', 'tsd_ms'),
                'ii_jusante_a': ('jusante', 'ii_a'), 'i2t_jusante': ('jusante', 'i2t')}


def _tensao(text, where):
    if text in (None, ''):
        return None
    try:
        rng = _range(text)
    except ValueError:
        raise ValueError(f'{where}: tensão inválida ({text!r}). Use, por exemplo, 380 ou 380-415.')
    return [rng[0], rng[1]] if rng else None


def _i2t(text, where):
    t = str(text or '').strip().upper()
    if not t:
        return None
    if t not in ('ON', 'OFF'):
        raise ValueError(f'{where}: I²t deve ser ON ou OFF.')
    return t


def import_data(p, body, autor):
    """Importa tabela de seletividade ou curva tempo × corrente do fabricante (somente revisor).

    Cada registro guarda as condições de validade declaradas no documento (tensão, ajustes, I²t); o nível
    verificado só é atribuído quando elas existem e conferem com o projeto. O registro recebe um selo."""
    from .integridade import stamp
    tipo = body.get('tipo')
    if tipo not in ('tabela_seletividade', 'curva'):
        raise ValueError('Escolha o tipo: tabela de seletividade ou curva tempo × corrente.')
    fab = str(body.get('fabricante') or '').strip()[:120]
    doc = str(body.get('documento') or '').strip()[:240]
    if not fab or len(doc) < 4:
        raise ValueError('Informe o fabricante e o documento de origem (catálogo, guia de seletividade…) — dados sem fonte não são aceitos.')
    item = {'id': uuid.uuid4().hex[:12], 'tipo': tipo, 'fabricante': fab, 'documento': doc,
            'edicao': str(body.get('edicao') or '').strip()[:60] or None, 'pagina': str(body.get('pagina') or '').strip()[:40] or None,
            'descricao': str(body.get('descricao') or '').strip()[:200] or None, 'importado_por': autor, 'ts': _now(),
            'tensao_v': _tensao(body.get('tensao_v'), 'Documento')}
    head, rows = _rows(body.get('conteudo'))
    allowed = (set(COND_COLUMNS) | {'montante', 'jusante', 'limite_ka', 'tensao_v', 'icu_jusante_ka'}
               if tipo == 'tabela_seletividade' else {'corrente_a', 'multiplo_ir', 'multiplo_in', 't_min_s', 't_max_s'})
    unknown = set(head) - allowed
    if unknown:
        raise ValueError('Cabeçalho não reconhecido: ' + ', '.join(sorted(unknown)) + '. Confira os nomes das colunas; nenhum dado foi importado.')
    if tipo == 'tabela_seletividade':
        need = ('montante', 'jusante', 'limite_ka')
        if any(h not in head for h in need):
            raise ValueError('Cabeçalho esperado: montante;jusante;limite_ka (limite em kA ou T), mais as colunas opcionais de condição: '
                             'tensao_v, icu_jusante_ka, ir_/isd_/ii_ (A), tsd_ (ms) e i2t_ seguidas de montante ou jusante.')
        out = []
        for n, row in enumerate(rows, 2):
            get = lambda h: (row[head.index(h)] if h in head and head.index(h) < len(row) else '').strip()
            up, down, lim = get('montante'), get('jusante'), get('limite_ka')
            if not up or not down:
                raise ValueError(f'Linha {n}: informe os modelos de montante e jusante.')
            lim = 'T' if lim.upper() == 'T' else _number(lim, 'limite (kA)', n)
            cond = {'montante': {}, 'jusante': {}}
            for col, (side, key) in COND_COLUMNS.items():
                raw = get(col)
                if raw:
                    cond[side][key] = _i2t(raw, f'Linha {n}') if key == 'i2t' else _number(raw, col, n)
            if get('tensao_v'):
                cond['tensao_v'] = _tensao(get('tensao_v'), f'Linha {n}')
            if get('icu_jusante_ka'):
                cond['icu_jusante_ka'] = _number(get('icu_jusante_ka'), 'icu_jusante_ka', n)
            if not cond.get('tensao_v') and not item['tensao_v']:
                raise ValueError(f'Linha {n}: informe a tensão para a qual a tabela vale (coluna tensao_v ou campo Tensão do documento).')
            out.append({'montante': up[:120], 'jusante': down[:120], 'limite_ka': lim, 'condicoes': cond})
        item['linhas'] = out
        item['descricao'] = item['descricao'] or f'Tabela de seletividade ({len(out)} par(es))'
    else:
        modelo = str(body.get('modelo') or '').strip()[:120]
        if not modelo:
            raise ValueError('Informe o modelo/referência do dispositivo da curva (igual ao usado no projeto).')
        bases = [h for h in ('corrente_a', 'multiplo_ir', 'multiplo_in') if h in head]
        if len(bases) != 1 or 't_min_s' not in head or 't_max_s' not in head:
            raise ValueError('Cabeçalho esperado: corrente_a (ou multiplo_ir / multiplo_in);t_min_s;t_max_s.')
        b = bases[0]
        ajustes = {}
        src = body.get('ajustes') if isinstance(body.get('ajustes'), dict) else body
        for key in ('ir_a', 'isd_a', 'tsd_ms', 'ii_a'):
            raw = src.get(key)
            if raw not in (None, ''):
                ajustes[key] = _number(str(raw), key, 1)
        if src.get('i2t') not in (None, ''):
            ajustes['i2t'] = _i2t(src.get('i2t'), 'Ajustes')
        pts = []
        for n, row in enumerate(rows, 2):
            get = lambda h: (row[head.index(h)] if head.index(h) < len(row) else '').strip()
            i = _number(get(b), 'corrente', n)
            tmin, tmax = get('t_min_s'), get('t_max_s')
            pt = {'i': i, 't_min': _number(tmin, 't_min_s', n) if tmin else None, 't_max': _number(tmax, 't_max_s', n) if tmax else None}
            if pt['t_min'] is None and pt['t_max'] is None:
                raise ValueError(f'Linha {n}: informe ao menos um dos tempos.')
            if any(t is not None and t <= 0 for t in (pt['t_min'], pt['t_max'])):
                raise ValueError(f'Linha {n}: tempos devem ser positivos.')
            if pt['t_min'] is not None and pt['t_max'] is not None and pt['t_min'] > pt['t_max']:
                raise ValueError(f'Linha {n}: t_min_s maior que t_max_s.')
            if i <= 0:
                raise ValueError(f'Linha {n}: corrente deve ser positiva.')
            pts.append(pt)
        pts.sort(key=lambda x: x['i'])
        item.update(modelo=modelo, base=b, pontos=pts, ajustes=ajustes)
        item['descricao'] = item['descricao'] or f'Curva tempo × corrente de {modelo} ({len(pts)} pontos)'
    stamp('dados_fabricante', item['id'], item)
    p.meta.setdefault('curvas', [])
    if not isinstance(p.meta['curvas'], list):
        p.meta['curvas'] = []
    p.meta['curvas'].append(item)
    return {'id': item['id'], 'descricao': item['descricao']}


def delete(p, item_id):
    items = _data(p)
    keep = [x for x in items if x.get('id') != item_id]
    if len(keep) == len(items):
        raise ValueError('Registro não encontrado.')
    p.meta['curvas'] = keep


def coordination_html(p):
    h = html.escape
    c = coordination(p)
    rows = []
    for x in c['pares']:
        if not x.get('aplicavel'):
            continue
        lim = x.get('limite_ka')
        rows.append('<tr><td>' + h(str(x['circuito'])) + (' <small>(origem × manutenção)</small>' if x.get('par') == 'origem_manutencao' else '')
                    + '</td><td>' + h(str((x['dispositivo_montante'] or {}).get('descricao') or '—')) +
                    '</td><td>' + h(LEVELS[x['nivel']]) + '</td><td>' + h(STATUS[x['situacao']]) +
                    (f' até ≈ {lim:g} kA' if lim is not None and x['situacao'] in ('parcial', 'limitada') else '') + '</td><td>' +
                    ('—' if x.get('ik_ka') is None else f"{x['ik_ka']:g}") + '</td><td>' + h(x.get('fonte') or '—') + '</td></tr>')
    if not rows:
        return '<p>Nenhum par de dispositivos montante × jusante para avaliar.</p>'
    return ('<p>' + h(c['nota']) + '</p><table><thead><tr><th>Circuito</th><th>Dispositivo a montante</th><th>Nível</th><th>Resultado</th>'
            '<th>Ik máx no ponto (kA)</th><th>Fonte</th></tr></thead><tbody>' + ''.join(rows) + '</tbody></table>')

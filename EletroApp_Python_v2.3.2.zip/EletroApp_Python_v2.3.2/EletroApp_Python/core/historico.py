"""Histórico recuperável do projeto inteiro (v1.12; formato nativo na v2.0).

Cada gravação gera uma revisão numerada com as diferenças em relação à anterior
e uma cópia completa periódica. Uma revisão contém tudo o que define o cálculo:
fonte, circuitos (entradas e vínculos), versões de expressões, edições de
tabelas técnicas, condições de instalação e modos de seleção.

Revisões gravadas pela v1.12 (projetos no formato de planilha) continuam
reconstruíveis: as diferenças antigas são aplicadas pelo código de
compatibilidade (``_apply_legacy``) e o resultado é convertido ao abrir.
"""
from __future__ import annotations

import copy
import gzip
import json

FULL_EVERY = 25  # uma cópia completa a cada N revisões
_MISSING = {'__eletro_removido__': True}


def pack(obj):
    return gzip.compress(json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode(), compresslevel=5)


def unpack(raw):
    return json.loads(gzip.decompress(raw))


def is_native(data):
    return isinstance(data, dict) and data.get('formato') == 'eletroapp-projeto'


def delta(old, new):
    """Diferença ``old`` → ``new`` entre dois documentos nativos."""
    if not (is_native(old) and is_native(new)):
        raise ValueError('Diferença só entre projetos no formato nativo.')
    d = {'v': 2, 'top': {}, 'circ_set': {}, 'circ_del': [], 'n_valores': 0}
    oc = {c['id']: c for c in old.get('circuitos', [])}
    nc = {c['id']: c for c in new.get('circuitos', [])}
    for uid, c in nc.items():
        o = oc.get(uid)
        if o != c:
            d['circ_set'][uid] = c
            oe, ne = (o or {}).get('entradas', {}), c.get('entradas', {})
            d['n_valores'] += sum(1 for k in set(oe) | set(ne) if oe.get(k) != ne.get(k))
    d['circ_del'] = [uid for uid in oc if uid not in nc]
    d['n_valores'] += sum(len(oc[u].get('entradas', {})) for u in d['circ_del'])
    if list(oc) != list(nc):
        d['order'] = list(nc)
    for k in set(old) | set(new):
        if k == 'circuitos':
            continue
        if k not in new:
            d['top'][k] = _MISSING
        elif old.get(k) != new.get(k):
            d['top'][k] = new[k]
            if k == 'fonte':
                of, nf = old.get(k) or {}, new[k]
                d['n_valores'] += sum(1 for x in set(of) | set(nf) if of.get(x) != nf.get(x))
    return d


def is_empty(d):
    if d.get('v') == 2:
        return not (d['top'] or d['circ_set'] or d['circ_del'] or d.get('order'))
    return not (d['sheets'] or d['del_sheets'] or d['top'] or d.get('order'))


def apply(data, d):
    """Aplica uma diferença sobre ``data`` (modificado no lugar) e devolve ``data``."""
    if d.get('v') != 2:
        return _apply_legacy(data, d)
    circ = {c['id']: c for c in data.get('circuitos', [])}
    for uid in d.get('circ_del', []):
        circ.pop(uid, None)
    for uid, c in d.get('circ_set', {}).items():
        circ[uid] = copy.deepcopy(c)
    order = d.get('order') or [c['id'] for c in data.get('circuitos', [])]
    seq = [circ[u] for u in order if u in circ]
    seq += [c for u, c in circ.items() if u not in order]
    data['circuitos'] = seq
    for k, v in d.get('top', {}).items():
        if v == _MISSING:
            data.pop(k, None)
        else:
            data[k] = copy.deepcopy(v)
    return data


def _apply_legacy(data, d):
    """Diferenças gravadas pela v1.12 (projeto em planilha)."""
    sheets = data.setdefault('sheets', {})
    for name in d.get('del_sheets', []):
        sheets.pop(name, None)
    for name, sd in d.get('sheets', {}).items():
        if 'full' in sd:
            sheets[name] = copy.deepcopy(sd['full'])
            continue
        body = sheets.setdefault(name, {'cells': {}})
        cells = body.setdefault('cells', {})
        for a in sd.get('del', []):
            cells.pop(a, None)
        for a, c in sd.get('set', {}).items():
            cells[a] = copy.deepcopy(c)
        for k in sd.get('rm_attrs', []):
            body.pop(k, None)
        for k, v in sd.get('attrs', {}).items():
            body[k] = copy.deepcopy(v)
    if d.get('order'):
        data['sheets'] = {n: sheets[n] for n in d['order'] if n in sheets} | {n: b for n, b in sheets.items() if n not in d['order']}
    for k, v in d.get('top', {}).items():
        if v == _MISSING:
            data.pop(k, None)
        else:
            data[k] = copy.deepcopy(v)
    return data


def counts(d):
    """Resumo numérico de uma diferença (para a lista de revisões)."""
    if d.get('v') == 2:
        return {'celulas': d.get('n_valores', 0), 'registros': len(d['circ_set']) + len(d['circ_del']),
                'circuitos_alterados': len(d['circ_set']), 'circuitos_removidos': len(d['circ_del']), 'meta': sorted(d.get('top', {}))}
    cells = sum(len(sd.get('set', {})) + len(sd.get('del', [])) for sd in d.get('sheets', {}).values() if 'full' not in sd)
    return {'celulas': d.get('n_valores', cells), 'registros': cells, 'meta': sorted(d.get('top', {}))}


# ---------------------------------------------------------------- comparação
def native(data):
    """Documento nativo (convertendo revisões antigas em planilha)."""
    if is_native(data):
        return data
    from .migracao import from_workbook
    return from_workbook(copy.deepcopy(data))


def compare_data(a, b, limit=400):
    """Entradas, expressões e tabelas diferentes entre os documentos ``a`` (antes) e ``b`` (depois)."""
    from .motor import model
    m = model()
    a, b = native(a), native(b)

    def label(vid):
        v = m.by_id.get(vid)
        return (v.label + (f' ({v.unit})' if v and v.unit else '')) if v else vid
    inputs, formulas = [], []
    n_inputs = n_formulas = 0
    ca = {c['id']: c for c in a.get('circuitos', [])}
    cb = {c['id']: c for c in b.get('circuitos', [])}
    for uid in dict.fromkeys(list(ca) + list(cb)):
        x, y = (ca.get(uid) or {}).get('entradas', {}), (cb.get(uid) or {}).get('entradas', {})
        name = y.get('ident.nome') or x.get('ident.nome')
        for k in dict.fromkeys(list(x) + list(y)):
            if x.get(k) == y.get(k):
                continue
            n_inputs += 1
            if len(inputs) < limit:
                inputs.append({'variavel': k, 'campo': label(k), 'circuito': name, 'antes': x.get(k), 'depois': y.get(k)})
    fa, fb = a.get('fonte', {}), b.get('fonte', {})
    for k in dict.fromkeys(list(fa) + list(fb)):
        if fa.get(k) != fb.get(k):
            n_inputs += 1
            if len(inputs) < limit:
                inputs.append({'variavel': k, 'campo': label(k), 'circuito': 'Fonte', 'antes': fa.get(k), 'depois': fb.get(k)})

    from . import versoes

    def slots(doc, k):
        return {(kind, cid): {x: y for x, y in slot.items() if x not in ('raiz', 'circuitos')}
                for kind, cid, slot in versoes.scopes(doc.get('formulas', {}).get(k))}

    def effective(doc, k, kind, cid):
        top = doc.get('formulas', {}).get(k) or {}
        own = slots(doc, k).get((kind, cid))
        expr = versoes.active(own)
        if expr:
            return expr
        v = m.by_id.get(k)
        if v is None:
            return None
        if kind == 'circuito':
            c = next((c for c in doc.get('circuitos', []) if c['id'] == cid), {})
            kind = 'raiz' if c.get('entradas', {}).get('ident.montante') in ('Fonte', 'Transformador') and v.variants.get('raiz') else 'comum'
        if kind == 'raiz' and v.variants.get('raiz'):
            return versoes.active(top.get('raiz')) or v.variants['raiz']
        return versoes.active(top) or v.expr

    xa, xb = a.get('formulas', {}), b.get('formulas', {})
    for k in dict.fromkeys(list(xa) + list(xb)):
        sa, sb = slots(a, k), slots(b, k)
        for kind, cid in dict.fromkeys(list(sa) + list(sb)):
            before, after = sa.get((kind, cid)), sb.get((kind, cid))
            ea, eb = effective(a, k, kind, cid), effective(b, k, kind, cid)
            if ea == eb and before == after:
                continue
            n_formulas += 1
            if len(formulas) < limit:
                c = cb.get(cid) or ca.get(cid) or {}
                name = c.get('entradas', {}).get('ident.nome')
                alcance = 'Circuitos ligados à fonte' if kind == 'raiz' else ('Circuito ' + str(name or cid) if cid else 'Comum')
                formulas.append({'variavel': k, 'campo': label(k), 'circuito': name, 'circuito_id': cid,
                                 'escopo': versoes.scope_name(kind, cid), 'escopo_rotulo': alcance,
                                 'antes': ea, 'depois': eb, 'versao_antes': (before or {}).get('ativa', 0),
                                 'versao_depois': (after or {}).get('ativa', 0),
                                 'historico_alterado': before != after})
    tables = []
    ta, tb = a.get('tabelas', {}), b.get('tabelas', {})
    for k in dict.fromkeys(list(ta) + list(tb)):
        x, y = (ta.get(k) or {}).get('celulas', {}), (tb.get(k) or {}).get('celulas', {})
        cells = [c for c in dict.fromkeys(list(x) + list(y)) if x.get(c) != y.get(c)]
        if cells:
            t = m.tables.get(k)
            tables.append({'tabela': k, 'nome': t.name if t else k, 'celulas': len(cells), 'exemplos': cells[:12]})
    ma, mb = a.get('meta', {}), b.get('meta', {})
    meta = []
    labels = {'title': 'Nome do projeto', 'installation_settings': 'Condições de instalação',
              'selection_modes': 'Modos de escolha (Automático/Manual)', 'ocupacao': 'Ocupação da edificação',
              'formula_normrefs': 'Referências normativas das expressões', 'normref_overrides': 'Referências normativas cadastradas',
              'curvas': 'Curvas e tabelas de seletividade do fabricante'}
    labels.update(migracoes_escopos='Migração de escopos das fórmulas', historico_legado='Histórico original da v1.x preservado')
    for k, lab in labels.items():
        if ma.get(k) != mb.get(k):
            meta.append({'chave': k, 'rotulo': lab})
    if [c['id'] for c in a.get('circuitos', [])] != [c['id'] for c in b.get('circuitos', [])]:
        meta.append({'chave': 'ordem', 'rotulo': 'Circuitos incluídos, excluídos ou reordenados'})
    return {'entradas': inputs, 'n_entradas': n_inputs, 'formulas': formulas, 'n_formulas': n_formulas, 'tabelas': tables,
            'meta': meta, 'truncado': n_inputs > limit or n_formulas > limit, 'posicoes_vazias': 0}


RESULT_KEYS = [('p_w', 'P (W)'), ('ib', 'Ib (A)'), ('sec_f', 'Fase (mm²)'), ('sec_n', 'Neutro (mm²)'), ('sec_pe', 'PE (mm²)'),
               ('dv_total', 'ΔV acum. (%)'), ('icc_max', 'Ik máx. (kA)'), ('protecao', 'Disjuntor'), ('ir_prot', 'Ir (A)'),
               ('ii_prot', 'Ii/Im (A)'), ('prot_status', 'Status da proteção'), ('dps_modelo', 'DPS'), ('status', 'Situação')]


def _plain(v):
    return v.get('error') if isinstance(v, dict) else v


def _same(x, y):
    x, y = _plain(x), _plain(y)
    if isinstance(x, (int, float)) and isinstance(y, (int, float)) and not isinstance(x, bool) and not isinstance(y, bool):
        return abs(x - y) <= max(1e-9, abs(x) * 1e-9)
    return x == y


def compare_results(pa, pb):
    """Resultados por circuito (pelo identificador) entre dois projetos calculados."""
    ca = {c['id']: c for c in pa.circuits()}
    cb = {c['id']: c for c in pb.circuits()}
    out = []
    for uid in dict.fromkeys(list(ca) + list(cb)):
        x, y = ca.get(uid), cb.get(uid)
        if x is None or y is None:
            out.append({'circuito': (y or x)['name'], 'situacao': 'incluído' if x is None else 'excluído', 'campos': []})
            continue
        fields = [{'campo': label, 'antes': _plain(x.get(k)), 'depois': _plain(y.get(k))} for k, label in RESULT_KEYS if not _same(x.get(k), y.get(k))]
        for sheet, col, label in [('Identificação-Método_Instal ', 'F', 'Método de referência'),
                                  ('Corrente_Max-Cond_Escolhido', 'K', 'Iz fase (A)'),
                                  ('Corrente_Max-Cond_Escolhido', 'O', 'Iz neutro (A)'),
                                  ('Corrente-Calc_Ampacidade ', 'O', 'Fator de agrupamento')]:
            va, vb = pa.get(sheet, col + str(pa.row_for(uid))), pb.get(sheet, col + str(pb.row_for(uid)))
            if not _same(va, vb):
                fields.append({'campo': label, 'antes': _plain(va), 'depois': _plain(vb)})
        if fields or x['name'] != y['name']:
            out.append({'circuito': y['name'], 'nome_anterior': x['name'] if x['name'] != y['name'] else None, 'situacao': 'alterado', 'campos': fields})
    return out

"""Núcleo de cálculo e persistência do EletroApp."""

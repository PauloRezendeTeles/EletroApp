"""Vista normativa da Base técnica (v2.2.0).

Mostra a base técnica do jeito que a norma a apresenta e ligada ao projeto:

* ``mapa``: todas as tabelas que o cálculo usa — as de ``data/tabelas`` e as regras em ``installation_rules.json`` —
  agrupadas por norma, com o localizador (tabela ou item), a situação da conferência, as células corrigidas nesta
  revisão da base e as edições do projeto;
* ``ampacidade``: Tabelas 36 a 39 com os cabeçalhos da norma, marcas por célula (corrigida nesta revisão, editada no
  projeto, usada por um circuito) e o uso de cada circuito;
* ``uso``: as células de qualquer tabela lidas pelo cálculo de um circuito, seguindo só os ramos de SE/SEERRO de fato
  tomados (INDEX/CORRESP, PROCV e nomes de célula), mais as leituras feitas pelas regras em Python;
* ``fichas``: um cartão por modelo de fabricante, com o texto do catálogo ao lado do valor que o cálculo lê;
* ``conferencia`` e ``verificar``: conferência guiada do registro normativo. A marcação fica no projeto
  (``meta['normref_overrides']``), com o nome do revisor e a data; não altera nenhum cálculo.

O módulo só lê o projeto, exceto ``verificar``.
"""
from __future__ import annotations

import datetime as dt
import re
from functools import lru_cache

from .formula import Error, Grid, address, col_name, scalar, truth
from .motor import compiled, model

IDENT = 'Identificação dos circuitos'
IZ = 'Corrente_Max-Cond_Escolhido'
PROT = 'Cálc-Prot_Cabos'
DPS = 'DPS'
AMP_TABLES = ('tab_ampacidade_2c', 'tab_ampacidade_3c')

# ---------------------------------------------------------------- famílias de norma (mapa)
FAMILIES = [
    ('nbr5410', 'ABNT NBR 5410:2004 (versão corrigida 2008) — Instalações elétricas de baixa tensão'),
    ('nbr5419', 'ABNT NBR 5419:2026 — Proteção contra descargas atmosféricas'),
    ('produto', 'Normas de produto — disjuntores e fusíveis (IEC 60898-1, IEC 60947-2, IEC 60269)'),
    ('iec60909', 'IEC 60909-0 — Correntes de curto-circuito'),
    ('nm280', 'ABNT NBR NM 280 — Condutores de cabos isolados'),
    ('referencia', 'Referências técnicas'),
    ('fabricante', 'Dados de fabricante'),
    ('sistema', 'Listas do aplicativo'),
]
FAMILY_LABEL = dict(FAMILIES)
FAMILY_ORDER = {k: i for i, (k, _) in enumerate(FAMILIES)}


def _family_of_norm(norma):
    n = str(norma or '')
    if '5410' in n:
        return 'nbr5410'
    if '5419' in n:
        return 'nbr5419'
    if any(x in n for x in ('60898', '60947', '60269')):
        return 'produto'
    if '60909' in n:
        return 'iec60909'
    if 'NM 280' in n:
        return 'nm280'
    return 'referencia'


# Regras operacionais (não editáveis) que fazem papel de tabela da norma.
RULE_ITEMS = [
    {'id': 'regra.matriz', 'nome': 'Matriz de instalação: tipo de linha, montagem e cabo → método de referência',
     'refs': ['NBR5410-T33'], 'arquivo': 'data/installation_rules.json',
     'uso': 'Escolha do método e da coluna das Tabelas 36 a 39', 'extensao': None,
     'mudancas': 'Forro falso e piso elevado como método 21 (Tabela 33, nota 5), no lugar do 28; notas da Tabela 33 junto de cada '
                 'método.'},
    {'id': 'regra.agrupamento', 'nome': 'Fatores de agrupamento (FCA)',
     'refs': ['NBR5410-T42', 'NBR5410-T43', 'NBR5410-T44', 'NBR5410-T45'], 'arquivo': 'data/installation_rules.json',
     'uso': 'FCA de cada circuito pela contagem de conjuntos no trecho',
     'extensao': 'Tabelas 44 e 45 acima de 6 circuitos (guia Prysmian, limitado ao valor da NBR para 6 circuitos). Na Tabela 42, '
                 'o valor único para 9 ou mais circuitos das linhas 2 a 5 é da própria NBR (p. 108).',
     'mudancas': 'Extensão da Tabela 45 (cabos multipolares, 1,0 m) limitada a 0,80; origem de cada linha (NBR ou extensão) na '
                 'consulta.'},
    {'id': 'regra.solo', 'nome': 'Resistividade térmica do solo e profundidade (FCR)',
     'refs': ['NBR5410-T41'], 'arquivo': 'data/installation_rules.json',
     'uso': 'FCR das linhas enterradas (método D)',
     'extensao': '0,5 e 0,7 K·m/W e cabo diretamente enterrado (IEC 60364-5-52:2009, Anexo B); correção de profundidade (guia Prysmian)',
     'mudancas': 'Origem das extensões de solo e de profundidade registrada nas regras e mostrada na consulta.'},
]

# ---------------------------------------------------------------- Tabelas 36 a 39
MATERIAL = {'Cu': 'Cobre', 'Al': 'Alumínio'}
AMP = {
    '36': {'ins': 'PVC70g', 'ref': 'NBR5410-T36',
           'titulo': 'Tabela 36 — Capacidades de condução de corrente, em ampères, para os métodos de referência A1, A2, B1, B2, C e D',
           'condicoes': 'Isolação de PVC · 70 °C no condutor · temperatura de referência do ambiente: 30 °C no ar e 20 °C no solo'},
    '37': {'ins': 'EPR_XLPE90g', 'ref': 'NBR5410-T37',
           'titulo': 'Tabela 37 — Capacidades de condução de corrente, em ampères, para os métodos de referência A1, A2, B1, B2, C e D',
           'condicoes': 'Isolação de EPR ou XLPE · 90 °C no condutor · temperatura de referência do ambiente: 30 °C no ar e 20 °C no solo'},
    '38': {'ins': 'PVC70g', 'ref': 'NBR5410-T38',
           'titulo': 'Tabela 38 — Capacidades de condução de corrente, em ampères, para os métodos de referência E, F e G',
           'condicoes': 'Isolação de PVC · 70 °C no condutor · temperatura ambiente de referência: 30 °C',
           'nota': 'Cabos unipolares ou, ainda, condutores isolados, quando o método de instalação permitir (nota 1 da tabela).'},
    '39': {'ins': 'EPR_XLPE90g', 'ref': 'NBR5410-T39',
           'titulo': 'Tabela 39 — Capacidades de condução de corrente, em ampères, para os métodos de referência E, F e G',
           'condicoes': 'Isolação de EPR ou XLPE · 90 °C no condutor · temperatura ambiente de referência: 30 °C',
           'nota': 'Cabos unipolares ou, ainda, condutores isolados, quando o método de instalação permitir (nota 1 da tabela).'},
}
# (código do método no nome interno, condutores carregados, arranjo, grupo do cabeçalho, subtítulo)
COLS_AD = [(m, n, 'NsA', m, f'{n}') for m in ('A1', 'A2', 'B1', 'B2', 'C', 'D') for n in (2, 3)]
COLS_EFG = [('É', 2, 'NsA', 'E', '2 condutores'), ('É', 3, 'NsA', 'E', '3 condutores'),
            ('F', 2, 'Justapostos', 'F', '2 justapostos'), ('F', 3, 'Trifólio', 'F', '3 em trifólio'),
            ('F', 3, 'Justapostos', 'F', '3 justapostos'),
            ('G', 3, 'Horizontal', 'G', '3 espaçados, horizontal'), ('G', 3, 'Vertical', 'G', '3 espaçados, vertical')]
GROUP_LABEL = {'E': 'Método E — cabos multipolares', 'F': 'Método F — cabos unipolares', 'G': 'Método G — unipolares espaçados'}
_MATRIX = re.compile(r'Cond([23])_(Cobre|Alumínio)_(PVC70g|EPR_XLPE90g)_(A1|A2|B1|B2|C|D|É|F|G)_(NsA|Justapostos|Trifólio|Horizontal|Vertical)$')


def _num(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _plain(v):
    if isinstance(v, Error):
        return {'error': v.code}
    if isinstance(v, float) and v != v:
        return None
    return v


@lru_cache(maxsize=1)
def _previous_values():
    """Valores anteriores da base por célula (registro da conversão de projetos da v1.x)."""
    from .migracao import _legacy_table_values
    return _legacy_table_values()


def previous(p, tid):
    """{endereço: [valores anteriores]} das células desta tabela alteradas na base atual. Vazio em base arquivada."""
    if p.model is not model():
        return {}
    t = p.model.tables.get(tid)
    if t is None:
        return {}
    out = {}
    for a, values in (_previous_values().get(tid) or {}).items():
        cur = t.cells.get(a)
        cur = None if cur is None else cur.get('v', cur.get('f'))
        old = [v for v in values if v != cur]
        if old:
            out[a] = old
    return out


def correction_for(t, a):
    """Entrada de ``correcoes`` dos metadados da tabela que cobre a célula (achado, fonte, motivo)."""
    r, c = address(a)
    for item in (t.meta or {}).get('correcoes') or []:
        for rng in item.get('celulas') or []:
            if rng == '*':
                return item
            a1, _, b1 = rng.partition(':')
            r1, c1 = address(a1)
            r2, c2 = address(b1 or a1)
            if r1 <= r <= r2 and c1 <= c <= c2:
                return item
    return None


def _refs(p):
    from .catalog import Catalog
    return {r['id']: r for r in Catalog(p, integrity=False).all_refs()}


def _locator(ref):
    if not ref.get('tabela') and not ref.get('item'):
        # Referência à norma inteira: mostra a norma de forma curta (ex.: “IEC 60898-1”, “NBR 5419-4:2026”).
        return re.sub(r'^ABNT\s+', '', str(ref.get('norma') or ref.get('id')).split(' / ')[0])
    loc = ref.get('tabela') or ref.get('item') or ref.get('id')
    if ref.get('tabela') and ref.get('item') and not str(ref['item']).startswith(('Anexo', str(ref['tabela']))):
        loc = f"{ref['tabela']} ({ref['item']})"
    elif ref.get('tabela') and str(ref.get('item') or '').startswith('Anexo'):
        loc = f"{ref['item']}, {ref['tabela']}"
    return loc


def _ref_brief(ref):
    """Resumo da referência: a conferência da base (auditoria) e a do revisor neste projeto ficam separadas."""
    proj = bool(ref.get('conferencia_projeto'))
    base = ref.get('verificacao_base') if proj else ({'por': ref.get('verificado_por'), 'em': ref.get('verificado_em')}
                                                    if ref.get('verificado_por') else None)
    return {'id': ref['id'], 'norma': ref.get('norma'), 'localizador': _locator(ref), 'pagina': ref.get('pagina'),
            'verificado_por': ref.get('verificado_por'), 'verificado_em': ref.get('verificado_em'),
            'conferencia_base': base,
            'conferencia_projeto': {'por': ref.get('verificado_por'), 'em': ref.get('verificado_em'),
                                    'nota': ref.get('nota_conferencia')} if proj else None}


def _conference(refs):
    if not refs:
        return {'estado': 'sem_referencia', 'rotulo': 'Sem referência normativa'}
    done = [r for r in refs if r.get('verificado_por')]
    if len(done) == len(refs):
        dates = sorted({str(r.get('verificado_em') or '') for r in done})
        who = sorted({str(r.get('verificado_por')) for r in done})
        return {'estado': 'conferida', 'rotulo': 'Conferida', 'em': dates[-1] if dates else None, 'por': who}
    if done:
        return {'estado': 'parcial', 'rotulo': f'{len(done)} de {len(refs)} localizadores conferidos'}
    return {'estado': 'pendente', 'rotulo': 'A conferir'}


def _sort_key(locator):
    m = re.match(r'(Tabela|Tabelas)\s+([A-Z]?)\.?(\d+)', str(locator or ''))
    if m:
        return (0 if not m.group(2) else 1, m.group(2), int(m.group(3)), str(locator))
    m = re.match(r'(\d+(?:\.\d+)*)', str(locator or ''))
    if m:
        return (2, '', 0, '.'.join(f'{int(x):03d}' for x in m.group(1).split('.')))
    return (3, '', 0, str(locator or ''))


# ---------------------------------------------------------------- mapa
def mapa(p):
    from . import tabelas
    refs = _refs(p)
    listing = tabelas.listing(p)
    current = p.model is model()  # marcas “nesta versão” só valem para a base em uso
    rows = []
    for t in listing['tabelas']:
        trefs = [refs[r] for r in t['refs'] if r in refs]
        if t['categoria'] in ('fabricante', 'sistema'):
            fam = t['categoria']
        else:
            fam = next((_family_of_norm(r.get('norma')) for r in trefs), 'referencia')
        locs = [_locator(r) for r in trefs if _family_of_norm(r.get('norma')) == fam] or [_locator(r) for r in trefs]
        corrected = previous(p, t['id'])
        rows.append({'tipo': 'tabela', 'id': t['id'], 'nome': t['nome'], 'familia': fam, 'localizadores': locs,
                     'refs': [_ref_brief(r) for r in trefs], 'paginas': [r.get('pagina') for r in trefs if r.get('pagina')],
                     'categoria': t['categoria_rotulo'], 'fonte': t['fonte'], 'situacao_fonte': t['situacao_fonte'],
                     'situacao_fonte_rotulo': t['situacao_fonte_rotulo'], 'revisao': t['revisao_base'],
                     'revisao_data': t['revisao_data'], 'uso': t['uso'], 'conferencia': _conference(trefs),
                     'corrigidas': len(corrected), 'editadas': t['celulas_editadas'], 'integridade': t['integridade'],
                     'integridade_rotulo': t['integridade_rotulo'],
                     'nova_em': t.get('nova_em') if current else None, 'revisao_nota': t.get('revisao_nota'),
                     'vista': 'ampacidade' if t['id'] in AMP_TABLES else 'grade'})
    for item in RULE_ITEMS:
        trefs = [refs[r] for r in item['refs'] if r in refs]
        rows.append({'tipo': 'regra', 'id': item['id'], 'nome': item['nome'], 'familia': 'nbr5410',
                     'localizadores': [_locator(r) for r in trefs], 'refs': [_ref_brief(r) for r in trefs],
                     'paginas': [r.get('pagina') for r in trefs if r.get('pagina')], 'categoria': 'Regra do cálculo (não editável)',
                     'fonte': item['arquivo'], 'situacao_fonte': 'referenciada', 'situacao_fonte_rotulo': 'Fonte identificada',
                     'uso': {'operacional': True, 'n_variaveis': 0, 'regras_python': 'core/installation.py, core/grouping.py',
                             'descricao': item['uso']},
                     'extensao': item['extensao'], 'conferencia': _conference(trefs), 'corrigidas': 0, 'editadas': 0,
                     'mudancas': item.get('mudancas') if current else None, 'vista': 'regras'})
    groups = []
    for fam, label in FAMILIES:
        items = [r for r in rows if r['familia'] == fam]
        if not items:
            continue
        items.sort(key=lambda r: (_sort_key((r['localizadores'] or [''])[0]), r['nome']))
        groups.append({'familia': fam, 'rotulo': label, 'itens': items})
    total = len(rows)
    resumo = {'total': total, 'conferidas': sum(1 for r in rows if r['conferencia']['estado'] == 'conferida'),
              'a_confirmar': sum(1 for r in rows if r['situacao_fonte'] == 'a_confirmar'),
              'com_correcoes': sum(1 for r in rows if r['corrigidas']), 'editadas': sum(1 for r in rows if r['editadas']),
              'novas': sum(1 for r in rows if r.get('nova_em')), 'regras': len(RULE_ITEMS), 'base_atual': current}
    return {'grupos': groups, 'resumo': resumo}


# ---------------------------------------------------------------- uso por circuito (leituras do cálculo)
def _circuits(p):
    out = []
    for r in p.active_rows():
        out.append({'row': r, 'id': p.meta['ids'].get(str(r)), 'nome': p.get(IDENT, f'B{r}')})
    return out


def _cell_of(p, value):
    if isinstance(value, Grid) and value.source and value.rows == 1 and value.cols == 1:
        s, r, c = value.source
        t = p.model.table(s)
        if t is not None:
            return t.id, f'{col_name(c)}{r}'
    return None


def cells_read(p, var, row=None):
    """[(tabela, endereço)] lidos pelo cálculo de ``var`` (no circuito da linha ``row``), só nos ramos tomados.

    Cobre INDEX (inclusive com intervalo escolhido por SE), PROCV/PROCH e nomes que apontam uma célula. Funções em
    Python registradas no motor não são seguidas (ver ``python_reads``)."""
    if var.kind != 'formula':
        return []
    if var.scope == 'circuito':
        if row is None:
            return []
        sheet, addr = var.sheet, f'{var.col}{row}'
        expr = p.expression(var, row)
    else:
        sheet, addr = var.sheet, var.addr
        expr = p.expression(var, None)
    if not expr:
        return []
    eng = p.engine
    names = {k.casefold(): v for k, v in p.model.names.items()}
    found = []

    def ev(node):
        try:
            return eng.evaluate(node, sheet, addr)
        except Exception:  # noqa: BLE001 — explicação nunca derruba a tela
            return Error('#VALUE!', '')

    def visit(node, depth=0):
        if depth > 400 or not isinstance(node, tuple):
            return
        kind = node[0]
        if kind == 'name':
            if node[1] not in p.model.by_id:
                dest = names.get(str(node[1]).casefold())
                if dest and ':' not in dest.rsplit('!', 1)[-1]:
                    hit = _cell_of(p, ev(node))
                    if hit:
                        found.append(hit)
            return
        if kind == 'bin':
            visit(node[2], depth + 1)
            visit(node[3], depth + 1)
            return
        if kind == 'unary':
            visit(node[2], depth + 1)
            return
        if kind != 'call':
            return
        fn, args = node[1], node[2]
        if fn in ('IF', 'TRECHO_SE') and args:
            visit(args[0], depth + 1)
            try:
                flag = truth(scalar(ev(args[0])))
            except Exception:  # noqa: BLE001
                return
            if flag:
                visit(args[1], depth + 1)
            elif len(args) > 2:
                visit(args[2], depth + 1)
            return
        if fn in ('IFERROR', 'IFNA') and args:
            v = scalar(ev(args[0]))
            if isinstance(v, Error) and (fn == 'IFERROR' or v.code == '#N/A') and len(args) > 1:
                visit(args[1], depth + 1)
            else:
                visit(args[0], depth + 1)
            return
        if fn == 'INDEX' and args:
            hit = _cell_of(p, ev(node))
            if hit:
                found.append(hit)
        elif fn in ('VLOOKUP', 'HLOOKUP') and len(args) >= 3:
            grid = ev(args[1])
            key = scalar(ev(args[0]))
            idx = _num(scalar(ev(args[2])))
            approx = True
            if len(args) > 3:
                try:
                    approx = truth(scalar(ev(args[3])))
                except Exception:  # noqa: BLE001
                    approx = True
            if isinstance(grid, Grid) and grid.source and idx and not isinstance(key, Error):
                from .formula import compare
                size = grid.rows if fn == 'VLOOKUP' else grid.cols
                hit = None
                for i in range(size):
                    x = grid.at(i, 0) if fn == 'VLOOKUP' else grid.at(0, i)
                    if isinstance(x, Error):
                        continue
                    try:
                        if compare(x, key, '='):
                            hit = i
                            break
                        if approx and x is not None and compare(x, key, '<='):
                            hit = i
                    except Exception:  # noqa: BLE001
                        continue
                if hit is not None:
                    s, r1, c1 = grid.source
                    r, c = (r1 + hit, c1 + int(idx) - 1) if fn == 'VLOOKUP' else (r1 + int(idx) - 1, c1 + hit)
                    t = p.model.table(s)
                    if t is not None:
                        found.append((t.id, f'{col_name(c)}{r}'))
        for a in args:
            visit(a, depth + 1)

    visit(compiled(expr))
    return list(dict.fromkeys(found))


def python_reads(p, tid, row):
    """Leituras das regras em Python que a explicação das expressões não alcança: [(endereço, rótulo)] e linhas usadas."""
    cells, rows = [], []
    if tid == 'tab_fatores_correcao':
        try:
            s = p.installation.state(int(row))
        except Exception:  # noqa: BLE001
            return cells, rows
        v = s['values']
        underground = s.get('reference') == 'D'
        temp = _num(v.get('temperature_soil' if underground else 'temperature_air'))
        try:
            temp = float(temp) if temp is not None else None
        except (TypeError, ValueError):
            temp = None
        col = 'P' if underground else 'L'
        thermal = (s.get('grouping') or {}).get('temperature')
        value_col = ('Q' if underground else 'M') if thermal == 70 else ('R' if underground else 'N')
        t = p.model.tables.get(tid)
        for r in range(2, 17):
            cell = p.table_cell(t, f'{col}{r}') if t else None
            x = cell.get('v') if cell else None
            if temp is not None and _num(x) is not None and float(x) == temp:
                cells.append((f'{value_col}{r}', 'FCT — fator de temperatura (regra em Python)'))
                cells.append((f'{col}{r}', 'FCT — temperatura procurada'))
                break
    elif tid == 'tab_weg_protecoes':
        models = {str(p.get(PROT, f'AM{row}') or '')}
        try:
            from . import trecho
            models.add(str(p.get(trecho.SHEET, f"{trecho.COL['mb_modelo']}{row}") or ''))
        except Exception:  # noqa: BLE001
            pass
        rows += _rows_with(p, tid, 'C', models - {''})
    elif tid in ('tab_dps_siemens', 'tab_dps_clamper'):
        fab = str(p.raw(DPS, f'BH{row}') or 'SIEMENS')
        if (fab == 'CLAMPER') == (tid == 'tab_dps_clamper'):
            rows += _rows_with(p, tid, 'D', {str(p.get(DPS, f'AV{row}') or '')} - {''})
    elif tid == 'tab_fusiveis_nh':
        rows += _rows_with(p, tid, 'D', {str(p.get(DPS, f'BP{row}') or '')} - {''})
    return cells, rows


def _rows_with(p, tid, col, values):
    t = p.model.tables.get(tid)
    if t is None or not values:
        return []
    out = []
    for r in range(2, t.max_row + 1):
        cell = p.table_cell(t, f'{col}{r}')
        if cell is not None and str(cell.get('v')) in values:
            out.append(r)
    return out


def uso(p, tid, uid):
    """Células da tabela lidas pelo cálculo de um circuito (e pelos cálculos do projeto inteiro)."""
    from . import tabelas
    t = p.model.tables.get(tid)
    if t is None:
        raise ValueError('Tabela técnica inexistente.')
    row = p.row_for(uid) if uid else None
    use = tabelas._usage().get(tid) or {}
    cells = {}
    for vid in sorted(use.get('variaveis') or []):
        var = p.model.by_id.get(vid)
        if var is None:
            continue
        if var.scope == 'circuito' and row is None:
            continue
        for table_id, a in cells_read(p, var, row if var.scope == 'circuito' else None):
            if table_id == tid:
                cells.setdefault(a, []).append({'id': var.id, 'rotulo': var.label,
                                                'escopo': 'circuito' if var.scope == 'circuito' else 'projeto'})
    rows = []
    if row is not None:
        extra, rows = python_reads(p, tid, row)
        for a, label in extra:
            cells.setdefault(a, []).append({'id': None, 'rotulo': label, 'escopo': 'circuito'})
    return {'tabela': tid, 'circuito': p.get(IDENT, f'B{row}') if row else None, 'celulas': cells, 'linhas': rows,
            'nota': 'Leituras seguidas nas expressões (INDEX, PROCV e nomes de célula) só nos ramos de SE e SEERRO de fato tomados; '
                    'as regras em Python indicam a linha do modelo escolhido ou a célula do fator de temperatura.'}


# ---------------------------------------------------------------- Tabelas 36 a 39 na forma da norma
def _range_of(p, name):
    dest = {k.casefold(): v for k, v in p.model.names.items()}.get(name.casefold())
    m = re.fullmatch(r"'?(.*?)'?!\$?([A-Z]+)\$?(\d+):\$?([A-Z]+)\$?(\d+)", dest or '')
    if not m:
        return None
    sheet, col, r1, _, r2 = m.groups()
    t = p.model.table(sheet)
    return (t.id, col, int(r1), int(r2)) if t else None


def _sections(p, tid):
    t = p.model.tables[tid]
    out = {}
    for r in range(3, t.max_row + 1):
        cell = p.table_cell(t, f'A{r}')
        s = _num(cell.get('v')) if cell else None
        if s is not None:
            out[r] = s
    return out


def matrix_cell(p, matrix, section):
    """(tabela, endereço, tabela da norma, material, rótulo da coluna) da célula de Iz de uma matriz e seção."""
    m = _MATRIX.match(str(matrix or ''))
    sec = _num(section)
    if not m or sec is None:
        return None
    n, mat, ins, ref, arr = m.groups()
    rng = _range_of(p, matrix)
    if not rng:
        return None
    tid, col, r1, r2 = rng
    row = next((r for r, s in _sections(p, tid).items() if r1 <= r <= r2 and s == sec), None)
    if row is None:
        return None
    if ref in ('É', 'F', 'G'):
        tab = '38' if ins == 'PVC70g' else '39'
        spec = next((c for c in COLS_EFG if c[0] == ref and c[1] == int(n) and c[2] == arr), None)
        label = f"{spec[3]}, {spec[4]}" if spec else f'{ref}, {n} condutores'
    else:
        tab = '36' if ins == 'PVC70g' else '37'
        label = f'{ref}, {n} condutores carregados'
    return tid, f'{col}{row}', tab, 'Cu' if mat == 'Cobre' else 'Al', label


def _amp_usage(p):
    """{(tabela, endereço): [uso]} e lista por circuito (fase e neutro) a partir da matriz e das seções escolhidas."""
    marks, items = {}, []
    for c in _circuits(p):
        r = c['row']
        matrix = p.get(IZ, f'D{r}')
        pending = None
        if not isinstance(matrix, str) or not _MATRIX.match(matrix):
            try:
                st = p.installation.state(r)
                matrix = st.get('table')
                pending = '; '.join(st.get('ampacity_issues') or []) or None
            except Exception:  # noqa: BLE001
                matrix = None
        entry = {'circuito': c['nome'], 'id': c['id'], 'matriz': matrix if isinstance(matrix, str) else None, 'pendente': pending}
        for role, scol, vcol in (('fase', 'E', 'F'), ('neutro', 'L', 'M')):
            sec = _num(p.get(IZ, f'{scol}{r}'))
            hit = matrix_cell(p, matrix, sec) if isinstance(matrix, str) else None
            if hit is None:
                continue
            tid, a, tab, mat, label = hit
            val = p.get(IZ, f'{vcol}{r}')
            info = {'tabela_norma': tab, 'material': mat, 'coluna': label, 'secao': sec, 'tabela': tid, 'endereco': a,
                    'valor': _plain(val)}
            entry[role] = info
            marks.setdefault((tid, a), []).append({'circuito': c['nome'], 'id': c['id'], 'papel': role})
        items.append(entry)
    return marks, items


def ampacidade(p, tab='36', mat='Cu', uid=None):
    tab = str(tab)
    if tab not in AMP or mat not in MATERIAL:
        raise ValueError('Tabela ou material inválido.')
    info = AMP[tab]
    refs = _refs(p)
    specs = COLS_AD if tab in ('36', '37') else COLS_EFG
    cols = []
    for ref, n, arr, group, sub in specs:
        name = f'Cond{n}_{MATERIAL[mat]}_{info["ins"]}_{ref}_{arr}'
        rng = _range_of(p, name)
        if not rng:
            continue
        tid, col, r1, r2 = rng
        cols.append({'nome': name, 'grupo': group, 'grupo_rotulo': GROUP_LABEL.get(group, f'Método {group}'), 'sub': sub,
                     'rotulo': (f'{group}, {sub} condutores carregados' if tab in ('36', '37') else f'{group}, {sub}'),
                     'tabela': tid, 'coluna': col, 'r1': r1, 'r2': r2})
    prev = {tid: previous(p, tid) for tid in AMP_TABLES}
    edits = {tid: ((p.doc.get('tabelas') or {}).get(tid) or {}).get('celulas') or {} for tid in AMP_TABLES}
    marks, usage = _amp_usage(p)
    sections = sorted({s for tid in AMP_TABLES for s in _sections(p, tid).values()})
    secrow = {tid: {s: r for r, s in _sections(p, tid).items()} for tid in AMP_TABLES}
    lines = []
    for s in sections:
        cells, any_value = [], False
        for c in cols:
            r = secrow[c['tabela']].get(s)
            if r is None or not c['r1'] <= r <= c['r2']:
                cells.append(None)
                continue
            a = f"{c['coluna']}{r}"
            t = p.model.tables[c['tabela']]
            cell = p.table_cell(t, a)
            v = cell.get('v') if cell else None
            if _num(v) is None or v == 0:
                # 0 na base = sem valor na norma (alumínio só a partir de 16 mm²)
                cells.append(None)
                continue
            any_value = True
            out = {'v': v, 'a': f"{c['tabela']}!{a}"}
            old = prev[c['tabela']].get(a)
            if old:
                corr = correction_for(t, a)
                out['anterior'] = old
                if corr:
                    out['correcao'] = {k: corr.get(k) for k in ('achado', 'fonte', 'motivo')}
            if a in edits[c['tabela']]:
                base = t.cells.get(a)
                out['editada'] = True
                out['base'] = None if base is None else base.get('v')
            used = marks.get((c['tabela'], a))
            if used:
                out['uso'] = used
            cells.append(out)
        if any_value:
            lines.append({'secao': s, 'celulas': cells})
    ref = refs.get(info['ref'], {'id': info['ref']})
    sel = None
    if uid:
        sel = next((u for u in usage if u['id'] == uid), None)
    return {'tabela': tab, 'material': mat, 'titulo': info['titulo'], 'condicoes': info['condicoes'], 'nota': info.get('nota'),
            'colunas': [{k: c[k] for k in ('nome', 'grupo', 'grupo_rotulo', 'sub', 'rotulo', 'tabela', 'coluna')} for c in cols],
            'linhas': lines, 'referencia': _ref_brief(ref) if ref.get('norma') else {'id': info['ref']},
            'conferencia': _conference([ref] if ref.get('norma') else []), 'uso_circuitos': usage, 'selecionado': sel,
            'base_atual': p.model is model(),
            'tabelas_base': [{'id': tid, 'revisao': (p.model.tables[tid].meta or {}).get('revisao'),
                              'verificacao': (p.model.tables[tid].meta or {}).get('verificacao'),
                              'revisao_nota': (p.model.tables[tid].meta or {}).get('revisao_nota')} for tid in AMP_TABLES]}


# ---------------------------------------------------------------- fichas de fabricante
def _val(p, t, a):
    cell = p.table_cell(t, a)
    if cell is None:
        return None
    if 'f' in cell:
        return _plain(p.engine.get(t.legacy or t.id, a))
    return cell.get('v')


def _used_models(p):
    out = {'weg': {}, 'dps': {}, 'nh': {}}
    try:
        from . import trecho
        mb_col = trecho.COL['mb_modelo']
    except Exception:  # noqa: BLE001
        trecho, mb_col = None, None
    for c in _circuits(p):
        r = c['row']
        for model_ in {str(p.get(PROT, f'AM{r}') or '')} | ({str(p.get(trecho.SHEET, f'{mb_col}{r}') or '')} if mb_col else set()):
            if model_:
                out['weg'].setdefault(model_, []).append(c['nome'])
        dps = str(p.get(DPS, f'AV{r}') or '')
        if dps and dps not in ('N/A', '—'):
            out['dps'].setdefault(dps, []).append(c['nome'])
        fuse = str(p.get(DPS, f'BP{r}') or '')
        if fuse:
            out['nh'].setdefault(fuse, []).append(c['nome'])
    return out


FICHA_TIPOS = {'dps_siemens': 'DPS Siemens', 'dps_clamper': 'DPS Clamper', 'weg': 'Disjuntores WEG', 'nh': 'Fusíveis NH gG'}


def fichas(p, tipo='dps_siemens', q='', usados=False, offset=0, limit=24):
    if tipo not in FICHA_TIPOS:
        raise ValueError('Tipo de ficha inválido.')
    tid = {'dps_siemens': 'tab_dps_siemens', 'dps_clamper': 'tab_dps_clamper', 'weg': 'tab_weg_protecoes', 'nh': 'tab_fusiveis_nh'}[tipo]
    t = p.model.tables[tid]
    used = _used_models(p)
    qn = (q or '').casefold().strip()
    cards = []
    edits = ((p.doc.get('tabelas') or {}).get(tid) or {}).get('celulas') or {}
    for r in range(2, t.max_row + 1):
        g = lambda c: _val(p, t, f'{c}{r}')  # noqa: E731
        if tipo.startswith('dps'):
            code = g('D')
            if not code:
                continue
            uses = used['dps'].get(str(code), [])
            pares = [
                {'rotulo': 'Uc', 'catalogo': g('K'), 'calculo': g('W'), 'unidade': 'V', 'endereco': f'K{r} → W{r}'},
                {'rotulo': 'Up', 'catalogo': g('L'), 'calculo': g('X'), 'unidade': 'kV', 'endereco': f'L{r} → X{r}'},
                {'rotulo': 'Iimp (10/350 µs)', 'catalogo': g('M'), 'calculo': g('Y'), 'unidade': 'kA', 'endereco': f'M{r} → Y{r}'},
                {'rotulo': 'In (8/20 µs)', 'catalogo': g('N'), 'calculo': g('Z'), 'unidade': 'kA', 'endereco': f'N{r} → Z{r}'},
                {'rotulo': 'Back-up máximo a montante', 'catalogo': g('Q'), 'calculo': g('Q'), 'unidade': 'A', 'endereco': f'Q{r}'},
            ]
            if tipo == 'dps_siemens':
                pares.append({'rotulo': 'Isccr com back-up máximo', 'catalogo': None, 'calculo': g('AA'), 'unidade': 'kA',
                              'endereco': f'AA{r}'})
            card = {'linha': r, 'titulo': str(code), 'subtitulo': ' · '.join(str(x) for x in (g('E'), g('F'), g('H'), g('J')) if x),
                    'pares': pares, 'fonte': g('V'), 'observacoes': g('U'), 'usado_por': uses}
        elif tipo == 'weg':
            code = g('C')
            if not code:
                continue
            uses = used['weg'].get(str(code), [])
            pares = [
                {'rotulo': 'Icu', 'catalogo': g('R'), 'calculo': g('AA'), 'unidade': f"kA ({g('AC') or '—'} V)", 'endereco': f'R{r} → AA{r}'},
                {'rotulo': 'Ics', 'catalogo': g('S'), 'calculo': g('AB'), 'unidade': 'kA', 'endereco': f'S{r} → AB{r}'},
                {'rotulo': 'In / frame', 'catalogo': g('I'), 'calculo': g('AL'), 'unidade': 'A', 'endereco': f'I{r} → AL{r}'},
                {'rotulo': 'Ir', 'catalogo': g('L'), 'calculo': g('AN'), 'unidade': 'A', 'endereco': f'L{r} → AN{r}'},
                {'rotulo': 'Im/Ii', 'catalogo': g('O'), 'calculo': g('AP'), 'unidade': 'A', 'endereco': f'O{r} → AP{r}'},
            ]
            card = {'linha': r, 'titulo': str(code),
                    'subtitulo': ' · '.join(str(x) for x in (g('B'), g('G'), g('F'), g('P'), g('Q') if g('Q') not in (None, '—') else None) if x),
                    'pares': pares, 'fonte': ' · '.join(str(x) for x in (g('W'), ('p. ' + str(g('X'))) if g('X') else None) if x),
                    'observacoes': g('V') or g('AD'), 'usado_por': uses}
        else:
            code = g('D')
            if not code:
                continue
            uses = used['nh'].get(str(code), [])
            pares = [{'rotulo': 'In', 'catalogo': g('G'), 'calculo': g('G'), 'unidade': 'A', 'endereco': f'G{r}'},
                     {'rotulo': 'Poder de corte (Icu)', 'catalogo': g('H'), 'calculo': g('H'), 'unidade': 'kA', 'endereco': f'H{r}'},
                     {'rotulo': 'Un', 'catalogo': g('F'), 'calculo': g('F'), 'unidade': 'V', 'endereco': f'F{r}'}]
            card = {'linha': r, 'titulo': str(code), 'subtitulo': ' · '.join(str(x) for x in (g('B'), g('C'), g('E')) if x),
                    'pares': pares, 'fonte': g('I'), 'observacoes': g('J'), 'usado_por': uses}
        card['editada'] = any(re.fullmatch(r'[A-Z]+' + str(r), a) for a in edits)
        for par in card['pares']:
            par['catalogo'], par['calculo'] = _plain(par['catalogo']), _plain(par['calculo'])
            par['a_confirmar'] = par['calculo'] in (None, '') or isinstance(par['calculo'], dict)
        if usados and not card['usado_por']:
            continue
        if qn and qn not in ' '.join(str(x) for x in (card['titulo'], card['subtitulo'], card['fonte'], card['observacoes'])).casefold():
            continue
        cards.append(card)
    total = len(cards)
    offset = max(0, int(offset))
    limit = max(1, min(int(limit), 60))
    meta = t.meta or {}
    return {'tipo': tipo, 'tipos': FICHA_TIPOS, 'tabela': tid, 'titulo': meta.get('titulo') or t.name, 'fonte': meta.get('fonte'),
            'revisao_nota': meta.get('revisao_nota'), 'total': total, 'inicio': offset, 'fichas': cards[offset:offset + limit],
            'usados': sum(1 for c in cards if c['usado_por'])}


# ---------------------------------------------------------------- conferência guiada
def conferencia(p):
    from . import tabelas
    refs = _refs(p)
    cited = {}
    for t in tabelas.listing(p)['tabelas']:
        for r in t['refs']:
            cited.setdefault(r, []).append({'id': t['id'], 'nome': t['nome']})
    for item in RULE_ITEMS:
        for r in item['refs']:
            cited.setdefault(r, []).append({'id': item['id'], 'nome': item['nome']})
    groups = {}
    for rid, ref in refs.items():
        fam = _family_of_norm(ref.get('norma'))
        item = {**_ref_brief(ref), 'condicoes': ref.get('condicoes') or [], 'tabelas': cited.get(rid, []),
                'item': ref.get('item'), 'tabela': ref.get('tabela')}
        groups.setdefault(fam, []).append(item)
    out = []
    for fam, label in FAMILIES:
        items = groups.get(fam)
        if not items:
            continue
        items.sort(key=lambda r: _sort_key(r['localizador']))
        out.append({'familia': fam, 'rotulo': label, 'itens': items})
    total = len(refs)
    done = sum(1 for r in refs.values() if r.get('verificado_por'))
    in_project = sum(1 for r in refs.values() if r.get('conferencia_projeto'))
    return {'grupos': out, 'total': total, 'conferidas': done, 'conferidas_no_projeto': in_project,
            'nota': 'A conferência da base foi feita na auditoria da versão 2.2.0 com o exemplar do usuário. A marcação do revisor '
                    'fica neste projeto, com nome e data, e não altera nenhum cálculo.'}


def verificar(p, rid, autor, pagina=None, nota=None, desfazer=False):
    """Marca (ou desmarca) um localizador como conferido no exemplar pelo revisor. Grava no projeto, não na base."""
    from .catalog import Catalog, normref_registry
    cat = Catalog(p, integrity=False)
    base = normref_registry().get(rid)
    over = cat.norm_overrides.get(rid)
    if base is None and over is None:
        raise ValueError('Referência normativa desconhecida.')
    pagina = (str(pagina).strip() or None) if pagina is not None else None
    nota = (str(nota).strip() or None) if nota is not None else None
    if pagina and len(pagina) > 40:
        raise ValueError('Página: use até 40 caracteres (ex.: p. 101 ou pp. 101–105).')
    if nota and len(nota) > 500:
        raise ValueError('Nota: use até 500 caracteres.')
    if desfazer:
        if over is None or not over.get('conferencia_projeto'):
            raise ValueError('Não há conferência registrada neste projeto para esta referência.')
        before = over.get('_antes')
        if before is None:
            cat.norm_overrides.pop(rid, None)  # volta à referência da base, com a conferência que ela já tinha
        else:
            cat.norm_overrides[rid] = before   # volta ao cadastro do projeto anterior à conferência
        return {'id': rid, 'conferida': False}
    data = dict(base or {})
    data.update(over or {})
    data.pop('id', None)
    if not (over or {}).get('conferencia_projeto'):
        # Guarda o estado anterior (None = sem cadastro no projeto) para desfazer sem perder um cadastro do revisor.
        data['_antes'] = None if over is None else {k: v for k, v in over.items() if k != '_antes'}
    if base is not None and base.get('verificado_por'):
        data['verificacao_base'] = {'por': base.get('verificado_por'), 'em': base.get('verificado_em')}
    data.update(verificado_por=autor, verificado_em=dt.date.today().isoformat(), conferencia_projeto=True)
    if pagina:
        data['pagina'] = pagina
    if nota is not None:
        data['nota_conferencia'] = nota
    cat.norm_overrides[rid] = data
    return {'id': rid, 'conferida': True, 'verificado_por': autor, 'verificado_em': data['verificado_em']}

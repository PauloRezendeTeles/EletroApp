"""Proteções da entrada, gerador I(t) e verificação do alimentador — v2.3.

Os resultados são acessados pelo motor nomeado e aparecem no catálogo. O estado
“calculado” fica limitado aos dados documentados; modelo de excitação constante
e curvas estáticas integradas sem modelo de memória são identificados como estimativa.
"""
from __future__ import annotations
import hashlib
import html
import json
import math
from . import curvas, trecho, protection_links as links
from . import fault_time as ft
from .protection_schema import *

def get(p,vid,r=None):
    var=p.model.by_id.get(vid)
    if var is None:return None
    return p.get(var.sheet,(var.col+str(r)) if var.scope=='circuito' else var.addr)

def src(p,key):return get(p,'entrada.'+key)
def cin(p,r,key):return get(p,'integrada.'+key,r)
def kind(p):return profile(get(p,'fonte.tipo_atendimento'),src(p,'tipo'))
def finite(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
def positive(v):return finite(v) and v>0

def ancestors(p,r):
    out=[];seen=set()
    while r is not None and r not in seen:
        seen.add(r);out.append(r);r=links.parent_row(p,r)
    return out

def boundary(p,key):
    uid=src(p,key)
    if uid:
        try:return p.row_for(uid)
        except ValueError:return None
    def matches(r):
        name=str(get(p,'ident.nome',r) or '').casefold()
        return (name.startswith('qm') or 'medição' in name or 'medicao' in name) if key=='medicao' else (name.startswith('qta') or 'transferência' in name or 'transferencia' in name)
    found=[r for r in p.active_rows() if matches(r)]
    return found[0] if len(found)==1 else None

def scope(p,r):
    k=kind(p)
    if k==GENERATOR:
        b=boundary(p,'qta')
        if b is None:return 'indefinido'
        if r==b or r in ancestors(p,b):return 'fabricante'
        if b not in ancestors(p,r):return 'indefinido'
    if k==UTILITY:
        b=boundary(p,'medicao')
        if b is None:return 'indefinido'
        if r==b or r in ancestors(p,b):return 'externo'
        if b not in ancestors(p,r):return 'indefinido'
    return 'interno'

def active(p,r):
    if p.circuit_at(r) is None or 'integrada.ativa' not in p.model.by_id:return False
    return (get(p,'fonte.tipo_atendimento')=='Gerador BT' or scope(p,r)!='interno' or links.requested(p,r)
            or get(p,'trecho.sem_origem',r) is True)

def current_context(p,r):
    """Curva por ponto só vale para o circuito e para os dados elétricos confirmados."""
    ids=[]
    prefixes=('ident.','dados.','condutores.','secoes.','instalacao.','metodo.','cargas.')
    ignored={'ident.nome','ident.descricao','ident.montante'}
    for q in p.active_rows():
        c=p.circuit_at(q)
        for var in p.model.inputs:
            if var.id.startswith(prefixes) and var.id not in ignored:p.engine.touch(var.sheet,var.col+str(q))
        ids.append({'id':c['id'],'entradas':{k:v for k,v in c['entradas'].items()
                   if k.startswith(prefixes) and k not in ignored}})
    raw={'circuitos':sorted(ids,key=lambda x:x['id']),'caminho':[p.circuit_at(q)['id'] for q in ancestors(p,r)],
         'base':p.model.manifest()['hash'],
         'instalacao':p.meta.get('installation_settings'),
         'fonte':{k:v for k,v in p.doc['fonte'].items() if not k.startswith('entrada.')},
         'tabelas':p.doc.get('tabelas'), 'formulas':p.doc.get('formulas')}
    return hashlib.sha256(json.dumps(raw,sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest()

def fuse_signature(p):
    return [src(p,k) for k in ('fusivel_tipo','fusivel_in','fusivel_curva','fusivel_documento')]

def confirm_curve(p,category,uid=None):
    if category=='fusivel':
        ft.parse_fuse(src(p,'fusivel_curva'))
        if not src(p,'fusivel_documento'):raise ValueError('Informe a referência da curva do elo.')
        ft.number(src(p,'fusivel_in'),'corrente nominal do elo',strict=True)
        if not src(p,'fusivel_tipo'):raise ValueError('Informe o tipo do elo.')
        p.meta['fuse_curve_confirmed']=fuse_signature(p)
    elif category=='gerador':
        r=p.row_for(uid)
        ft.parse_time_curves(cin(p,r,'curva_corrente'))
        if not cin(p,r,'curva_documento'):raise ValueError('Informe a referência das curvas I(t).')
        p.meta.setdefault('generator_curves_confirmed',{})[uid]={'context':current_context(p,r),
            'text':cin(p,r,'curva_corrente'),'document':cin(p,r,'curva_documento')}
    else:raise ValueError('Tipo de curva inválido.')
    p.engine.clear()

def update_curves(p,changes,curve_uids=()):
    # Informar pontos e referência já é a confirmação do dado para a condição atual.
    if any(x['sheet']==SOURCE_SHEET and x['address']==SCOL['fusivel_curva'] and x.get('value') for x in changes):
        if src(p,'fusivel_documento') and src(p,'fusivel_tipo') and positive(src(p,'fusivel_in')):confirm_curve(p,'fusivel')
    for uid in curve_uids:
        r=p.row_for(uid)
        if cin(p,r,'curva_documento'):confirm_curve(p,'gerador',uid)

def validate_value(p,var,value):
    if value in (None,''):return value
    if var.id.startswith('entrada.'):
        spec=next((x for x in SOURCE if 'entrada.'+x[0]==var.id),None)
        key=var.id[8:]
    elif var.id.startswith('integrada.'):
        spec=next((x for x in CIRCUIT if 'integrada.'+x[0]==var.id),None)
        key=var.id[9:]
    else:return value
    if spec is None:return value
    unit,options=spec[2],spec[3]
    if options:
        if value not in options:raise ValueError('Seleção inválida em '+var.label+'.')
    elif key in ('medicao','qta'):
        p.row_for(value)
    elif unit=='csv':
        (ft.parse_fuse if key=='fusivel_curva' else ft.parse_time_curves)(value)
    elif unit or key.endswith('_tempo'):
        if isinstance(value,str):value=ft.numeros.parse_br(value)
        ft.number(value,var.label)
        if key=='horizonte_s' and not 0.1<=value<=30:raise ValueError('Horizonte: entre 0,1 e 30 s.')
        if key in ('gerador_td_duas','gerador_td_linha','gerador_xd_linha','fusivel_in') and value<=0:raise ValueError(var.label+': informe valor maior que zero.')
    elif not isinstance(value,str):raise ValueError('Texto inválido em '+var.label+'.')
    return value

def device(p,r):
    """Dispositivo que elimina faltas no CABO, nunca o da chegada do próprio cabo."""
    err=links.problem(p,r)
    if err:raise ft.MissingData(err)
    if get(p,'trecho.sem_origem',r) is not True:
        if links.requested(p,r):return breaker(p,links.parent_row(p,r),'manutencao')
        return breaker(p,r,'origem')
    for q in ancestors(p,r)[1:]:
        if get(p,'trecho.tem_mb',q) is True:return breaker(p,q,'manutencao')
        if get(p,'trecho.sem_origem',q) is not True:
            if links.requested(p,q):return breaker(p,links.parent_row(p,q),'manutencao')
            return breaker(p,q,'origem')
    k=kind(p)
    if k in (FUSE,RELAY):return {'kind':k,'name':source_name(p),'id':'protecao_fonte'}
    raise ft.MissingData('Não há dispositivo a montante cadastrado para proteger este cabo.')

def breaker(p,r,position):
    d=curvas._device(p,r,position)
    if not d.get('modelo'):raise ft.MissingData('Informe o modelo do disjuntor em '+str(get(p,'ident.nome',r))+'.')
    if d.get('conflitos'):raise ft.MissingData(' '.join(d['conflitos']))
    linked=position=='manutencao'
    opening=cin(p,r,'mb_interrupcao_s') if linked else get(p,'protecao.tempo_de_abertura_do_disjuntor_s_informar',r)
    inst=cin(p,r,'mb_instantaneo_s' if linked else 'instantaneo_s')
    i2t=cin(p,r,'mb_i2t') if linked else d.get('i2t')
    return {'kind':'breaker','data':d,'row':r,'position':position,'name':d['descricao'],
            'id':links.device_id(p,r,position),'opening':opening,'instantaneous':inst,'i2t':i2t}

def source_name(p):
    k=kind(p)
    if k==FUSE:return f'Chave fusível MT — elo {src(p,"fusivel_in") or "?"} A {src(p,"fusivel_tipo") or "?"}'
    if k==RELAY:return 'Disjuntor MT com relé 50/51/50N/51N'
    if k==GENERATOR:return 'Disjuntor do quadro de transferência'
    return 'Rede BT — proteção externa sem dados'

def transfer(p,fault):
    ratio=ft.number(get(p,'fonte.tensao_linha_v'),'tensão BT',strict=True)/(1000*ft.number(get(p,'fonte.tensao_mt_kv'),'tensão MT',strict=True))
    group=get(p,'fonte.trafo_grupo_ligacao')
    if group=='Dyn':
        return ratio*({'3F':1,'2F':2/math.sqrt(3),'FN':1/math.sqrt(3),'FPE':1/math.sqrt(3)}[fault]),0.0
    if group=='YNyn':return ratio,ratio if fault in ('FN','FPE') else 0.0
    if group=='Yyn' and fault in ('3F','2F'):return ratio,0.0
    raise ft.MissingData('Transferência de falta à MT não definida para este grupo de ligação e tipo de falta.')

def laws(p,d,fault):
    """Características do relé/disparador, antes da interrupção do disjuntor."""
    if d['kind']==RELAY:
        ph,res=transfer(p,fault)
        opening=ft.number(src(p,'interrupcao_ms'),'tempo de interrupção do disjuntor MT',strict=True)/1000
        out=[]
        for fn in ('50','51','50N','51N'):
            enabled=src(p,fn+'_ativa')
            if enabled not in (YES,NO):raise ft.MissingData(f'Informe se a função {fn} está habilitada.')
            if enabled==NO:continue
            pickup=ft.number(src(p,fn+'_corrente'),'corrente de partida '+fn,strict=True)
            setting=ft.number(src(p,fn+'_tempo'),'tempo/TMS da função '+fn)
            curve=src(p,fn+'_curva') if fn.startswith('51') else 'Tempo definido'
            if not curve:raise ft.MissingData('Informe a característica da função '+fn+'.')
            if curve!='Tempo definido' and setting<=0:raise ft.MissingData('O TMS deve ser maior que zero.')
            factor=res if fn.endswith('N') else ph
            if factor:out.append({'name':fn,'pickup':pickup,'setting':setting,'curve':curve,'factor':factor})
        if not out:raise ft.MissingData('Nenhuma função habilitada recebe corrente para esta falta (considere o grupo do transformador).')
        return out,opening,False
    data=d['data'];out=[]
    opening=ft.number(d['opening'],'tempo de interrupção de '+d['name'],strict=True)
    if positive(data.get('ii')) or all(positive(x) for x in data.get('mag_cat',(None,None))):
        pickup=data['mag_cat'][1] if not data.get('ajustavel') and positive(data['mag_cat'][1]) else data['ii']*1.2
        if finite(d['instantaneous']) and d['instantaneous']>=0:
            out.append({'name':'I','pickup':pickup,'setting':d['instantaneous'],'curve':'Tempo definido'})
    if positive(data.get('isd')) and positive(data.get('tsd')):
        if d['i2t']=='OFF':out.append({'name':'S','pickup':data['isd']*1.2,'setting':data['tsd']/1000,'curve':'Tempo definido'})
    if not out:raise ft.MissingData('Informe o tempo da função instantânea ou a função S com I²t OFF e seus ajustes. Curvas estáticas não comprovam a memória dinâmica do disparador.')
    return out,opening,False

def fault_types(p,r):
    phases=get(p,'icc.no_de_fases',r)
    out=['3F','2F'] if phases==3 else ['2F'] if phases==2 else []
    ct=str(get(p,'carga.tipo_de_circuito',r) or '')
    if 'N' in ct:out.append('FN')
    if 'T' in ct or 'PEN' in ct:out.append('FPE')
    return out

def static_current(p,r,fault,high):
    ids={('3F',True):'icc.ik3f_max_ka_cmax_r20',('3F',False):'icc.ik3f_min_ka_cmin_rquente',
         ('2F',True):'icc.ik2f_max_ka_z1_z2',('2F',False):'icc.ik2f_min_ka_cmin_rquente',
         ('FN',True):'icc.ik1f_max_ka_z1_z2_z0',('FN',False):'icc.ik_min_1f_ka'}
    if fault!='FPE':return ft.number(get(p,ids[(fault,high)],r),'corrente de curto '+fault,strict=True)*1000
    # Modelo do laço fase–PE já existente; cmax/cmin aplicados à tensão de fase.
    return ft.number(get(p,'choque.ik_do_laco_de_falta_a',r),'corrente do laço fase–PE',strict=True)*ft.number(get(p,'fonte.cmax' if high else 'fonte.cmin'),'fator de tensão',strict=True)

def parameter_current(p,r,fault,high):
    n=lambda vid:ft.number(get(p,vid,r),'dado '+vid)
    xd2=ft.number(get(p,'fonte.reatancia_sub_transitoria_percentual_x'),'X″d',strict=True)/100
    xd1=ft.number(src(p,'gerador_xd_linha'),'X′d',strict=True)/100
    xs=ft.number(get(p,'fonte.reatancia_sincrona_percentual_xs'),'Xs',strict=True)/100
    td1=ft.number(src(p,'gerador_td_linha'),'T′d',strict=True)
    td2=ft.number(src(p,'gerador_td_duas'),'T″d',strict=True)
    if not xd2<=xd1<=xs or td2>td1:raise ft.MissingData('Exige X″d ≤ X′d ≤ Xs e T″d ≤ T′d.')
    source_x2=ft.number(get(p,'fonte.x1_sistema'),'reatância equivalente inicial',strict=True)/1000
    v=ft.number(get(p,'fonte.tensao_linha_v'),'tensão do gerador',strict=True)
    c=ft.number(get(p,'fonte.cmax' if high else 'fonte.cmin'),'fator de tensão',strict=True)
    rr=n('imp.r1_total_a_20c_ohm' if high else 'imp.resistencia_fase_total')
    xx=n('imp.reatancia_fase_total')
    factor=c/math.sqrt(3)
    if fault in ('2F','FN'):
        rr+=n('imp.r2_total_a_20c_ohm' if high else 'imp.r2_total_quente_ohm')
        xx+=n('imp.x2_total_ohm');factor=c
        if fault=='FN':
            rr+=n('imp.r0_total_a_20c_ohm' if high else 'imp.resistencia_seq_zero_total')
            xx+=n('imp.reatancia_seq_zero_total');factor=math.sqrt(3)*c
    if fault=='FPE':
        # Mesmo laço do aplicativo, sem substituir o retorno PE pelo neutro.
        rr=n('choque.resistencia_fase')+n('choque.r_terra_total_ohm')
        xx=n('choque.reatancia_fase')+n('choque.x_terra_total_ohm')
    generator=(xd2,xd1,xs,td2,td1)
    return lambda t:ft.current_from_parameters(v,factor,rr,xx,1,source_x2,generator,t)

def currents(p,r,fault):
    horizon=src(p,'horizonte_s') or 10
    horizon=ft.number(horizon,'horizonte de cálculo',strict=True)
    if horizon>30:raise ft.MissingData('Horizonte máximo de 30 s.')
    if get(p,'fonte.tipo_atendimento')!='Gerador BT':
        lo,hi=static_current(p,r,fault,False),static_current(p,r,fault,True)
        return (lambda t:lo),(lambda t:hi),horizon,[],False
    mode=src(p,'gerador_modo')
    if mode==PARAMETERS:
        return parameter_current(p,r,fault,False),parameter_current(p,r,fault,True),horizon,[],True
    if mode!=POINT_CURVES:raise ft.MissingData('Escolha o modelo temporal do gerador em Entrada e fontes.')
    text=cin(p,r,'curva_corrente');doc=cin(p,r,'curva_documento')
    points=ft.parse_time_curves(text).get(fault)
    if not points:raise ft.MissingData('Falta a curva I(t) de '+fault+' para este circuito.')
    if not doc:raise ft.MissingData('Informe a referência das curvas I(t).')
    seal=p.meta.get('generator_curves_confirmed',{}).get(p.circuit_at(r)['id'],{})
    if seal.get('context')!=current_context(p,r) or seal.get('text')!=text or seal.get('document')!=doc:
        raise ft.MissingData('Curvas I(t) não confirmadas para os dados atuais; confira a aplicabilidade e confirme novamente.')
    initial_lo=static_current(p,r,fault,False);initial_hi=static_current(p,r,fault,True)
    if points[0][1]>initial_lo+1 or points[0][2]<initial_hi-1:
        raise ft.MissingData(f'O envelope inicial de {fault} deve abranger o cálculo da fonte ({initial_lo:.1f}…{initial_hi:.1f} A). Revise os dados da fonte ou as curvas do ponto; tolerância de arredondamento de 1 A.')
    end=min(horizon,points[-1][0]);breaks=[x[0] for x in points]
    return (lambda t:ft.interpolate(points,t,1)),(lambda t:ft.interpolate(points,t,2)),end,breaks,False

def evaluate_fault(p,r,d,fault):
    lo,hi,end,breaks,estimated=currents(p,r,fault)
    if d['kind']==FUSE:
        if p.meta.get('fuse_curve_confirmed')!=fuse_signature(p):raise ft.MissingData('Confirme a curva do elo para o tipo e a corrente nominal selecionados.')
        points=ft.parse_fuse(src(p,'fusivel_curva'));ph,_=transfer(p,fault)
        # Fusível MT não está em série com fonte geradora: rejeita a combinação.
        if get(p,'fonte.tipo_atendimento')=='Gerador BT':raise ft.MissingData('Gerador BT não usa proteção MT neste perfil.')
        il,ih=lo(0)*ph,hi(0)*ph
        tlo=ft.interpolate(points,il,2,True);thi=ft.interpolate(points,ih,2,True)
        motor=get(p,'motores.contrib_icc_total_ka',r) if fault=='3F' else 0
        motor=1000*motor if positive(motor) else 0
        # Limite superior conservador: contribuição dos motores mantida até tmax.
        energy=max((lo(0)+motor)**2*tlo,(hi(0)+motor)**2*thi)
        # Inclui todos os vértices internos: I²t não é necessariamente máximo no Ik máximo.
        for i,_,tm in points:
            if il<=i<=ih:energy=max(energy,(i/ph+motor)**2*tm)
        tmax=max(tlo,thi);tmin=ft.interpolate(points,ih,1,True)
        return {'fault':fault,'imin_a':lo(0),'imax_a':hi(0),'seen_min_a':il,'seen_max_a':ih,
                'trip_s':None,'clear_s':tmax,'min_s':tmin,'energy':energy,'function':'elo fusível',
                'estimated':False,'reason':None,'samples':[[0,lo(0),hi(0)],[tmax,lo(0),hi(0)]]}
    ll,opening,approx=laws(p,d,fault)
    a=ft.simulate(lo,ll,opening,end,breaks)
    b=ft.simulate(hi,ll,opening,end,breaks)
    tmax=max(a['clear_s'],b['clear_s']) if a['clear_s'] is not None and b['clear_s'] is not None else None
    # Envelope conservador: Imax durante o maior tempo necessário a Imin/Imax.
    # Não combina Imax com seu tempo menor e ignora casos intermediários.
    motor=get(p,'motores.contrib_icc_total_ka',r) if fault=='3F' and src(p,'gerador_modo')!=POINT_CURVES else 0
    motor=1000*motor if positive(motor) else 0
    energy=ft.energy(lambda t:hi(t)+motor,tmax,breaks) if tmax is not None else None
    sample_times=sorted(set([0,end,*[min(end,x) for x in (0.01,0.02,0.05,0.1,0.2,0.5,1,2,5)],*([tmax] if tmax is not None else [])]))
    sample_times += [t for t in breaks if 0<=t<=end]
    sample_times=sorted(set(sample_times))[:220]
    ph,res=transfer(p,fault) if d['kind']==RELAY else (1,0)
    return {'fault':fault,'imin_a':lo(0),'imax_a':hi(0),'seen_min_a':lo(0)*ph,'seen_max_a':hi(0)*ph,'residual_min_a':lo(0)*res,
            'trip_s':a['trip_s'],'clear_s':tmax,'min_s':b['clear_s'],'energy':energy,'function':a['function'],
            'estimated':estimated or approx,'reason':a['reason'] or b['reason'],'opening_s':opening,
            'horizon_s':end,'samples':[[t,lo(t),hi(t)] for t in sample_times]}

class Protection:
    def __init__(self,p):self.p=p
    def install(self):
        self.p.engine.functions['PROTECTIONVALUE']=self.value
        self.p.engine.functions['PROTECTIONARRIVAL']=self.arrival
    def arrival(self,r,key):
        p=self.p;r=int(r)
        try:
            d=breaker(p,r,'manutencao')
            f=evaluate_fault(p,r,d,'FPE')
            if key=='time':return f.get('clear_s') if finite(f.get('clear_s')) else 'N/D — '+str(f.get('reason'))
            lim=get(p,'choque.tempo_maximo_de_seccionamento_tn_aplicavel_s',r)
            if not positive(lim) or not finite(f.get('clear_s')):return '⏳ NÃO VERIFICADA — '+str(f.get('reason') or 'limite TN pendente')
            if f['clear_s']>lim:return f'✗ NÃO ATENDE — {f["clear_s"]:.4f} s > {lim:g} s.'
            return ('△ ESTIMATIVA' if f.get('estimated') else '✓ ATENDE')+f' — falta no quadro: {f["clear_s"]:.4f} s ≤ {lim:g} s.'
        except (ft.MissingData,ValueError,TypeError) as exc:
            return ('N/D — ' if key=='time' else '⏳ NÃO VERIFICADA — ')+str(exc)
    def value(self,r,key):
        r=int(r)
        if key=='active':return active(self.p,r)
        return self.result(r).get(key,'')
    def result(self,r):
        p=self.p;e=p.engine;key=(CIRCUIT_SHEET,'@RESULT'+str(r))
        e.touch(*key)
        if key in e.cache:return e.cache[key]
        if key in e.stack:return {'status':'⏳ PENDENTE — dependência circular na proteção integrada.'}
        e.stack.add(key);e.trail.append(key)
        try:
            result=self.compute(r)
        except (ft.MissingData,ValueError,TypeError,ZeroDivisionError,OverflowError) as exc:
            result={'active':True,'status':'⏳ NÃO VERIFICADA — '+str(exc),'thermal':'⏳ NÃO VERIFICADA — '+str(exc),
                    'tn':'⏳ NÃO VERIFICADA — '+str(exc),'detail':str(exc),'faults':[]}
        finally:e.trail.pop();e.stack.discard(key)
        e.cache[key]=result
        return result
    def compute(self,r):
        p=self.p
        if not active(p,r):return {'active':False,'status':'Verificação usual do dispositivo de saída.','faults':[]}
        st=get(p,'fonte.tipo_atendimento');k=kind(p)
        valid={GENERATOR} if st=='Gerador BT' else {UTILITY} if st=='Rede BT Direta' else {FUSE,RELAY}
        if k not in valid:raise ft.MissingData('O perfil de proteção não corresponde ao tipo de atendimento. Selecione Automático ou um perfil compatível.')
        sc=scope(p,r)
        if sc in ('externo','fabricante','indefinido'):
            text={'externo':'⏳ NÃO VERIFICÁVEL — rede BT: parâmetros da rede e da proteção da concessionária não fornecidos; avaliação a partir da saída do quadro de medição.',
                  'fabricante':'A CARGO DO FABRICANTE DO GERADOR — trecho até o quadro de transferência.',
                  'indefinido':'⏳ NÃO VERIFICADA — selecione o quadro de medição/transferência que delimita este circuito.'}[sc]
            return {'active':True,'status':text,'thermal':text,'tn':text,'detail':text,'scope':sc,'faults':[]}
        if k==GENERATOR:
            qta=boundary(p,'qta')
            if qta is None or get(p,'trecho.tem_mb',qta) is not True:
                raise ft.MissingData('Cadastre o disjuntor de chegada do quadro de transferência.')
            qta_device=breaker(p,qta,'manutencao')
            laws(p,qta_device,'FPE')  # Dados do QTA são obrigatórios mesmo com saídas próprias.
        d=device(p,r)
        out={'active':True,'device':d['name'],'device_id':d['id'],'scope':sc,'faults':[],
             'method':'Correntes constantes' if get(p,'fonte.tipo_atendimento')!='Gerador BT' else src(p,'gerador_modo')}
        errors=[]
        for fault in fault_types(p,r):
            try:out['faults'].append(evaluate_fault(p,r,d,fault))
            except (ft.MissingData,ValueError,TypeError,ZeroDivisionError) as exc:
                out['faults'].append({'fault':fault,'reason':str(exc),'clear_s':None,'energy':None})
        if not out['faults']:errors.append('Defina as fases e os condutores do circuito.')
        for q in out['faults']:
            if q.get('reason'):errors.append(q['fault']+': '+q['reason'])
        phase=[q for q in out['faults'] if q['fault']!='FPE']
        pe=[q for q in out['faults'] if q['fault']=='FPE']
        neutral=[q for q in out['faults'] if q['fault']=='FN']
        def maximum(rows,key):return max((x[key] for x in rows),default=None) if rows and all(finite(x.get(key)) for x in rows) else None
        out['time_phase']=maximum(phase,'clear_s');out['time_pe']=maximum(pe,'clear_s')
        out['energy_phase']=maximum(out['faults'],'energy');out['energy_neutral']=maximum(neutral,'energy');out['energy_pe']=maximum(pe,'energy')
        estimated=any(q.get('estimated') for q in out['faults'])
        thermal=[];failed=False
        n=ft.number(get(p,'condutores.por_polo',r),'número de condutores por polo',strict=True)
        # v2.3.2: neutro/PEN e PE com quantidades próprias de condutores em paralelo (vazio = igual às fases).
        nn=ft.number(get(p,'condutores.nc_neutro',r),'número de condutores em paralelo do neutro',strict=True)
        npe=ft.number(get(p,'condutores.nc_pe',r),'número de condutores em paralelo do PE',strict=True)
        ncount={'phase':n,'neutral':nn,'pe':npe}
        kp=ft.number(get(p,'integrada.k_fase',r),'k térmico da fase',strict=True)
        # O k do PE depende da seção: usa o valor já correspondente à seção escolhida.
        ke=get(p,'integrada.k_pe',r)
        sn=get(p,'secoes.neutro_mm2',r);spe=get(p,'secoes.pe_mm2',r)
        if 'PEN' in str(get(p,'carga.tipo_de_circuito',r)):
            pen=max((x for x in (sn,spe) if positive(x)),default=None)
            sn=spe=pen  # Mesmo condutor físico; o app adota a maior seção informada.
        for label,key,sec,k in [('fase','phase',get(p,'secoes.fase_mm2',r),kp),
                                ('neutro','neutral',sn,get(p,'integrada.k_neutro',r)),
                                ('PE','pe',spe,ke)]:
            val=out['energy_'+key]
            if val is None:
                if key=='neutral' and not neutral:continue
                if key=='pe' and not pe:continue
                thermal.append('energia de '+label+' não determinada');continue
            if not positive(k) or not positive(sec):thermal.append('seção/k de '+label+' pendente');continue
            required=math.sqrt(val)/(k*ncount[key])
            out['section_'+key]=required
            if sec+1e-9<required:thermal.append(f'{label}: {sec:g} < {required:.2f} mm² por condutor');failed=True
        times=[q['clear_s'] for q in out['faults'] if finite(q.get('clear_s'))]
        outside=any(t<0.1-1e-8 or t>5+1e-8 for t in times)
        if outside:thermal.append('tempo fora de 0,1…5 s: confirmar energia passante/critério térmico aplicável')
        pref='✗ NÃO ATENDE' if failed else '⏳ NÃO VERIFICADA' if errors or thermal else '△ ESTIMATIVA' if estimated else '✓ ATENDE'
        out['thermal']=pref+' — '+('; '.join(thermal+errors) if thermal or errors else '∫I²dt ≤ k²S², nos dados e no intervalo informados')
        limit=get(p,'choque.tempo_maximo_de_seccionamento_tn_aplicavel_s',r)
        if not pe:out['tn']='N/A — circuito sem PE/PEN.'
        elif positive(limit) and any((q.get('horizon_s') or 0)>=limit and q.get('reason','') and q['reason'].startswith('Sem atuação demonstrada') for q in pe):
            out['tn']='✗ NÃO ATENDE — não há atuação demonstrada com Imin dentro do limite TN.'
        elif not positive(limit) or not finite(out['time_pe']):out['tn']='⏳ NÃO VERIFICADA — tempo de eliminação fase–PE ou limite TN não determinado.'
        elif out['time_pe']>limit+1e-8:out['tn']=f'✗ NÃO ATENDE — {out["time_pe"]:.4f} s > {limit:g} s.'
        else:out['tn']=('△ ESTIMATIVA' if estimated else '✓ ATENDE')+f' — eliminação em {out["time_pe"]:.4f} s ≤ {limit:g} s.'
        out['status']='✗ ATUAÇÃO/TÉRMICA NÃO ATENDIDA' if '✗' in out['thermal']+out['tn'] else '⏳ ATUAÇÃO/TÉRMICA NÃO VERIFICADA' if '⏳' in out['thermal']+out['tn'] else '△ ATUAÇÃO/TÉRMICA ESTIMADA' if estimated else '✓ ATUAÇÃO E TÉRMICA ATENDIDAS NOS DADOS INFORMADOS'
        detail=['Dispositivo: '+d['name'],'Método: '+str(out['method']),
                'Atuação: integração ∫dt/t(I)=1; reset imediato abaixo da partida; tempo de interrupção somado após o comando.',
                'Energia: integral do envelope Imax até o maior tempo de eliminação de Imin/Imax; por condutor em paralelo.']
        if estimated:detail.append('Modelo de excitação constante: não reproduz o AVR; confirmação exige curvas I(t) aplicáveis ao ponto de falta.')
        if d['kind'] in (RELAY,FUSE):detail.append('Correntes convertidas à MT conforme o grupo de ligação; não se aplica uma razão única a todas as faltas.')
        detail.extend(errors)
        out['detail']=' '.join(detail)
        return out

def source_status(p):
    out={'profile':kind(p),'description':source_name(p),'issues':[]}
    k=out['profile']
    st=get(p,'fonte.tipo_atendimento')
    valid={GENERATOR} if st=='Gerador BT' else {UTILITY} if st=='Rede BT Direta' else {FUSE,RELAY}
    if k and k not in valid:out['issues'].append('O perfil de proteção não corresponde ao tipo de atendimento.')
    if k==FUSE:
        if not src(p,'fusivel_tipo') or not positive(src(p,'fusivel_in')):out['issues'].append('Informe tipo e corrente nominal do elo MT.')
        if p.meta.get('fuse_curve_confirmed')!=fuse_signature(p):out['issues'].append('Informe/confirme as curvas de fusão mínima e eliminação máxima do elo.')
    elif k==RELAY:
        if not positive(src(p,'interrupcao_ms')):out['issues'].append('Informe o tempo de interrupção do disjuntor MT.')
        for fn in ('50','51','50N','51N'):
            if src(p,fn+'_ativa') not in (YES,NO):out['issues'].append('Defina habilitação da função '+fn+'.')
            elif src(p,fn+'_ativa')==YES and (not positive(src(p,fn+'_corrente')) or not finite(src(p,fn+'_tempo'))):out['issues'].append('Complete corrente e tempo/TMS da função '+fn+'.')
            elif src(p,fn+'_ativa')==YES and fn.startswith('51'):
                curve=src(p,fn+'_curva')
                if not curve:out['issues'].append('Selecione a característica da função '+fn+'.')
                elif curve!='Tempo definido' and not positive(src(p,fn+'_tempo')):out['issues'].append('O TMS da função '+fn+' deve ser maior que zero.')
        if all(src(p,fn+'_ativa')==NO for fn in ('50','51','50N','51N')):out['issues'].append('Nenhuma função do relé está habilitada.')
    elif k==GENERATOR:
        r=boundary(p,'qta')
        if r is None:out['issues'].append('Selecione o quadro de transferência.')
        elif get(p,'trecho.tem_mb',r) is not True:out['issues'].append('Informe o disjuntor de chegada do quadro de transferência.')
        else:
            try:laws(p,breaker(p,r,'manutencao'),'FPE')
            except ft.MissingData as exc:out['issues'].append(str(exc))
        if src(p,'gerador_modo') not in (PARAMETERS,POINT_CURVES):out['issues'].append('Selecione o modelo temporal do gerador.')
        if r is not None:out['qta_id']=p.circuit_at(r)['id']
    elif k==UTILITY:
        out['note']='Proteção externa não verificável; avaliar os circuitos a jusante da medição com os dados disponíveis da fonte.'
        if boundary(p,'medicao') is None:out['issues'].append('Selecione o quadro de medição.')
    return out

def source_pair(p,r,down):
    """Pré-verificação no ponto de falta; não declara seletividade em todo o intervalo."""
    k=kind(p)
    if k not in (FUSE,RELAY):return None
    source={'kind':k,'name':source_name(p),'id':'protecao_fonte'}
    messages=[];complete=False
    try:
        device_row=next((q for q in p.active_rows() if get(p,'ident.nome',q)==down.get('circuito')),r)
        d=breaker(p,device_row,down.get('posicao') or 'origem')
        for fault in fault_types(p,r):
            up=evaluate_fault(p,r,source,fault);dn=evaluate_fault(p,r,d,fault)
            if finite(up.get('min_s')) and finite(dn.get('clear_s')):
                complete=True
                messages.append(f'{fault} no fim do alimentador: montante ≥ {up["min_s"]:.4f} s; jusante ≤ {dn["clear_s"]:.4f} s — '+
                                ('separação de tempos no ponto' if up['min_s']>dn['clear_s'] else 'sem separação demonstrada no ponto'))
            else:messages.append(f'{fault}: faltam tempos completos para comparar.')
    except (ft.MissingData,ValueError,TypeError) as exc:messages.append(str(exc))
    messages.append('Pré-verificação nas faltas calculadas; não demonstra seletividade total. Conferir curvas/tabelas e tolerâncias em todo o intervalo.')
    return {'circuito':get(p,'ident.nome',r),'montante':'Proteção da entrada','par':'fonte',
            'nivel':'pre_verificacao' if complete else 'sem_dados','situacao':'indeterminada','limite_ka':None,
            'dispositivo_montante':{'id':'protecao_fonte','descricao':source['name'],'posicao':'fonte'},
            'dispositivo_jusante':curvas._dev_view(down),'ik_ka':get(p,'icc.ik_max_ka',r),'aplicavel':True,
            'metodo':'faltas no fim do alimentador','detalhes':messages}

def decorate_field(p,f,r=None):
    var=p.var_at(f['sheet'],f['address'])
    if not var:return
    spec=var.spec
    f['hint']=spec.get('orientacao','')
    f['textarea']=var.unit=='csv'
    f['numeric']=bool(var.unit and var.unit!='csv') or var.id.endswith('_tempo')
    f['strict']=bool(var.options)
    f['pending_list']=False
    f['protection_key']=var.id.split('.',1)[1]
    if r is None:
        f['block']='gerador_dinamico' if spec.get('bloco_protecao')=='gerador_dinamico' else 'protecao_entrada'
        f['protection_block']=spec.get('bloco_protecao')
        if f['protection_key'] in ('medicao','qta'):
            f['options']=[c['id'] for c in p.circuits_doc]
            f['option_labels']={c['id']:c['entradas'].get('ident.nome','') for c in p.circuits_doc}
            f['strict']=True
            f['empty_label']='Automático pelo nome do quadro'
    else:
        f['empty_label']='Saída própria no quadro precedente (padrão)' if f['protection_key']=='vinculo' else 'Não informado'

def report_html(p):
    esc=lambda x:html.escape(str(x if x is not None else '—'))
    parts=['<p>'+esc(source_status(p)['description'])+'</p>']
    parts.append('<table><tr><th>Dado da proteção de entrada</th><th>Valor informado</th></tr>')
    for key,label,unit,_,block,_ in SOURCE:
        value=src(p,key)
        if value not in (None,'') and unit!='csv':
            if key in ('qta','medicao'):
                try:value=get(p,'ident.nome',p.row_for(value))
                except ValueError:pass
            if block=='fusivel' and kind(p)!=FUSE or block=='rele' and kind(p)!=RELAY or block=='gerador_dinamico' and kind(p)!=GENERATOR:continue
            parts.append('<tr><td>'+esc(label)+'</td><td>'+esc(value)+' '+esc(unit)+'</td></tr>')
    parts.append('</table>')
    for r in p.active_rows():
        result=p.protection.result(r)
        link=links.view(p,r)
        parts.append('<h3>'+esc(get(p,'ident.nome',r))+'</h3><p>'+esc(link['descricao'])+'</p>')
        if not result.get('active'):continue
        parts.append('<p>'+esc(result.get('status'))+'</p><p>'+esc(result.get('detail'))+'</p>')
        if not result.get('faults'):continue
        parts.append('<table><tr><th>Falta</th><th>Imin inicial (A)</th><th>Imax inicial (A)</th><th>Função</th><th>Tempo total (s)</th><th>∫I²dt (A²s)</th><th>Observação</th></tr>')
        for f in result['faults']:
            parts.append('<tr>'+''.join('<td>'+esc(round(f[k],6) if finite(f.get(k)) else f.get(k))+'</td>' for k in ('fault','imin_a','imax_a','function','clear_s','energy','reason'))+'</tr>')
        parts.append('</table><p>'+esc(result.get('thermal'))+'</p><p>'+esc(result.get('tn'))+'</p>')
    return ''.join(parts)

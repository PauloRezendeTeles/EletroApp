"""Validação elétrica da topologia entre montante e jusante (v1.12).

A verificação da r42 (Identificação dos circuitos!H:K) só confere se o
montante existe, se não há autorreferência e se a ordem é plausível. Aqui se
confere, para cada vínculo, se o montante pode de fato alimentar o circuito:

* fases: o circuito não pode usar mais fases do que o montante distribui;
* neutro: um circuito com neutro (N ou PEN) exige neutro no montante;
* condutor de proteção: o circuito exige PE ou PEN no montante;
* esquema de aterramento: TN-C (PEN) não pode existir a jusante de um trecho
  TN-S — depois de separados, neutro e PE não voltam a ser reunidos;
* PEN: seção mínima de 10 mm² em cobre ou 16 mm² em alumínio (NBR 5410:2004,
  6.4.3.4.1) e proibição de seccionar o PEN (5.6.2.2). Neutro e PE separados não
  voltam a ser reunidos a jusante (6.4.3.4.3). Até a v2.1.2 estas regras citavam o
  5.4.3.6, que trata da separação do PEN na entrada da edificação (TN-C-S).

Os resultados entram nas pendências do circuito e substituem o indicador
"✓ TOPOLOGIA VÁLIDA" quando a ligação é eletricamente incompatível.
"""
from __future__ import annotations

ROOTS = ('Fonte', 'Transformador')
PHASES = {'Monofásico': 1, 'Bifásico': 2, 'Trifásico': 3}


def conductors(tipo):
    """'3F+N+T' → {'fases':3,'neutro':True,'pe':True,'pen':False}. None se desconhecido."""
    if not isinstance(tipo, str) or not tipo or tipo == 'N/A':
        return None
    partes = tipo.split('+')
    try:
        fases = int(partes[0][0])
    except (ValueError, IndexError):
        return None
    pen = 'PEN' in partes
    return {'fases': fases, 'neutro': 'N' in partes or pen, 'pe': 'T' in partes or 'PE' in partes or pen, 'pen': pen}


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def check(child, parent, source_earthing=None, material=None, sec_pen=None, pen_seccionado=False):
    """Problemas elétricos do vínculo ``parent`` → ``child``.

    ``child``/``parent``: dicts com 'name', 'tipo' (ex.: '3F+N+T'), 'phases'
    (Monofásico...) e 'earthing' (TN-S/TN-C). ``parent`` é None para circuitos
    ligados diretamente à fonte."""
    out = []
    c = conductors(child.get('tipo'))
    if c is None:
        return out
    if parent is None:
        if source_earthing == 'TN-S' and c['pen']:
            out.append(f'O circuito usa PEN (TN-C), mas a fonte é TN-S: depois de separados, neutro e PE não podem voltar a ser reunidos.')
    else:
        p = conductors(parent.get('tipo'))
        pname = parent.get('name')
        if p is not None:
            if c['fases'] > p['fases']:
                out.append(f'O circuito usa {c["fases"]} fase(s), mas o montante {pname} distribui só {p["fases"]}.')
            if c['neutro'] and not p['neutro']:
                out.append(f'O circuito exige neutro, mas o montante {pname} não distribui neutro.')
            if c['pe'] and not p['pe']:
                out.append(f'O circuito exige condutor de proteção (PE/PEN), mas o montante {pname} não o distribui.')
            if c['pen'] and not p['pen']:
                out.append(f'O circuito é TN-C (PEN) e o montante {pname} é TN-S: depois de separados, neutro e PE não podem voltar a ser reunidos a jusante (NBR 5410, 6.4.3.4.3).')
    if c['pen']:
        minimo = 16 if material == 'Alumínio' else 10
        if _num(sec_pen) and sec_pen < minimo:
            out.append(f'PEN de {str(sec_pen).replace(".", ",")} mm²: a função PEN exige seção de pelo menos {minimo} mm² em '
                       f'{"alumínio" if minimo == 16 else "cobre"} (NBR 5410, 6.4.3.4.1).')
        if pen_seccionado:
            out.append('O PEN não pode ser seccionado (NBR 5410, 5.6.2.2); a proteção do circuito está marcada como “neutro seccionado”.')
    return out

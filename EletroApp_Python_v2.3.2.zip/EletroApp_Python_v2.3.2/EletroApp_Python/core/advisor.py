"""Assistente heurístico local para proteção, seletividade e DPS.

Escopo e limites, por definição (conforme decisão do usuário):

- 100% local e offline: nenhuma chamada de rede, nenhum modelo generativo,
  nenhuma chave de API. Apenas regras determinísticas sobre os dados já
  presentes no projeto (fórmulas já calculadas) e nos catálogos da base técnica
  (biblioteca de disjuntores WEG e de DPS Clamper/Siemens).
- Papel estritamente consultivo (ver Seção 34 do projeto): este módulo NUNCA
  grava, decide ou substitui uma escolha do projetista. Ele apenas monta
  listas ordenadas de candidatos e textos de pré-verificação para o usuário
  escolher — a escolha final sempre passa pela mesma lista de opções (com a
  opção "Outro/manual") já usada em qualquer campo do formulário.
- Onde o dado necessário para uma verificação seria obtido só por análise de
  texto livre arriscada (ex.: Icu do catálogo, que mistura várias condições
  de tensão em uma única célula descritiva), o módulo NÃO tenta reinterpretar
  esse texto sozinho: mostra o texto original do catálogo e pede conferência
  manual, em vez de arriscar uma comparação de segurança incorreta.
- Seletividade nunca é declarada "total": usa apenas o vocabulário previsto
  na Seção 25 do projeto ("Pré-verificação atendida", "Seletividade
  provável", "Critério instantâneo atendido", "Verificar curva/tabela do
  fabricante"), a partir de uma regra simples e conservadora de razão entre
  correntes — o mesmo critério que a própria Seção 25 autoriza como
  triagem automática, sem prometer mais do que isso entrega.
"""
from __future__ import annotations
from .formula import col_name
from .project import IDENT, RESULTS


def _catalog_rows(project, sheet):
    """Lê uma tabela técnica inteira como lista de dicts {rótulo: valor} (cabeçalho = linha 1)."""
    t = project.model.table(sheet)
    if t is None:
        return []
    headers = {}
    for c in range(1, t.max_col + 1):
        label = project.get(sheet, f'{col_name(c)}1')
        if isinstance(label, str) and label:
            headers[col_name(c)] = label
    out = []
    for r in range(2, t.max_row + 1):
        row = {label: project.get(sheet, col + str(r)) for col, label in headers.items()}
        if any(v not in (None, '') for v in row.values()):
            out.append(row)
    return out


def _num(v):
    return v if isinstance(v, (int, float)) else None


def _get_result(project, key, row):
    sheet, col = RESULTS[key]
    return project.get(sheet, col + str(row))


def _ib(project, row):
    vals = [_num(_get_result(project, k, row)) for k in ('ir', 'is', 'it')]
    vals = [v for v in vals if v is not None]
    return max(vals) if vals else None


def protection_suggestions(project, row, limit=8):
    """Sugere, entre os modelos já disponíveis na família/linha escolhida
    (mesma lista que alimenta o campo 'Modelo/referência'), quais atendem
    Ib ≤ Ir ≤ Iz — ordenados do menor frame adequado para o maior, conforme
    a Seção 21 ('não aumentar indiscriminadamente o In'). Nunca decide Icu
    sozinho: sempre reexibe o texto do catálogo para conferência manual.
    """
    sheet = 'Cálc-Prot_Cabos'
    family = project.raw(sheet, f'AL{row}')
    if not family:
        return {'status': 'sem_familia',
                'message': 'Escolha primeiro a linha/família do disjuntor (campo "Linha/família") — '
                            'a sugestão de modelo depende dessa escolha, do mesmo jeito que a lista nativa da planilha.',
                'items': []}
    ib = _ib(project, row)
    iz = _num(_get_result(project, 'iz', row))
    icc_max = _num(_get_result(project, 'icc_origem', row))
    candidates = project.options(sheet, f'AM{row}')
    if not candidates:
        return {'status': 'sem_candidatos',
                'message': 'Nenhum modelo encontrado no catálogo para esta família. Confira a escolha da família ou consulte o fabricante.',
                'items': []}
    catalog = {r.get('Referência/modelo'): r for r in _catalog_rows(project, 'Biblioteca_Proteções_WEG')}
    items = []
    for model in candidates:
        cat = catalog.get(model)
        if not cat:
            items.append({'modelo': model, 'fit': 'sem_dados', 'nota': 'Modelo não encontrado no catálogo incorporado — conferir manualmente.'})
            continue
        ir_min, ir_max = _num(cat.get('Ir mínimo')), _num(cat.get('Ir máximo'))
        ii_min, ii_max = _num(cat.get('Im/Ii mínimo')), _num(cat.get('Im/Ii máximo'))
        icu_txt = cat.get('Icu')
        item = {'modelo': model, 'familia': cat.get('Família'), 'fabricante': cat.get('Fabricante'),
                'ir_min': ir_min, 'ir_max': ir_max, 'ii_min': ii_min, 'ii_max': ii_max,
                'icu_catalogo': icu_txt,
                'nota_icu': (f'Confirme Icu ≥ Ik,máx do quadro de instalação ({icc_max:g} kA) na condição de tensão real do sistema — '
                             f'o catálogo lista: "{icu_txt}".') if icc_max is not None and icu_txt else
                            'Confirme Icu ≥ Ik,máx do circuito na ficha do fabricante.'}
        if ir_min is None or ir_max is None or ib is None or iz is None:
            item['fit'] = 'dados_insuficientes'
            item['nota_fit'] = 'Dados insuficientes para verificar Ib ≤ Ir ≤ Iz automaticamente.'
        elif ir_max < ib:
            item['fit'] = 'nao_atende'
            item['nota_fit'] = f'Ir máximo do modelo ({ir_max:g} A) é menor que Ib ({ib:g} A) — não atende.'
        elif ir_min > iz:
            item['fit'] = 'nao_atende'
            item['nota_fit'] = f'Mesmo no ajuste mínimo, Ir ({ir_min:g} A) ultrapassa Iz ({iz:g} A) — sobrecarrega o cabo.'
        else:
            lo, hi = max(ir_min, ib), min(ir_max, iz)
            if lo <= hi:
                item['fit'] = 'atende'
                item['nota_fit'] = f'Permite ajustar Ir entre {lo:g} e {hi:g} A, dentro de Ib ≤ Ir ≤ Iz ({ib:g}–{iz:g} A).'
            else:
                item['fit'] = 'nao_atende'
                item['nota_fit'] = 'Faixa de Ir do modelo não intercepta o intervalo [Ib, Iz] do circuito.'
        items.append(item)
    order = {'atende': 0, 'dados_insuficientes': 1, 'sem_dados': 2, 'nao_atende': 3}
    items.sort(key=lambda x: (order.get(x['fit'], 9), x.get('ir_max') if x.get('ir_max') is not None else 1e9))
    return {'status': 'ok', 'ib': ib, 'iz': iz, 'icc_max': icc_max, 'family': family, 'items': items[:limit]}


def selectivity_precheck(project, row):
    """Pré-verificação conservadora de seletividade entre o dispositivo deste
    trecho e o dispositivo que alimenta o quadro a montante, por razão de
    correntes — o próprio critério que a Seção 25 do projeto autoriza como
    triagem, sem declarar 'total'.

    v1.10: os dispositivos considerados são os efetivos (aba Seletividade, colunas
    W/X): um quadro alimentado por circuito sem dispositivo na origem passa a ser
    protegido pelo disjuntor de manutenção desse circuito, ou pelo primeiro
    dispositivo encontrado mais a montante.
    """
    parent_name = project.raw(IDENT, f'D{row}')
    if not parent_name or parent_name in ('Fonte', 'Transformador'):
        return {'status': 'sem_montante', 'message': 'Este circuito não possui proteção a montante modelada para comparar.'}
    if not any(project.raw(IDENT, f'B{r}') == parent_name for r in project.active_rows()):
        return {'status': 'sem_montante', 'message': 'Circuito a montante não encontrado.'}
    S = 'Seletividade'
    down = project.get(S, f'X{row}')
    up = project.get(S, f'W{row}')
    if isinstance(down, str) and down.startswith('Sem dispositivo'):
        return {'status': 'sem_dispositivo', 'message': 'Este trecho não tem dispositivo próprio; a seletividade é verificada nos quadros vizinhos.'}
    if not up:
        return {'status': 'sem_montante', 'message': 'Nenhum dispositivo de proteção de baixa tensão a montante deste quadro.'}
    ir_down, ii_down = _num(project.get(S, f'L{row}')), _num(project.get(S, f'O{row}'))
    ir_up, ii_up = _num(project.get(S, f'M{row}')), _num(project.get(S, f'P{row}'))
    pair = f'{up} × {down}: '
    if ir_down is None or ir_up is None:
        return {'status': 'dados_insuficientes', 'message': pair + 'defina os ajustes dos dois dispositivos para pré-verificar a seletividade.'}
    if ir_up <= ir_down:
        return {'status': 'atencao', 'label': '✗ Verificar seletividade invertida',
                'message': pair + f'a proteção a montante (Ir {ir_up:g} A) não é superior à de jusante (Ir {ir_down:g} A) — '
                            'risco de seletividade invertida ou atuação simultânea. Revisar as duas escolhas.'}
    ratio_ii = (ii_up / ii_down) if (ii_up and ii_down) else None
    ratio_ir = ir_up / ir_down
    if ratio_ii is not None and ratio_ii >= 2:
        return {'status': 'provavel', 'label': 'Critério instantâneo atendido',
                'message': pair + f'Ii a montante é {ratio_ii:.1f}× o de jusante (≥ 2×) — critério instantâneo atendido. '
                            'Indicativo; verificar curva/tabela do fabricante para confirmar a faixa completa.'}
    if ratio_ir >= 1.6:
        return {'status': 'provavel', 'label': 'Seletividade provável',
                'message': pair + f'Ir a montante é {ratio_ir:.1f}× o de jusante — seletividade provável pela razão de correntes. '
                            'Verificar curva/tabela do fabricante para confirmação.'}
    return {'status': 'verificar', 'label': 'Verificar curva/tabela do fabricante',
            'message': pair + f'razão de correntes (montante/jusante ≈ {ratio_ir:.2f}) não é folgada o suficiente para uma '
                        'pré-verificação conclusiva. Consultar curva tempo×corrente ou tabela de seletividade do fabricante.'}


def dps_candidates(project, row, limit=6):
    """Lista candidatos de DPS do catálogo incorporado cujo esquema de
    aterramento bate com o do circuito — para o usuário escolher e
    preencher o campo manual. Não decide Tipo 1/2/3 nem confirma
    coordenação entre estágios: a Seção 26 exige dado de fabricante para
    isso, que este módulo não possui.
    """
    earthing = project.raw(IDENT, f'F{row}')
    status_txt = _get_result(project, 'dps_status', row)
    out = []
    for sheet in ('Biblioteca_DPS_Clamper', 'Biblioteca_DPS_Siemens'):
        if project.model.table(sheet) is None:
            continue
        for cat in _catalog_rows(project, sheet):
            scheme = cat.get('Sistema de aterramento')
            if earthing and scheme and scheme != earthing:
                continue
            out.append({'fabricante': cat.get('Fabricante'), 'linha': cat.get('Linha'), 'codigo': cat.get('Código'),
                         'classe': cat.get('Classe/Tipo'), 'uc': cat.get('Uc'), 'iimp': cat.get('Iimp (10/350µs)'),
                         'in_': cat.get('In (8/20µs)'), 'fonte': sheet.replace('Biblioteca_DPS_', '')})
    return {'status': 'ok' if out else 'sem_candidatos', 'earthing': earthing,
            'status_atual': status_txt if isinstance(status_txt, str) else None,
            'items': out[:limit],
            'message': None if out else 'Nenhum candidato do catálogo incorporado bate com o esquema de aterramento deste circuito — consultar fabricante.'}


def advise(project, row):
    return {'protecao': protection_suggestions(project, row),
            'seletividade': selectivity_precheck(project, row),
            'dps': dps_candidates(project, row)}

"""Integridade das expressões e das tabelas de um projeto (v2.0, modelo nativo).

A referência é o modelo nativo do aplicativo (``data/modelo``) e a base técnica
(``data/tabelas``), que não são gravados no projeto. O projeto guarda apenas o
que difere da referência: versões de expressões (``doc['formulas']``) e edições
de tabelas (``doc['tabelas']``). Cada versão registrada pelo aplicativo recebe
um selo (resumo criptográfico dos seus campos). Ao abrir o projeto, toda versão
sem selo válido — editada no arquivo .eletro, no banco ou herdada de um projeto
antigo com fórmulas diferentes sem registro — aparece como "alterada fora do
aplicativo".

O selo detecta alterações acidentais ou feitas por fora do fluxo de revisão;
não é uma assinatura digital e não impede uma falsificação deliberada.

Situações:

* ``modelo``          — expressão do modelo nativo (nada gravado no projeto);
* ``editada``         — versão registrada pelo revisor, com selo válido;
* ``alterada``        — versão sem selo válido ou marcada como externa;
* ``desconhecida``    — expressão para uma variável que não existe no modelo;
* ``invalida``        — registro corrompido (versão ativa inexistente, expressão ilegível);
* ``tabela_editada``  — edição de tabela técnica registrada, com selo válido;
* ``tabela_alterada`` — edição de tabela sem selo válido;
* ``dado_ignorado``   — valor gravado sobre uma variável calculada (o motor o ignora).
"""
from __future__ import annotations

import hashlib
import json
import re

LABELS = {'modelo': 'Expressão do modelo do aplicativo', 'editada': 'Editada pelo revisor (registrada)',
          'alterada': 'Alterada fora do aplicativo', 'desconhecida': 'Variável desconhecida',
          'invalida': 'Registro de versão inválido', 'tabela_editada': 'Tabela editada pelo revisor (registrada)',
          'tabela_alterada': 'Tabela alterada fora do aplicativo', 'dado_ignorado': 'Valor fixo sobre variável calculada (ignorado)',
          'fabricante_registrado': 'Dados de fabricante importados (registrados)',
          'fabricante_alterado': 'Dados de fabricante alterados fora do aplicativo (desconsiderados na coordenação)',
          'base_diferente': 'Base de cálculo diferente da registrada no projeto',
          'conversao_pendente': 'Fórmula de projeto antigo não convertida (conferir)'}
PROBLEMS = ('alterada', 'desconhecida', 'invalida', 'tabela_alterada', 'dado_ignorado', 'fabricante_alterado', 'base_diferente',
            'conversao_pendente')
_SEALED_OUT = ('selo', 'impacto')


def seal(kind, key, entry):
    """Selo de uma versão: resumo dos campos registrados (exceto o próprio selo e o impacto calculado)."""
    body = {k: v for k, v in entry.items() if k not in _SEALED_OUT}
    raw = json.dumps([kind, key, body], ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str)
    return hashlib.blake2b(raw.encode(), digest_size=16, person=b'eletroapp-v2').hexdigest()


def stamp(kind, key, entry):
    entry['selo'] = seal(kind, key, entry)
    return entry


def valid(kind, key, entry):
    return isinstance(entry, dict) and entry.get('tipo') != 'externa' and entry.get('selo') == seal(kind, key, entry)


def _slot_status(var_id, kind, cid, slot):
    from .formula import parse
    from .versoes import seal_key
    versions = slot.get('versoes') if isinstance(slot, dict) else None
    n = slot.get('ativa', 0) if isinstance(slot, dict) else None
    if not isinstance(versions, list) or not isinstance(n, int) or not 0 <= n <= len(versions):
        return 'invalida'
    if n == 0:
        return 'modelo'
    active = versions[n - 1]
    try:
        parse(str(active.get('expressao')))
    except Exception:
        return 'invalida'
    return 'editada' if valid('formula', seal_key(var_id, kind, cid), active) else 'alterada'


RANK = {'modelo': 0, 'editada': 1, 'alterada': 2, 'invalida': 3, 'desconhecida': 4}


def scope_statuses(p, var_id):
    """[(escopo, circuito_id, situação)] de todos os escopos registrados de uma variável."""
    from .versoes import scopes
    top = p.doc['formulas'].get(var_id)
    var = p.model.by_id.get(var_id)
    if not top:
        return []
    if var is None or var.kind != 'formula':
        return [('comum', None, 'desconhecida')]
    if not isinstance(top, dict):
        return [('comum', None, 'invalida')]
    out = []
    if 'versoes' in top or 'ativa' in top:
        out.append(('comum', None, _slot_status(var_id, 'comum', None, top)))
    for kind, cid, slot in scopes(top):
        if kind != 'comum':
            if kind == 'raiz' and not var.variants.get('raiz'):
                out.append((kind, cid, 'invalida'))
            else:
                out.append((kind, cid, _slot_status(var_id, kind, cid, slot)))
    return out


def formula_status(p, var_id, escopo=None):
    """Situação da expressão de uma variável: a pior entre os escopos registrados (ou de um escopo específico)."""
    st = scope_statuses(p, var_id)
    if escopo is not None:
        from .versoes import parse_scope
        kind, cid = parse_scope(escopo)
        st = [x for x in st if x[0] == kind and x[1] == cid]
    if not st:
        return 'modelo'
    return max((x[2] for x in st), key=lambda k: RANK[k])


def table_status(p, table_id):
    ed = p.doc['tabelas'].get(table_id)
    if not ed:
        return None
    if table_id not in p.model.tables:
        return 'desconhecida'
    versions = ed.get('versoes') or []
    if not versions:
        return 'tabela_alterada'
    last = versions[-1]
    # O selo da última versão cobre o conteúdo completo das células editadas.
    ok = valid('tabela', table_id, last) and last.get('conteudo') == content_hash(ed.get('celulas', {}))
    if ok and not ed.get('celulas'):
        return None  # edições desfeitas: a tabela voltou à base do aplicativo
    return 'tabela_editada' if ok else 'tabela_alterada'


def content_hash(cells):
    raw = json.dumps(cells, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str)
    return hashlib.blake2b(raw.encode(), digest_size=16).hexdigest()


def report(p, limit=300):
    counts = {k: 0 for k in LABELS}
    items = []

    def add(kind, **info):
        counts[kind] += 1
        if kind in PROBLEMS and len(items) < limit:
            items.append({'situacao': kind, 'rotulo': LABELS[kind], **info})
    names = {c['id']: c['entradas'].get('ident.nome') for c in p.circuits_doc}
    for vid in sorted(p.doc['formulas']):
        var = p.model.by_id.get(vid)
        top = p.doc['formulas'][vid]
        for kind, cid, st in scope_statuses(p, vid):
            expr = None
            try:
                from .versoes import get_slot, active
                expr = active(get_slot(p.doc['formulas'], vid, kind, cid)) if isinstance(top, dict) else None
            except Exception:
                pass
            add(st, variavel=vid, descricao=var.label if var else vid, expressao=expr, escopo_versao=kind,
                circuito=names.get(cid) if kind == 'circuito' else ('circuitos ligados à fonte' if kind == 'raiz' else None),
                escopo=var.scope if var else None, n_circuitos=len(p.circuits_doc) if var is not None and var.scope == 'circuito' else None)
    counts['modelo'] = sum(1 for v in p.model.by_id.values() if v.kind == 'formula' and formula_status(p, v.id) == 'modelo')
    for tid in sorted(p.doc['tabelas']):
        kind = table_status(p, tid)
        if kind is None:
            continue
        t = p.model.tables.get(tid)
        add(kind, tabela=tid, descricao=t.name if t else tid, celulas=len(p.doc['tabelas'][tid].get('celulas', {})))
    formula_ids = {v.id for v in p.model.by_id.values() if v.kind == 'formula'}
    for c in p.circuits_doc:
        bad = [k for k in c['entradas'] if k in formula_ids or k not in p.model.by_id]
        for k in bad:
            add('dado_ignorado', variavel=k, circuito=c['entradas'].get('ident.nome'),
                descricao=p.model.by_id[k].label if k in p.model.by_id else k)
    for k in p.doc['fonte']:
        if k in formula_ids or k not in p.model.by_id:
            add('dado_ignorado', variavel=k, circuito=None, descricao=p.model.by_id[k].label if k in p.model.by_id else k)
    curves = p.meta.get('curvas') if isinstance(p.meta.get('curvas'), list) else []
    for item in curves:
        ok = isinstance(item, dict) and valid('dados_fabricante', str(item.get('id')), item)
        add('fabricante_registrado' if ok else 'fabricante_alterado', dados_fabricante=item.get('id') if isinstance(item, dict) else None,
            descricao=(item.get('descricao') or item.get('documento')) if isinstance(item, dict) else 'registro inválido')
    mig = p.meta.get('migracao') if isinstance(p.meta.get('migracao'), dict) else {}
    for item in mig.get('nao_convertidas') or []:
        if not item.get('conferido_por'):
            add('conversao_pendente', variavel=item.get('variavel'), circuito=item.get('circuito'), circuito_id=item.get('circuito_id'),
                descricao=item.get('motivo'),
                expressao=item.get('formula_original'))
    base = base_check(p)
    if base:
        add('base_diferente', descricao=base['descricao'], componentes=base['componentes'])
    problems = sum(counts[k] for k in PROBLEMS)
    return {'situacao': 'ok' if not problems else 'alterada', 'problemas': problems, 'contagem': counts, 'rotulos': LABELS,
            'itens': items, 'truncado': problems > len(items),
            'referencia': 'Modelo nativo do EletroApp (variáveis nomeadas) e base técnica versionada'}


def base_record(manifest):
    """O que o projeto guarda da base em que foi revisado (o retrato completo fica no arquivo de bases do aplicativo)."""
    return {'hash': manifest['hash'], 'app': manifest['app'], 'dados': manifest['dados'], 'codigo': manifest['codigo'],
            'componentes': manifest['componentes']}


def base_check(p):
    """Diferença entre a base registrada no projeto e a base em uso. None quando conferem (ou sem registro ainda)."""
    rec = p.doc.get('base')
    if not isinstance(rec, dict) or not rec.get('hash'):
        return None
    cur = p.model.manifest()
    if cur['hash'] == rec.get('hash'):
        return None
    old = rec.get('componentes') or {}
    changed = sorted(k for k in set(old) | set(cur['componentes']) if old.get(k) != cur['componentes'].get(k))
    return {'descricao': f"Projeto revisado com a base {str(rec.get('hash'))[:10]} (EletroApp {rec.get('app')}); em uso: "
                         f"{cur['hash'][:10]} (EletroApp {cur['app']}). Componentes diferentes: " + ', '.join(changed),
            'componentes': changed, 'registrada': rec.get('hash'), 'atual': cur['hash']}


def cell_status(p, sheet, addr):
    """Situação da expressão de um dado (trilha de cálculo)."""
    from .catalog import INSTALL_COLUMNS
    var = p.var_at(sheet, addr)
    if var is None:
        t = p.model.table(sheet)
        if t is None:
            return None
        kind = table_status(p, t.id) or 'modelo'
        return {'situacao': kind, 'rotulo': LABELS.get(kind, 'Tabela da base técnica')}
    if var.kind != 'formula':
        return None
    if var.scope == 'circuito' and (var.sheet, var.col) in INSTALL_COLUMNS:
        return {'situacao': 'regra_aplicativo', 'rotulo': 'Regra do aplicativo (Python)'}
    row = int(re.sub(r'[^0-9]', '', addr) or 0) if var.scope == 'circuito' else None
    escopo = p.expression_scope(var, row)
    kind = formula_status(p, var.id, escopo)
    out = {'situacao': kind, 'rotulo': LABELS[kind], 'escopo_versao': escopo}
    if kind == 'modelo' and escopo == 'raiz':
        out['rotulo'] = 'Variante do modelo para circuito ligado à fonte'
    return out


def summary(p):
    r = report(p)
    c = r['contagem']
    return {'situacao': r['situacao'], 'problemas': r['problemas'],
            'alteradas': c['alterada'] + c['desconhecida'] + c['invalida'] + c['tabela_alterada'] + c['dado_ignorado'] + c['fabricante_alterado']
                         + c['conversao_pendente'],
            'base_diferente': c['base_diferente'],
            'editadas': c['editada'] + c['tabela_editada'], 'inativas': 0}

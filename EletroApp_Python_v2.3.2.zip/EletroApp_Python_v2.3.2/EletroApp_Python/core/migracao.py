"""Conversão de projetos da v1.x (planilha r42 interpretada) para o formato nativo (v2.0).

O projeto antigo guarda as 60 abas com todas as fórmulas. A conversão:

1. aplica as adaptações da v1.12 (as mesmas que o aplicativo aplicava ao abrir);
2. copia os dados de entrada de cada circuito e da fonte para as variáveis nomeadas;
3. compara cada fórmula do projeto com a do modelo nativo. Uma fórmula editada pelo
   revisor (histórico do catálogo) vira uma versão da variável, com autor, data e
   justificativa; uma fórmula diferente sem registro é preservada como
   "alterada fora do aplicativo" e aparece na conferência de integridade;
4. compara as tabelas técnicas com a base do aplicativo e preserva as diferenças
   como edições da tabela no projeto;
5. registra o que foi feito em ``meta['migracao']``.
"""
from __future__ import annotations

import copy
import datetime as dt
import json
import re
from pathlib import Path
import unicodedata
import uuid

from .formula import address, col_name, parse
from .expressao import text, transform
from .motor import ROOTS, model
from .integridade import stamp

IDENT = 'Identificação dos circuitos'
FONTE = 'Padrão de entrada'
DROPPED_PREFIX = ('Memorial-', 'Auditoria_Seleção')
# Colunas reescritas pelo próprio aplicativo a cada abertura (regras em Python) e a posição.
APP_MANAGED = {('Identificação dos circuitos', 'A'), ('Cálc_Icc-Cond_Sugerido', 'A'), ('Cálc_Icc-Cond_Escolhido', 'A')}


def _now():
    return dt.datetime.now().astimezone().isoformat(timespec='seconds')


def rewrite_legacy(formula, sheet, row):
    """Fórmula em células → expressão nomeada do motor nativo. ValueError se não houver equivalente."""
    m = model()

    def ref(n):
        if n[0] != 'ref':
            return n
        ts = n[1] or sheet
        a, b = n[2].replace('$', ''), n[3].replace('$', '')
        r1, c1 = address(a)
        r2, c2 = address(b)
        if ts in m.circuit_sheet_set:
            fx = m.fixed.get((ts, a))
            if fx is not None and r1 == r2 and c1 == c2:
                return ('name', fx.id)
            var1 = m.by_legacy.get((ts, col_name(c1)))
            var2 = m.by_legacy.get((ts, col_name(c2)))
            if var1 is None or var2 is None:
                if r1 == r2 == 1:
                    return ('lit', var1.header if var1 else None)
                raise ValueError(f'{ts}!{a}: coluna sem variável no modelo')
            if r1 == r2 and c1 == c2:
                if r1 == row or (r1 == 2 and row == 2):
                    return ('name', var1.id)
                if r1 == row - 1:
                    return ('call', 'ANTERIOR', (('name', var1.id),))
                if r1 == 1:
                    return ('lit', var1.header)
                raise ValueError(f'{ts}!{a}: referência a outra linha')
            if r1 == r2:
                if r1 != row:
                    raise ValueError(f'{ts}!{a}:{b}: faixa em outra linha')
                return ('call', 'FAIXA', (('name', var1.id), ('name', var2.id)))
            if r1 <= 3 and r2 >= 100:
                args = (('name', var1.id),) + ((('name', var2.id),) if c2 != c1 else ())
                return ('call', 'CIRCUITOS', args)
            raise ValueError(f'{ts}!{a}:{b}: intervalo sem equivalente')
        if ts in m.fixed_sheets and ts not in m.circuit_sheet_set:
            if (r1, c1) != (r2, c2):
                raise ValueError(f'{ts}!{a}:{b}: intervalo na fonte')
            fx = m.fixed.get((ts, a))
            return ('name', fx.id) if fx else ('lit', None)
        t = m.table(ts)
        if t is not None:
            return ('ref', t.id, n[2], n[3])
        if ts.startswith(DROPPED_PREFIX):
            return ('lit', None)
        raise ValueError(f'{ts}: aba desconhecida')
    return text(transform(parse(formula), ref))


def _slug(textv):
    t = unicodedata.normalize('NFKD', textv).encode('ascii', 'ignore').decode()
    t = re.sub(r'[^0-9A-Za-z]+', '-', t.strip().casefold())
    return t.strip('-') or 'aba'


def legacy_entry_map():
    """Identificador do catálogo da v1.x (aba-coluna) → variável nativa."""
    m = model()
    out = {}
    for v in m.circuit:
        out[f'{_slug(v.sheet)}-{v.col}'] = v.id
    for v in m.fonte + m.project:
        col = re.match(r'[A-Z]+', v.addr)[0]
        out[f'{_slug(v.sheet)}-{col}-L{address(v.addr)[0]}'] = v.id
    return out


def _legacy_variants():
    path = Path(__file__).resolve().parent.parent / 'data' / 'modelo' / 'variantes_legado.json'
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding='utf-8')).get('variantes', {})
    return {vid: {e: set(rows) for e, rows in d.items()} for vid, d in data.items()}


def _legacy_fixed():
    path = Path(__file__).resolve().parent.parent / 'data' / 'modelo' / 'variantes_legado.json'
    return json.loads(path.read_text(encoding='utf-8')).get('variantes_fixas', {})


def _legacy_data():
    path = Path(__file__).resolve().parent.parent / 'data' / 'modelo' / 'variantes_legado.json'
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}


def _legacy_fonte_exprs():
    """v2.2.0: expressões anteriores das variáveis da fonte e do projeto, reconhecidas como do modelo (não como alteração)."""
    out = {}
    for vid, exprs in (_legacy_data().get('variantes_fonte') or {}).items():
        parsed = set()
        for e in exprs:
            try:
                parsed.add(parse(e))
            except Exception:
                continue
        out[vid] = parsed
    return out


def _same_formula(known, formula):
    """Fórmula registrada como valor anterior da base (texto que começa com “=”) equivalente à da planilha."""
    if not isinstance(known, str) or not known.startswith('='):
        return False
    try:
        return parse(known) == parse(formula)
    except Exception:  # noqa: BLE001
        return False


def _legacy_table_values():
    """v2.2.0: valores anteriores da base técnica por célula. Uma planilha da v1.x com o valor antigo segue a base corrigida;
    só um valor diferente da base atual e de todas as anteriores é preservado como edição do projeto."""
    return _legacy_data().get('tabelas') or {}


def _literal(value):
    if isinstance(value, bool):
        return 'TRUE' if value else 'FALSE'
    if isinstance(value, (int, float)):
        return repr(value)
    return '"' + str(value).replace('"', '""') + '"'


_ROWTOKEN = re.compile(r'\{row(?:([+-])(\d+))?\}')


def _expand(template, row):
    return _ROWTOKEN.sub(lambda m: str(row + (int(m[2]) * (1 if m[1] == '+' else -1) if m[1] else 0)), template)


def _registered(slot, v, rows):
    """Histórico de edições do catálogo da v1.x convertido em expressões nativas: {'versoes': [...], 'active': expr}."""
    if not slot:
        return None
    row = address(v.addr)[0] if v.scope != 'circuito' else next((r for r in rows if r >= 4), rows[0] if rows else 4)
    out = []
    for x in slot.get('versoes', []):
        tpl = x.get('template') or x.get('expressao')
        try:
            expr = rewrite_legacy(_expand(str(tpl), row), v.sheet, row) if tpl else None
        except ValueError:
            expr = None
        out.append({**{k: x.get(k) for k in ('versao', 'tipo', 'autor', 'ts', 'justificativa', 'impacto')},
                    'expressao': expr, 'original': copy.deepcopy(x)})
    n = slot.get('ativa', 0)
    active = v.expr if n == 0 else (out[n - 1]['expressao'] if isinstance(n, int) and 0 < n <= len(out) else None)
    return {'versoes': out, 'active': active, 'ativa': n}


def _store(doc, vid, kind, cid, expr, registered, log, motivo=None):
    """Grava a versão convertida no escopo; edições registradas na v1.x preservam todo o histórico (com selo)."""
    from . import versoes
    slot = versoes.get_slot(doc['formulas'], vid, kind, cid, create=True)
    esc = versoes.scope_name(kind, cid)
    key = versoes.seal_key(vid, kind, cid)
    if registered:
        hist, mapping = [], {}
        for index, x in enumerate(registered['versoes'], 1):
            if not x['expressao']:
                pending = {'variavel': vid, 'circuito_id': cid, 'escopo': esc,
                           'motivo': f'Histórico da v1.x: versão {x.get("versao") or index} sem equivalente nativo; original preservado.',
                           'formula_original': str(x.get('original', {}).get('template') or x.get('original', {}).get('expressao')),
                           'versao_legada': index}
                if pending not in log['nao_convertidas']:
                    log['nao_convertidas'].append(pending)
                continue
            entry = {'versao': len(hist) + 1, 'expressao': x['expressao'], 'ts': x.get('ts') or _now(), 'escopo': esc,
                     'tipo': x.get('tipo') or 'edicao', 'autor': x.get('autor'),
                     'justificativa': x.get('justificativa') or 'Edição registrada na v1.x', 'impacto': x.get('impacto')}
            entry['versao_legada'] = x.get('versao') or index
            hist.append(stamp('formula', key, entry))
            mapping[index] = len(hist)
        slot['versoes'] = hist
        slot['ativa'] = mapping.get(registered['ativa'], 0)
        if vid not in log['formulas_editadas']:
            log['formulas_editadas'].append(vid)
        return
    entry = {'versao': len(slot['versoes']) + 1, 'expressao': expr, 'ts': _now(), 'escopo': esc, 'tipo': 'externa', 'autor': None,
             'justificativa': motivo or ('Fórmula diferente da referência encontrada ao converter o projeto da v1.x, sem edição registrada'
                                         + ('' if kind == 'comum' else ' (alteração particular deste escopo).' if kind == 'circuito' else
                                            ' (variante dos circuitos ligados à fonte).'))}
    slot['versoes'].append(entry)
    slot['ativa'] = entry['versao']
    if kind != 'circuito' and vid not in log['formulas_alteradas']:
        log['formulas_alteradas'].append(vid)


def _patch(data):
    from . import nc_patch, dps_patch, catalog_icu, motors, selection, trecho
    from .installation import patch_workbook
    nc_patch.apply(data)
    dps_patch.apply(data)
    catalog_icu.apply(data)
    motors.apply(data)
    selection.install(data)
    trecho.apply(data)
    patch_workbook(data)


def from_workbook(data):
    """Projeto da v1.x (dicionário com 'sheets') → documento nativo."""
    m = model()
    data = data if isinstance(data, dict) else {}
    if 'sheets' not in data or IDENT not in data['sheets']:
        raise ValueError('Projeto antigo sem a aba de identificação dos circuitos.')
    _patch(data)
    sheets = data['sheets']
    meta = copy.deepcopy(data.get('meta') or {})
    log = {'origem': 'Projeto da versão 1.x (modelo r42)', 'data': _now(), 'formulas_editadas': [], 'formulas_alteradas': [],
           'tabelas_alteradas': [], 'avisos': []}
    ids = meta.get('ids') if isinstance(meta.get('ids'), dict) else {}
    ident = sheets[IDENT]['cells']
    rows = [r for r in range(2, 102) if ident.get(f'B{r}', {}).get('value') not in (None, '')]

    def val(sheet, a):
        return sheets.get(sheet, {}).get('cells', {}).get(a, {}).get('value')

    def is_formula(sheet, a):
        return bool(sheets.get(sheet, {}).get('cells', {}).get(a, {}).get('formula'))

    circuits = []
    for r in rows:
        entradas = {}
        for v in m.inputs:
            if v.sheet == 'Levantamento de carga' and r < 4:
                continue  # linhas 2 e 3 da r42 guardavam subtítulos, não dados
            a = f'{v.col}{r}'
            if is_formula(v.sheet, a):
                continue
            x = val(v.sheet, a)
            if x not in (None, ''):
                entradas[v.id] = copy.deepcopy(x)
        uid = ids.get(str(r))
        if not isinstance(uid, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', uid):
            uid = uuid.uuid4().hex
        circuits.append({'id': uid, 'entradas': entradas})
    fonte = {}
    for v in m.fonte:
        if v.kind == 'entrada':
            x = val(FONTE, v.addr)
            if x is not None:
                fonte[v.id] = copy.deepcopy(x)
    doc = {'formato': 'eletroapp-projeto', 'versao': 2, 'semantica_formulas': 'escopos-v1', 'meta': {}, 'fonte': fonte, 'circuitos': circuits,
           'formulas': {}, 'tabelas': {}}
    # ---- fórmulas ------------------------------------------------------
    # v2.1: cada fórmula é comparada circuito a circuito. Alteração comum a todos vira versão comum (ou da variante
    # dos circuitos ligados à fonte); alteração particular vira versão daquele circuito; o que não tem equivalente
    # nativo é listado como conversão pendente (aparece na integridade), nunca descartado em silêncio.
    old_versions = meta.pop('formula_versions', {}) or {}
    if old_versions:
        meta['historico_legado'] = copy.deepcopy(old_versions)
    entry_map = legacy_entry_map()
    edited_vars = {}
    for eid, slot in old_versions.items():
        base = re.sub(r'-L\d+$', '', eid)
        vid = entry_map.get(eid) or entry_map.get(base)
        if vid and isinstance(slot, dict) and slot.get('versoes'):
            edited_vars[vid] = slot
    known = _legacy_variants()
    log['formulas_particulares'] = []
    log['nao_convertidas'] = []
    uid_at = {r: circuits[i]['id'] for i, r in enumerate(rows)}
    root_rows = {r for r in rows if val(IDENT, f'D{r}') in ROOTS}
    from .catalog import INSTALL_COLUMNS
    for v in m.circuit:
        if v.kind != 'formula' or (v.sheet, v.col) in APP_MANAGED or (v.sheet, v.col) in INSTALL_COLUMNS:
            continue
        cells = sheets.get(v.sheet, {}).get('cells', {})
        found = {}
        for r in rows:
            if v.sheet == 'Levantamento de carga' and r < 4:
                continue  # linhas 2 e 3 da r42 guardavam subtítulos nesta aba
            raw_cell = cells.get(f'{v.col}{r}')
            root = r in root_rows and bool(v.variants.get('raiz'))
            expected = v.variants['raiz'] if root else v.expr
            if raw_cell is None or (not raw_cell.get('formula') and raw_cell.get('value') in (None, '')):
                if r in known.get(v.id, {}).get('', ()):
                    continue  # célula vazia também na planilha de origem (subtítulo ou linha estrutural)
                log['nao_convertidas'].append({'variavel': v.id, 'circuito': val(IDENT, f'B{r}'), 'circuito_id': uid_at[r],
                                               'motivo': 'Célula vazia no lugar da fórmula; mantida a expressão do modelo.', 'formula_original': None})
                continue
            if raw_cell.get('formula'):
                try:
                    expr = rewrite_legacy(raw_cell['value'], v.sheet, r)
                except ValueError as e:
                    log['nao_convertidas'].append({'variavel': v.id, 'circuito': val(IDENT, f'B{r}'), 'circuito_id': uid_at[r],
                                                   'motivo': f'Fórmula sem equivalente nativo ({e}); mantida a expressão do modelo.',
                                                   'formula_original': str(raw_cell['value'])[:500]})
                    continue
                if parse(expr) == parse(expected) or r in known.get(v.id, {}).get(expr, ()):
                    continue
            else:
                expr = '=' + _literal(raw_cell.get('value'))
                if r in known.get(v.id, {}).get(expr, ()):
                    continue
            found[r] = (expr, root, raw_cell.get('formula'))
        registered = _registered(edited_vars.get(v.id), v, rows)
        if registered:
            _store(doc, v.id, 'comum', None, v.expr, {**registered, 'ativa': 0}, log)
        if not found:
            continue
        for root_group in (False, True):
            group_rows = [r for r in rows if (r in root_rows and bool(v.variants.get('raiz'))) == root_group
                          and not (v.sheet == 'Levantamento de carga' and r < 4)]
            diff = {r: found[r] for r in group_rows if r in found}
            if not diff:
                continue
            exprs = {parse(e) for e, _, _ in diff.values()}
            kind = 'raiz' if root_group else 'comum'
            everywhere = len(diff) == len(group_rows) and len(exprs) == 1 and len(group_rows) > 1
            reg_ok = registered and registered['active'] and not root_group and any(parse(e) == parse(registered['active']) for e, _, _ in diff.values())
            if everywhere or reg_ok:
                common = registered['active'] if reg_ok else next(iter(diff.values()))[0]
                _store(doc, v.id, kind, None, common, registered if reg_ok else None, log)
                rest = {r: x for r, x in diff.items() if parse(x[0]) != parse(common)}
                # Circuitos do grupo que tinham a fórmula do modelo continuam com ela (versão própria).
                for r in group_rows:
                    if r not in diff:
                        rest[r] = (v.variants['raiz'] if root_group else v.expr, root_group, True)
            else:
                rest = diff
            for r, (expr, _, was_formula) in rest.items():
                _store(doc, v.id, 'circuito', uid_at[r], expr, None, log,
                       motivo=None if was_formula else 'Valor fixo no lugar da fórmula no projeto da v1.x.')
                log['formulas_particulares'].append({'variavel': v.id, 'circuito': val(IDENT, f'B{r}')})
    fixed_defaults = _legacy_fixed()
    known_fonte = _legacy_fonte_exprs()
    for v in m.fonte + m.project:
        if v.kind != 'formula':
            continue
        registered = _registered(edited_vars.get(v.id), v, rows)
        if registered:
            _store(doc, v.id, 'comum', None, v.expr, {**registered, 'ativa': 0}, log)
        f = val(v.sheet, v.addr)
        cell = sheets.get(v.sheet, {}).get('cells', {}).get(v.addr)
        label = 'Fonte' if v.scope == 'fonte' else 'Projeto'
        expected = fixed_defaults.get(v.id)
        if expected and cell and cell.get('formula') == expected['formula'] and cell.get('value') == expected['value']:
            log.setdefault('consultas_legadas', []).append({'variavel': v.id, 'original': copy.deepcopy(expected),
                'motivo': 'Verificação documental da planilha original, substituída pela verificação nativa.'})
            continue
        if not is_formula(v.sheet, v.addr):
            if f in (None, ''):
                if cell is not None:
                    log['nao_convertidas'].append({'variavel': v.id, 'circuito': label, 'circuito_id': None,
                        'motivo': 'Célula vazia no lugar da fórmula da fonte/projeto; mantida a expressão do modelo.', 'formula_original': f})
                continue
            expr = '=' + _literal(f)
        else:
            try:
                expr = rewrite_legacy(f, v.sheet, address(v.addr)[0])
            except ValueError as e:
                log['nao_convertidas'].append({'variavel': v.id, 'circuito': label, 'circuito_id': None,
                    'motivo': f'Fórmula da fonte/projeto sem equivalente nativo ({e}); mantida a expressão do modelo.',
                    'formula_original': str(f)})
                continue
        if parse(expr) == parse(v.expr) or parse(expr) in known_fonte.get(v.id, ()):
            continue
        if 'Memorial' in str(f):
            log['nao_convertidas'].append({'variavel': v.id, 'circuito': label, 'circuito_id': None,
                'motivo': 'Fórmula dependente do memorial legado; mantida a expressão do modelo para conferência.', 'formula_original': str(f)})
            continue
        reg = registered if registered and registered['active'] and parse(expr) == parse(registered['active']) else None
        _store(doc, v.id, 'comum', None, expr, reg, log,
               motivo=None if is_formula(v.sheet, v.addr) else 'Valor fixo da fonte/projeto preservado da v1.x.')
    # ---- tabelas -------------------------------------------------------
    previous_values = _legacy_table_values()
    for t in m.tables.values():
        legacy = sheets.get(t.legacy)
        if not legacy:
            continue
        changed = {}
        cells = legacy['cells']
        known = previous_values.get(t.id) or {}
        for a in set(cells) | set(t.cells):
            c = cells.get(a)
            base = t.cells.get(a)
            if c is None or (c.get('value') in (None, '') and not c.get('formula')):
                if base is not None and base.get('v') is not None:
                    if None in known.get(a, ()):
                        continue  # célula criada numa revisão posterior da base (v2.2.0+)
                    changed[a] = {'v': None}
                continue
            if c.get('formula'):
                try:
                    cell = {'f': rewrite_legacy(c['value'], t.legacy, address(a)[0])}
                except ValueError:
                    continue
                if base and 'f' in base and parse(base['f']) == parse(cell['f']):
                    continue
                if base and 'f' in base and any(_same_formula(k, cell['f']) for k in known.get(a, ())):
                    continue  # fórmula da base anterior (trocada numa revisão posterior): o projeto segue a base atual
            else:
                cell = {'v': c.get('value')}
                if base and base.get('v') == cell['v'] and 'f' not in base:
                    continue
                if (base is None or 'f' not in base) and cell['v'] in known.get(a, ()):
                    continue  # valor da base anterior (corrigido numa revisão posterior): o projeto segue a base atual
            changed[a] = cell
        if changed:
            doc['tabelas'][t.id] = {'celulas': changed, 'versoes': [{'versao': 1, 'ts': _now(), 'autor': None, 'tipo': 'externa',
                                                                     'justificativa': 'Diferenças encontradas ao converter o projeto da v1.x.',
                                                                     'celulas': sorted(changed)}]}
            log['tabelas_alteradas'].append(t.id)
    # ---- metadados -----------------------------------------------------
    links = meta.pop('formula_normrefs', {}) or {}
    new_links = {}
    for eid, refs in links.items():
        vid = entry_map.get(eid) or entry_map.get(re.sub(r'-L\d+$', '', eid))
        if vid:
            new_links.setdefault(vid, [])
            new_links[vid] += [r for r in refs if r not in new_links[vid]]
    meta['formula_normrefs'] = new_links
    for k in ('ids', 'motor_workflow_version', 'trecho_version', 'insulation_alias_version', 'grouping_version', 'engine_version', 'sha256'):
        meta.pop(k, None)
    meta.setdefault('title', 'Projeto convertido')
    meta['migracao'] = log
    doc['meta'] = meta
    return doc


def acknowledge(p, variavel, circuito_id, autor, justificativa):
    """O revisor confere uma fórmula antiga não convertida (fica registrado quem conferiu, quando e por quê)."""
    justificativa = str(justificativa or '').strip()
    if len(justificativa) < 15:
        raise ValueError('Justificativa obrigatória (mínimo 15 caracteres).')
    mig = p.meta.get('migracao') if isinstance(p.meta.get('migracao'), dict) else {}
    for item in mig.get('nao_convertidas') or []:
        if item.get('variavel') == variavel and (item.get('circuito_id') or None) == (circuito_id or None) and not item.get('conferido_por'):
            item.update(conferido_por=autor, conferido_em=_now(), justificativa=justificativa)
            return {'ok': True}
    raise ValueError('Pendência de conversão não encontrada.')

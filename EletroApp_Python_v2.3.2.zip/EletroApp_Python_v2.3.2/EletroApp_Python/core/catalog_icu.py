"""Preenche Icu/Ics aplicáveis (colunas AA/AB/AC) da Biblioteca_Proteções_WEG a partir dos textos R/S.

Regras (conservadoras; linha já preenchida nunca é alterada):
 - Icu: usa o menor valor "N kA (...)" cuja tensão inclui 220 V (ex.: 220/240V, 127/220V); tensão do registro = 220.
   Sem valor a 220 V, usa o valor declarado a 380 V (Icu cai com a tensão, então 380 V é um limite inferior
   conservador para 220 V); tensão do registro = 380.
 - Ics: valor explícito na mesma tensão do Icu, ou percentual de Icu ("Ics=75%Icu") aplicado ao Icu da tensão
   adotada. Sem declaração → fica vazio (o app segue exigindo conferência: "ICS NÃO DECLARADO").
Tudo isso é extração automática do texto do catálogo: conferir no datasheet antes de usar em projeto.
O módulo é idempotente.
"""
import re
SHEET='Biblioteca_Proteções_WEG'
_NUM=r'(\d+(?:[.,]\d+)?)'
_SEG=re.compile(_NUM+r'\s*(?:\([^)]*\)\s*)?kA\s*\(([^)]*)\)')
_PCT=re.compile(r'(\d+(?:[.,]\d+)?)\s*%\s*Icu',re.I)
def _f(x):return float(x.replace(',','.'))
def _volts(par):return {int(v) for v in re.findall(r'\d+',par)}
def _seg(text,volt):
    """Menor valor declarado na tensão (se houver versões/classes diferentes, fica o conservador)."""
    v=[_f(m.group(1)) for m in _SEG.finditer(text or '') if volt in _volts(m.group(2)) and 'N/D' not in m.group(0)]
    return min(v) if v else None
def _num(x):
    return int(x) if float(x).is_integer() else round(x,2)
def parse(r,s):
    """Devolve (icu, ics, tensão) ou None."""
    r,s=str(r or ''),str(s or '')
    if re.search(r'exceção|estimad',r,re.I):return None   # texto do catálogo avisa de caso especial → conferir manualmente
    for volt in (220,380):
        icu=_seg(r,volt)
        if icu is None:continue
        ics=_seg(s,volt)
        if ics is None:
            pct=_PCT.search(s)
            if pct and 'NÃO' not in s.split('Icu')[0][-12:]:
                ics=icu*_f(pct.group(1))/100
            elif 'N/D' not in s and re.match(r'\s*'+_NUM+r'\s*kA\s*(—|$)',s):
                v=_f(re.match(r'\s*'+_NUM,s).group(1)); ics=v  # ex.: "120 kA — Ics=100%Icu"
        return _num(icu),(_num(ics) if ics is not None else None),volt
    return None
def _in_nominal(v):
    if isinstance(v,(int,float)) and not isinstance(v,bool):return int(v) if float(v).is_integer() else v
    m=re.search(r'In\s*=\s*(\d+(?:[.,]\d+)?)\s*A',str(v or ''))
    if not m:return None
    x=_f(m.group(1));return int(x) if x.is_integer() else x
def apply(data):
    cells=data['sheets'].get(SHEET,{}).get('cells')
    if not cells:return 0
    n=0
    if 'BM1' not in cells:
        cells['BM1']={'value':'In nominal numérico (A) [auto — da coluna I]','formula':False}
    for r in range(2,569):
        if 'BM%d'%r not in cells:
            x=_in_nominal(cells.get('I%d'%r,{}).get('value'))
            if x is not None:cells['BM%d'%r]={'value':x,'formula':False};n+=1
    for r in range(2,569):
        if str(cells.get('AA%d'%r,{}).get('value') or '')!='':continue
        res=parse(cells.get('R%d'%r,{}).get('value'),cells.get('S%d'%r,{}).get('value'))
        if not res:continue
        icu,ics,volt=res
        cells['AA%d'%r]={'value':icu,'formula':False}
        if ics is not None and str(cells.get('AB%d'%r,{}).get('value') or '')=='':
            cells['AB%d'%r]={'value':ics,'formula':False}
        if str(cells.get('AC%d'%r,{}).get('value') or '')=='':
            cells['AC%d'%r]={'value':volt,'formula':False}
        n+=1
    return n

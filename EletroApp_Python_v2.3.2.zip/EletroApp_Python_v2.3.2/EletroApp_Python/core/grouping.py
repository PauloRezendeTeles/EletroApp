"""Agrupamento por trecho: uma origem de dados para cálculo e consulta.

NBR 5410:2004 (corrigida 2008), 6.2.5.5 e tabelas 42–45.
Extensões identificadas: guia Prysmian BT Rev10, tabelas 15–17.
Não infere independência térmica apenas por haver eletrodutos distintos.
"""
import math

NBR='ABNT NBR 5410:2004, versão corrigida 2008'
GUIDE='Guia Prysmian BT Rev10'
IEC_SOIL='IEC 60364-5-52:2009, Anexo B (extensão)'
SOIL_NOTE=('A Tabela 41 da NBR traz só linhas em eletrodutos enterrados, de 1 a 3 K·m/W, até 0,8 m de profundidade. Para cabo '
           'diretamente enterrado, a nota 3 remete à NBR 11301; o aplicativo usa os fatores da IEC 60364-5-52:2009, Anexo B, '
           'identificados como extensão.')
DEPTH_NOTE=('Profundidade: a Tabela 41 vale até 0,8 m (nota 2) e as Tabelas 44 e 45 a 0,7 m. Entre 0,70 e 2,00 m o aplicativo '
            'reduz 1% a cada 0,10 m adicional (guia Prysmian BT Rev10, 5.7.4) — extensão; acima de 0,8 m só com 2,5 K·m/W.')
KEYS={'group_mode','count_mode','physical_count','other_units','parallel_layout','independence_basis','group_signature',
      'homogeneity','group_temperature','heterogeneous_basis','manual_factor','manual_source','manual_reason',
      'duct_layout','allow_guide','air_gap_ratio','low_load_count','low_load_ib','low_load_iz','low_load_basis',
      'neutral_reduction','neutral_basis','neutral_floor'}
LABELS={'feixe':'Feixe / conduto fechado','parede':'Camada única em parede, piso ou bandeja não perfurada',
        'teto':'Camada única no teto','bandeja':'Camada única em bandeja perfurada',
        'leito':'Camada única em leito ou suporte','camadas':'Várias camadas',
        'direto':'Cabos diretamente enterrados','dutos':'Dutos enterrados'}
BANDS=['1','2','3','4','5','6','7','8','9–11','12–15','16–19','≥20']
LBANDS=['2','3','4–5','6–8','≥9']
SPACES={'direto':['0','diametro','0.125','0.25','0.5'],'dutos':['0','0.25','0.5','1']}
SPACE_LABEL={'0':'Encostados','diametro':'1 diâmetro externo','0.125':'0,125 m','0.25':'0,25 m','0.5':'0,50 m','1':'1,00 m'}

def number(v):
    if isinstance(v,bool):return None
    try:
        n=float(v)
        return n if math.isfinite(n) else None
    except (TypeError,ValueError):return None

def whole(v,zero=False):
    n=number(v)
    return int(n) if n is not None and n.is_integer() and (0 if zero else 1)<=n<=100000 else None

def options(ref,method):
    method=str(method)
    if ref=='D':return ['direto'] if method=='63' else ['dutos']
    if ref in ('A1','A2','B1','B2'):return ['feixe']
    if ref=='C':
        if method in ('11A','11B'):return ['teto','feixe','camadas']
        return ['parede','feixe','camadas']
    if ref in ('E','F'):return ['bandeja' if method=='13' else 'leito','feixe','camadas']
    return []

def temperature(v,st,count):
    own=70 if v.get('insulation') in ('PVC','LSHF/A') else 90
    if count>1 and st.get('homogeneity') in ('mixed','heterogeneous'):
        other=number(st.get('group_temperature'))
        if other in (70,90):return min(own,other)
    return own

def lookup(rules,group,count,cable,st):
    """Retorna valor, fonte e coordenada. Não interpola lacunas."""
    if count==1:
        f=.95 if group=='teto' else 1.
        return f, NBR, ('Tabela 42, linha 3, n=1' if group=='teto' else 'Um conjunto no trecho')
    if group in rules['group_air']:
        i=count-1 if count<=8 else 8 if count<=11 else 9 if count<=15 else 10 if count<=19 else 11
        row={'feixe':1,'parede':2,'teto':3,'bandeja':4,'leito':5}[group]
        return rules['group_air'][group][i],NBR,f'Tabela 42, linha {row}, n={BANDS[i]}'
    if group=='camadas':
        a,b=whole(st.get('layers')),whole(st.get('per_layer'))
        if not a or not b or min(a,b)<2 or a*b!=count:return None,NBR,'Tabela 43: camadas × conjuntos por camada deve ser o total; ambos ≥2.'
        def band(n):return 0 if n==2 else 1 if n==3 else 2 if n<=5 else 3 if n<=8 else 4
        return rules['group_layers'][band(a)][band(b)],NBR,f'Tabela 43, {LBANDS[band(a)]} camadas × {LBANDS[band(b)]} por camada'
    if group in SPACES:
        sp=st.get('spacing');spaces=SPACES[group]
        if sp not in spaces:return None,NBR,'Informe a distância livre entre circuitos/cabos ou grupos de dutos.'
        if group=='direto':values=rules['group_direct'].get(str(count));table='44' if count<=6 else '15'
        else:
            key='group_duct_multi' if cable=='Cabo multipolar' else 'group_duct_single'
            values=rules[key][count-2] if 2<=count<=20 else None
            table='45' if count<=6 else ('16' if cable=='Cabo multipolar' else '17')
        source=NBR if count<=6 else GUIDE
        return (values[spaces.index(sp)] if values else None),source,f'Tabela {table}, n={count}, distância livre {SPACE_LABEL[sp]}'
    return None,NBR,'Disposição sem enquadramento automático nas tabelas 42–45.'

def evaluate(rules,v,ref,n,st):
    """Sem ler resultados dimensionados: evita ciclos e confirmações implícitas."""
    st=dict(st);issues=[];notes=[]
    nc=whole(v.get('parallel'));circuits=whole(v.get('circuits'))
    opts=options(ref,v.get('method'));group=st.get('group')
    mode=st.setdefault('group_mode','auto')
    if mode not in ('auto','manual'):issues.append('Escolha agrupamento automático ou manual.')
    if group not in opts:group=None
    if len(opts)==1:group=opts[0]
    # Teto é inferível da montagem; não migra parede para um fator favorável.
    if str(v.get('method')) in ('11A','11B') and group is None:group='teto'
    st['group']=group
    if nc is None or circuits is None:
        return {'settings':st,'issues':['Quantidades de circuitos e paralelos devem ser inteiras e positivas.'],
                'factor':None,'physical_count':None,'count':None,'source':None,'coordinate':'','notes':[], 'temperature':temperature(v,st,1)}
    layout=st.setdefault('parallel_layout','together')
    if layout not in ('together','independent'):issues.append('Informe a relação térmica entre os paralelos.')
    if layout=='independent' and nc>1:
        if len(str(st.get('independence_basis') or '').strip())<15:issues.append('Justifique a independência térmica entre os trechos dos paralelos; dutos distintos, sozinhos, não a demonstram.')
    own=1 if layout=='independent' else nc
    count_mode=st.setdefault('count_mode','auto')
    if count_mode=='total':
        count=whole(st.get('physical_count'))
        if count is None or count<own:issues.append(f'O total físico deve incluir pelo menos {own} conjunto(s) deste circuito.')
    elif count_mode=='auto':
        others=whole(st.get('other_units'),True) if st.get('other_units') is not None else (0 if circuits==1 else None)
        if others is None:issues.append('Informe quantos conjuntos dos demais circuitos compartilham o trecho, incluindo seus paralelos.')
        count=own+(others if others is not None else circuits-1)
    else:count=None;issues.append('Escolha como contar os conjuntos no trecho.')
    count=count or own
    physical=count
    if count>1 and group is None and mode=='auto' and ref!='G':issues.append('Escolha a disposição física do agrupamento.')
    if count==1 and group is None and ref!='G' and opts:
        group=opts[0];st['group']=group
    context_keys=('count_mode','physical_count','other_units','parallel_layout')
    if mode=='manual':context_keys+=('group','spacing','depth','layers','per_layer','duct_layout')
    signature='|'.join(str(x) for x in [v.get(k) for k in ('line','method','cable','material','insulation','parallel')]+[st.get(k) for k in context_keys])
    if st.get('group_signature') and st['group_signature']!=signature:
        st['homogeneity']=None
        if layout=='independent':issues.append('Reconfirme a independência térmica: a instalação ou a contagem mudou.')
        if mode=='manual':issues.append('Reconfirme a justificativa do FCA manual: a instalação ou a contagem mudou.')
    temp=temperature(v,st,count)
    source=None;coordinate='';factor=None
    single_circuit=(count==own and st.get('other_units') in (None,0) and count_mode=='auto')
    hom=st.get('homogeneity')
    if count>1 and not single_circuit and hom not in ('similar','mixed','heterogeneous'):
        issues.append('Confirme a classe térmica e a semelhança das seções do grupo.')
    if count>1 and hom in ('mixed','heterogeneous') and number(st.get('group_temperature')) not in (70,90):
        issues.append('Informe a menor temperatura de serviço contínuo dos cabos do grupo (70 ou 90 °C).')
    if count>1:notes.append('Todos os conjuntos considerados carregados; seções semelhantes: intervalo de três seções normalizadas consecutivas.')
    if mode=='manual':
        factor=number(st.get('manual_factor'));source='Entrada manual: '+str(st.get('manual_source') or '')
        coordinate=str(st.get('manual_reason') or '').strip()
        if factor is None or not 0<factor<=1:issues.append('O FCA manual deve ser maior que zero e no máximo 1.')
        if len(str(st.get('manual_source') or '').strip())<5 or len(coordinate)<15:issues.append('Registre a fonte e a justificativa do fator manual para este trecho.')
        if group=='teto' and factor is not None and factor>.95:issues.append('No teto, o fator manual não pode superar 0,95 sem rever o enquadramento da instalação.')
    elif hom=='heterogeneous' and count>1:
        if len(str(st.get('heterogeneous_basis') or '').strip())<15:issues.append('Justifique por que não é viável o cálculo específico do grupo heterogêneo (6.2.5.5.5 b).')
        factor=1/math.sqrt(count);source=NBR;coordinate=f'6.2.5.5.5 b, grupo não semelhante, n={count}'
    else:
        gap=number(st.get('air_gap_ratio'))
        if gap is not None and gap<0:issues.append('O afastamento relativo não pode ser negativo.')
        exemption=ref!='D' and group in ('parede','teto','bandeja','leito') and gap is not None and gap>2
        if exemption:
            factor=.95 if group=='teto' else 1.;source=NBR;coordinate='Tabela 42, nota 2: distância horizontal livre >2De; correção de teto preservada'
            notes.append('De corresponde ao maior diâmetro externo do grupo; o vão deve ser atendido entre todos os conjuntos, horizontalmente.')
        else:
            factor,source,coordinate=lookup(rules,group,count,v.get('cable'),st)
            if factor is None:issues.append(coordinate)
        if group=='camadas' and n!=3 and v.get('cable')!='Cabo multipolar':issues.append('A tabela 43 exige circuitos trifásicos ou cabos multipolares.')
        if ref=='G' and count>1:issues.append('Método G agrupado: forneça fator manual com cálculo específico; não há linha G diretamente cadastrada nas tabelas 42–45.')
        if ref=='D' and count>1:
            if number(st.get('depth',.7))!=.7 or number(v.get('soil'))!=2.5:
                issues.append('As tabelas de agrupamento enterrado usam 0,70 m e solo de 2,5 K·m/W. Para outras condições, forneça FCA manual justificado por cálculo específico.')
            if group=='dutos':
                required='one_cable' if v.get('cable')=='Cabo multipolar' else 'one_conductor'
                if st.get('duct_layout')!=required:issues.append('Confirme '+('um cabo multipolar por duto' if required=='one_cable' else 'um condutor por duto não metálico, com os dutos dispostos em grupos por circuito')+'; outras distribuições exigem cálculo específico.')
            if source==GUIDE and st.get('allow_guide') is not True:
                issues.append('A NBR tabela apenas 2 a 6 circuitos enterrados. Autorize a extensão identificada do guia ou informe fator manual.')
        excluded=whole(st.get('low_load_count',0),True)
        if excluded is None:issues.append('Quantidade de conjuntos excluídos deve ser inteira e não negativa.')
        elif excluded:
            ib=number(st.get('low_load_ib'));iz=number(st.get('low_load_iz'))
            if excluded>physical-own:issues.append('Só é possível excluir conjuntos dos demais circuitos; preserve os paralelos deste circuito.')
            if group=='camadas':issues.append('Para exclusão em várias camadas, informe fator manual e documente a geometria remanescente.')
            if ib is None or ib<0 or iz is None or iz<=0 or factor is None or ib>.3*iz*factor:
                issues.append('Exclusão por baixa carga exige Ib máximo ≤30% de Iz mínimo já corrigido pelo FCA do grupo completo.')
            if len(str(st.get('low_load_basis') or '').strip())<15:issues.append('Identifique os conjuntos excluídos e a origem das correntes e capacidades usadas.')
            if not issues:
                full=factor;count=physical-excluded
                factor,source,coordinate=lookup(rules,group,count,v.get('cable'),st)
                notes.append(f'6.2.5.5.2: excluídos {excluded}; Ib máx. {ib:g} A ≤ 0,30 × Iz sem FCA {iz:g} A × FCA completo {full:g}.')
                if factor is None:issues.append(coordinate)
    if str(v.get('method')) in ('11A','11B') and count==1 and factor is not None:factor=min(factor,.95)
    if str(v.get('method'))=='11B':notes.append('Afastamento do teto não fornece uma nova linha na tabela 42; adotada a linha de teto de forma conservadora quando em camada única.')
    if ref=='D' and number(st.get('depth',.7))!=.7:notes.append('Profundidade: correção complementar Prysmian, 5.7.4 (separada do FCA). Não amplia a validade das tabelas 44/45.')
    return {'settings':st,'signature':signature,'issues':issues,'factor':factor if not issues else None,'candidate_factor':factor,
            'physical_count':physical,'count':count,'own_count':own,'source':source,'coordinate':coordinate,
            'temperature':temp,'notes':notes,'mode':mode,'count_explanation':f'{own} conjunto(s) deste circuito + {physical-own} dos demais = {physical} no trecho'}

def consultation(rules):
    rows=[]
    for key,vals in rules['group_air'].items():
        for n,f in zip(BANDS,vals):rows.append({'group':LABELS[key],'count':n,'spacing':'—','factor':f,'source':NBR,'table':'42'})
    for i,row in enumerate(rules['group_layers']):
        for j,f in enumerate(row):rows.append({'group':f'{LBANDS[i]} camadas × {LBANDS[j]} conjuntos/camada','count':'Produto','spacing':'—','factor':f,'source':NBR,'table':'43'})
    for key,group in [('group_direct','direto'),('group_duct_multi','dutos'),('group_duct_single','dutos')]:
        records=rules[key].items() if group=='direto' else [(str(i+2),v) for i,v in enumerate(rules[key])]
        for n,vals in records:
            for sp,f in zip(SPACES[group],vals):
                norm=int(n)<=6
                table=('44' if group=='direto' else '45') if norm else {'group_direct':'15','group_duct_multi':'16','group_duct_single':'17'}[key]
                label=LABELS[group] if group=='direto' else ('Um cabo multipolar por duto' if key.endswith('multi') else 'Um condutor por duto, agrupados por circuito')
                rows.append({'group':label,'count':n,'spacing':SPACE_LABEL[sp],'factor':f,'source':NBR if norm else GUIDE,'table':table})
    # v2.2.0: a origem de cada linha fica explícita (NBR ou extensão) e o solo (Tabela 41) entra na mesma consulta.
    for row in rows:row['extensao']=row['source']!=NBR
    soil=[]
    records=list(rules.get('soil') or [])
    if not any(x.get('resistividade')==2.5 for x in records):
        records.append({'resistividade':2.5,'dutos_enterrados':1.0,'diretamente_enterrados':1.0})
    for x in sorted(records,key=lambda x:x['resistividade']):
        rho=x['resistividade']
        ref=rho==2.5
        soil.append({'resistividade':rho,'dutos':x['dutos_enterrados'],'direto':x['diretamente_enterrados'],
                     'fonte_dutos':'Referência (Tabelas 36 e 37)' if ref else ('NBR 5410, Tabela 41' if rho in (1,1.5,2,3) else IEC_SOIL),
                     'fonte_direto':'Referência (Tabelas 36 e 37)' if ref else IEC_SOIL,
                     'extensao_dutos':not ref and rho not in (1,1.5,2,3),'extensao_direto':not ref})
    return {'rows':rows,'soil':soil,'soil_note':SOIL_NOTE,'depth':DEPTH_NOTE,'notes':[
        'Conte conjuntos físicos no mesmo trecho: cada cabo multipolar ou conjunto completo de fases conta uma vez; inclua os paralelos. Não conte cada fase como circuito.',
        'Tabela 43 substitui a tabela 42; os dois fatores não são multiplicados.',
        'Dutos separados não demonstram independência térmica. A tabela 45 distingue um multipolar por duto e um condutor por duto. A rota automática de um condutor por duto exige duto não metálico; outras condições precisam de estudo, conforme nota 2.',
        'Tabelas 44/45: 2 a 6 circuitos, solo 2,5 K·m/W e profundidade 0,70 m. Extensões do guia são opcionais e identificadas.',
        'Grupos semelhantes: mesma temperatura de referência e seções em três valores normalizados consecutivos. Classes térmicas diferentes: calcular pela menor temperatura (6.2.5.5.1).',
        '1/√n somente para grupos não semelhantes, quando o cálculo específico não for viável (6.2.5.5.5 b). Não é uma regra por exceder oito conjuntos.',
        'Afastamento horizontal livre >2De: verificar todos os conjuntos; não confundir com o afastamento entre fases do método G.',
        'Baixa carga: exclusão opcional exige Ib ≤30% de Iz já corrigido pelo agrupamento (6.2.5.5.2). Sem demonstração, todos são contados.',
        'Neutro carregado por harmônicas: fator 0,86 separado do FCA (6.2.5.6.1). Piso de corrente de 15% é uma opção interna, não uma exigência da norma.',
        'A redução da seção do neutro depende das condições de 6.2.6.2.6; não é autorizada apenas por um fator de corrente.',
        'Avalie o trecho termicamente mais desfavorável do percurso (6.2.5.8). A entrada manual deve registrar a fonte e a justificativa.'
    ]}

"""Base técnica versionada (v2.0).

As tabelas técnicas do aplicativo ficam em ``data/tabelas`` (uma por arquivo) e
os metadados de cada uma — título, categoria, fonte, edição, revisão da base,
condições de uso e referências normativas — em ``data/tabelas/_metadados.json``.
A base não é gravada no projeto; o projeto registra apenas a revisão da base
usada e as edições feitas pelo revisor, que são versionadas (autor, data, fonte
do novo valor, justificativa e os valores anteriores) e seladas para a
conferência de integridade.

Uma edição que crie erros novos nos resultados obrigatórios é bloqueada, como na
edição de expressões.
"""
from __future__ import annotations

import copy
import datetime as dt
import html
import re

from .formula import Error, address, col_name
from .integridade import content_hash, stamp, table_status, LABELS
from . import numeros

CATEGORIES = {'norma': 'Norma técnica', 'fabricante': 'Dados de fabricante', 'referencia': 'Referência técnica', 'sistema': 'Listas do aplicativo'}
SITUATIONS = {'referenciada': 'Fonte identificada', 'a_confirmar': 'Fonte a confirmar'}
MIN_JUSTIFICATION = 15
_ADDR = re.compile(r'[A-Z]{1,3}[1-9]\d{0,5}')


class TableError(ValueError):
    pass


# Tabelas lidas diretamente pelas regras em Python (inteiras), além das referências nas expressões do modelo.
PYTHON_TABLES = {'tab_disjuntores_ref': 'core/curvas.py (características convencionais e faixas magnéticas)',
                 'tab_weg_protecoes': 'core/project.py, core/selection.py, core/curvas.py (catálogo de disjuntores)',
                 'tab_dps_clamper': 'core/selection.py (seleção de DPS)', 'tab_dps_siemens': 'core/selection.py (seleção de DPS)',
                 'tab_fusiveis_nh': 'core/project.py (backup do DPS)', 'tab_fatores_correcao': 'core/installation.py (fator de temperatura)',
                 'tab_secao_neutro': 'core/installation.py (NEUTRALMIN: redução do neutro pela Tabela 48)'}
# Regras operacionais que não são tabelas editáveis: entram no manifesto da base e só mudam com nova versão do aplicativo.
RULE_SOURCES = [
    {'arquivo': 'data/installation_rules.json', 'uso': 'Matriz de instalação: linha elétrica × montagem × tipo de cabo → método de referência (A1…G), '
                                                     'tabela de ampacidade, arranjo e fatores de agrupamento.'},
    {'arquivo': 'data/metodos_instalacao.json', 'uso': 'Métodos de instalação ilustrados (descrição e imagem).'},
    {'arquivo': 'data/metodos_por_linha.json', 'uso': 'Métodos compatíveis por tipo de instalação.'},
]
DOCUMENTARY_NOTES = {'tab_nbr5410_t33': 'A seleção do método de instalação usa a matriz de instalação (data/installation_rules.json), '
                                        'versionada no manifesto da base; esta tabela é consulta.',
                     'tab_metodos': 'Tabela auxiliar de navegação; a seleção usa a matriz de instalação.',
                     'tab_nbr5410_t49': 'Tabela de consulta: o fator 1,1 × Uo usado no cálculo fica na tabela de critérios de DPS.',
                     'tab_ref_nm280': 'Tabela de consulta: confere as resistências da tabela de impedâncias na vista normativa.'}


def _usage():
    """{tabela: {'celulas': conjunto de (linha, coluna) referenciados, 'variaveis': conjunto de ids}} pelas expressões do modelo."""
    from .motor import model, compiled
    from .expressao import walk
    m = model()
    cached = getattr(m, '_table_usage', None)
    if cached is not None:
        return cached
    use = {}

    def mark(table, a, b, vid):
        t = m.table(table)
        if t is None:
            return
        r1, c1 = address(a.replace('$', ''))
        r2, c2 = address(b.replace('$', ''))
        u = use.setdefault(t.id, {'faixas': [], 'variaveis': set()})
        u['faixas'].append((r1, c1, min(r2, t.max_row + 60), c2))
        if vid:
            u['variaveis'].add(vid)

    def scan(expr, vid, ctx=None):
        try:
            tree = compiled(expr)
        except Exception:
            return
        for n in walk(tree):
            if n[0] == 'call' and n[1] == 'INDIRECT':
                # Nome montado em tempo de cálculo: marca os nomes compatíveis com os textos fixos do argumento (ou todos).
                lits = [x[1] for x in walk(n) if x[0] == 'lit' and isinstance(x[1], str) and len(x[1]) >= 3]
                for name, dest in m.names.items():
                    if (not lits or any(name.startswith(l) or l in name for l in lits)) and '!' in dest:
                        sheet, rng = dest.rsplit('!', 1)
                        a, _, b = rng.partition(':')
                        mark(sheet.strip("'"), a, b or a, vid)
            if n[0] == 'ref' and (n[1] or ctx):
                mark(n[1] or ctx, n[2], n[3], vid)
            elif n[0] == 'columns' and (n[1] or ctx):
                t = m.table(n[1] or ctx)
                if t is not None:
                    mark(t.id, n[2] + '1', n[3] + str(t.max_row), vid)
            elif n[0] == 'name' and n[1] in m.names:
                dest = m.names[n[1]]
                if '!' in dest:
                    sheet, rng = dest.rsplit('!', 1)
                    a, _, b = rng.partition(':')
                    mark(sheet.strip("'"), a, b or a, vid)
    for v in m.by_id.values():
        for e in [v.expr] + list((v.variants or {}).values()):
            if e:
                scan(e, v.id)
        if isinstance(v.options, dict) and v.options.get('formula'):
            scan(v.options['formula'], v.id)
    for t in m.tables.values():
        for c in t.cells.values():
            if 'f' in c:
                scan(c['f'], None, t.id)
    m._table_usage = use
    return use


def usage(table_id):
    u = _usage().get(table_id)
    py = PYTHON_TABLES.get(table_id)
    doc = table_id in DOCUMENTARY_NOTES
    return {'operacional': (bool(u) or bool(py)) and not doc, 'regras_python': py, 'variaveis': sorted(u['variaveis']) if u else [],
            'nota': DOCUMENTARY_NOTES.get(table_id) + (' Alimenta apenas textos descritivos.' if u else '') if doc else None}


def cell_used(table_id, addr):
    if table_id in DOCUMENTARY_NOTES:
        return False
    if table_id in PYTHON_TABLES:
        return True
    u = _usage().get(table_id)
    if not u:
        return False
    r, c = address(addr)
    return any(r1 <= r <= r2 and c1 <= c <= c2 for r1, c1, r2, c2 in u['faixas'])


def _now():
    return dt.datetime.now().astimezone().isoformat(timespec='seconds')


def _table(p, tid):
    t = p.model.tables.get(tid)
    if t is None:
        raise TableError('Tabela técnica inexistente.')
    return t


def info(p, t):
    meta = t.meta or {}
    ed = p.doc['tabelas'].get(t.id) or {}
    versions = ed.get('versoes') or []
    status = table_status(p, t.id)
    return {'id': t.id, 'nome': meta.get('titulo') or t.name, 'categoria': meta.get('categoria'),
            'categoria_rotulo': CATEGORIES.get(meta.get('categoria'), '—'), 'fonte': meta.get('fonte'), 'edicao': meta.get('edicao'),
            'revisao_base': meta.get('revisao'), 'revisao_data': meta.get('revisao_data'), 'revisao_nota': meta.get('revisao_nota'),
            'nova_em': meta.get('nova_em'),
            'condicoes': meta.get('condicoes') or [], 'refs': meta.get('refs') or [], 'situacao_fonte': meta.get('situacao'),
            'situacao_fonte_rotulo': SITUATIONS.get(meta.get('situacao'), '—'), 'verificacao': meta.get('verificacao'),
            'origem_por_linha': meta.get('origem_por_linha'), 'linhas': t.max_row, 'colunas': t.max_col,
            'celulas_editadas': len(ed.get('celulas') or {}), 'versao_projeto': len(versions),
            'integridade': status, 'integridade_rotulo': LABELS.get(status) if status else 'Base do aplicativo, sem edições',
            'uso': (lambda u: {**u, 'n_variaveis': len(u['variaveis']), 'variaveis': u['variaveis'][:40]})(usage(t.id))}


def listing(p):
    from .catalog import normref_registry
    reg = normref_registry()
    items = []
    for t in p.model.tables.values():
        x = info(p, t)
        x['refs_detalhe'] = [{'id': r, 'rotulo': ' · '.join(str(v) for v in (reg[r].get('norma'), reg[r].get('tabela') or reg[r].get('item')) if v)}
                             for r in x['refs'] if r in reg]
        items.append(x)
    items.sort(key=lambda x: (list(CATEGORIES).index(x['categoria']) if x['categoria'] in CATEGORIES else 9, x['nome']))
    from .motor import model
    comps = model().manifest()['componentes']
    rules = [{**r, 'resumo': comps.get('regras.' + r['arquivo'].split('/')[-1])} for r in RULE_SOURCES]
    return {'tabelas': items, 'categorias': CATEGORIES, 'regras_operacionais': rules}


def _display(v):
    if isinstance(v, Error):
        return {'error': v.code}
    return v


def view(p, tid, row=1, count=60, q=''):
    t = _table(p, tid)
    count = max(1, min(int(count), 200))
    ed = (p.doc['tabelas'].get(tid) or {}).get('celulas') or {}
    cols = [{'letra': col_name(c), 'nome': (t.columns[c - 1]['nome'] if c - 1 < len(t.columns) else '')} for c in range(1, t.max_col + 1)]
    qn = (q or '').casefold().strip()
    rows_all = list(range(1, t.max_row + 1))
    if qn:
        def hit(r):
            for c in range(1, t.max_col + 1):
                cell = p.table_cell(t, f'{col_name(c)}{r}')
                if cell and qn in str(cell.get('v', cell.get('f', ''))).casefold():
                    return True
            return False
        rows_all = [r for r in rows_all if hit(r)]
    start = max(0, int(row) - 1) if not qn else 0
    page = rows_all[start:start + count]
    from .normativa import previous, correction_for
    prev = previous(p, tid)  # v2.2.0: células com valor diferente da revisão anterior da base
    rows = []
    for r in page:
        cells = []
        for c in range(1, t.max_col + 1):
            a = f'{col_name(c)}{r}'
            cell = p.table_cell(t, a)
            if cell is None:
                cells.append({'v': None, 'anterior': prev[a], 'removida': True} if a in prev else None)
                continue
            out = {'v': _display(p.engine.get(t.legacy or t.id, a)) if 'f' in cell else cell.get('v')}
            if 'f' in cell:
                out['calculada'] = True
            if a in ed:
                base = t.cells.get(a)
                out['editada'] = True
                out['base'] = None if base is None else base.get('v', base.get('f'))
            if a in prev:
                out['anterior'] = prev[a]
                corr = correction_for(t, a)
                if corr:
                    out['correcao'] = {k: corr.get(k) for k in ('achado', 'fonte', 'motivo')}
            cells.append(out)
        rows.append({'linha': r, 'celulas': cells})
    versions = []
    for v in (p.doc['tabelas'].get(tid) or {}).get('versoes') or []:
        versions.append({k: v.get(k) for k in ('versao', 'tipo', 'ts', 'autor', 'justificativa', 'fonte')} | {'n_celulas': len(v.get('celulas') or [])})
    return {**info(p, t), 'colunas_def': cols, 'linhas_def': rows, 'inicio': start + 1, 'total_linhas': len(rows_all), 'versoes': versions,
            'corrigidas': len(prev), 'correcoes': (t.meta or {}).get('correcoes') or []}


def _parse_value(raw, base):
    if raw is None or raw == '':
        return None
    if isinstance(raw, bool) or isinstance(raw, (dict, list)):
        raise TableError('Valor inválido.')
    if isinstance(raw, (int, float)):
        return numeros.parse_br(raw)
    text = str(raw).strip()
    if len(text) > 2000:
        raise TableError('Texto muito longo.')
    base_v = (base or {}).get('v')
    if isinstance(base_v, (int, float)) and not isinstance(base_v, bool) or numeros.looks_numeric(text):
        try:
            return numeros.parse_br(text)
        except ValueError:
            if isinstance(base_v, (int, float)):
                raise TableError(f'“{text}” não é um número válido (a célula da base é numérica).')
    return text


def _apply(p, tid, new_cells, info_):
    t = p.model.tables[tid]
    slot = p.doc['tabelas'].setdefault(tid, {'celulas': {}, 'versoes': []})
    cells = slot.setdefault('celulas', {})
    previous = {}
    for a, value in new_cells.items():
        base = t.cells.get(a)
        previous[a] = copy.deepcopy(cells.get(a, base))
        base_v = None if base is None else base.get('v')
        if base is not None and 'f' not in base and base_v == value or base is None and value is None:
            cells.pop(a, None)  # voltou ao valor da base
        else:
            cells[a] = {'v': value}
    n = len(slot['versoes']) + 1
    entry = {'versao': n, 'ts': _now(), 'celulas': sorted(new_cells), 'anteriores': previous,
             'revisao_base': (t.meta or {}).get('revisao'), 'conteudo': content_hash(cells), **info_}
    slot['versoes'].append(stamp('tabela', tid, entry))
    if not cells and not slot['versoes']:
        p.doc['tabelas'].pop(tid, None)
    p.engine.clear()
    return n


def _gate(p, before_doc, apply_fn):
    from .catalog import Catalog
    cat = Catalog(p, integrity=False)
    saved = copy.deepcopy(p.doc['tabelas'])
    before = cat.snapshot()
    apply_fn()
    after = cat.snapshot(p)
    gate = cat._gate(before, after, p)
    if gate['bloqueada']:
        p.doc['tabelas'].clear()
        p.doc['tabelas'].update(saved)  # nada fica gravado no projeto
        p.engine.clear()
        raise TableError(f"Edição bloqueada: cria {gate['erros_obrigatorios']} erro(s) novo(s) em cálculos obrigatórios. Nada foi gravado. Exemplos: " +
                         '; '.join(f"{x['circuito'] or 'projeto'} · {x['rotulo']} = {x['erro']}" for x in gate['exemplos_erros'][:4]))
    return cat.diff(before, after, limit=0)


def edit(p, tid, celulas, autor, justificativa, fonte):
    """Edita valores de uma tabela técnica no projeto (somente revisor)."""
    t = _table(p, tid)
    justificativa = str(justificativa or '').strip()
    fonte = str(fonte or '').strip()
    if len(justificativa) < MIN_JUSTIFICATION:
        raise TableError(f'Justificativa obrigatória (mínimo {MIN_JUSTIFICATION} caracteres).')
    if len(fonte) < 5:
        raise TableError('Informe a fonte do novo valor (norma e edição, catálogo e página, ensaio…).')
    if not isinstance(celulas, dict) or not celulas:
        raise TableError('Nenhuma célula informada.')
    if len(celulas) > 500:
        raise TableError('Edite no máximo 500 células por vez.')
    parsed = {}
    for a, raw in celulas.items():
        a = str(a).upper().replace('$', '')
        if not _ADDR.fullmatch(a):
            raise TableError(f'Posição inválida: {a}')
        r, c = address(a)
        if r < 2 or r > t.max_row + 50 or c > t.max_col:
            raise TableError(f'Posição fora da tabela: {a} (cabeçalhos e colunas novas não são editáveis).')
        base = t.cells.get(a)
        if base is not None and 'f' in base:
            raise TableError(f'{a} é calculada a partir de outras células e não é editável.')
        if not cell_used(tid, a):
            nota = DOCUMENTARY_NOTES.get(tid) or 'Nenhum cálculo do modelo lê esta posição.'
            raise TableError(f'{a} é apenas documental: alterá-la não mudaria nenhum cálculo. {nota}')
        parsed[a] = _parse_value(raw, base)
    current = (p.doc['tabelas'].get(tid) or {}).get('celulas') or {}
    if all((current.get(a) or t.cells.get(a) or {}).get('v') == v for a, v in parsed.items()):
        raise TableError('Os valores informados são iguais aos atuais.')
    impacto = _gate(p, None, lambda: _apply(p, tid, parsed, {'tipo': 'edicao', 'autor': autor, 'justificativa': justificativa, 'fonte': fonte}))
    slot = p.doc['tabelas'][tid]
    slot['versoes'][-1]['impacto'] = {k: impacto[k] for k in ('campos_afetados', 'celulas_afetadas', 'circuitos_afetados', 'novos_erros')}
    _reopen(p)
    return {'versao': len(slot['versoes']), 'impacto': slot['versoes'][-1]['impacto']}


def restore(p, tid, autor, justificativa):
    """Volta a tabela à base do aplicativo (a história das edições é mantida)."""
    t = _table(p, tid)
    slot = p.doc['tabelas'].get(tid)
    if not slot or not slot.get('celulas'):
        raise TableError('A tabela já está igual à base do aplicativo.')
    justificativa = str(justificativa or '').strip() or 'Restauração da base técnica do aplicativo'
    edited = dict(slot['celulas'])
    back = {a: (None if t.cells.get(a) is None else t.cells[a].get('v')) for a in edited if 'f' not in (t.cells.get(a) or {})}
    impacto = _gate(p, None, lambda: _apply(p, tid, back, {'tipo': 'restauracao', 'autor': autor, 'justificativa': justificativa,
                                                          'fonte': f"Base técnica do aplicativo, revisão {(t.meta or {}).get('revisao')}"}))
    for a in edited:
        slot['celulas'].pop(a, None)
    slot['versoes'][-1]['conteudo'] = content_hash(slot['celulas'])
    stamp('tabela', tid, slot['versoes'][-1])
    slot['versoes'][-1]['impacto'] = {k: impacto[k] for k in ('campos_afetados', 'celulas_afetadas', 'circuitos_afetados', 'novos_erros')}
    p.engine.clear()
    _reopen(p)
    return {'versao': len(slot['versoes']), 'impacto': slot['versoes'][-1]['impacto']}


def _reopen(p):
    from .catalog import Catalog
    Catalog(p, integrity=False)._reopen_confirmations(p)
    Catalog(p, integrity=False)._reselect(p)


def report_html(p):
    h = html.escape
    rows = []
    for t in p.model.tables.values():
        x = info(p, t)
        rows.append('<tr><td>' + h(x['nome']) + '</td><td>' + h(x['categoria_rotulo']) + '</td><td>' + h(str(x['fonte'] or '—')) +
                    (' · ' + h(str(x['edicao'])) if x['edicao'] else '') + '</td><td>' + str(x['revisao_base']) + '</td><td>' +
                    h(x['situacao_fonte_rotulo']) + '</td><td>' + (h(f"{x['celulas_editadas']} célula(s) editada(s) no projeto — {x['integridade_rotulo']}")
                                                                if x['celulas_editadas'] or x['integridade'] else 'Base do aplicativo') + '</td></tr>')
    edits = []
    for tid, slot in p.doc['tabelas'].items():
        t = p.model.tables.get(tid)
        for v in slot.get('versoes') or []:
            edits.append('<tr><td>' + h(t.meta.get('titulo', t.name) if t else tid) + '</td><td>v' + str(v.get('versao')) + '</td><td>' +
                         h(str(v.get('autor') or '—')) + '</td><td>' + h(str(v.get('ts') or '')) + '</td><td>' + h(str(v.get('fonte') or '—')) +
                         '</td><td>' + h(str(v.get('justificativa') or '')) + '</td><td>' + str(len(v.get('celulas') or [])) + '</td></tr>')
    out = ('<h3>Base técnica utilizada</h3><table><thead><tr><th>Tabela</th><th>Categoria</th><th>Fonte e edição</th><th>Revisão da base</th>'
           '<th>Origem</th><th>No projeto</th></tr></thead><tbody>' + ''.join(rows) + '</tbody></table>')
    if edits:
        out += ('<h3>Edições de tabelas técnicas no projeto</h3><table><thead><tr><th>Tabela</th><th>Versão</th><th>Autor</th><th>Data</th>'
                '<th>Fonte do valor</th><th>Justificativa</th><th>Células</th></tr></thead><tbody>' + ''.join(edits) + '</tbody></table>')
    return out

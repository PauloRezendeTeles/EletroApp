"""Entradas guiadas de motores. As fórmulas r42 continuam sendo a base.

Os campos de placa são substituições opcionais: vazio conserva a consulta da
tabela. Projetos anteriores mantêm as cargas informadas, sem somar motores duas
vezes. Circuitos novos somam a potência elétrica dos motores automaticamente.
"""
import math

LOAD='Levantamento de carga'
CALC='Cálc_Icc-Motores'
START='ΔV_Partida_Motores'
ADD='Somar automaticamente às cargas gerais'
INCLUDED='Já incluídos nas cargas gerais'
OVERRIDES={'AG':('E','Fator de potência do maior motor (placa)'),
           'AH':('F','Rendimento do maior motor (%) — placa'),
           'AI':('G','Relação Ip/In do maior motor — placa'),
           'AJ':('H','Corrente nominal do maior motor (A) — placa'),
           'AK':('D','Potência mecânica do maior motor (W) — placa'),
           'AL':('J','Conjugado nominal do maior motor (kgf·m) — placa')}
INPUTS=[*OVERRIDES,'AN','AO']

def apply(data):
    cells=data['sheets'][LOAD]['cells'];calc=data['sheets'][CALC]['cells']
    if data.setdefault('meta',{}).get('motor_workflow_version')==1:return
    data['meta']['motor_workflow_version']=1
    for c,(_,label) in OVERRIDES.items():cells[c+'1']={'value':label,'formula':False}
    cells['AN1']={'value':'Inclusão dos motores na carga','formula':False}
    cells['AO1']={'value':'Fase / ramo dos motores (alimentação não trifásica)','formula':False}
    for c,label in [('AP','Potência elétrica dos motores (W)'),('AQ','Potência reativa dos motores (var)')]:
        cells[c+'1']={'value':label,'formula':False}
    for r in range(4,102):
        for c in INPUTS:cells.setdefault(f'{c}{r}',{'value':INCLUDED if c=='AN' else 'R' if c=='AO' else None,'formula':False})
        for entry,(target,_) in OVERRIDES.items():
            a=f'{target}{r}';old=calc.get(a)
            if old and old.get('formula'):
                old['value']=f'=IF(AND(\'{LOAD}\'!$V{r}>0,ISNUMBER(\'{LOAD}\'!${entry}{r})),\'{LOAD}\'!${entry}{r},{old["value"][1:]})'
        # Quando não há corrente tabelada, deriva de potência, fp e rendimento.
        h=calc.get(f'H{r}')
        if h and h.get('formula'):
            base=h['value'][1:]
            fallback=f'IF(AND(ISNUMBER($D{r}),ISNUMBER($E{r}),$E{r}>0,ISNUMBER($F{r}),$F{r}>0),ROUND($D{r}/(IF(\'{LOAD}\'!$U{r}="Trifásico",SQRT(3)*\'Padrão de entrada\'!$B$135,IF(\'{LOAD}\'!$U{r}="Bifásico",\'Padrão de entrada\'!$B$135,IF(\'Padrão de entrada\'!$B$135=220,127,IF(\'Padrão de entrada\'!$B$135=380,220,\'Padrão de entrada\'!$B$135/SQRT(3)))))*$E{r}*($F{r}/100)),2),"")'
            manual=f"'{LOAD}'!"
            h['value']=f'=IF({manual}$V{r}>0,IF(ISNUMBER({manual}$AJ{r}),{manual}$AJ{r},IF(OR(ISNUMBER({manual}$AG{r}),ISNUMBER({manual}$AH{r}),ISNUMBER({manual}$AK{r})),{fallback},IF(ISNUMBER({base}),{base},{fallback}))),"")'
        l=calc.get(f'L{r}')
        if l and l.get('formula'):
            original=l['value'][1:]
            supply=f'IF(\'{LOAD}\'!$U{r}="Trifásico",SQRT(3)*\'Padrão de entrada\'!$B$135,IF(\'{LOAD}\'!$U{r}="Bifásico",\'Padrão de entrada\'!$B$135,IF(\'Padrão de entrada\'!$B$135=220,127,IF(\'Padrão de entrada\'!$B$135=380,220,\'Padrão de entrada\'!$B$135/SQRT(3)))))'
            l['value']=f'=IF(\'{LOAD}\'!$AN{r}="{ADD}",IF(\'{LOAD}\'!$Y{r}>0,IFERROR(ROUND($K{r}/({supply}*\'{LOAD}\'!$AA{r}*(\'{LOAD}\'!$AB{r}/100)),2),""),0),{original})'
        for c,reactive in [('AP',False),('AQ',True)]:
            largest=f'IF($V{r}>0,\'{CALC}\'!$D{r}/(\'{CALC}\'!$F{r}/100)'+(f'*TAN(ACOS(\'{CALC}\'!$E{r}))' if reactive else '')+',0)'
            others=f'IF($Y{r}>0,\'{CALC}\'!$K{r}/($AB{r}/100)'+(f'*TAN(ACOS($AA{r}))' if reactive else '')+',0)'
            cells[f'{c}{r}']={'value':f'=IF($A{r}="","",IFERROR(ROUND({largest}+{others},2),"⏳ Dados do motor pendentes"))','formula':True}
        for targets,extra in [(['J','K','L'],'AP'),(['AB','AC','AD'],'AQ')]:
            for idx,target in enumerate(targets):
                a=f'{target}{r}';cell=data['sheets']['Carga nos circuitos']['cells'].get(a)
                if not cell or not cell.get('formula'):continue
                original=cell['value'][1:]
                load=f"'{LOAD}'!"
                component=f'IF({load}$U{r}="Trifásico",{load}${extra}{r}/3,IF({load}$AO{r}="{"RST"[idx]}",{load}${extra}{r},0))'
                cell['value']=f'=IF({load}$AN{r}="{ADD}",({original})+({component}),{original})'

def validate(sheet,col,value):
    if value in (None,''):return
    if sheet==LOAD:
        if col in OVERRIDES or col in ('T','V','Y','AA','AB'):
            if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
                raise ValueError('Informe um número válido nos dados do motor.')
            if col in ('V','Y'):
                if value<0:raise ValueError('Potência de motores não pode ser negativa.')
            elif value<=0:raise ValueError('O parâmetro do motor deve ser maior que zero.')
            if col in ('AG','AA') and value>1:raise ValueError('Fator de potência: informe de 0 a 1, excluindo zero.')
            if col in ('AH','AB') and value>100:raise ValueError('Rendimento: informe de 0 a 100%, excluindo zero.')
            if col=='AI' and value<1:raise ValueError('Ip/In deve ser pelo menos 1.')
            if col=='T' and (value<2 or value%2):raise ValueError('Polos do motor: informe um inteiro par, a partir de 2.')
        if col=='AN' and value not in (ADD,INCLUDED):raise ValueError('Escolha como incluir os motores na carga.')
        if col=='AO' and value not in ('R','S','T'):raise ValueError('Escolha a fase / ramo dos motores.')
    if sheet==START and col in ('D','O','P','X') and value!='N/A':
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<=0:
            raise ValueError('Informe um parâmetro de partida maior que zero.')
        if col=='D' and value>1:raise ValueError('O fator de potência de partida deve ser no máximo 1.')
        if col=='X' and value>100:raise ValueError('Na aproximação adotada, o parâmetro de partida deve estar entre 0 e 100%, excluindo zero.')

def issues(p,r):
    v=lambda c:p.get(LOAD,f'{c}{r}')
    n=lambda c:p.get(CALC,f'{c}{r}')
    out=[]
    if isinstance(v('V'),(int,float)) and v('V')>0:
        for col,label in [('E','fator de potência'),('F','rendimento'),('G','Ip/In'),('H','corrente nominal')]:
            if not isinstance(n(col),(int,float)) or n(col)<=0:out.append('Maior motor: informe '+label+' nos dados de placa; não há valor válido na tabela.')
    if isinstance(v('Y'),(int,float)) and v('Y')>0:
        for col,label in [('AA','fator de potência médio'),('AB','rendimento médio')]:
            if not isinstance(v(col),(int,float)) or v(col)<=0:out.append('Demais motores: informe '+label+'.')
    return out

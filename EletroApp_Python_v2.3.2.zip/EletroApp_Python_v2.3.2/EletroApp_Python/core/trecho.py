"""Dispositivos do trecho (v1.10): dispositivo na origem opcional, disjuntor de
manutenção na extremidade (jusante) e DPS opcional por quadro.

O modelo r42 supõe um dispositivo de proteção na origem de cada circuito e um
DPS em todo quadro de origem ou distribuição. Este módulo, aplicado ao carregar
o modelo, cria a aba ``Dispositivos_Trecho`` e envolve as fórmulas r42 que
dependem desses dispositivos com ``TRECHO_SE(condição; variante; original)``.

* ``TRECHO_SE`` é avaliada como ``SE``: só um ramo é calculado.
* Com os valores padrão (dispositivo na origem, sem disjuntor de manutenção,
  DPS pela regra da natureza) a condição é falsa em todas as linhas e o
  resultado é exatamente o da fórmula original.
* O catálogo de fórmulas reconhece a fórmula original dentro do envoltório
  (``unwrap``) e o reaplica ao editar ou restaurar uma fórmula (``rewrap``).

Referências normativas citadas nas mensagens (NBR 5410:2004): 5.3.4.2.2
(dispositivo contra sobrecarga ao longo do percurso, sem derivações), 5.3.4.3
(omissão da proteção contra sobrecargas), 5.3.5.2 (localização) e 5.3.5.3
(omissão da proteção contra curtos-circuitos, inclusive linhas que ligam
transformadores aos quadros). Os itens foram conferidos em material de apoio;
confira o texto na edição vigente da norma.
"""
from __future__ import annotations

import re

SHEET = 'Dispositivos_Trecho'
FN = 'TRECHO_SE'
VERSION = 2  # 2: Icu do dispositivo da origem comparado ao Ik do quadro de instalação
ROWS = range(2, 102)
IDENT = "'Identificação dos circuitos'"
PROT = "'Cálc-Prot_Cabos'"
CHOQUE = "'Cálc-Prot_Choque'"
WEG = 'Biblioteca_Proteções_WEG'

ORIGEM_SIM = 'SIM — dispositivo na origem'
ORIGEM_NAO = 'NÃO — sem dispositivo próprio'
SIM, NAO = 'SIM', 'NÃO'
JUSTIFICATIVAS = [
    'Ligação do transformador ao quadro — proteção no quadro de destino (NBR 5410, 5.3.5.3)',
    'Trecho do padrão de entrada — proteção pela concessionária',
    'Trecho sem derivações protegido pelo dispositivo a montante',
]
DPS_NAO = 'NÃO — sem DPS neste quadro'
DPS_T2 = 'SIM — Tipo 2 / Classe II'
DPS_T12 = 'SIM — Tipo 1+2 / Classe I+II'
DPS_OPCOES = [DPS_NAO, DPS_T2, DPS_T12]

# (chave, cabeçalho, fórmula ou None para entrada). A ordem define as colunas.
INPUT = None
SPEC = [
    ('id', 'ID', "={IDENT}!$A{r}"),
    ('circuito', 'Circuito', '=IF($A{r}="","",{IDENT}!$B{r})'),
    ('origem', 'Dispositivo de proteção na origem do circuito [ENTRADA — vazio = SIM]', INPUT),
    ('justificativa', 'Justificativa da ausência do dispositivo na origem [ENTRADA]', INPUT),
    ('condicoes', 'Condições da dispensa confirmadas pelo projetista (SIM/NÃO) [ENTRADA]', INPUT),
    ('tempo_montante', 'Tempo de eliminação da falta pela proteção a montante (s) [ENTRADA]', INPUT),
    ('desc_montante', 'Proteção a montante — descrição [ENTRADA]', INPUT),
    ('manut', 'Disjuntor de manutenção na extremidade (jusante)? [ENTRADA — vazio = NÃO]', INPUT),
    ('mb_familia', 'Disjuntor de manutenção — linha/família [ENTRADA]', INPUT),
    ('mb_modelo', 'Disjuntor de manutenção — modelo/referência [ENTRADA]', INPUT),
    ('mb_ir', 'Disjuntor de manutenção — Ir adotado (A) [ENTRADA]', INPUT),
    ('mb_ii', 'Disjuntor de manutenção — Ii/Im adotado (A) [ENTRADA]', INPUT),
    ('mb_isd', 'Disjuntor de manutenção — Isd adotado (A) [ENTRADA, eletrônico]', INPUT),
    ('mb_tsd', 'Disjuntor de manutenção — tsd adotado (ms) [ENTRADA, eletrônico]', INPUT),
    ('sem_origem', 'Sem dispositivo na origem? (auto)', '=LEFT(<origem>,3)="NÃO"'),
    ('tem_mb', 'Disjuntor de manutenção previsto? (auto)', '=<manut>="SIM"'),
    ('mb_idx', 'Índice do disjuntor de manutenção na Biblioteca WEG (auto)',
     '=IF(OR(NOT(<tem_mb>),<mb_modelo>=""),"",IFERROR(MATCH(<mb_modelo>,{W:C},0),"✗ NÃO ENCONTRADO"))'),
    ('mb_fabricante', 'Fabricante (auto)', '=IF(ISNUMBER(<mb_idx>),{X:A},"")'),
    ('mb_in', 'In do disjuntor de manutenção (A) (auto)', '=IF(ISNUMBER(<mb_idx>),{X:AL},"")'),
    ('mb_polos', 'Polos (auto)', '=IF(ISNUMBER(<mb_idx>),{X:G},"")'),
    ('mb_ir_min', 'Ir mínimo permitido (A) (auto)', '=IF(ISNUMBER(<mb_idx>),{X:J},"")'),
    ('mb_ir_max', 'Ir máximo permitido (A) (auto)', '=IF(ISNUMBER(<mb_idx>),{X:K},"")'),
    ('mb_im_min', 'Im/Ii mínimo (A) (auto)', '=IF(ISNUMBER(<mb_idx>),{X:M},"")'),
    ('mb_im_max', 'Im/Ii máximo (A) (auto)', '=IF(ISNUMBER(<mb_idx>),{X:N},"")'),
    ('mb_icu', 'Icu de catálogo na tensão do circuito (kA) (auto)',
     '=IF(ISNUMBER(<mb_idx>),IF({X:AA}<>"",{X:AA},"N/D — VERIFICAR TENSÃO NO CATÁLOGO"),"")'),
    ('mb_ics', 'Ics de catálogo na tensão do circuito (kA) (auto)',
     '=IF(ISNUMBER(<mb_idx>),IF({X:AB}<>"",{X:AB},"N/D — VERIFICAR TENSÃO NO CATÁLOGO"),"")'),
    ('mb_tensao', 'Tensão de referência do catálogo (V) (auto)', '=IF(ISNUMBER(<mb_idx>),{X:AC},"")'),
    ('mb_ajustavel', 'Disparo térmico ajustável? (auto)',
     '=IF(NOT(ISNUMBER(<mb_idx>)),"",IF(AND(ISNUMBER(<mb_ir_min>),ISNUMBER(<mb_ir_max>)),IF(<mb_ir_min>=<mb_ir_max>,"NÃO","SIM"),"N/D"))'),
    ('mb_classe', 'Classe do disjuntor de manutenção (auto)',
     '=IF(NOT(ISNUMBER(<mb_idx>)),"",IF(<mb_ajustavel>="N/D","somente magnético",IF(<mb_ajustavel>="NÃO","fixo",'
     'IF(OR(ISNUMBER(SEARCH("letr",{X:P})),LEFT({X:P},3)="ETS",LEFT({X:P},3)="ETM",LEFT({X:P},3)="AG1"),"eletrônico","termomagnético"))))'),
    ('mb_curva', 'Curva/tabela do fabricante disponível? (auto)',
     '=IF(NOT(ISNUMBER(<mb_idx>)),"",IF(AND({X:W}<>"",{X:X}<>""),"SIM","NÃO"))'),
    ('ib', 'Ib — corrente de projeto (A)', "={PROT}!$D{r}"),
    ('iz', 'Iz — capacidade do cabo (A)', "={PROT}!$F{r}"),
    ('ik_max', 'Ik máximo na extremidade (kA)', "='Cálc_Icc-Cond_Escolhido'!$S{r}"),
    ('ik_laco', 'Ik do laço de falta na extremidade (A)', "={CHOQUE}!$X{r}"),
    ('ip', 'Ip de partida dos motores (A)', "={PROT}!$I{r}"),
    ('mb_protege_cabo', 'O disjuntor de manutenção protege o cabo contra sobrecarga?',
     '=IF(NOT(<tem_mb>),"N/A",IF(<sem_origem>,"SIM — único dispositivo do trecho","NÃO — o dispositivo da origem protege o cabo"))'),
    ('mb_ib_ir', 'Ib ≤ Ir?',
     '=IF(OR(NOT(<tem_mb>),NOT(ISNUMBER(<mb_ir>)),NOT(ISNUMBER(<ib>))),"N/A",<ib><=<mb_ir>)'),
    ('mb_ir_iz', 'Ir ≤ Iz? (exigido quando não há dispositivo na origem)',
     '=IF(OR(NOT(<tem_mb>),NOT(<sem_origem>),NOT(ISNUMBER(<mb_ir>)),NOT(ISNUMBER(<iz>))),"N/A",<mb_ir><=<iz>)'),
    ('mb_ir_faixa', 'Ir dentro da faixa do catálogo?',
     '=IF(OR(NOT(ISNUMBER(<mb_idx>)),NOT(ISNUMBER(<mb_ir>)),NOT(ISNUMBER(<mb_ir_min>)),NOT(ISNUMBER(<mb_ir_max>))),"N/A",AND(<mb_ir>>=<mb_ir_min>,<mb_ir><=<mb_ir_max>))'),
    ('mb_inst', 'Limiar de disparo instantâneo garantido (A)',
     '=IF(NOT(ISNUMBER(<mb_idx>)),"",IF(<mb_classe>="fixo",<mb_im_max>,IF(ISNUMBER(<mb_ii>),<mb_ii>,"")))'),
    ('mb_mag_min', 'Limiar mínimo de disparo magnético ou de curto retardo (A)',
     '=IF(NOT(ISNUMBER(<mb_idx>)),"",IF(<mb_classe>="fixo",<mb_im_min>,IF(AND(<mb_classe>="eletrônico",ISNUMBER(<mb_isd>)),<mb_isd>,IF(ISNUMBER(<mb_ii>),<mb_ii>,""))))'),
    ('mb_partida', 'Partida: disparo magnético ≥ 1,2 × Ip?',
     '=IF(OR(NOT(<tem_mb>),NOT(ISNUMBER(<ip>))),"N/A",IF(<ip><=0,"N/A",IF(ISNUMBER(<mb_mag_min>),<mb_mag_min>>=1.2*<ip>,"N/A")))'),
    ('mb_icu_ok', 'Icu ≥ Ik no ponto de instalação?',
     '=IF(OR(NOT(ISNUMBER(<mb_idx>)),NOT(ISNUMBER(<ik_max>))),"N/A",IF(ISNUMBER(<mb_icu>),<mb_icu>>=<ik_max>,FALSE))'),
    ('mb_ics_ok', 'Ics declarado?', '=IF(NOT(ISNUMBER(<mb_idx>)),"N/A",ISNUMBER(<mb_ics>))'),
    ('mb_tensao_ok', 'Tensão do catálogo ≥ tensão do sistema?',
     "=IF(NOT(ISNUMBER(<mb_idx>)),\"N/A\",IF(ISNUMBER(<mb_tensao>),<mb_tensao>>='Padrão de entrada'!$B$135,FALSE))"),
    ('mb_polos_ok', 'Polos compatíveis com o circuito?',
     '=IF(NOT(ISNUMBER(<mb_idx>)),"N/A",IF(ISNUMBER(SEARCH("3P ou 4P",{PROT}!$BP{r})),OR(ISNUMBER(SEARCH("3P",<mb_polos>)),ISNUMBER(SEARCH("4P",<mb_polos>))),'
     'IF(ISNUMBER(SEARCH("CONFIRMAR",{PROT}!$BP{r})),"△ CONFIRMAR",IF(ISNUMBER(SEARCH("P",LEFT({PROT}!$BP{r},2))),ISNUMBER(SEARCH(LEFT({PROT}!$BP{r},2),<mb_polos>)),"N/A"))))'),
    ('mb_funcao', 'Função que atua na falta no quadro (auto)',
     '=IF(NOT(<tem_mb>),"N/A",IF(OR(NOT(ISNUMBER(<mb_idx>)),NOT(ISNUMBER(<ik_laco>))),"DADOS INCOMPLETOS",'
     'IF(AND(ISNUMBER(<mb_inst>),<ik_laco>>=<mb_inst>),"I — INSTANTÂNEA",'
     'IF(AND(<mb_classe>="eletrônico",ISNUMBER(<mb_isd>),<ik_laco>>=<mb_isd>),"S — CURTO RETARDO",'
     'IF(AND(<mb_classe>="fixo",ISNUMBER(<mb_im_min>),<ik_laco>>=<mb_im_min>),"△ DENTRO DA BANDA MAGNÉTICA","L — LONGO RETARDO")))))'),
    ('mb_tempo', 'Tempo estimado de eliminação da falta no quadro (s)',
     '=IF(<mb_funcao>="I — INSTANTÂNEA",0.01,IF(<mb_funcao>="S — CURTO RETARDO",IF(ISNUMBER(<mb_tsd>),ROUND(<mb_tsd>/1000,3),"N/D — informe o tsd do disjuntor de manutenção"),'
     'IF(<mb_funcao>="L — LONGO RETARDO",IF(AND(ISNUMBER(<mb_in>),ISNUMBER(<ik_laco>)),IF(AND(<mb_in>>0,<ik_laco>>0),ROUND(MAX(0.01,214*((<ik_laco>/<mb_in>)^-3.42)),3),"N/D"),"N/D"),'
     'IF(<mb_funcao>="△ DENTRO DA BANDA MAGNÉTICA","N/D — atuação dentro da banda magnética (consultar curva WEG)",IF(<mb_funcao>="N/A","","N/D — dados do disjuntor de manutenção incompletos")))))'),
    ('mb_tn', 'Seccionamento automático — falta no quadro (disjuntor de manutenção)', None),  # montado abaixo
    ('mb_status', 'STATUS DO DISJUNTOR DE MANUTENÇÃO', None),  # montado abaixo
    ('trecho_curto', 'Proteção contra curtos-circuitos do trecho (sem dispositivo na origem)', None),
    ('trecho_sobrecarga', 'Proteção contra sobrecargas do trecho (sem dispositivo na origem)', None),
    ('trecho_choque_cabo', 'Seccionamento automático — falta no próprio trecho', None),
    ('trecho_choque', 'SECCIONAMENTO AUTOMÁTICO DO TRECHO (sem dispositivo na origem)', None),
    ('ir_ef', 'Ir do dispositivo do circuito (efetivo)',
     '=IF(<sem_origem>,IF(AND(<tem_mb>,ISNUMBER(<mb_ir>)),<mb_ir>,""),{PROT}!$Y{r})'),
    ('ii_ef', 'Ii/Im do dispositivo do circuito (efetivo)',
     '=IF(<sem_origem>,IF(AND(<tem_mb>,ISNUMBER(<mb_ii>)),<mb_ii>,""),{PROT}!$Z{r})'),
    ('in_ef', 'In do dispositivo do circuito (efetivo)',
     '=IF(<sem_origem>,IF(AND(<tem_mb>,ISNUMBER(<mb_in>)),<mb_in>,""),{PROT}!$K{r})'),
    ('curva_ef', 'Curva/tabela do dispositivo do circuito disponível? (efetivo)',
     '=IF(<sem_origem>,IF(<tem_mb>,<mb_curva>,""),{PROT}!$AY{r})'),
    ('disp_txt', 'Dispositivo deste trecho considerado na seletividade',
     '=IF($A{r}="","",IF(<sem_origem>,IF(<tem_mb>,"Disjuntor de manutenção de "&<circuito>,"Sem dispositivo neste trecho"),"Dispositivo da origem de "&<circuito>))'),
    ('df_origem', 'O dispositivo que alimenta o quadro é o da origem deste circuito? (auto)',
     '=AND(NOT(<tem_mb>),NOT(<sem_origem>))'),
    ('df_desc', 'Dispositivo que alimenta o quadro deste circuito (para os circuitos a jusante)',
     '=IF($A{r}="","",IF(<tem_mb>,"Disjuntor de manutenção de "&<circuito>,IF(NOT(<sem_origem>),"Dispositivo da origem de "&<circuito>,{PREC:df_desc})))'),
    ('df_in', 'In do dispositivo que alimenta o quadro (A)',
     '=IF(<tem_mb>,<mb_in>,IF(NOT(<sem_origem>),{PROT}!$K{r},{PREC:df_in}))'),
    ('df_ir', 'Ir do dispositivo que alimenta o quadro (A)',
     '=IF(<tem_mb>,<mb_ir>,IF(NOT(<sem_origem>),{PROT}!$Y{r},{PREC:df_ir}))'),
    ('df_ii', 'Ii/Im do dispositivo que alimenta o quadro (A)',
     '=IF(<tem_mb>,<mb_ii>,IF(NOT(<sem_origem>),{PROT}!$Z{r},{PREC:df_ii}))'),
    ('df_curva', 'Curva do dispositivo que alimenta o quadro disponível?',
     '=IF(<tem_mb>,<mb_curva>,IF(NOT(<sem_origem>),{PROT}!$AY{r},{PREC:df_curva}))'),
    ('mb_x_origem', 'Pré-seletividade: dispositivo da origem × disjuntor de manutenção',
     '=IF(OR(<sem_origem>,NOT(<tem_mb>)),"N/A",IF(AND(ISNUMBER(<mb_ir>),ISNUMBER({PROT}!$Y{r})),IF({PROT}!$Y{r}>=1.6*<mb_ir>,'
     '"△ RAZÃO DE Ir FAVORÁVEL (≥ 1,6) — confirmar curvas WEG","△ RAZÃO DE Ir < 1,6 — os dois disjuntores em série podem atuar juntos; confirmar curvas WEG"),"N/A"))'),
    ('filhos', 'Circuitos alimentados por este quadro (auto)',
     '=IF($A{r}="","",COUNTIF({IDENT}!$D$2:$D$101,<circuito>))'),
    ('carga_propria', 'Carga própria deste quadro (W) (auto)',
     "=IF($A{r}=\"\",\"\",SUM('Carga nos circuitos'!$J{r}:$L{r}))"),
    ('jus_ir', 'Ir do primeiro dispositivo a jusante, em cadeia sem derivações (A)',
     '=IF($A{r}="","",IF(OR(<filhos><>1,<carga_propria><>0),"",IFERROR(IF(NOT(INDEX($O$2:$O$101,{K})),INDEX({PROT}!$Y$2:$Y$101,{K}),'
     'IF(INDEX($P$2:$P$101,{K}),INDEX($K$2:$K$101,{K}),INDEX(<jus_ir:range>,{K}))),"")))'),
    ('jus_desc', 'Primeiro dispositivo a jusante, em cadeia sem derivações',
     '=IF($A{r}="","",IF(OR(<filhos><>1,<carga_propria><>0),"",IFERROR(IF(NOT(INDEX($O$2:$O$101,{K})),"dispositivo da origem de "&INDEX($B$2:$B$101,{K}),'
     'IF(INDEX($P$2:$P$101,{K}),"disjuntor de manutenção de "&INDEX($B$2:$B$101,{K}),INDEX(<jus_desc:range>,{K}))),"")))'),
    ('ik_origem', 'Ik máximo no quadro de instalação do dispositivo da origem (kA)',
     "=IF($A{r}=\"\",\"\",IF(NOT(ISNUMBER('Cálc_Icc-Cond_Escolhido'!$S{r})),'Cálc_Icc-Cond_Escolhido'!$S{r},"
     'MAX(IF(OR({IDENT}!$D{r}="Transformador",{IDENT}!$D{r}="Fonte",{IDENT}!$D{r}=""),'
     "IFERROR(ROUND('Padrão de entrada'!$B$147*'Padrão de entrada'!$B$135/(SQRT(3)*SQRT(('Padrão de entrada'!$B$137/1000)^2+('Padrão de entrada'!$B$138/1000)^2))/1000,3)"
     "+IF('Cálc_Icc-Cond_Escolhido'!$Q{r}=3,IF(ISNUMBER('Cálc_Icc-Motores'!$AN{r}),'Cálc_Icc-Motores'!$AN{r},0),0),0),"
     "IFERROR(INDEX('Cálc_Icc-Cond_Escolhido'!$S$2:$S$101,MATCH({IDENT}!$D{r},'Cálc_Icc-Cond_Escolhido'!$B$2:$B$101,0)),0)),"
     "'Cálc_Icc-Cond_Escolhido'!$S{r})))"),
]

def _col_name(n):
    out = ''
    while n:
        n, rem = divmod(n - 1, 26)
        out = chr(65 + rem) + out
    return out


COL = {key: _col_name(i + 1) for i, (key, _, _) in enumerate(SPEC)}
INPUTS = [COL[k] for k in ('origem', 'justificativa', 'condicoes', 'tempo_montante', 'desc_montante', 'manut',
                           'mb_familia', 'mb_modelo', 'mb_ir', 'mb_ii', 'mb_isd', 'mb_tsd')]
MB_INPUTS = [COL[k] for k in ('mb_familia', 'mb_modelo', 'mb_ir', 'mb_ii', 'mb_isd', 'mb_tsd')]
# Colunas da r42 em que o Icu/Ics do dispositivo da origem é comparado ao Ik máximo (ver ik_sub).
IK_COLUMNS = {('Cálc-Prot_Cabos', c) for c in ('X', 'AF', 'AG', 'DG', 'CM', 'CN', 'CO', 'CP', 'CQ', 'CR')}
_IK_ORIG = "'Cálc_Icc-Cond_Escolhido'!$S{r}"
_IK_REF = f"{SHEET}!${COL['ik_origem']}"
NUMERIC = {COL[k] for k in ('tempo_montante', 'mb_ir', 'mb_ii', 'mb_isd', 'mb_tsd')}


def ref(key, r):
    """Referência a uma coluna desta aba a partir de outra aba."""
    return f'{SHEET}!${COL[key]}{r}'


def _num(expr, pattern='0.00'):
    """Número com vírgula decimal dentro de uma mensagem."""
    return f'SUBSTITUTE(TEXT({expr},"{pattern}"),".",",")'


def _nest(pairs, default):
    """IF(c1,v1,IF(c2,v2,...,default))."""
    out = default
    for cond, value in reversed(pairs):
        out = f'IF({cond},{value},{out})'
    return out


def _built(key):
    """Fórmulas longas, montadas por partes para ficarem legíveis."""
    V = f'{CHOQUE}!$V{{r}}'
    if key == 'mb_tn':
        ok = _nest([('<mb_funcao>="S — CURTO RETARDO"',
                     '"△ ATENDE PELO CURTO RETARDO ("&' + _num('<mb_tempo>') + '&" s) — somar o tempo de abertura do catálogo"'),
                    ('<mb_funcao>="L — LONGO RETARDO"',
                     '"△ ATENDE PELA CURVA TÉRMICA APROXIMADA ("&' + _num('<mb_tempo>') + '&" s) — confirmar na curva WEG"')],
                   '"✓ FALTA NO QUADRO ELIMINADA A TEMPO — disjuntor de manutenção em "&' + _num('<mb_tempo>') + '&" s ≤ "&' + _num(V) + '&" s"')
        return '=' + _nest([
            ('NOT(<tem_mb>)', '"N/A"'),
            ('NOT(ISNUMBER(<mb_tempo>))', '"⏳ PENDENTE — "&<mb_tempo>'),
            (f'NOT(ISNUMBER({V}))', '"⏳ PENDENTE — tempo máximo de seccionamento indefinido"'),
            (f'<mb_tempo><={V}', ok)],
            '"✗ FALTA NO QUADRO NÃO ELIMINADA A TEMPO — tempo estimado "&' + _num('<mb_tempo>') + '&" s > "&' + _num(V) + '&" s"')
    if key == 'mb_status':
        return '=' + _nest([
            ('NOT(<tem_mb>)', '"N/A — sem disjuntor de manutenção"'),
            ('<mb_modelo>=""', '"⏳ PENDENTE — escolha o modelo do disjuntor de manutenção"'),
            ('NOT(ISNUMBER(<mb_idx>))', '"✗ MODELO NÃO ENCONTRADO NO CATÁLOGO WEG"'),
            ('<mb_classe>="somente magnético"', '"✗ MODELO SOMENTE MAGNÉTICO — sem proteção contra sobrecarga"'),
            ('NOT(ISNUMBER(<mb_ir>))', '"⏳ PENDENTE — informe o Ir do disjuntor de manutenção"'),
            ('<mb_ib_ir>=FALSE', '"✗ Ir ("&' + _num('<mb_ir>', '0') + '&" A) MENOR QUE Ib ("&' + _num('<ib>', '0.0') + '&" A)"'),
            ('<mb_ir_iz>=FALSE', '"✗ Ir ("&' + _num('<mb_ir>', '0') + '&" A) MAIOR QUE Iz ("&' + _num('<iz>', '0.0') + '&" A) — não protege o cabo contra sobrecarga"'),
            ('<mb_ir_faixa>=FALSE', '"✗ Ir FORA DA FAIXA DO CATÁLOGO ("&' + _num('<mb_ir_min>', '0') + '&"–"&' + _num('<mb_ir_max>', '0') + '&" A)"'),
            ('<mb_icu_ok>=FALSE', '"✗ ICU INSUFICIENTE PARA O Ik NO PONTO ("&' + _num('<ik_max>') + '&" kA)"'),
            ('<mb_tensao_ok>=FALSE', '"✗ TENSÃO DO CATÁLOGO INFERIOR À DO SISTEMA"'),
            ('<mb_partida>=FALSE', '"✗ PARTIDA NÃO ATENDIDA — disparo magnético < 1,2 × Ip"'),
            ('<mb_polos_ok>=FALSE', '"✗ POLOS INCOMPATÍVEIS COM O CIRCUITO ("&<mb_polos>&")"'),
            ('LEFT(<mb_tn>,1)="✗"', '<mb_tn>'),
            ('<mb_polos_ok>="△ CONFIRMAR"', '"△ CONFIRMAR O TRATAMENTO DO NEUTRO (POLOS DO DISJUNTOR DE MANUTENÇÃO)"'),
            ('<mb_ics_ok>=FALSE', '"△ ICS NÃO DECLARADO NO CATÁLOGO — demais verificações atendidas"'),
            ('OR(LEFT(<mb_tn>,1)="△",LEFT(<mb_tn>,1)="⏳")', '<mb_tn>')],
            '"✓ DISJUNTOR DE MANUTENÇÃO COMPATÍVEL"')
    if key == 'trecho_curto':
        return '=' + _nest([
            ('NOT(<sem_origem>)', '"N/A — dispositivo na origem"'),
            ('<justificativa>=""', '"⏳ PENDENTE — informe a justificativa da ausência do dispositivo na origem"'),
            ('<condicoes>="SIM"', '"✓ DISPENSA JUSTIFICADA (NBR 5410, 5.3.5.3) — "&<justificativa>'),
            ('<condicoes>="NÃO"', '"✗ CONDIÇÕES DA DISPENSA NÃO ATENDIDAS — prever dispositivo na origem (NBR 5410, 5.3.5.2)"')],
            '"⏳ PENDENTE — confirme as condições da dispensa: linha com risco mínimo de curto-circuito e afastada de material combustível (NBR 5410, 5.3.5.3)"')
    if key == 'trecho_sobrecarga':
        mb = _nest([('AND(<mb_ib_ir>=TRUE,<mb_ir_iz>=TRUE)',
                     '"✓ PELO DISJUNTOR DE MANUTENÇÃO NA EXTREMIDADE — trecho sem derivações (NBR 5410, 5.3.4.2.2)"'),
                    ('<mb_modelo>=""', '"⏳ PENDENTE — escolha o disjuntor de manutenção"'),
                    ('NOT(ISNUMBER(<mb_ir>))', '"⏳ PENDENTE — informe o Ir do disjuntor de manutenção"')],
                   '"✗ Ib ≤ Ir ≤ Iz NÃO ATENDIDO — disjuntor de manutenção"')
        jus = _nest([('<jus_ir><=<iz>',
                      '"✓ PELO "&UPPER(<jus_desc>)&" — Ir "&' + _num('<jus_ir>', '0') + '&" A ≤ Iz "&' + _num('<iz>', '0') +
                      '&" A; cadeia sem derivações até o dispositivo (NBR 5410, 5.3.4.2.2)"')],
                    '"✗ DISPOSITIVO A JUSANTE NÃO PROTEGE O CABO — "&<jus_desc>&" com Ir "&' + _num('<jus_ir>', '0') + '&" A > Iz "&' + _num('<iz>', '0') +
                    '&" A; reduza o Ir ou preveja dispositivo na origem"')
        return '=' + _nest([
            ('NOT(<sem_origem>)', '"N/A — dispositivo na origem"'),
            ('<tem_mb>', mb),
            ('AND(ISNUMBER(<jus_ir>),ISNUMBER(<iz>))', jus),
            ('<condicoes>="SIM"', '"△ SEM PROTEÇÃO CONTRA SOBRECARGA NO TRECHO — confirmar que a linha não é suscetível de sobrecarga (NBR 5410, 5.3.4.3)"'),
            ('<condicoes>="NÃO"', '"✗ TRECHO SEM PROTEÇÃO CONTRA SOBRECARGA — prever dispositivo"')],
            '"⏳ PENDENTE — confirme a dispensa ou adote disjuntor de manutenção na extremidade"')
    if key == 'trecho_choque_cabo':
        ok = _nest([(f'<tempo_montante><={V}',
                     '"✓ FALTA NO TRECHO ELIMINADA A TEMPO — proteção a montante em "&' + _num('<tempo_montante>') + '&" s ≤ "&' + _num(V) + '&" s"')],
                   '"✗ PROTEÇÃO A MONTANTE LENTA — "&' + _num('<tempo_montante>') + '&" s > "&' + _num(V) +
                   '&" s (tempo máximo); prever dispositivo na origem ou isolação dupla/reforçada no trecho"')
        return '=' + _nest([
            ('NOT(<sem_origem>)', '"N/A — dispositivo na origem"'),
            ('NOT(ISNUMBER(<tempo_montante>))',
             '"⏳ PENDENTE — informe o tempo de eliminação da falta pela proteção a montante ("&IF(<desc_montante>="","proteção de MT ou da concessionária",<desc_montante>)&")"'),
            (f'NOT(ISNUMBER({V}))', '"⏳ PENDENTE — tempo máximo de seccionamento indefinido"')], ok)
    if key == 'trecho_choque':
        return '=' + _nest([
            ('NOT(<sem_origem>)', '""'),
            ('LEFT(<trecho_choque_cabo>,1)="✗"', '<trecho_choque_cabo>'),
            ('AND(<tem_mb>,LEFT(<mb_tn>,1)="✗")', '<mb_tn>'),
            ('LEFT(<trecho_choque_cabo>,1)="⏳"', '<trecho_choque_cabo>'),
            ('AND(<tem_mb>,LEFT(<mb_tn>,1)="⏳")', '<mb_tn>'),
            ('AND(<tem_mb>,LEFT(<mb_tn>,1)="△")', '<mb_tn>'),
            ('<tem_mb>', '"✓ SECCIONAMENTO ATENDIDO — trecho pela proteção a montante e quadro pelo disjuntor de manutenção"')],
            '<trecho_choque_cabo>')
    raise KeyError(key)


def _render(template, r):
    text = template
    text = text.replace('{K}', f"MATCH(<circuito>,{IDENT}!$D$2:$D$101,0)")
    text = text.replace('{IDENT}', IDENT).replace('{PROT}', PROT).replace('{CHOQUE}', CHOQUE)
    for col in ('A', 'C', 'G', 'J', 'K', 'M', 'N', 'P', 'W', 'X', 'AA', 'AB', 'AC', 'AL'):
        text = text.replace('{W:%s}' % col, f'{WEG}!${col}$2:${col}$568')
        text = text.replace('{X:%s}' % col, f'INDEX({WEG}!${col}$2:${col}$568,<mb_idx>)')
    parent = f"{IDENT}!$D{{r}}"
    for key in COL:
        root = f'OR({parent}="Transformador",{parent}="Fonte",{parent}="")'
        prec = (f'IF({root},"",IFERROR(INDEX(${COL[key]}$2:${COL[key]}$101,'
                f"MATCH({parent},{IDENT}!$B$2:$B$101,0)),\"\"))")
        text = text.replace('{PREC:%s}' % key, prec)
    for key in sorted(COL, key=len, reverse=True):
        text = text.replace(f'<{key}:range>', f'${COL[key]}$2:${COL[key]}$101')
        text = text.replace(f'<{key}>', f'${COL[key]}{{r}}')
    return text.replace('{r}', str(r))


def sheet_formulas(r):
    out = {}
    for key, _, formula in SPEC:
        if key in ('mb_tn', 'mb_status', 'trecho_curto', 'trecho_sobrecarga', 'trecho_choque_cabo', 'trecho_choque'):
            formula = _built(key)
        if formula is INPUT:
            continue
        out[COL[key]] = _render(formula, r)
    return out


# ---------------------------------------------------------------------------
# Envoltório TRECHO_SE nas fórmulas r42 dependentes dos dispositivos
# ---------------------------------------------------------------------------
def _split_args(body):
    args, cur, depth, quote, i = [], [], 0, None, 0
    while i < len(body):
        ch = body[i]
        if quote:
            cur.append(ch)
            if ch == quote:
                if i + 1 < len(body) and body[i + 1] == quote:
                    cur.append(body[i + 1]); i += 2; continue
                quote = None
        elif ch in '"\'':
            quote = ch; cur.append(ch)
        elif ch in '({':
            depth += 1; cur.append(ch)
        elif ch in ')}':
            depth -= 1; cur.append(ch)
        elif ch == ',' and depth == 0:
            args.append(''.join(cur)); cur = []
        else:
            cur.append(ch)
        i += 1
    args.append(''.join(cur))
    return args


def unwrap(formula):
    """Fórmula r42 original dentro de um (ou mais) TRECHO_SE."""
    f = formula
    while isinstance(f, str) and f.startswith('=' + FN + '(') and f.endswith(')'):
        args = _split_args(f[len(FN) + 2:-1])
        if len(args) != 3:
            break
        f = '=' + args[2]
    if isinstance(f, str) and _IK_REF in f:
        f = re.sub(re.escape(_IK_REF) + r'(\d+)', lambda m: _IK_ORIG.format(r=m.group(1)), f)
    return f


def _root(c):
    return f'OR({c}="Transformador",{c}="Fonte",{c}="")'


def _par(key, r, name="$C{r}"):
    name = name.format(r=r)
    return (f"IFERROR(INDEX({SHEET}!${COL[key]}$2:${COL[key]}$101,"
            f"MATCH({name},{IDENT}!$B$2:$B$101,0)),\"\")")


def _sel_upnd(r):
    """Seletividade: o dispositivo que alimenta o quadro a montante não é o da origem dele."""
    return (f'AND(NOT({_root(f"$C{r}")}),NOT(IFERROR(INDEX({SHEET}!${COL["df_origem"]}$2:${COL["df_origem"]}$101,'
            f'MATCH($C{r},{IDENT}!$B$2:$B$101,0)),TRUE)))')


def _sel_v_new(r):
    return (f'IF({_root(f"$C{r}")},"N/A — PRIMEIRO NÍVEL",IF(AND({ref("sem_origem", r)},NOT({ref("tem_mb", r)})),'
            f'"N/A — SEM DISPOSITIVO NESTE TRECHO",IF({_par("df_desc", r)}="","N/A — SEM DISPOSITIVO DE PROTEÇÃO A MONTANTE",'
            f'"△ PRÉ-VERIFICAÇÃO — NECESSÁRIA TABELA WEG DE SELETIVIDADE")))')


def _dps_changed(r):
    return f'AND(NOT({_root(f"$C{r}")}),$BV{r}<>$C{r})'


def _wraps():
    so = lambda r: ref('sem_origem', r)
    W = {}
    # Cálc-Prot_Cabos ------------------------------------------------------
    W[('Cálc-Prot_Cabos', 'AH')] = lambda o, r: (so(r), '"N/A — SEM DISPOSITIVO NA ORIGEM"')
    W[('Cálc-Prot_Cabos', 'BJ')] = lambda o, r: (so(r), '"N/A — SEM DISPOSITIVO NA ORIGEM"')
    W[('Cálc-Prot_Cabos', 'CG')] = lambda o, r: (so(r), '"Sem dispositivo na origem — verificações do trecho em Proteções › Dispositivos do trecho."')
    W[('Cálc-Prot_Cabos', 'AI')] = lambda o, r: (
        so(r), f'IF(ISNUMBER({ref("tempo_montante", r)}),{o.replace(f"$CE{r}", ref("tempo_montante", r))},'
               f'"N/A — sem dispositivo na origem: informe o tempo da proteção a montante")')
    # Cálc-Prot_Choque -----------------------------------------------------
    W[('Cálc-Prot_Choque', 'Q')] = lambda o, r: (so(r), ref('ii_ef', r))
    W[('Cálc-Prot_Choque', 'V')] = lambda o, r: (so(r), o.replace(f"{PROT}!$Y{r}", ref('ir_ef', r)))
    W[('Cálc-Prot_Choque', 'AA')] = lambda o, r: (so(r), o.replace(f"{PROT}!$Y{r}", ref('ir_ef', r)))
    W[('Cálc-Prot_Choque', 'W')] = lambda o, r: (
        so(r), f'IF({ref("tem_mb", r)},{ref("mb_tempo", r)},IF(ISNUMBER({ref("tempo_montante", r)}),{ref("tempo_montante", r)},"N/D — proteção a montante"))')
    W[('Cálc-Prot_Choque', 'Z')] = lambda o, r: (so(r), ref('trecho_choque', r))
    W[('Cálc-Prot_Choque', 'AD')] = lambda o, r: (so(r), f'IF({ref("tem_mb", r)},{ref("mb_funcao", r)},"PROTEÇÃO A MONTANTE")')
    # Comprimento máximo para atuação instantânea ---------------------------
    W[('Cálc_Comp_Max-Icc', 'J')] = lambda o, r: (so(r), '"N/A — sem dispositivo na origem: a falta no trecho é eliminada pela proteção a montante"')
    # PE pelo critério adiabático: tempo da proteção a montante ou tabela 58 --
    W[('Cálc-Condutor_Terra_Sugerido', 'I')] = lambda o, r: (
        so(r), f'IF(ISNUMBER({ref("tempo_montante", r)}),{ref("tempo_montante", r)},"N/D — sem dispositivo na origem")')
    W[('Cálc-Condutor_Terra_Sugerido', 'J')] = lambda o, r: (
        f'AND({so(r)},NOT(ISNUMBER($I{r})))', '"N/A — sem tempo da proteção a montante: PE pela tabela 58"')
    W[('Cálc-Condutor_Terra_Sugerido', 'M')] = lambda o, r: (f'AND({so(r)},NOT(ISNUMBER($I{r})))', f'$L{r}')
    # Identificação: circuito final ≤ 32 A ----------------------------------
    W[('Identificação dos circuitos', 'N')] = lambda o, r: (so(r), o.replace(f"{PROT}!$Y{r}", ref('ir_ef', r)))
    # Partida × disparo instantâneo -----------------------------------------
    W[('ΔV_Partida_Motores', 'AE')] = lambda o, r: (
        so(r), f'IF(AND({ref("tem_mb", r)},ISNUMBER({ref("ii_ef", r)})),{o.replace(f"{PROT}!$Z{r}", ref("ii_ef", r))},"N/A — sem disjuntor no trecho")')
    # Auditoria ----------------------------------------------------------------
    W[('Auditoria_Checklist', 'I')] = lambda o, r: (so(r), ref('trecho_sobrecarga', r))
    W[('Auditoria_Checklist', 'J')] = lambda o, r: (so(r), ref('trecho_curto', r))
    W[('Auditoria_Checklist', 'K')] = lambda o, r: (so(r), f'IF({ref("tem_mb", r)},{ref("mb_status", r)},"N/A — sem disjuntor no trecho")')
    # Seletividade: dispositivo efetivo a jusante e a montante ----------------
    up = _sel_upnd
    W[('Seletividade', 'D')] = lambda o, r: (so(r), ref('in_ef', r))
    W[('Seletividade', 'L')] = lambda o, r: (so(r), ref('ir_ef', r))
    W[('Seletividade', 'O')] = lambda o, r: (so(r), ref('ii_ef', r))
    W[('Seletividade', 'E')] = lambda o, r: (up(r), _par('df_in', r))
    W[('Seletividade', 'G')] = lambda o, r: (up(r), _par('df_ii', r))
    W[('Seletividade', 'M')] = lambda o, r: (up(r), _par('df_ir', r))
    W[('Seletividade', 'P')] = lambda o, r: (up(r), _par('df_ii', r))
    W[('Seletividade', 'Q')] = lambda o, r: (
        f'OR({so(r)},{up(r)})',
        f'IF({_root(f"$C{r}")},"N/A",IF(AND({ref("curva_ef", r)}="SIM",{_par("df_curva", r)}="SIM"),"SIM","NÃO"))')
    W[('Seletividade', 'V')] = lambda o, r: (f'OR({so(r)},{up(r)})', _sel_v_new(r))
    W[('Seletividade', 'K')] = lambda o, r: (
        f'OR({so(r)},{up(r)})', f'IF(LEFT({_sel_v_new(r)},3)="N/A",{_sel_v_new(r)},{o})')
    # DPS opcional e DPS a montante efetivo ------------------------------------
    W[('DPS', 'I')] = lambda o, r: (
        f'OR(LEFT($BT{r},3)="NÃO",LEFT($BT{r},3)="SIM")',
        f'IF(LEFT($BT{r},3)="NÃO","✗ Não — sem DPS neste quadro (definido pelo projetista)","✓ SIM — definido pelo projetista")')
    W[('DPS', 'J')] = lambda o, r: (
        f'OR(LEFT($BT{r},3)="NÃO",LEFT($BT{r},3)="SIM",AND($A{r}<>"",$BT{r}="",$D{r}="Distribuição",$H{r}="Sim",$BV{r}="",NOT({_root(f"$C{r}")})))',
        f'IF(LEFT($BT{r},3)="NÃO","—",IF($BT{r}="{DPS_T2}","Tipo 2 / Classe II","Tipo 1+2 / Classe I+II"))')
    W[('DPS', 'U')] = lambda o, r: (
        _dps_changed(r), f'IF($BV{r}="","MONTANTE SEM DPS",IFERROR(INDEX($J$2:$J$101,MATCH($BV{r},$B$2:$B$101,0)),"MONTANTE SEM DPS"))')
    W[('DPS', 'V')] = lambda o, r: (
        _dps_changed(r),
        f'IF($J{r}="—","N/A",IF($BV{r}="",IF(AND($H{r}="Sim",$J{r}<>"Tipo 1+2 / Classe I+II"),'
        f'"✗ PRIMEIRO DPS DA INSTALAÇÃO COM SPDA EXTERNO — usar Tipo 1+2 / Classe I+II","✓ PRIMEIRO DPS DA INSTALAÇÃO"),{o}))')
    W[('DPS', 'AL')] = lambda o, r: (
        _dps_changed(r), f'IF($BV{r}="","N/A",IFERROR($G{r}-INDEX($G$2:$G$111,MATCH($BV{r},$B$2:$B$111,0)),"N/A"))')
    W[('DPS', 'BD')] = lambda o, r: (_dps_changed(r), o.replace(f'MATCH($C{r},$B$2:$B$101,0)', f'MATCH($BV{r},$B$2:$B$101,0)'))
    return W


WRAPS = _wraps()


def wrap(sheet, col, row, formula):
    spec = WRAPS.get((sheet, col))
    if not spec or not isinstance(formula, str) or not formula.startswith('='):
        return formula
    original = unwrap(formula)[1:]
    cond, new = spec(original, row)
    return f'={FN}({cond},{new},{original})'


def ik_sub(sheet, col, row, formula):
    """Icu/Ics do dispositivo da origem: Ik do quadro onde ele está instalado (coluna ik_origem),
    no lugar do Ik do fim do próprio cabo usado pela r42."""
    if (sheet, col) not in IK_COLUMNS or not isinstance(formula, str):
        return formula
    return formula.replace(_IK_ORIG.format(r=row), ref('ik_origem', row))


def rewrap(sheet, col, row, formula):
    """Reaplica o envoltório e a troca do Ik depois de uma edição de fórmula pelo modo revisor."""
    if (sheet, col) in WRAPS:
        formula = wrap(sheet, col, row, formula)
    return ik_sub(sheet, col, row, formula)


NEW_COLUMNS = {
    ('DPS', 'BT'): ('DPS neste quadro [ENTRADA — vazio = automático pela natureza e posição do quadro]', None),
    ('DPS', 'BU'): ('Justificativa / observação do DPS neste quadro [ENTRADA]', None),
    ('DPS', 'BV'): ('Circuito do DPS a montante efetivo (auto)',
                    lambda r: (f'=IF($A{r}="","",IF({_root(f"$C{r}")},"",IFERROR(IF(INDEX($J$2:$J$101,MATCH($C{r},$B$2:$B$101,0))<>"—",'
                               f'$C{r},INDEX($BV$2:$BV$101,MATCH($C{r},$B$2:$B$101,0))),"")))')),
    ('Seletividade', 'W'): ('Dispositivo a montante considerado',
                            lambda r: f'=IF($A{r}="","",IF({_root(f"$C{r}")},"",{_par("df_desc", r)}))'),
    ('Seletividade', 'X'): ('Dispositivo deste trecho considerado', lambda r: f'=IF($A{r}="","",{ref("disp_txt", r)})'),
}


def apply(data):
    """Cria a aba e envolve as fórmulas. Idempotente."""
    meta = data.setdefault('meta', {})
    sheets = data['sheets']
    if SHEET in sheets and meta.get('trecho_version') == VERSION:
        return 0
    n = 0
    cells = {}
    for key, header, formula in SPEC:
        cells[COL[key] + '1'] = {'value': header, 'formula': False}
    for r in ROWS:
        for col in INPUTS:
            cells[f'{col}{r}'] = {'value': None, 'formula': False}
        for col, formula in sheet_formulas(r).items():
            cells[f'{col}{r}'] = {'value': formula, 'formula': True, 'cache': None}
    old = sheets.get(SHEET)
    if old:  # preserva entradas existentes
        for a, c in old['cells'].items():
            col = ''.join(ch for ch in a if ch.isalpha())
            if col in INPUTS and not c.get('formula'):
                cells[a] = c
    sheets[SHEET] = {'cells': cells, 'validations': [], 'state': 'visible'}
    for (sheet, col), (header, formula) in NEW_COLUMNS.items():
        body = sheets.get(sheet)
        if not body:
            continue
        body['cells'][col + '1'] = {'value': header, 'formula': False}
        for r in ROWS:
            a = f'{col}{r}'
            if formula is None:
                body['cells'].setdefault(a, {'value': None, 'formula': False})
            else:
                body['cells'][a] = {'value': formula(r), 'formula': True, 'cache': None}
    for (sheet, col) in WRAPS:
        body = sheets.get(sheet)
        if not body:
            continue
        for r in ROWS:
            c = body['cells'].get(f'{col}{r}')
            if c and c.get('formula'):
                new = wrap(sheet, col, r, c['value'])
                if new != c['value']:
                    c['value'] = new
                    n += 1
    for (sheet, col) in IK_COLUMNS:
        body = sheets.get(sheet)
        if not body:
            continue
        for r in ROWS:
            c = body['cells'].get(f'{col}{r}')
            if c and c.get('formula'):
                new = ik_sub(sheet, col, r, c['value'])
                if new != c['value']:
                    c['value'] = new
                    n += 1
    meta['trecho_version'] = VERSION
    return n


# ---------------------------------------------------------------------------
# Leitura para a interface, auditoria e relatório
# ---------------------------------------------------------------------------
def state(p, r):
    g = lambda key: p.get(SHEET, f'{COL[key]}{r}')
    raw = lambda key: p.raw(SHEET, f'{COL[key]}{r}')
    sem_origem = g('sem_origem') is True
    tem_mb = g('tem_mb') is True
    mb = None
    if tem_mb:
        mb = {k: g('mb_' + k) for k in ('modelo', 'familia', 'fabricante', 'in', 'polos', 'ir', 'ii', 'isd', 'tsd', 'ir_min',
                                        'ir_max', 'im_min', 'im_max', 'icu', 'ics', 'classe', 'funcao', 'tempo', 'tn', 'status',
                                        'protege_cabo', 'x_origem')}
        mb['ik_max'] = g('ik_max')
        mb['ik_laco'] = g('ik_laco')
    return {
        'sem_origem': sem_origem,
        'origem_valor': raw('origem') or ORIGEM_SIM,
        'justificativa': raw('justificativa'),
        'condicoes': raw('condicoes'),
        'tempo_montante': raw('tempo_montante'),
        'desc_montante': raw('desc_montante'),
        'tem_mb': tem_mb,
        'mb': mb,
        'status': {'curto': g('trecho_curto'), 'sobrecarga': g('trecho_sobrecarga'),
                   'choque_cabo': g('trecho_choque_cabo'), 'choque': g('trecho_choque'),
                   'mb': g('mb_status') if tem_mb else None},
        'disp_txt': g('disp_txt'),
        'montante': p.get('Seletividade', f'W{r}'),
        'enderecos': {k: {'sheet': SHEET, 'address': f'{COL[k]}{r}'} for k in
                      ('trecho_curto', 'trecho_sobrecarga', 'trecho_choque_cabo', 'trecho_choque', 'mb_status', 'mb_tn',
                       'mb_ib_ir', 'mb_ir_iz', 'mb_icu_ok', 'mb_partida', 'mb_polos_ok', 'mb_tempo', 'mb_x_origem')},
    }


def dps_mode(p, r):
    v = p.raw('DPS', f'BT{r}')
    return v if v in DPS_OPCOES else ''


def exemplo_entrada(p):
    """Alterações do ponto de partida "Exemplo r42 — entrada sem disjuntor na origem".

    Arranjo comum em subestação com medição em baixa tensão: transformador → medição → QGBT sem
    disjuntor nem DPS na origem dos trechos, com o disjuntor geral (de manutenção) na chegada do
    QGBT e o primeiro DPS da instalação no QGBT. As confirmações físicas (condições da dispensa e
    tempo da proteção a montante) ficam pendentes de propósito: dependem da instalação real.
    """
    name=lambda r:p.raw('Identificação dos circuitos',f'B{r}')
    qm=name(3);qgbt=next((r for r in p.active_rows() if r>3 and p.raw('Identificação dos circuitos',f'D{r}')==qm),None)
    ch=lambda r,k,v:{'sheet':SHEET,'address':f'{COL[k]}{r}','value':v}
    out=[ch(2,'origem',ORIGEM_NAO),ch(2,'justificativa',JUSTIFICATIVAS[0]),
         ch(3,'origem',ORIGEM_NAO),ch(3,'justificativa',JUSTIFICATIVAS[1]),
         {'sheet':'DPS','address':'BT2','value':DPS_NAO},{'sheet':'DPS','address':'BT3','value':DPS_NAO}]
    if qgbt:
        out+=[ch(qgbt,'origem',ORIGEM_NAO),ch(qgbt,'justificativa',JUSTIFICATIVAS[0]),ch(qgbt,'manut',SIM),
              ch(qgbt,'mb_familia','ACW400H_630H'),ch(qgbt,'mb_modelo','ACW400H-ETS400-3'),ch(qgbt,'mb_ir',300),
              ch(qgbt,'mb_ii',4400),ch(qgbt,'mb_isd',1500),ch(qgbt,'mb_tsd',100)]
    return out

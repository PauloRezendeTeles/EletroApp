"""Curvas I(t), integração da atuação e integral térmica. Somente biblioteca padrão.

As correntes são eficazes simétricas. A verificação adiabática que usa este módulo
é restrita a 0,1…5 s; transitórios assimétricos/limitação abaixo de 0,1 s exigem I²t
do fabricante. Curvas por ponto não são extrapoladas nem transferidas por uma razão
fixa. O modelo de reatâncias é explicitamente uma estimativa de excitação constante.
"""
from __future__ import annotations
import bisect
import csv
import io
import math
from . import numeros

class MissingData(ValueError):
    pass

def number(value, label, minimum=0, strict=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise MissingData('Informe '+label+'.')
    if value < minimum or strict and value <= minimum:
        raise MissingData(label+': valor fora da faixa admitida.')
    return float(value)

def csv_rows(text, header):
    if not isinstance(text, str) or not text.strip():
        raise MissingData('Informe os pontos da curva.')
    if len(text) > 5000:
        raise ValueError('Curva muito longa (máximo de 5000 caracteres).')
    rows = list(csv.reader(io.StringIO(text.strip()), delimiter=';'))
    if [x.strip().lower() for x in rows[0]] != header:
        raise ValueError('Cabeçalho da curva: '+';'.join(header))
    rows = [r for r in rows[1:] if any(x.strip() for x in r)]
    if not 2 <= len(rows) <= 200:
        raise ValueError('Informe de 2 a 200 pontos na curva.')
    if any(len(r) != len(header) for r in rows):
        raise ValueError('Quantidade de colunas inválida na curva.')
    return rows

def parse_time_curves(text):
    out = {}
    for row in csv_rows(text, ['falta','tempo_s','i_min_a','i_max_a']):
        fault = row[0].strip().upper()
        if fault not in ('3F','2F','FN','FPE'):
            raise ValueError('Tipo de falta inválido: '+fault)
        t, lo, hi = [numeros.parse_br(x.strip()) for x in row[1:]]
        if not all(math.isfinite(x) for x in (t,lo,hi)) or t < 0 or t > 30 or lo < 0 or hi < lo:
            raise ValueError('Curva I(t): 0 ≤ tempo ≤ 30 s e 0 ≤ Imin ≤ Imax.')
        out.setdefault(fault, []).append((t,lo,hi))
    for fault, points in out.items():
        if len(points)<2 or points[0][0]!=0 or any(b[0]<=a[0] for a,b in zip(points,points[1:])):
            raise ValueError(f'{fault}: comece em t=0 e informe tempos estritamente crescentes.')
    return out

def parse_fuse(text):
    out=[]
    for row in csv_rows(text,['corrente_a','t_fusao_min_s','t_eliminacao_max_s']):
        i, lo, hi = [numeros.parse_br(x.strip()) for x in row]
        if not all(math.isfinite(x) for x in (i,lo,hi)) or min(i,lo,hi)<=0 or lo>hi:
            raise ValueError('Curva do elo: I > 0 e 0 < fusão mínima ≤ eliminação máxima.')
        out.append((i,lo,hi))
    if any(b[0]<=a[0] or b[1]>a[1] or b[2]>a[2] for a,b in zip(out,out[1:])):
        raise ValueError('Curva do elo: correntes crescentes e tempos não crescentes.')
    return out

def interpolate(points, x, column=1, logarithmic=False):
    if x < points[0][0]-1e-12 or x > points[-1][0]+1e-12:
        raise MissingData('Corrente/tempo fora do intervalo documentado da curva; sem extrapolação.')
    xs=[p[0] for p in points]
    k=bisect.bisect_left(xs,x)
    if k<len(points) and abs(points[k][0]-x)<=1e-12:
        return points[k][column]
    if k==0:return points[0][column]
    if k==len(points):return points[-1][column]
    a,b=points[k-1],points[k]
    if logarithmic:
        q=math.log(x/a[0])/math.log(b[0]/a[0])
        return math.exp(math.log(a[column])+q*math.log(b[column]/a[column]))
    q=(x-a[0])/(b[0]-a[0])
    return a[column]+q*(b[column]-a[column])

IEC = {'IEC inversa normal':(0.14,0.02), 'IEC muito inversa':(13.5,1.0),
       'IEC extremamente inversa':(80.0,2.0)}

def operating_time(i, pickup, setting, curve='Tempo definido'):
    if i <= pickup:return math.inf
    if curve == 'Tempo definido':return setting
    if curve not in IEC:raise MissingData('Característica de atuação desconhecida.')
    k,alpha=IEC[curve]
    return setting*k/math.expm1(alpha*math.log(i/pickup))

def time_grid(end, breaks=(), resolution=1.0):
    """Passos logarítmicos: resolução relativa ≤ 0,25%, com todos os vértices incluídos."""
    if end<=0:return [0.0]
    grid=[0.0, end]
    t=1e-6
    while t<end:
        grid.append(t)
        t *= 1+0.0025/resolution
    grid.extend(float(t) for t in breaks if 0<t<end)
    return sorted(set(grid))

def simulate(current, laws, interruption, horizon, breaks=()):
    """Integra ∫dt/t(I)=1; tempo definido exige permanência acima de pickup.

    Latch após comando: a interrupção continua mesmo se a corrente decair. O
    reset das funções é imediato abaixo de pickup (modelo explicitado). O tempo
    de interrupção nunca participa da integral do relé e é somado uma única vez.
    """
    state=[0.0]*len(laws)
    grid=time_grid(horizon,breaks)
    previous=0.0
    for t in grid[1:]:
        dt=t-previous
        trips=[]
        for k,law in enumerate(laws):
            factor=law.get('factor',1.0)
            i=min(current(previous),current((t+previous)/2),current(t))*factor
            op=operating_time(i,law['pickup'],law['setting'],law.get('curve','Tempo definido'))
            if math.isinf(op):
                state[k]=0.0
                continue
            rate=math.inf if op==0 else 1/op
            need=0.0 if op==0 else max(0.0,1-state[k])/rate
            if need<=dt:
                trips.append((previous+need,law['name']))
            else:
                state[k]+=dt*rate
        if trips:
            trip,name=min(trips)
            total=trip+interruption
            if total > horizon+1e-10:
                return {'trip_s':trip,'clear_s':None,'function':name,'reason':'Curva/horizonte termina antes da interrupção completa.'}
            return {'trip_s':trip,'clear_s':total,'function':name,'reason':None}
        previous=t
    return {'trip_s':None,'clear_s':None,'function':None,'reason':f'Sem atuação demonstrada até {horizon:g} s.'}

def energy(current, end, breaks=()):
    """∫ I(t)² dt por Simpson, incluindo vértices de curvas lineares."""
    total=0.0
    grid=time_grid(end,breaks)
    for a,b in zip(grid,grid[1:]):
        total+=(b-a)/6*(current(a)**2+4*current((a+b)/2)**2+current(b)**2)
    return total

def admittance(t, xd2, xd1, xs, td2, td1):
    return ((1/xd2-1/xd1)*math.exp(-t/td2)+(1/xd1-1/xs)*math.exp(-t/td1)+1/xs)

def current_from_parameters(voltage, factor, r, x, multiplicity, source_x2, generator, t):
    """Equivalente de sequência positiva variável; a impedância dos cabos é mantida.

    multiplicity é 1 para 3F e para as somas Z1+Z2 e Z1+Z2+Z0: apenas Z1
    recebe a variação de Xd. O modelo não multiplica a corrente inicial do cabo
    pela curva dos terminais e não presume corrente sustentada de 3 In.
    """
    a=admittance(t,*generator)
    effective=source_x2*(1/a)/generator[0]
    z=complex(r,x+multiplicity*(effective-source_x2))
    if abs(z)<=0:raise MissingData('Impedância de falta inválida.')
    return factor*voltage/abs(z)

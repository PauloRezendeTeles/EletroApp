"""Escopos das versões de expressão (v2.1).

Uma variável pode ter versões registradas em três escopos, cada um com sua própria lista de versões e versão ativa:

* ``comum``         — vale para os circuitos (e para a fonte/projeto). Em variáveis com variante para circuitos ligados
                      diretamente à fonte, NÃO substitui essa variante;
* ``raiz``          — só a variante dos circuitos ligados diretamente à fonte ou ao transformador;
* ``circuito:<id>`` — só um circuito (usado para preservar fórmulas particulares de projetos antigos).

Ordem de resolução para um circuito: versão do próprio circuito → (circuito raiz e variável com variante: versão
``raiz`` ou a variante do modelo) → versão ``comum`` → expressão do modelo.

Armazenamento em ``doc['formulas'][var]``: ``{'ativa', 'versoes'}`` (comum), ``'raiz': {...}``, ``'circuitos': {id: {...}}``.
"""
from __future__ import annotations

import copy
import datetime as dt
import re

_CID = re.compile(r'[A-Za-z0-9_-]{1,64}')


def parse_scope(escopo):
    escopo = str(escopo or 'comum').strip()
    if escopo in ('comum', 'raiz'):
        return escopo, None
    if escopo.startswith('circuito:') and _CID.fullmatch(escopo[9:]):
        return 'circuito', escopo[9:]
    raise ValueError('Escopo de versão inválido.')


def scope_name(kind, cid=None):
    return f'circuito:{cid}' if kind == 'circuito' else kind


def seal_key(vid, kind, cid=None):
    return vid if kind == 'comum' else (f'{vid}#raiz' if kind == 'raiz' else f'{vid}@{cid}')


def get_slot(formulas, vid, kind, cid=None, create=False):
    top = formulas.get(vid)
    if top is None:
        if not create:
            return None
        top = formulas[vid] = {'ativa': 0, 'versoes': []}
    if not isinstance(top, dict):
        return None
    if kind == 'comum':
        top.setdefault('ativa', 0)
        top.setdefault('versoes', [])
        return top
    if kind == 'raiz':
        if 'raiz' not in top:
            if not create:
                return None
            top['raiz'] = {'ativa': 0, 'versoes': []}
        return top['raiz']
    circ = top.get('circuitos')
    if circ is None:
        if not create:
            return None
        circ = top['circuitos'] = {}
    if cid not in circ:
        if not create:
            return None
        circ[cid] = {'ativa': 0, 'versoes': []}
    return circ[cid]


def active(slot):
    """Expressão ativa do escopo (None quando vale o nível seguinte)."""
    try:
        n = slot.get('ativa', 0) if isinstance(slot, dict) else 0
        if isinstance(n, int) and n > 0:
            return slot['versoes'][n - 1]['expressao']
    except (IndexError, KeyError, TypeError):
        return None
    return None


def scopes(top):
    """(tipo, id do circuito, slot) de todos os escopos com registro de uma variável."""
    if not isinstance(top, dict):
        return
    if top.get('versoes'):
        yield 'comum', None, top
    if isinstance(top.get('raiz'), dict) and top['raiz'].get('versoes'):
        yield 'raiz', None, top['raiz']
    for cid, slot in (top.get('circuitos') or {}).items() if isinstance(top.get('circuitos'), dict) else ():
        if isinstance(slot, dict) and slot.get('versoes'):
            yield 'circuito', cid, slot


def any_active(top):
    return any((s.get('ativa') or 0) > 0 for _, _, s in scopes(top))


def copy_slot(slot, vid, from_kind, from_cid, to_kind, to_cid):
    """Copia histórico entre escopos sem regularizar uma edição externa ou adulterada."""
    from .integridade import valid, stamp
    result = copy.deepcopy(slot)
    source_key = seal_key(vid, from_kind, from_cid)
    target_key = seal_key(vid, to_kind, to_cid)
    for source, entry in zip(slot.get('versoes', []), result.get('versoes', [])):
        if not isinstance(entry, dict):
            continue
        trusted = valid('formula', source_key, source)
        entry.pop('selo', None)
        entry['escopo'] = scope_name(to_kind, to_cid)
        entry['origem_copia'] = {'escopo': scope_name(from_kind, from_cid), 'versao': source.get('versao')}
        if trusted:
            stamp('formula', target_key, entry)
    return result


def migrate_native(doc, model):
    """Marca a semântica dos escopos e preserva o efeito das edições comuns da 2.0 na raiz."""
    marker = doc.get('semantica_formulas')
    if marker == 'escopos-v1':
        return
    if marker is not None:
        raise ValueError('Semântica de fórmulas desconhecida; abra o projeto na versão do aplicativo que o criou.')
    formulas = doc.get('formulas') or {}
    app = str((doc.get('base') or {}).get('app') or '')
    scoped = any(isinstance(s, dict) and ('raiz' in s or 'circuitos' in s) for s in formulas.values())
    old_common = (app.startswith('2.0') or (not app and not scoped))
    changes = []
    if old_common:
        for vid, top in formulas.items():
            var = model.by_id.get(vid)
            if var and var.variants.get('raiz') and isinstance(top, dict) and active(top) and 'raiz' not in top:
                slot = {k: copy.deepcopy(v) for k, v in top.items() if k not in ('raiz', 'circuitos')}
                top['raiz'] = copy_slot(slot, vid, 'comum', None, 'raiz', None)
                changes.append({'variavel': vid, 'expressao_preservada': active(top), 'de': 'comum da v2.0', 'para': 'raiz'})
    if changes:
        doc.setdefault('meta', {}).setdefault('migracoes_escopos', []).append({
            'data': dt.datetime.now().astimezone().isoformat(timespec='seconds'),
            'origem': app or 'Projeto nativo sem identificação de escopos (compatibilidade v2.0)',
            'alteracoes': changes})
    doc['semantica_formulas'] = 'escopos-v1'

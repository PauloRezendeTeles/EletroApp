"""Correção de "Condutores por polo" (Nc) nas fórmulas da planilha r42.

A r42 aplica Nc na ampacidade e nas impedâncias, mas não na queda de tensão
(seção por condutor), no critério de curto-circuito, na Iz do grupo de
condutores nem na Iz usada em Temp_Operacional. Este módulo reescreve essas
fórmulas ao carregar o modelo. Para Nc = 1 o resultado é idêntico ao da r42.
Premissa (NBR 5410, 6.2.5.7.1 a / 6.2.5.7.2): divisão igual de corrente.
O patch é idempotente: só reescreve a fórmula se ela ainda for a original.
"""
import re

NC="'Dados dos condutores '!$D{r}"
AMP="'Cálc_Seç-Ampacidade'"
FATOR_PAR="IF("+AMP+"!$E{r}=\"Sim\","+AMP+"!$D{r},1)"

def _row(a):return int(re.sub(r'\D','',a))

def _p_queda_sec(f,r):
    """Seção por condutor = seção calculada com a corrente total ÷ Nc (queda de tensão)."""
    pre='=IF($A%d="","",INDEX(Cond2_Seção_Iz,MATCH('%r
    suf=',Cond2_Seção_Iz,-1)))'
    if not (f.startswith(pre) and f.endswith(suf)):return f
    inner=f[len(pre):-len(suf)]
    if "/'Dados dos condutores '!$D" in inner:return f
    return pre+'('+inner+')/'+NC.format(r=r)+suf

def _p_ik_fase(f,r):
    old="IF('Cálc_Icc-Cond_Sugerido'!$R%d=\"\",\"\",'Cálc_Icc-Cond_Sugerido'!$R%d)"%(r,r)
    return f.replace(old,"IF('Cálc_Icc-Cond_Sugerido'!$R%d=\"\",\"\",'Cálc_Icc-Cond_Sugerido'!$R%d/%s)"%(r,r,NC.format(r=r))) if old in f else f

def _p_ik_neutro(f,r):
    pre='=IF($A%d="","",'%r
    if not f.startswith(pre) or not f.endswith(')') or '/\'Dados dos condutores' in f:return f
    inner=f[len(pre):-1]
    return pre+"IF(ISNUMBER(%s),(%s)/%s,%s))"%(inner,inner,NC.format(r=r),inner)

def _p_termica_n(f,r):
    old="*1000)*SQRT($CE%d)"%r
    return f.replace(old,"*1000)/%s*SQRT($CE%d)"%(NC.format(r=r),r)) if old in f else f

def _p_iz(f,r):
    old="ROUND(($J%d*($G%d*$H%d*$I%d)),2)"%(r,r,r,r)
    new="ROUND(($J%d*($G%d*$H%d*$I%d)*%s*%s),2)"%(r,r,r,r,NC.format(r=r),FATOR_PAR.format(r=r))
    return f.replace(old,new) if old in f else f

def _p_temp_iz(f,r):
    old="'Corrente_Max-Cond_Escolhido'!$K%d"%r
    return f.replace(old,old+"/"+NC.format(r=r)) if f=="=IF($A%d=\"\",\"\",%s)"%(r,old) else f

PATCHES=[
 ('Cálc_Seç-Queda de tensão','N',_p_queda_sec),
 ('Cálc_Seç-Queda de tensão','O',_p_queda_sec),
 ('Cálc_Seç-Icc_Cond_Sugerido','G',_p_ik_fase),
 ('Cálc_Seç-Icc_Cond_Sugerido','H',_p_ik_neutro),
 ('Cálc-Prot_Cabos','AI',_p_termica_n),
 ('Corrente_Max-Cond_Escolhido','K',_p_iz),
 ('Corrente_Max-Cond_Sugerido','K',_p_iz),
 ('Temp_Operacional','J',_p_temp_iz),
]

def apply(data):
    """Reescreve as fórmulas e devolve a quantidade de células alteradas."""
    n=0
    for sheet,col,fn in PATCHES:
        cells=data['sheets'].get(sheet,{}).get('cells',{})
        for a,c in cells.items():
            if not c.get('formula'):continue
            m=re.fullmatch(col+r'(\d+)',a)
            if not m or not 2<=int(m.group(1))<=101:continue
            r=int(m.group(1))
            new=fn(c['value'],r)
            if new!=c['value']:c['value']=new;n+=1
    return n

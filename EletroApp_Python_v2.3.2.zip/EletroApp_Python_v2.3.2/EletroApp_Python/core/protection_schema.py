"""Entradas da proteção integrada (v2.3), compartilhadas pelo modelo e pelos formulários."""
SOURCE_SHEET = 'Proteção da entrada'
CIRCUIT_SHEET = 'Proteção integrada'
AUTO = 'Automático pelo atendimento'
FUSE = 'Chave fusível MT'
RELAY = 'Disjuntor MT com relé'
UTILITY = 'Rede BT — proteção externa desconhecida'
GENERATOR = 'Gerador — disjuntor no quadro de transferência'
OWN = 'Saída própria no quadro precedente'
LINK = 'Usar o disjuntor de chegada do quadro precedente'
PARAMETERS = 'Parâmetros — excitação constante'
POINT_CURVES = 'Curvas I(t) por ponto de falta'
YES, NO = 'SIM', 'NÃO'

# chave, rótulo, unidade, opções, bloco, orientação. Nenhum ajuste elétrico é inventado.
SOURCE = [
 ('tipo','Proteção a montante do ramal','',[AUTO,FUSE,RELAY,UTILITY,GENERATOR],'entrada','Em automático: MT sem dados → chave fusível; MT com dados → relé; rede BT → proteção externa desconhecida; gerador → quadro de transferência.'),
 ('medicao','Quadro de medição','',[],'entrada','Limite entre o trecho externo não verificável e a instalação a jusante. Em branco, identifica o quadro pelo nome QM/medição.'),
 ('qta','Quadro de transferência','',[],'entrada','Cadastre o quadro e seu disjuntor de chegada em Proteções. O cabo entre gerador e este quadro fica a cargo do fabricante do gerador.'),
 ('fusivel_tipo','Tipo do elo fusível','',['H','K','T','Outro'],'fusivel','Selecione o tipo efetivo do elo, não a corrente nominal da chave.'),
 ('fusivel_in','Corrente nominal do elo','A',None,'fusivel','Use a corrente nominal da curva informada abaixo.'),
 ('fusivel_documento','Referência da curva do elo','',None,'fusivel','Documento, edição e página do fabricante.'),
 ('fusivel_curva','Curva do elo: corrente_a;t_fusao_min_s;t_eliminacao_max_s','csv',None,'fusivel','Um ponto por linha; mínimo 2 pontos. Correntes em amperes de MT e tempos em segundos. Interpolação logarítmica apenas dentro do intervalo informado; sem curva genérica por letra.'),
 ('interrupcao_ms','Tempo de interrupção do disjuntor MT','ms',None,'rele','Intervalo máximo entre o comando do relé e a eliminação da corrente. Somado uma única vez ao tempo de atuação da função.'),
]
for fn in ('50','51','50N','51N'):
 SOURCE += [(fn+'_ativa',f'Função {fn} habilitada?','',[YES,NO],'rele','Funções N recebem a corrente residual efetivamente transferida à MT; ligação Dyn bloqueia sequência zero na linha primária.'),
            (fn+'_corrente',f'{fn} — corrente de partida na MT','A',None,'rele','Corrente efetiva no circuito de média tensão, já convertida quando necessário.'),
            (fn+'_tempo',f'{fn} — '+('tempo de atuação' if fn.startswith('50') else 'tempo definido ou multiplicador TMS'),'s' if fn.startswith('50') else '',None,'rele','Para tempo definido: segundos. Para curva IEC: multiplicador TMS, adimensional. O tempo de interrupção do disjuntor é somado separadamente.')]
 if fn.startswith('51'):
  SOURCE += [(fn+'_curva',f'{fn} — característica','',['Tempo definido','IEC inversa normal','IEC muito inversa','IEC extremamente inversa'],'rele','IEC: t = TMS × k / ((I/Ip)^α − 1), somente para I > Ip.')]
SOURCE += [
 ('gerador_modo','Modelo temporal do gerador','',[PARAMETERS,POINT_CURVES],'gerador_dinamico','O modelo por parâmetros é uma estimativa com excitação constante. Para incluir a resposta real do AVR, informe curvas I(t) aplicáveis ao ponto de falta em cada circuito.'),
 ('gerador_xd_linha','Reatância transitória X′d','%',None,'gerador_dinamico','Na mesma base da potência nominal do gerador. Deve ficar entre X″d e Xs.'),
 ('gerador_td_linha','Constante de tempo transitória de curto T′d','s',None,'gerador_dinamico','Use a constante de curto-circuito, não a constante de circuito aberto T′do.'),
 ('gerador_td_duas','Constante de tempo subtransitória de curto T″d','s',None,'gerador_dinamico','Valor do fabricante; T″d ≤ T′d.'),
 ('horizonte_s','Horizonte da verificação temporal','s',None,'gerador_dinamico','Até 30 s. Sem atuação nesse intervalo, o aplicativo informa o horizonte, sem concluir que o dispositivo nunca atua.'),
]

CIRCUIT = [
 ('vinculo','Proteção do alimentador','',[OWN,LINK],'Saída própria: o dispositivo fica instalado no quadro precedente. Vínculo: reutiliza o disjuntor de chegada do precedente, sem duplicá-lo.'),
 ('instantaneo_s','Tempo máximo da função instantânea do disjuntor de saída','s',None,'Tempo de atuação da função, sem o tempo de interrupção já informado no catálogo de proteção. Necessário para verificar I(t) sem presumir atuação em 0,01 s.'),
 ('mb_interrupcao_s','Tempo de interrupção do disjuntor de chegada','s',None,'Somado ao tempo da função; não confundir com o retardo Isd.'),
 ('mb_instantaneo_s','Tempo máximo da função instantânea do disjuntor de chegada','s',None,'Tempo de atuação da função, sem a interrupção mecânica.'),
 ('mb_i2t','Disjuntor de chegada — I²t','',['OFF','ON'],'OFF: retardo definido; ON exige a característica dinâmica documentada para confirmação.'),
 ('curva_documento','Referência das curvas de corrente no circuito','',None,'Documento do fabricante ou estudo de curto, edição/página e condição de excitação. As curvas devem incluir a impedância até este ponto e a corrente que percorre este alimentador.'),
 ('curva_corrente','Curvas do gerador: falta;tempo_s;i_min_a;i_max_a','csv',None,'Tipos: 3F, 2F, FN e FPE. Um ponto por linha, a partir de t=0; mínimo 2 pontos por falta. Correntes eficazes simétricas no alimentador para falta no fim do circuito, já considerando cabos, rede e excitação. Não transpor uma curva dos terminais por uma razão constante.'),
]
SCOL = {x[0]:'B'+str(i+2) for i,x in enumerate(SOURCE)}
CCOL = {x[0]:chr(65+i) for i,x in enumerate(CIRCUIT)}
RESULTS = [
 ('ativa','Verificação integrada aplicável?','active'),
 ('estado','Proteção integrada — situação','status'),
 ('tempo_cabo_s','Tempo máximo de eliminação — faltas entre condutores (s)','time_phase'),
 ('tempo_pe_s','Tempo máximo de eliminação — falta fase–PE (s)','time_pe'),
 ('energia_fase','Integral de corrente ao quadrado — fase (A²s)','energy_phase'),
 ('energia_neutro','Integral de corrente ao quadrado — neutro (A²s)','energy_neutral'),
 ('energia_pe','Integral de corrente ao quadrado — PE (A²s)','energy_pe'),
 ('secao_fase_min','Seção térmica calculada por condutor de fase (mm²)','section_phase'),
 ('secao_neutro_min','Seção térmica calculada por condutor neutro (mm²)','section_neutral'),
 ('secao_pe_min','Seção térmica calculada por condutor PE (mm²)','section_pe'),
 ('termica','Suportabilidade térmica do cabo','thermal'),
 ('tn','Seccionamento automático com a proteção efetiva','tn'),
 ('dispositivo','Dispositivo físico que protege o alimentador','device'),
 ('metodo','Método da verificação','method'),
 ('detalhes','Memória da verificação integrada','detail'),
]
RCOL = {x[0]:chr(65+len(CIRCUIT)+i) for i,x in enumerate(RESULTS)}

def profile(source_type, selected=None):
 if selected and selected != AUTO:
  return selected
 return {'Rede MT/Trafo sem dados':FUSE,'Rede MT/Trafo com dados':RELAY,'Rede BT Direta':UTILITY,'Gerador BT':GENERATOR}.get(source_type)

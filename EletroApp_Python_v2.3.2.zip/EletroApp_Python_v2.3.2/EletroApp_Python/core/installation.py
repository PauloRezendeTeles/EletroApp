"""Uma única regra para as escolhas da tela, a API e as fórmulas elétricas.

Fontes: guia Prysmian Rev10, tabelas 1, 5–17, pp. 3 e 7–19;
NBR 5410:2004, versão corrigida 2008, tabela 33 e 6.2.5.1.2.
Em divergência, prevalece a norma.
O documento foi consultado no chat; somente as regras extraídas são distribuídas.
"""
import json
import math
import re
import unicodedata
from pathlib import Path
from .formula import Error
from . import grouping

RULES=json.loads((Path(__file__).resolve().parents[1]/'data/installation_rules.json').read_text(encoding='utf-8'))
METHOD='Identificação-Método_Instal '
WIRE='Dados dos condutores '
LINE='Maneira de instalar'
ENV='Dados dos circuitos'
FIELDS={'line':(LINE,'B'),'method':(METHOD,'B'),'cable':(METHOD,'C'),
        'adjustment':(METHOD,'H'),'material':(WIRE,'F'),'insulation':(WIRE,'I'),
        'voltage':(WIRE,'J'),'arrangement':(WIRE,'L'),'parallel':(WIRE,'D'),
        'separate':(WIRE,'E'),'temperature_air':(ENV,'B'),'temperature_soil':(ENV,'C'),
        'soil':(ENV,'D'),'circuits':(ENV,'E')}
LABELS={'line':'Tipo de linha elétrica','method':'Montagem da instalação',
        'cable':'Tipo de condutor','adjustment':'Disposição dos condutores',
        'material':'Material do condutor','insulation':'Isolação','voltage':'Tensão de isolação',
        'arrangement':'Arranjo para cálculo de impedância','parallel':'Condutores por polo',
        'separate':'Paralelos em condutos distintos (não implica independência térmica)','soil':'Resistividade térmica do solo','circuits':'Circuitos elétricos no trecho (cadastro legado)'}
GROUP_LABELS={'feixe':'Em feixe / dentro de conduto fechado','parede':'Camada única na parede, piso ou bandeja não perfurada',
              'teto':'Camada única no teto','bandeja':'Camada única em bandeja perfurada',
              'leito':'Camada única sobre leito ou suporte','camadas':'Mais de uma camada',
              'direto':'Cabos diretamente enterrados','dutos':'Circuitos em dutos individuais enterrados'}
SETTING_KEYS={'group','spacing','depth','layers','per_layer','geometry_mode','geometry_signature',
              'diameter','surface_gap','cable_gap','space_ratio'} | grouping.KEYS
DISPOSITIONS=[{'reference':'F','loaded':2,'options':['Justapostos']},
              {'reference':'F','loaded':3,'options':['Justapostos','Trifólio']},
              {'reference':'G','loaded':3,'options':['Horizontal','Vertical']}]
INSULATIONS={'Condutor isolado':['PVC','LSHF/A'],
             'Cabo unipolar':['PVC','EPR','HEPR','XLPE'],
             'Cabo multipolar':['PVC','EPR','HEPR','XLPE']}
CLEARANCES={'E':{'cable':'Cabo multipolar','surface_ratio':.3,'cable_ratio':None},
            'F':{'cable':'Cabo unipolar','surface_ratio':1,'cable_ratio':None},
            'G':{'cable':'Condutor isolado ou cabo unipolar','surface_ratio':1,'cable_ratio':1}}
PERFORATION_MIN=30

def thermal_insulation(value):
    return {'LSHF/A':'PVC','HEPR':'EPR'}.get(value,value)

_THERMAL_REF=re.compile(r"'Dados dos condutores '!\$?I\$?\d+")
_THERMAL_WRAPPER=re.compile(r"THERMALINSULATION\(('Dados dos condutores '!\$?I\$?\d+)\)")

def thermal_formula(expression,unwrap=False):
    """Adapta a classe térmica sem mudar textos nem duplicar funções.

    O catálogo reconhece o template original e mantém a adaptação ao editar
    ou restaurar uma fórmula. O nome informado no cadastro continua intacto.
    """
    parts=re.split(r'("(?:[^"]|"")*")',expression)
    for i in range(0,len(parts),2):
        part=_THERMAL_WRAPPER.sub(r'\1',parts[i])
        parts[i]=part if unwrap else _THERMAL_REF.sub(lambda m:'THERMALINSULATION('+m[0]+')',part)
    return ''.join(parts)

def method_number(value):return str(value).split('_')[0]

def catalogs():
    """Tabelas, galeria e validação compartilham a mesma matriz."""
    methods={};lines={}
    for line in RULES['lines']:
        codes=[]
        for v in line['variants']:
            code=v['code'];codes.append(code)
            item=methods.setdefault(code,{'codigo':code,'numero':method_number(v['method']),
                'method':v['method'],'descricao':v['description'],'letra':v['reference'],
                'imagem':v['image'],'tipos':[],'notas':list(v.get('norm_notes',[]))})
            if v['cable'] not in item['tipos']:item['tipos'].append(v['cable'])
        record={'codigos_imagem':list(dict.fromkeys(codes)),'sem_imagem':[],
                'cabos':list(dict.fromkeys(v['cable'] for v in line['variants']))}
        for name in [line['name']]+line.get('aliases',[]):lines[normalized(name)]=record
    return list(methods.values()),lines

def consultation():
    order=[21,25,28,20,24,9,19,5,6,17,18,16,11,12,10,30,31,8,3,13,14,15,4,26,1,23,22,7,2,27,0,29]
    return {'source':RULES['source'],'note':RULES['normative_note'],
            'lines':[RULES['lines'][i] for i in order],'dispositions':DISPOSITIONS,
            'insulations':INSULATIONS,'clearances':[{'reference':ref,**x} for ref,x in CLEARANCES.items()],
            'perforation_min':PERFORATION_MIN,'grouping':grouping.consultation(RULES)}

def normalized(value):
    return ' '.join(unicodedata.normalize('NFKD',str(value or '')).encode('ascii','ignore').decode().casefold().split())
def unique(values):return list(dict.fromkeys(values))
def numeric(value):
    if isinstance(value,bool):return None
    try:
        result=float(value)
        return result if math.isfinite(result) else None
    except (TypeError,ValueError):return None
def integer(value):
    n=numeric(value)
    return int(n) if n is not None and n>=1 and n.is_integer() else None
def equal(a,b):return str(a)==str(b) or numeric(a) is not None and numeric(a)==numeric(b)
def pending(message):return Error('#N/A','Instalação pendente: '+message)

class Installation:
    def __init__(self,project):
        self.p=project
        self.rules=project.model.rules.get('installation_rules.json')
        if self.rules is None:
            raise ValueError('Base arquivada incompleta: regras de instalação ausentes; não é possível reproduzir os cálculos antigos.')
    def values(self,r):
        v={k:self.p.raw(s,f'{c}{r}') for k,(s,c) in FIELDS.items()}
        line=self.line(v['line'])
        if line:
            v['line']=line['name']
            match=next((x for x in line['variants'] if equal(x['method'],v['method']) or v['method'] in x.get('method_aliases',[])),None)
            if match:v['method']=match['method']
        return v
    def settings(self,r):
        uid=self.p.meta['ids'].get(str(r))
        return self.p.meta.get('installation_settings',{}).get(uid,{})
    def line(self,value):return next((x for x in self.rules['lines'] if normalized(value) in [normalized(n) for n in [x['name']]+x.get('aliases',[])]),None)
    def loaded(self,r):
        n=self.p.get(WIRE,f'C{r}')
        return int(n) if numeric(n) in (2,3) else None
    def named_rows(self,name):
        target=self.p.model.names.get(name,'')
        m=re.fullmatch(r"'?(.*?)'?!\$?([A-Z]+)\$?(\d+):\$?([A-Z]+)\$?(\d+)",target)
        if not m:return []
        s,col,start,_,end=m.groups()
        raw=self.p.raw
        return [(raw(s,f'{col}{r}'),raw(s,f'BR{r}')) for r in range(int(start),int(end)+1)]
    def table_name(self,ref,material,insulation,n,adjustment):
        if not all([ref,material,insulation,n]):return None
        n=integer(n) or n
        insulation=thermal_insulation(insulation)
        thermal='PVC70g' if insulation=='PVC' else 'EPR_XLPE90g' if insulation in ('EPR','XLPE') else None
        if not thermal:return None
        prefix=f'Cond{n}_{material}_{thermal}_{ref}_'
        suffix=adjustment if ref in ('F','G') else 'NsA'
        for name in self.p.model.names:
            canonical=name.replace('_É_','_E_')
            if canonical==prefix+str(suffix):return name
            # A tabela de dois condutores não distingue trifólio: um único par justaposto.
            if n==2 and ref=='F' and adjustment=='Justapostos' and canonical==prefix+'NsA':return name
        return None
    def group_options(self,ref,method):
        return grouping.options(ref,method)
    def state(self,r,reference=None,reconcile=False,trigger=None,settings=None):
        v=self.values(r);settings=dict(self.settings(r) if settings is None else settings)
        line=self.line(v['line']);variants=line['variants'] if line else []
        refs=line['references'] if line else []
        matching=[x for x in variants if equal(x['method'],v['method'])]
        # Primeiro o número do método determina a letra de referência; o tipo
        # de cabo depois restringe as opções. Isso mantém 1/2 visíveis como A1/A2
        # mesmo quando um arquivo antigo contém uma combinação incompatível.
        derived=matching[0]['reference'] if matching else None
        ref=reference if reference is not None else derived
        if ref not in refs:ref=None
        if reconcile and ref is None and len(refs)==1:ref=refs[0]
        opts={'line':[x['name'] for x in self.rules['lines']]}
        def choose(k,options,auto=False):
            opts[k]=options
            # Uma etapa ainda sem opções mantém a entrada anterior desabilitada.
            # Assim uma transição com cabo pendente não apaga cobre/PVC válidos;
            # a restrição efetiva é aplicada quando a lista volta a existir.
            if reconcile and options:
                if not any(equal(v[k],o) for o in options):v[k]=None
                if v[k] is None and auto and len(options)==1:v[k]=options[0]
        if line:v['line']=line['name']
        variants_ref=variants
        # O método da interface é a montagem física; sua letra (A1, A2, B1...)
        # vem da matriz. A lista nunca é filtrada pelo cabo antigo salvo.
        method_options=unique(x['method'] for x in variants_ref)
        choose('method',method_options,True)
        method_variants=[x for x in variants_ref if equal(x['method'],v['method'])]
        if not method_variants:method_variants=variants_ref
        if method_variants:
            # Alguns métodos têm duas letras de referência, determinadas pelo
            # tipo de cabo (por exemplo 13/14: E para multipolar e F para
            # unipolar). Não descarte uma delas antes de olhar o cabo salvo.
            by_cable=next((x for x in method_variants if x['cable']==v['cable']),None)
            if by_cable: ref=by_cable['reference']
            elif len({x['reference'] for x in method_variants})==1: ref=method_variants[0]['reference']
        choose('cable',unique(x['cable'] for x in method_variants),True)
        current=next((x for x in method_variants if x['cable']==v['cable']),None)
        if current:ref=current['reference']
        n=self.loaded(r)
        choose('adjustment',(['Justapostos'] if n==2 else ['Justapostos','Trifólio']) if ref=='F' else ['Horizontal','Vertical'] if ref=='G' else ['N/A'] if ref else [],True)
        bloqueio=self.p.aluminio_bloqueado()
        choose('material',(['Cobre'] if bloqueio else ['Cobre','Alumínio']) if v['cable'] in opts['cable'] else [])
        choose('insulation',INSULATIONS.get(v['cable'],[]),True)
        choose('voltage',['450/750V'] if v['cable']=='Condutor isolado' and v['insulation'] in opts['insulation'] else ['0,6/1kV'] if v['cable'] in ('Cabo unipolar','Cabo multipolar') and v['insulation'] in opts['insulation'] else [],True)
        wire_key={'Condutor isolado':'Condutor_Isolado','Cabo unipolar':'Cabo_Unipolar','Cabo multipolar':'Cabo_Multipolar'}.get(v['cable'])
        all_arr=self.named_rows(f'ProcTab_{n}Cond_{wire_key}') if wire_key and n else []
        allowed_codes=[]
        if v['cable']=='Cabo multipolar':allowed_codes=[f'{n}Cond_'+('Bipolar' if n==2 else 'Tripolar')]
        elif ref=='F':allowed_codes=[f'{n}Cond_'+('Trifólio' if v['adjustment']=='Trifólio' else 'Próximo')]
        elif ref=='G':allowed_codes=[f'{n}Cond_{suffix}' for suffix in ('2x_Diâmetro','13cm','20cm')]
        elif ref:allowed_codes=[f'{n}Cond_Próximo']+(['3Cond_Trifólio'] if n==3 else [])
        choose('arrangement',[label for label,code in all_arr if code in allowed_codes],True)
        opts['soil']=[.5,.7,1,1.5,2,2.5,3] if ref=='D' else []
        group_opts=self.group_options(ref,v['method'])
        # A nova interface torna explícita a profundidade que antes era implícita nas tabelas.
        settings.setdefault('depth',.7)
        grouped=grouping.evaluate(self.rules,v,ref,n,settings)
        settings=grouped['settings'];group=settings.get('group')
        spaces=grouping.SPACES.get(group,[])
        issues=[]
        if not line:issues.append('Selecione um tipo de linha elétrica do catálogo.')
        if not ref:issues.append('Selecione o método de referência compatível com a instalação.')
        for k in ['method','cable','adjustment','material','insulation','voltage']:
            if v[k] in (None,''):issues.append(f'{LABELS[k]}: selecione uma opção compatível.')
            elif not any(equal(v[k],o) for o in opts[k]):issues.append(f'{LABELS[k]}: "{v[k]}" é incompatível com as escolhas anteriores.')
        if not current and line and v['method'] not in (None,'') and v['cable']:issues.append('A montagem e o tipo de condutor não pertencem ao método de referência escolhido.')
        if v['material']=='Alumínio':issues.extend(self.p.aluminio_regras(r))
        for k in ['parallel','circuits']:
            if integer(v[k]) is None:issues.append(f'{LABELS[k]} deve ser um número inteiro maior que zero.')
        thermal='PVC' if grouped['temperature']==70 else 'EPR'
        table=self.table_name(ref,v['material'],thermal,n,v['adjustment'])
        if not table:
            issues.append('Método G: não há coluna de ampacidade para dois condutores carregados na base; esta condição requer cálculo específico.' if ref=='G' and n==2 else 'Não há coluna de ampacidade cadastrada para esta combinação de método, isolação e condutores carregados.')
        if ref=='D':
            if numeric(v['soil']) not in opts['soil']:issues.append('Selecione uma resistividade do solo tabelada.')
            depth=numeric(settings.get('depth'))
            if depth is None or not .7<=depth<=2:issues.append('A profundidade suportada pelo guia está entre 0,70 m e 2,00 m.')
            elif depth>.8 and numeric(v['soil'])!=2.5:issues.append('Fator de resistividade fora da profundidade coberta pela tabela 12 (até 0,80 m); requer cálculo específico.')
        issues.extend(grouped['issues'])
        if v['separate'] not in ('Sim','Não'):issues.append('Informe se há condutos distintos para os condutores em paralelo.')
        geometry=self.geometry(v,ref,n,settings)
        issues.extend(geometry['issues'])
        # O arranjo de impedância não escolhe a coluna de ampacidade. Uma
        # pendência nele mantém o circuito incompleto, mas não apaga um
        # cálculo térmico cujas condições já foram verificadas.
        ampacity_issues=unique(issues)
        if v['arrangement'] in (None,''):
            issues.append(f'{LABELS["arrangement"]}: selecione uma opção compatível.')
        elif not any(equal(v['arrangement'],o) for o in opts['arrangement']):
            issues.append(f'{LABELS["arrangement"]}: "{v["arrangement"]}" é incompatível com as escolhas anteriores.')
        return {'values':v,'options':opts,'references':refs,'reference':ref,'variants':method_variants,'selected':current,
                'loaded':n,'table':table,'settings':settings,'group_options':[{'value':x,'label':GROUP_LABELS[x]} for x in group_opts],
                'spacing_options':spaces,'geometry':geometry,'grouping':grouped,
                'issues':unique(issues),'valid':not issues,'underground':ref=='D',
                'ampacity_issues':ampacity_issues,'ampacity_valid':not ampacity_issues}

    def geometry(self,v,ref,n,settings):
        """Condições físicas não são inferidas da categoria selecionada."""
        criteria=[];fields=[];limits=None
        method=str(v['method'] or '')
        if '_' in method:
            span=method.split('_',1)[1]
            ranges={'1,5-5De':(1.5,5),'5-50De':(5,50),'1,5-20De':(1.5,20),'20+De':(20,None)}
            limits=ranges.get(span)
            if limits:
                lo,hi=limits
                criteria.append(f'{lo:g} ≤ V/De'+(f' < {hi:g}' if hi else ' (sem limite superior tabelado)'))
                fields=[{'key':'space_ratio','label':'Relação V/De','unit':''}]
        if ref in ('E','F','G'):
            ratio=CLEARANCES[ref]['surface_ratio']
            criteria.append(f'Distância livre do cabo à superfície adjacente ≥ {ratio:g} × diâmetro externo do cabo.')
            fields += [{'key':'diameter','label':'Diâmetro externo do cabo','unit':'mm'},
                       {'key':'surface_gap','label':'Distância livre até a superfície','unit':'mm'}]
            if ref=='G':
                criteria.append('Distância livre entre cabos ≥ um diâmetro externo do cabo.')
                fields.append({'key':'cable_gap','label':'Distância livre entre cabos','unit':'mm'})
        if equal(v['method'],13):criteria.append(f'Área perfurada da bandeja ≥ {PERFORATION_MIN}% da área total (NBR 5410, tabela 33, nota 4).')
        signature='|'.join(str(x) for x in [v['line'],v['method'],v['cable'],v['insulation'],v['adjustment'],n])
        mode=settings.get('geometry_mode') if settings.get('geometry_signature')==signature else None
        issues=[]
        if criteria:
            if mode not in ('confirmed','dimensions'):issues.append('Confirme as condições geométricas da instalação ou informe as dimensões.')
            elif mode=='dimensions':
                if limits:
                    value=numeric(settings.get('space_ratio'));lo,hi=limits
                    if value is None or value<lo or hi is not None and value>=hi:issues.append('A relação V/De não atende à faixa da instalação selecionada.')
                if ref in ('E','F','G'):
                    d=numeric(settings.get('diameter'));gap=numeric(settings.get('surface_gap'))
                    if d is None or d<=0 or gap is None or gap<ratio*d:issues.append('O afastamento da superfície não atende ao mínimo para o cabo e método selecionados.')
                    if ref=='G':
                        gap=numeric(settings.get('cable_gap'))
                        if d is None or d<=0 or gap is None or gap<d:issues.append('O afastamento entre cabos não atende ao método G.')
        basis='De: diâmetro externo do eletroduto circular ou altura/profundidade do conduto não circular.' if method_number(method) in ('22','23','24','25','41') else 'De: dimensão equivalente do cabo/conjunto. Para três unipolares: 2,2 × diâmetro em trifólio ou 3 × diâmetro no mesmo plano (tabela 33, nota 6).'
        return {'required':bool(criteria),'criteria':criteria,'fields':fields,'signature':signature,'mode':mode,
                'basis':basis if limits else 'Use distâncias livres, medidas entre as superfícies, e o diâmetro externo completo do cabo.', 'issues':issues}
    def verify(self,r):
        state=self.state(r)
        if state['issues']:raise ValueError('Revise a instalação: '+' '.join(state['issues']))
    def method_ref(self,r):
        v=self.values(int(r));line=self.line(v['line'])
        match=next((x for x in (line['variants'] if line else []) if equal(x['method'],v['method']) and x['cable']==v['cable']),None)
        # A base legada escreve É nos nomes das tabelas. O usuário vê E.
        return ('É' if match['reference']=='E' else match['reference']) if match else pending('linha, montagem e tipo de condutor incompatíveis')
    def amp_table(self,r):
        s=self.state(int(r))
        return s['table'] if s['ampacity_valid'] else pending('; '.join(s['ampacity_issues']))
    def ampacity_error(self,r,quantity,kind):
        """Diagnóstico da consulta, sem substituir INDEX/MATCH ou seus valores.

        Chamado apenas pelo ramo de erro das fórmulas de seção e Iz; mantém
        a causa das entradas/dependências em vez de devolver texto numérico.
        """
        s=self.state(int(r))
        if s['ampacity_issues']:return pending('; '.join(s['ampacity_issues']))
        if isinstance(quantity,Error):return quantity
        value=numeric(quantity)
        if value is None:return Error('#N/A','Ampacidade pendente: informe '+('a seção do condutor.' if kind=='section' else 'a corrente de dimensionamento.'))
        if kind=='section':
            return Error('#N/A',f'Ampacidade pendente: seção de {value:g} mm² sem valor na tabela selecionada; confira a seção e os dados da tabela.')
        return Error('#N/A',f'Ampacidade pendente: corrente de dimensionamento de {value:g} A sem seção correspondente na tabela selecionada; confira os limites e os dados da tabela.')
    def arrangement_code(self,r):
        s=self.state(int(r));v=s['values']
        keys=['line','method','cable','adjustment','material','insulation','voltage','arrangement']
        if not s['selected'] or any(not any(equal(v[k],o) for o in s['options'][k]) for k in keys):
            return pending('corrija a combinação de instalação, cabo e arranjo')
        key={'Condutor isolado':'Condutor_Isolado','Cabo unipolar':'Cabo_Unipolar','Cabo multipolar':'Cabo_Multipolar'}[v['cable']]
        return next((code for label,code in self.named_rows(f"ProcTab_{s['loaded']}Cond_{key}") if label==v['arrangement']),pending('arranjo não cadastrado'))
    def soil_factor(self,r):
        ref=self.method_ref(r)
        if isinstance(ref,Error):return ref
        if ref!='D':return 1.0
        v=self.values(int(r));rho=numeric(v['soil'])
        depth=numeric(self.settings(int(r)).get('depth',.7))
        if depth is None or not .7<=depth<=2:return pending('profundidade fora da faixa 0,70–2,00 m')
        if depth>.8 and rho!=2.5:return pending('resistividade fora do limite de profundidade da tabela')
        if rho==2.5:f=1.0
        else:
            record=next((x for x in self.rules['soil'] if x['resistividade']==rho),None)
            if not record:return pending('resistividade do solo não tabelada')
            f=record['diretamente_enterrados' if equal(v['method'],63) else 'dutos_enterrados']
        return f*(1-(depth-.7)*.1)
    def group_factor(self,r,count=None):
        s=self.state(int(r));g=s['grouping']
        return g['factor'] if s['ampacity_valid'] and g['factor'] is not None else pending('; '.join(s['ampacity_issues']))

    def group_trace(self,r):
        g=self.state(int(r))['grouping']
        parts=[g.get('count_explanation',''),g.get('source') or '',g['coordinate']]
        if g['factor'] is not None:parts.append(f"FCA={g['factor']:.6g}")
        parts+=g['issues']+g['notes']
        return ' | '.join(x for x in parts if x)

    def temperature_factor(self,r):
        s=self.state(int(r));v=s['values'];underground=s['reference']=='D'
        temp=numeric(v['temperature_soil' if underground else 'temperature_air'])
        raw=lambda a:self.p.raw('Tabelas_Correção-In',a)
        col='P' if underground else 'L'
        value_col=('Q' if underground else 'M') if s['grouping']['temperature']==70 else ('R' if underground else 'N')
        for row in range(2,17):
            if numeric(raw(f'{col}{row}'))==temp and temp is not None:
                value=numeric(raw(f'{value_col}{row}'))
                return value if value is not None and value>0 else pending('temperatura fora da classe térmica do grupo')
        return pending('temperatura não tabelada')

    def _neutral_heating(self,r):
        """(fator, motivo) do carregamento do neutro — 6.2.5.6.1 e Anexo F (F.2 e F.3)."""
        r=int(r);kind=str(self.p.get('Carga nos circuitos',f'D{r}'))
        rate=numeric(self.p.raw(ENV,f'G{r}'))
        if not (kind.startswith('3F') and 'N' in kind):
            return 1.,'1 — não se aplica: o fator 0,86 de 6.2.5.6.1 vale para circuito trifásico com neutro.'
        if rate is None or rate<=15:
            return 1.,'1 — 3ª harmônica até 15%: o neutro não é considerado carregado (6.2.5.6.1).'
        if rate>45:
            # F.2 (condutores isolados ou unipolares com fases igualadas ao neutro) e F.3 (cabo tetra/pentapolar com
            # todos os condutores da mesma seção): o fator torna-se dispensável quando o cálculo usa taxa acima de 45%.
            fase=numeric(self.p.raw('Seleção-Seção_Condutor',f'T{r}'));neutro=numeric(self.p.raw('Seleção-Seção_Condutor',f'W{r}'))
            if fase is not None and neutro is not None and fase==neutro:
                return 1.,(f'1 — fator 0,86 dispensado: 3ª harmônica de {rate:g}% (acima de 45%) e fases com a mesma seção do neutro '
                           '(NBR 5410, Anexo F, F.2 e F.3).')
            return .86,(f'0,86 — neutro carregado, 3ª harmônica de {rate:g}% (6.2.5.6.1). Acima de 45%, o fator é dispensável se as fases '
                        'tiverem a seção do neutro (Anexo F, F.2 e F.3).')
        return .86,f'0,86 — neutro carregado, 3ª harmônica de {rate:g}% (6.2.5.6.1).'

    def neutral_heating(self,r):
        return self._neutral_heating(r)[0]

    def neutral_heating_info(self,r):
        return self._neutral_heating(r)[1]

    def neutral_current(self,r):
        r=int(r)
        kind=str(self.p.get('Carga nos circuitos',f'D{r}'))
        if 'N' not in kind:return 'N/A'  # circuito sem neutro (2F+T, 3F+T): Tabela 46
        phase=self.p.get('Cálc_Seç-Ampacidade',f'F{r}')
        neutral=self.p.get('Corrente-Calc_Ampacidade ',f'S{r}');nc=integer(self.values(r)['parallel'])
        # v2.3.2: o neutro pode ter quantidade própria de condutores em paralelo (vazio = igual às fases).
        nn=integer(self.p.get(WIRE,f'R{r}'))
        if numeric(neutral) is None or not nc or not nn or numeric(phase) is None:return pending('correntes do neutro ou paralelos pendentes')
        # Piso legado opcional: 15% da corrente da fase, repartida entre os condutores do neutro (uma única divisão).
        floor=.15*phase*nc/nn if self.settings(r).get('neutral_floor',True) else 0
        return max(neutral/nn,floor)

    def reduced_neutral_table(self):
        """Tabela 48 lida da Base técnica (tab_secao_neutro, colunas A e B): {seção da fase: seção mínima do neutro}."""
        out={}
        for row in range(2,40):
            fase=numeric(self.p.get('tab_secao_neutro',f'A{row}'));neutro=numeric(self.p.get('tab_secao_neutro',f'B{row}'))
            if fase is None or neutro is None:continue
            out[fase]=neutro
        return out

    def _neutral_minimum_per_phase(self,r,phase):
        r=int(r);phase=numeric(phase)
        if phase is None:return pending('seção da fase pendente para verificar o neutro')
        kind=str(self.p.get('Carga nos circuitos',f'D{r}'));st=self.settings(r)
        if 'N' not in kind:return 0.
        rate=numeric(self.p.raw(ENV,f'G{r}'))
        # Sem comprovação das três condições, a seção mínima é a da fase.
        if not (kind.startswith('3F') and phase>25 and rate is not None and rate<=15
                and st.get('neutral_reduction')=='verified' and len(str(st.get('neutral_basis') or '').strip())>=15):return phase
        # v2.2.0: a Tabela 48 vem da Base técnica (uma fonte só); acima de 400 mm² a norma não reduz.
        return self.reduced_neutral_table().get(phase,phase)

    def standard_sections(self):
        """Seções nominais da Base técnica (Cond2_Seção_Iz = tab_ampacidade_2c!A3:A26), em ordem crescente."""
        out=[numeric(self.p.get('tab_ampacidade_2c',f'A{row}')) for row in range(3,27)]
        return sorted(x for x in out if x is not None)

    def neutral_minimum(self,r,phase):
        """Seção mínima por condutor de neutro. v2.3.2: com Nc do neutro ≠ Nc das fases, a seção total de neutro
        (Nc_N × S_N) não pode ser menor que Nc_F × (mínimo por condutor de fase); arredonda para a seção nominal superior."""
        base=self._neutral_minimum_per_phase(r,phase)
        if not isinstance(base,(int,float)) or isinstance(base,bool) or base<=0:return base
        nc=integer(self.values(int(r))['parallel']);nn=integer(self.p.get(WIRE,f'R{int(r)}'))
        if not nc or not nn:return pending('condutores em paralelo do neutro ou das fases pendentes')
        if nn==nc:return base
        need=base*nc/nn
        for s in self.standard_sections():
            if s>=need-1e-9:return s
        return pending(f'neutro equivalente de {need:g} mm² por condutor acima da maior seção tabelada')
    def install(self):
        """Registra as regras de instalação (Python) usadas pelas expressões do modelo."""
        p=self.p
        p.engine.functions.update(INSTALLREF=self.method_ref,INSTALLTABLE=self.amp_table,AMPACITYERROR=self.ampacity_error,INSTALLARRANGEMENT=self.arrangement_code,
                                  INSTALLSOIL=self.soil_factor,INSTALLGROUP=self.group_factor,THERMALINSULATION=thermal_insulation,
                                  GROUPTRACE=self.group_trace,GROUPTEMPERATURE=self.temperature_factor,
                                  NEUTRALHEATING=self.neutral_heating,NEUTRALHEATINGINFO=self.neutral_heating_info,
                                  NEUTRALCURRENT=self.neutral_current,NEUTRALMIN=self.neutral_minimum)


# v2.2.0 — forro falso e piso elevado são espaço de construção (NBR 5410, Tabela 33, nota 5): método 21.
METHOD_RENAMES={'28_1,5-5De':'21_1,5-5De','28_5-50De':'21_5-50De'}


def migrate_inputs(doc):
    """Converte, ao abrir, o método 28 (guia) gravado em projetos antigos para o método 21 da NBR, com as mesmas faixas.

    O resultado não muda (mesmas referências B2/B1); as confirmações geométricas acompanham a troca."""
    changed=[]
    var='metodo.nro_do_metodo_de_instalacao'
    for c in doc.get('circuitos') or []:
        ent=c.get('entradas') if isinstance(c,dict) else None
        if not isinstance(ent,dict):continue
        old=ent.get(var)
        if isinstance(old,str) and old in METHOD_RENAMES:
            ent[var]=METHOD_RENAMES[old]
            changed.append({'circuito':ent.get('ident.nome'),'circuito_id':c.get('id'),'de':old,'para':METHOD_RENAMES[old]})
    if changed:
        meta=doc.setdefault('meta',{})
        for st in (meta.get('installation_settings') or {}).values():
            if not isinstance(st,dict):continue
            for key in ('geometry_signature','group_signature'):
                if isinstance(st.get(key),str):
                    for a,b in METHOD_RENAMES.items():st[key]=st[key].replace('|'+a+'|','|'+b+'|')
        meta.setdefault('migracoes_entradas',[]).append({'versao':'2.2.0','motivo':'Forro falso e piso elevado: método 21 da NBR 5410 '
                                                         '(Tabela 33, nota 5), no lugar do método 28 do guia; mesmas referências B2/B1.',
                                                         'alteracoes':changed})
    return changed


def patch_workbook(data):
    """Migração de projetos da v1.x: aplica à planilha as adaptações de instalação da v1.12."""
    meta=data.setdefault('meta',{})
    if meta.get('insulation_alias_version')!=1:
        for sheet,table in data['sheets'].items():
            if sheet.startswith('Memorial'):continue
            for cell in table['cells'].values():
                if cell.get('formula') and _THERMAL_REF.search(cell['value']):
                    cell['value']=thermal_formula(cell['value'])
        meta['insulation_alias_version']=1
    changes=[(METHOD,'F','INSTALLREF'),(WIRE,'M','INSTALLARRANGEMENT'),('Cálc_Seç-Ampacidade','N','INSTALLTABLE'),
             ('Corrente-Calc_Ampacidade ','N','INSTALLSOIL'),('Corrente-Calc_Ampacidade ','O','INSTALLGROUP'),
             ('Corrente-Calc_Ampacidade ','M','GROUPTEMPERATURE'),('Corrente-Calc_Ampacidade ','V','GROUPTRACE'),
             ('Corrente-Calc_Ampacidade ','W','NEUTRALHEATING'),('Cálc_Seç-Ampacidade','S','GROUPTRACE'),
             ('Cálc_Seç-Ampacidade','G','NEUTRALCURRENT')]
    for s,col,fn in changes:
        cells=data['sheets'][s]['cells']
        for r in range(2,102):
            a=f'{col}{r}';cell=cells.get(a,{})
            cells[a]={**cell,'value':f'=IF($A{r}="","",{fn}({r}))','formula':True,'cache':None}
    # Um único FCA efetivo. D/E permanecem para compatibilidade de endereços,
    # com fator unitário; nenhuma segunda correção para os paralelos.
    expressions={
        ('Cálc_Seç-Ampacidade','D'):'1',
        ('Cálc_Seç-Ampacidade','E'):'"Não"',
        ('Cálc_Seç-Ampacidade','F'):"MAX('Corrente-Calc_Ampacidade '!$P{r}:$R{r})/$C{r}",
        ('Corrente-Calc_Ampacidade ','P'):'ROUND($B{r}/($M{r}*$N{r}*$O{r}*$W{r}),2)',
        ('Corrente-Calc_Ampacidade ','Q'):'ROUND($C{r}/($M{r}*$N{r}*$O{r}*$W{r}),2)',
        ('Corrente-Calc_Ampacidade ','R'):'ROUND($D{r}/($M{r}*$N{r}*$O{r}*$W{r}),2)',
        ('Corrente-Calc_Ampacidade ','S'):'MAX($E{r},$F{r})/($M{r}*$N{r}*$O{r}*$W{r})*$T{r}',
        ('Cálc_Seç_Red_N-T-Cond Sugerido','G'):'NEUTRALMIN({r},$E{r})',
        ('Cálc_Seç_Red_N_PE-Cond escolhid','C'):'NEUTRALMIN({r},$B{r})',
        ('Temp_Operacional','I'):"MAX('Corrente nominal'!$P{r},'Corrente nominal'!$R{r},'Corrente nominal'!$T{r})/'Dados dos condutores '!$D{r}",
    }
    for sheet in ('Corrente_Max-Cond_Escolhido','Corrente_Max-Cond_Sugerido'):
        expressions[(sheet,'K')]="ROUND($J{r}*$G{r}*$H{r}*$I{r}*'Dados dos condutores '!$D{r}*'Corrente-Calc_Ampacidade '!$W{r},2)"
        expressions[(sheet,'O')]="ROUND($N{r}*$G{r}*$H{r}*$I{r}*'Dados dos condutores '!$D{r}*'Corrente-Calc_Ampacidade '!$W{r},2)"
    for (sheet,col),expression in expressions.items():
        cells=data['sheets'][sheet]['cells']
        for r in range(2,102):
            a=f'{col}{r}';cells[a]={**cells.get(a,{}),'value':f'=IF($A{r}="","",{expression.format(r=r)})','formula':True,'cache':None}
    data['sheets']['Corrente-Calc_Ampacidade ']['cells']['W1']={'value':'Fator de carregamento do neutro (separado do FCA)','formula':False}
    meta['grouping_version']=2
    # Nomes incompletos da validação Excel não limitam cabos multipolares a EPR.

"""Números no formato brasileiro e regras de entrada numérica por campo (v1.12).

``parse_br`` é a mesma regra usada no navegador (static/numeros.js):

* com vírgula: a vírgula é o separador decimal e os pontos são de milhar
  ("1.000,00" → 1000; "1,5" → 1,5);
* sem vírgula: pontos em grupos de três dígitos são separadores de milhar
  ("1.000" → 1000; "12.500.000" → 12500000); qualquer outro ponto é decimal
  ("1.5" → 1,5; "0.25" → 0,25).
"""
from __future__ import annotations

import math
import re

_THOUSANDS = re.compile(r'[+-]?\d{1,3}(?:\.\d{3})+')
_BR_DECIMAL = re.compile(r'[+-]?(?:\d{1,3}(?:\.\d{3})+|\d+),\d+|[+-]?(?:\d{1,3}(?:\.\d{3})+|\d+),?')
_PLAIN = re.compile(r'[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?')


def parse_br(text):
    """Converte texto numérico (pt-BR ou com ponto decimal) em float. ValueError se não for número."""
    if isinstance(text, bool):
        raise ValueError('Valor lógico não é número.')
    if isinstance(text, (int, float)):
        if not math.isfinite(text):
            raise ValueError('Número inválido.')
        return float(text)
    t = str(text).strip().replace(' ', '').replace(' ', '')
    if not t:
        raise ValueError('Número vazio.')
    if ',' in t:
        if t.count(',') > 1 or not _BR_DECIMAL.fullmatch(t):
            raise ValueError(f'Número inválido: {text}')
        v = float(t.replace('.', '').replace(',', '.'))
    elif _THOUSANDS.fullmatch(t):
        v = float(t.replace('.', ''))
    elif _PLAIN.fullmatch(t):
        v = float(t)
    else:
        raise ValueError(f'Número inválido: {text}')
    if not math.isfinite(v):
        raise ValueError('Número inválido.')
    return v


def looks_numeric(x):
    try:
        parse_br(x)
        return True
    except (TypeError, ValueError):
        return False


# (aba, coluna) → regra de entrada. step = incremento dos botões − / +;
# integer = contagem (nunca fracionária); decimals = casas exibidas.
SPECS = {
    ('Dados dos circuitos', 'B'): {'step': 1, 'min': -20, 'max': 90, 'decimals': 0, 'unit': '°C'},
    ('Dados dos circuitos', 'C'): {'step': 1, 'min': -10, 'max': 80, 'decimals': 0, 'unit': '°C'},
    ('Dados dos circuitos', 'D'): {'step': 0.5, 'min': 0.1, 'max': 10, 'decimals': 1, 'unit': 'K·m/W'},
    ('Dados dos circuitos', 'E'): {'step': 1, 'min': 1, 'max': 200, 'integer': True},
    ('Dados dos circuitos', 'F'): {'step': 1, 'min': 0.1, 'max': 100000, 'decimals': 1, 'unit': 'm'},
    ('Dados dos circuitos', 'H'): {'step': 0.05, 'min': 0, 'max': 1, 'decimals': 2},
    ('Dados dos circuitos', 'J'): {'step': 0.5, 'min': 0.1, 'max': 20, 'decimals': 1, 'unit': '%'},
    ('Dados dos condutores ', 'D'): {'step': 1, 'min': 1, 'max': 20, 'integer': True},
    ('Dados dos condutores ', 'P'): {'step': 1, 'min': 1, 'max': 20, 'integer': True},  # v2.3.2: neutro/PEN
    ('Dados dos condutores ', 'Q'): {'step': 1, 'min': 1, 'max': 20, 'integer': True},  # v2.3.2: PE
    ('Levantamento de carga', 'D'): {'step': 100, 'min': 0, 'max': 1e8, 'decimals': 0, 'unit': 'W'},
    ('Levantamento de carga', 'H'): {'step': 100, 'min': 0, 'max': 1e8, 'decimals': 0, 'unit': 'W'},
    ('Levantamento de carga', 'L'): {'step': 100, 'min': 0, 'max': 1e8, 'decimals': 0, 'unit': 'W'},
    ('Levantamento de carga', 'E'): {'step': 0.01, 'min': 0.01, 'max': 1, 'decimals': 2},
    ('Levantamento de carga', 'I'): {'step': 0.01, 'min': 0.01, 'max': 1, 'decimals': 2},
    ('Levantamento de carga', 'M'): {'step': 0.01, 'min': 0.01, 'max': 1, 'decimals': 2},
    ('Levantamento de carga', 'T'): {'step': 2, 'min': 2, 'max': 24, 'integer': True},
    ('Levantamento de carga', 'V'): {'step': 0.5, 'min': 0, 'max': 10000, 'decimals': 2, 'unit': 'cv'},
    ('Levantamento de carga', 'Y'): {'step': 0.5, 'min': 0, 'max': 100000, 'decimals': 2, 'unit': 'cv'},
    ('Levantamento de carga', 'AA'): {'step': 0.01, 'min': 0.01, 'max': 1, 'decimals': 2},
    ('Levantamento de carga', 'AB'): {'step': 1, 'min': 1, 'max': 100, 'decimals': 1, 'unit': '%'},
    ('ΔV_Partida_Motores', 'D'): {'step': 0.05, 'min': 0.05, 'max': 1, 'decimals': 2},
    ('ΔV_Partida_Motores', 'O'): {'step': 0.5, 'min': 0.5, 'max': 30, 'decimals': 1, 'unit': '%'},
    ('ΔV_Partida_Motores', 'P'): {'step': 0.5, 'min': 0.5, 'max': 40, 'decimals': 1, 'unit': '%'},
    ('ΔV_Partida_Motores', 'X'): {'step': 5, 'min': 1, 'max': 100, 'decimals': 0, 'unit': '%'},
    ('Cálc-Prot_Cabos', 'K'): {'step': 1, 'min': 0.5, 'max': 10000, 'decimals': 0, 'unit': 'A'},
    ('Cálc-Prot_Cabos', 'Y'): {'step': 1, 'min': 0.1, 'max': 10000, 'decimals': 1, 'unit': 'A'},
    ('Cálc-Prot_Cabos', 'Z'): {'step': 10, 'min': 0.1, 'max': 200000, 'decimals': 0, 'unit': 'A'},
    ('Cálc-Prot_Cabos', 'BX'): {'step': 10, 'min': 0.1, 'max': 200000, 'decimals': 0, 'unit': 'A'},
    ('Cálc-Prot_Cabos', 'CX'): {'step': 0.01, 'min': 0, 'max': 30, 'decimals': 3, 'unit': 's'},
    ('Cálc-Prot_Cabos', 'CY'): {'step': 0.01, 'min': 0, 'max': 30, 'decimals': 3, 'unit': 's'},
    ('Seleção-Seção_Condutor', 'T'): {'min': 0.5, 'max': 1000, 'decimals': 1, 'unit': 'mm²'},
    ('Seleção-Seção_Condutor', 'W'): {'min': 0.5, 'max': 1000, 'decimals': 1, 'unit': 'mm²'},
    ('Seleção-Seção_Condutor', 'Z'): {'min': 0.5, 'max': 1000, 'decimals': 1, 'unit': 'mm²'},
    ('Levantamento de carga', 'AG'): {'step': 0.01, 'min': 0.01, 'max': 1, 'decimals': 2},
    ('Levantamento de carga', 'AH'): {'step': 1, 'min': 1, 'max': 100, 'decimals': 1, 'unit': '%'},
    ('Levantamento de carga', 'AI'): {'step': 0.5, 'min': 1, 'max': 20, 'decimals': 1},
    ('Levantamento de carga', 'AJ'): {'step': 1, 'min': 0.01, 'max': 100000, 'decimals': 1, 'unit': 'A'},
    ('Levantamento de carga', 'AK'): {'step': 100, 'min': 1, 'max': 1e8, 'decimals': 0, 'unit': 'W'},
    ('Levantamento de carga', 'AL'): {'step': 0.1, 'min': 0.001, 'max': 100000, 'decimals': 2, 'unit': 'kgf·m'},
}


def spec_for(sheet, col):
    return SPECS.get((sheet, col))


def check(sheet, col, value, label=None):
    """Aplica inteiro/limites do campo. Devolve o valor (int para contagens)."""
    spec = SPECS.get((sheet, col))
    if spec is None or not isinstance(value, (int, float)) or isinstance(value, bool):
        return value
    name = label or f'{sheet}!{col}'
    if spec.get('integer'):
        if abs(value - round(value)) > 1e-9:
            raise ValueError(f'{name}: informe um número inteiro (contagem), não {str(value).replace(".", ",")}.')
        value = int(round(value))
    lo, hi = spec.get('min'), spec.get('max')
    if lo is not None and value < lo:
        raise ValueError(f'{name}: o valor mínimo é {str(lo).replace(".", ",")}.')
    if hi is not None and value > hi:
        raise ValueError(f'{name}: o valor máximo é {str(hi).replace(".", ",")}.')
    return value

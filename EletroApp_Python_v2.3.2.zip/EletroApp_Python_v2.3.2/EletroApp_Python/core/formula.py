"""Interpretador das fórmulas usadas na planilha r42, sem Excel e sem eval.

As referências são preguiçosas: SUMIF/INDEX só leem as células selecionadas.
Erros permanecem explícitos. Valores salvos no XLSX nunca substituem cálculos.
"""
from __future__ import annotations
import math
import re
import operator
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from functools import lru_cache


@dataclass(frozen=True)
class Error:
    code: str
    detail: str = ""
    def __str__(self):
        return self.code


class CalculationError(Exception):
    def __init__(self, code="#VALUE!", detail=""):
        self.value = Error(code, detail)


def col_number(text):
    n = 0
    for c in text.replace('$', '').upper():
        n = n * 26 + ord(c) - 64
    return n


def col_name(n):
    result = ''
    while n:
        n, rem = divmod(n - 1, 26)
        result = chr(65 + rem) + result
    return result


def address(text):
    m = re.fullmatch(r'\$?([A-Za-z]{1,3})\$?(\d+)', text)
    if not m:
        raise CalculationError('#REF!', text)
    return int(m[2]), col_number(m[1])


class Grid:
    """Intervalo ou matriz. ``values`` (lista por linhas) existe quando todos os elementos já são conhecidos:
    nesse caso as operações elemento a elemento são feitas de uma vez, sem avaliação preguiçosa."""
    __slots__ = ('rows', 'cols', 'getter', 'source', 'values')

    def __init__(self, rows, cols, getter, source=None, values=None):
        self.rows, self.cols, self.getter, self.source, self.values = rows, cols, getter, source, values
    def at(self, r=0, c=0):
        if not (0 <= r < self.rows and 0 <= c < self.cols):
            return Error('#REF!', 'Índice fora do intervalo')
        if self.values is not None:
            return self.values[r * self.cols + c]
        try:
            return self.getter(r, c)
        except CalculationError as e:
            return e.value
        except (ValueError, TypeError, OverflowError, ZeroDivisionError) as e:
            return Error('#VALUE!', str(e))
    def flat(self):
        if self.values is not None:
            yield from self.values
            return
        for r in range(self.rows):
            for c in range(self.cols):
                yield self.at(r, c)


def scalar(v):
    return v.at() if isinstance(v, Grid) else v


def checked(v):
    v = scalar(v)
    if isinstance(v, Error):
        raise CalculationError(v.code, v.detail)
    return v


def num(v):
    v = checked(v)
    if v is None:
        return 0
    if isinstance(v, (int, float, bool)):
        return v
    try:
        return float(v)
    except (ValueError, TypeError):
        raise CalculationError('#VALUE!', f'Número esperado: {v!r}')


def text(v):
    v = checked(v)
    if v is None:
        return ''
    if isinstance(v, bool):
        return 'TRUE' if v else 'FALSE'
    if isinstance(v, (int, float)) and math.isfinite(v):
        return format(v, '.15g')
    return str(v)


def truth(v):
    v = checked(v)
    if isinstance(v, str):
        if v.upper() == 'TRUE': return True
        if v.upper() == 'FALSE' or v == '': return False
        raise CalculationError('#VALUE!', f'Valor lógico esperado: {v}')
    return bool(v)


def flatten(items):
    for v in items:
        if isinstance(v, Grid): yield from v.flat()
        else: yield v


def lift(fn, *args):
    grids = [x for x in args if isinstance(x, Grid)]
    if not grids:
        try:
            return fn(*args)
        except CalculationError as e:
            return e.value
        except ZeroDivisionError:
            return Error('#DIV/0!')
        except (ValueError, OverflowError, TypeError) as e:
            return Error('#VALUE!', str(e))
    rows, cols = max(x.rows for x in grids), max(x.cols for x in grids)
    if any(x.rows not in (1, rows) or x.cols not in (1, cols) for x in grids):
        return Error('#VALUE!', 'Dimensões incompatíveis')
    if any(x.values is not None for x in grids) and all(x.values is not None or x.rows * x.cols == 1 for x in grids):
        # Operando 1×1 (variável do circuito) com tabela já lida: o valor único é lido uma vez.
        args = tuple(Grid(1, 1, None, x.source, [x.at(0, 0)]) if isinstance(x, Grid) and x.values is None else x for x in args)
        grids = [x for x in args if isinstance(x, Grid)]
    if all(x.values is not None for x in grids):
        # Todos os operandos já calculados (tabelas técnicas): operação feita de uma vez.
        out = []
        for r in range(rows):
            for c in range(cols):
                out.append(lift(fn, *[x.values[(r if x.rows > 1 else 0) * x.cols + (c if x.cols > 1 else 0)] if isinstance(x, Grid) else x
                                      for x in args]))
        return Grid(rows, cols, None, None, out)
    return Grid(rows, cols, lambda r, c: lift(fn, *[
        x.at(r if x.rows > 1 else 0, c if x.cols > 1 else 0) if isinstance(x, Grid) else x
        for x in args]))


def compare(a, b, op):
    a, b = checked(a), checked(b)
    if a is None: a = '' if isinstance(b, str) else 0
    if b is None: b = '' if isinstance(a, str) else 0
    if isinstance(a, str) and isinstance(b, str): a, b = a.casefold(), b.casefold()
    elif isinstance(a, str) != isinstance(b, str):
        a, b = (1 if isinstance(a, str) else 0), (1 if isinstance(b, str) else 0)
    return {'=': operator.eq, '<>': operator.ne, '<': operator.lt,
            '>': operator.gt, '<=': operator.le, '>=': operator.ge}[op](a, b)


_FAST_OPS = {'=': operator.eq, '<>': operator.ne, '<': operator.lt, '>': operator.gt, '<=': operator.le, '>=': operator.ge,
             '+': operator.add, '-': operator.sub, '*': operator.mul, '/': operator.truediv}
_PLAIN = (int, float, bool)


def _fast_binary(op, a, b):
    """Operação elemento a elemento entre matrizes numéricas já calculadas (mesmo resultado do caminho geral)."""
    f = _FAST_OPS.get(op)
    if f is None or not (isinstance(a, Grid) or isinstance(b, Grid)):
        return None
    shapes = []
    lists = []
    for x in (a, b):
        if isinstance(x, Grid):
            if x.values is None:
                if x.rows * x.cols != 1:
                    return None
                v = [x.at(0, 0)]
            else:
                v = x.values
            if len(v) > 1:
                shapes.append((x.rows, x.cols))
        else:
            v = [x]
        for item in v:
            if type(item) not in _PLAIN:
                return None
        lists.append(v)
    if not shapes or any(sh != shapes[0] for sh in shapes):
        return None
    rows, cols = shapes[0]
    va, vb = lists
    try:
        if len(va) == 1:
            x = va[0]
            out = [f(x, y) for y in vb]
        elif len(vb) == 1:
            y = vb[0]
            out = [f(x, y) for x in va]
        else:
            out = [f(x, y) for x, y in zip(va, vb)]
    except (ZeroDivisionError, OverflowError, ValueError, TypeError):
        return None
    return Grid(rows, cols, None, None, out)


def binary(op, a, b):
    fast = _fast_binary(op, a, b)
    if fast is not None:
        return fast
    if op in ('=', '<>', '<', '>', '<=', '>='):
        return lift(lambda x, y: compare(x, y, op), a, b)
    if op == '&': return lift(lambda x, y: text(x) + text(y), a, b)
    funcs = {'+': operator.add, '-': operator.sub, '*': operator.mul,
             '/': operator.truediv, '^': operator.pow}
    return lift(lambda x, y: funcs[op](num(x), num(y)), a, b)


TOKEN = re.compile(r'''\s*(?:
    (?P<string>"(?:[^"]|"")*")|
    (?P<sheet>'(?:[^']|'')*')|
    (?P<number>(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?)|
    (?P<error>\#(?:REF!|DIV/0!|VALUE!|NAME\?|N/A|NUM!|NULL!))|
    (?P<id>[$\w\\][\w.$\\]*)|
    (?P<op><>|<=|>=|[+*/^&=<>%(),:!;{}-]))''', re.X | re.UNICODE)


class Parser:
    precedence = {'=': 1, '<>': 1, '<': 1, '>': 1, '<=': 1, '>=': 1,
                  '&': 2, '+': 3, '-': 3, '*': 4, '/': 4, '^': 5, ':':7}
    def __init__(self, formula):
        self.tokens, self.i = [], 0
        expr = formula.lstrip('=')
        pos = 0
        while pos < len(expr):
            if not expr[pos:].strip(): break
            m = TOKEN.match(expr, pos)
            if not m:
                raise CalculationError('#PARSE!', expr[pos:pos+80])
            self.tokens.append((m.lastgroup, m.group(m.lastgroup)))
            pos = m.end()
        self.tokens.append(('end', ''))
    def peek(self): return self.tokens[self.i][1]
    def pop(self):
        t = self.tokens[self.i]; self.i += 1; return t
    def need(self, token):
        if self.pop()[1] != token:
            raise CalculationError('#PARSE!', f'Esperado {token}')
    def parse(self, p=0):
        kind, val = self.pop()
        if val in ('+', '-'):
            left = ('unary', val, self.parse(6))
        elif val == '(':
            left = self.parse(); self.need(')')
        elif val == '{':
            rows, row = [], []
            while self.peek() != '}':
                row.append(self.parse())
                if self.peek() == ';': self.pop(); rows.append(tuple(row)); row=[]
                elif self.peek() == ',': self.pop()
                elif self.peek() != '}': self.need('}')
            self.need('}'); rows.append(tuple(row)); left=('array', tuple(rows))
        elif kind == 'number': left = ('lit', float(val))
        elif kind == 'string': left = ('lit', val[1:-1].replace('""', '"'))
        elif kind == 'error': left = ('lit', Error(val))
        elif kind in ('id', 'sheet'):
            if self.peek() == '(':
                self.pop(); args=[]
                while self.peek() != ')':
                    args.append(('lit', None) if self.peek() == ',' else self.parse())
                    if self.peek() == ',':
                        self.pop()
                        if self.peek() == ')': args.append(('lit', None))
                    elif self.peek() != ')': self.need(')')
                self.need(')'); left=('call', val.upper().replace('_XLFN.', ''), tuple(args))
            else:
                sheet = None
                if self.peek() == '!':
                    self.pop(); sheet = val[1:-1].replace("''", "'") if kind == 'sheet' else val
                    val = self.pop()[1]
                if re.fullmatch(r'\$?[A-Za-z]{1,3}',val) and self.peek()==':':
                    self.pop(); end=self.pop()[1]
                    left=('columns',sheet,val,end)
                elif re.fullmatch(r'\$?[A-Za-z]{1,3}\$?\d+', val):
                    end = val
                    if self.peek() == ':':
                        self.pop(); end = self.pop()[1]
                    left=('ref', sheet, val, end)
                elif val.upper() in ('TRUE', 'FALSE'):
                    left=('lit', val.upper() == 'TRUE')
                else: left=('name', val)
        else:
            raise CalculationError('#PARSE!', val)
        while self.peek() == '%' or self.precedence.get(self.peek(), -1) >= p:
            op = self.pop()[1]
            if op == '%': left=('unary', '%', left); continue
            left=('bin', op, left, self.parse(self.precedence[op] + 1))
        return left


@lru_cache(maxsize=160000)
def parse(formula):
    parser = Parser(formula)
    result = parser.parse()
    if parser.peek(): raise CalculationError('#PARSE!', parser.peek())
    return result


def criterion(value, condition):
    condition = checked(condition)
    if isinstance(condition, str):
        m = re.match(r'^(<=|>=|<>|=|<|>)(.*)$', condition)
        op, target = (m[1], m[2]) if m else ('=', condition)
        try: target = float(target)
        except ValueError: pass
        if isinstance(target, str) and ('*' in target or '?' in target):
            pattern = re.escape(target).replace(r'\*', '.*').replace(r'\?', '.')
            match = re.fullmatch(pattern, text(value), re.I) is not None
            return not match if op == '<>' else match
        if isinstance(target, (int, float)) and isinstance(value, str):
            try: value = float(value)
            except ValueError: pass
        return compare(value, target, op)
    return compare(value, condition, '=')


class Engine:
    def __init__(self, data):
        self.data = data
        self.cache, self.stack, self.diagnostics = {}, set(), {}
        self.names = {k.casefold(): v for k, v in data.get('names', {}).items()}
        self.functions = {}
    def clear(self):
        self.cache.clear(); self.stack.clear(); self.diagnostics.clear()
    def get(self, sheet, addr):
        addr = addr.replace('$', '').upper(); key=(sheet, addr)
        if key in self.cache: return self.cache[key]
        if sheet not in self.data['sheets']: return Error('#REF!', sheet)
        if key in self.stack: return Error('#CYCLE!', f'{sheet}!{addr}')
        cell = self.data['sheets'][sheet]['cells'].get(addr, {})
        if not cell.get('formula'):
            if cell.get('error'):return Error(cell.get('value','#VALUE!'),'Erro já presente no XLSX')
            return cell.get('value')
        self.stack.add(key)
        try:
            value = scalar(self.evaluate(parse(cell['value']), sheet, addr))
            if isinstance(value, float) and not math.isfinite(value):
                value = Error('#NUM!', 'Resultado não finito')
        except CalculationError as e: value = e.value
        except (ValueError, TypeError, OverflowError, ZeroDivisionError) as e:
            value = Error('#VALUE!', str(e))
        except RecursionError: value = Error('#CYCLE!', 'Profundidade excessiva de dependências')
        finally: self.stack.remove(key)
        if isinstance(value, Error): self.diagnostics[key] = value
        self.cache[key] = value
        return value
    def range(self, sheet, start, end):
        r1,c1=address(start); r2,c2=address(end)
        if r2<r1 or c2<c1 or (r2-r1+1)*(c2-c1+1)>250000:
            return Error('#REF!', 'Intervalo inválido ou muito grande')
        return Grid(r2-r1+1, c2-c1+1, lambda r,c:self.get(sheet, f'{col_name(c+c1)}{r+r1}'),
                    (sheet,r1,c1))
    def evaluate(self, node, sheet, addr):
        try: return self._evaluate(node, sheet, addr)
        except CalculationError as e: return e.value
        except ZeroDivisionError: return Error('#DIV/0!')
        except (ValueError, TypeError, OverflowError) as e: return Error('#VALUE!', str(e))
    def _evaluate(self, node, sheet, addr):
        kind = node[0]
        ev = lambda n:self.evaluate(n,sheet,addr)
        if kind == 'lit': return node[1]
        if kind == 'ref': return self.range(node[1] or sheet,node[2],node[3])
        if kind == 'columns':
            target=node[1] or sheet
            last=max((address(a)[0] for a in self.data['sheets'][target]['cells']),default=1)
            return self.range(target,node[2]+'1',node[3]+str(last))
        if kind == 'name':
            formula=self.names.get(node[1].casefold())
            if formula is None: return Error('#NAME?', node[1])
            return ev(parse(formula))
        if kind == 'array':
            rows=node[1]
            return Grid(len(rows), len(rows[0]), lambda r,c:scalar(ev(rows[r][c])))
        if kind == 'unary':
            return lift(lambda x: num(x)*(-1 if node[1]=='-' else .01 if node[1]=='%' else 1),ev(node[2]))
        if kind == 'bin':
            if node[1]==':':
                a,b=ev(node[2]),ev(node[3])
                if not isinstance(a,Grid) or not isinstance(b,Grid) or not a.source or not b.source or a.source[0]!=b.source[0]:
                    return Error('#REF!','Operador de intervalo exige referências')
                s,r,c=a.source; _,br,bc=b.source
                return self.range(s,f'{col_name(c)}{r}',f'{col_name(bc+b.cols-1)}{br+b.rows-1}')
            return binary(node[1], ev(node[2]), ev(node[3]))
        name,args=node[1:]
        if name in self.functions:
            return self.functions[name](*[scalar(ev(arg)) for arg in args])
        # Control flow is intentionally lazy; unused branches must not create errors.
        # TRECHO_SE (core/trecho.py) é um SE com a fórmula r42 original como último argumento.
        if name in ('IF','TRECHO_SE'):
            cond=ev(args[0]); yes=args[1]; no=args[2] if len(args)>2 else ('lit',False)
            if isinstance(cond,Grid) and (cond.rows>1 or cond.cols>1):
                def choose(r,c):
                    branch=ev(yes if truth(cond.at(r,c)) else no)
                    return branch.at(r if branch.rows>1 else 0,c if branch.cols>1 else 0) if isinstance(branch,Grid) else branch
                return Grid(cond.rows,cond.cols,choose)
            return ev(yes if truth(cond) else no)
        if name in ('IFERROR','IFNA'):
            value=ev(args[0])
            def rescue(x):
                x=scalar(x)
                if isinstance(x,Error) and (name=='IFERROR' or x.code=='#N/A'):
                    return scalar(ev(args[1]))
                return x
            return lift(rescue,value)
        if name == 'ROW':
            if not args: return address(addr)[0]
            value=ev(args[0])
            if isinstance(value,Grid) and value.source:
                base=value.source[1]
                return Grid(value.rows,1,lambda r,c:base+r,None,[base+r for r in range(value.rows)])
            return Error('#VALUE!','ROW exige referência')
        if name in ('SUMIF','COUNTIF','SUMIFS','MAXIFS','COUNTIFS'):
            vals=[ev(a) for a in args]
            if name in ('SUMIF','COUNTIF'):
                ranges=[vals[0]]; criteria=[scalar(vals[1])]
                target=vals[2] if len(vals)>2 else vals[0]
            else:
                first=0 if name=='COUNTIFS' else 1
                target=None if name=='COUNTIFS' else vals[0]
                ranges=vals[first::2]; criteria=[scalar(x) for x in vals[first+1::2]]
            if not all(isinstance(x,Grid) for x in ranges):
                return Error('#VALUE!','Critério sem intervalo')
            values=[]; count=0
            for r in range(ranges[0].rows):
                for c in range(ranges[0].cols):
                    if all(criterion(g.at(r,c),v) for g,v in zip(ranges,criteria)):
                        count+=1
                        if name not in ('COUNTIF','COUNTIFS'):
                            v=checked(target.at(r,c) if isinstance(target,Grid) else target)
                            if isinstance(v,(int,float)) and not isinstance(v,bool): values.append(v)
            if name in ('COUNTIF','COUNTIFS'): return count
            return max(values,default=0) if name=='MAXIFS' else sum(values)
        vals=[ev(a) for a in args]
        if name in ('ISNUMBER','ISTEXT','ISERROR','ISNA','ISBLANK'):
            tests={'ISNUMBER':lambda x:isinstance(x,(int,float)) and not isinstance(x,bool),
                   'ISTEXT':lambda x:isinstance(x,str), 'ISERROR':lambda x:isinstance(x,Error),
                   'ISNA':lambda x:isinstance(x,Error) and x.code=='#N/A', 'ISBLANK':lambda x:x is None}
            return lift(tests[name],vals[0])
        if name in ('AND','OR'):
            flags=[truth(x) for x in flatten(vals)]
            return all(flags) if name=='AND' else any(flags)
        if name == 'NOT': return lift(lambda x:not truth(x),vals[0])
        if name in ('SUM','MIN','MAX','AVERAGE','LARGE'):
            seq=list(flatten(vals[:-1] if name=='LARGE' else vals))
            seq=[checked(x) for x in seq]
            seq=[x for x in seq if isinstance(x,(int,float)) and not isinstance(x,bool)]
            if name=='SUM': return sum(seq)
            if name=='MIN': return min(seq,default=0)
            if name=='MAX': return max(seq,default=0)
            if name=='AVERAGE': return sum(seq)/len(seq)
            rank=int(num(vals[-1]))
            if rank<1 or rank>len(seq): return Error('#NUM!')
            return sorted(seq,reverse=True)[rank-1]
        if name=='SUMPRODUCT':
            def numeric(x):
                x=checked(x)
                return x if isinstance(x,(int,float,bool)) else 0
            product=1
            for v in vals: product=lift(lambda a,b:numeric(a)*numeric(b),product,v)
            return sum(num(x) for x in flatten([product]))
        if name in ('INDEX','OFFSET'):
            grid=vals[0]
            if not isinstance(grid,Grid): return Error('#REF!')
            if name=='INDEX':
                r=int(num(vals[1])) if len(vals)>1 else 1
                c=int(num(vals[2])) if len(vals)>2 else 1
                if len(vals)==2 and grid.rows==1: c,r=r,1
                if r==0:
                    source=(grid.source[0],grid.source[1],grid.source[2]+c-1) if grid.source else None
                    return Grid(grid.rows,1,lambda rr,cc:grid.at(rr,c-1),source)
                if c==0:
                    source=(grid.source[0],grid.source[1]+r-1,grid.source[2]) if grid.source else None
                    return Grid(1,grid.cols,lambda rr,cc:grid.at(r-1,cc),source)
                if grid.source:
                    if not (1<=r<=grid.rows and 1<=c<=grid.cols):return Error('#REF!')
                    source=(grid.source[0],grid.source[1]+r-1,grid.source[2]+c-1)
                    return Grid(1,1,lambda rr,cc:grid.at(r-1,c-1),source)
                return grid.at(r-1,c-1)
            if not grid.source:return Error('#REF!')
            s,r,c=grid.source; r+=int(num(vals[1])); c+=int(num(vals[2]))
            h=int(num(vals[3])) if len(vals)>3 else grid.rows
            w=int(num(vals[4])) if len(vals)>4 else grid.cols
            return self.range(s,f'{col_name(c)}{r}',f'{col_name(c+w-1)}{r+h-1}')
        if name=='MATCH':
            key=checked(vals[0]); mode=int(num(vals[2])) if len(vals)>2 else 1
            seq=list(flatten([vals[1]])); candidate=None
            for i,x in enumerate(seq):
                if isinstance(x,Error): continue
                if compare(x,key,'='): return i+1
                if mode!=0 and compare(x,key,'<=' if mode>0 else '>='): candidate=i+1
            return candidate if candidate is not None else Error('#N/A',text(key))
        if name in ('VLOOKUP','HLOOKUP'):
            key=checked(vals[0]); grid=vals[1]; idx=int(num(vals[2]))-1
            approx=truth(vals[3]) if len(vals)>3 else True
            if not isinstance(grid,Grid): return Error('#REF!')
            size=grid.rows if name=='VLOOKUP' else grid.cols
            found=None
            for i in range(size):
                x=grid.at(i,0) if name=='VLOOKUP' else grid.at(0,i)
                if isinstance(x,Error):continue
                if compare(x,key,'='): found=i; break
                if approx and x is not None and compare(x,key,'<='):found=i
            if found is None:return Error('#N/A',text(key))
            return grid.at(found,idx) if name=='VLOOKUP' else grid.at(idx,found)
        if name=='INDIRECT':
            return ev(parse(text(vals[0])))
        if name=='ADDRESS':
            r,c=int(num(vals[0])),int(num(vals[1])); mode=int(num(vals[2])) if len(vals)>2 else 1
            a=('$' if mode in (1,3) else '')+col_name(c)+('$' if mode in (1,2) else '')+str(r)
            return ("'"+text(vals[4]).replace("'","''")+"'!" if len(vals)>4 else '')+a
        if name in ('ROUND','ROUNDUP','ROUNDDOWN'):
            def rnd(x,d=0):
                x=num(x); d=int(num(d))
                if abs(d)>100:return Error('#NUM!')
                if name=='ROUND':
                    # Decimal(str(x)) toma o float ao pé da letra: quando uma soma como
                    # 0,00225+3*0,0045 cai, por ruído de ponto flutuante IEEE754, um
                    # ULP abaixo do decimal exato (0,015749999999999997 em vez de
                    # 0,01575), isso empurra um empate exato de arredondamento para o
                    # lado errado. Excel/LibreOffice corrigem isso limpando o valor
                    # para ~15 dígitos significativos antes de decidir a direção do
                    # arredondamento; replicamos essa limpeza aqui via formatação '%.15g'
                    # antes de construir o Decimal.
                    return float(Decimal(f'{x:.15g}').quantize(Decimal('1').scaleb(-d),rounding=ROUND_HALF_UP))
                y=abs(x)*10**d
                return math.copysign((math.ceil(y) if name=='ROUNDUP' else math.floor(y))/10**d,x)
            return lift(rnd,*vals)
        funcs={'SQRT':math.sqrt,'ACOS':math.acos,'SIN':math.sin,'COS':math.cos,'TAN':math.tan,
               'ABS':abs,'EXP':math.exp,'RADIANS':math.radians,'DEGREES':math.degrees,
               'INT':math.floor}
        if name in funcs: return lift(lambda x:funcs[name](num(x)),vals[0])
        if name=='MOD':return lift(lambda x,y:num(x)%num(y),*vals)
        if name=='VALUE':return lift(lambda x:num(text(x).strip()),vals[0])
        if name in ('LEFT','RIGHT'):
            return lift(lambda s,n=1: text(s)[:int(num(n))] if name=='LEFT' else (text(s)[-int(num(n)):] if num(n) else ''),*vals)
        if name=='MID':return lift(lambda s,start,n:text(s)[int(num(start))-1:int(num(start))-1+int(num(n))],*vals)
        if name in ('SEARCH','FIND'):
            def find(needle,hay,start=1):
                needle,hay=text(needle),text(hay)
                if name=='SEARCH':needle,hay=needle.casefold(),hay.casefold()
                i=hay.find(needle,int(num(start))-1)
                return i+1 if i>=0 else Error('#VALUE!')
            return lift(find,*vals)
        if name=='LEN':return lift(lambda x:len(text(x)),vals[0])
        if name=='TRIM':return lift(lambda x:' '.join(text(x).split()),vals[0])
        if name=='LOWER':return lift(lambda x:text(x).lower(),vals[0])
        if name=='UPPER':return lift(lambda x:text(x).upper(),vals[0])
        if name=='SUBSTITUTE':
            def substitute(s,old,new,n=None):
                s,old,new=text(s),text(old),text(new)
                if n is None:return s.replace(old,new)
                parts=s.split(old); idx=int(num(n))
                if idx<1 or idx>=len(parts):return s
                return old.join(parts[:idx])+new+old.join(parts[idx:])
            return lift(substitute,*vals)
        if name=='TEXTJOIN':
            sep=text(vals[0]); ignore=truth(vals[1])
            return sep.join(text(x) for x in flatten(vals[2:]) if not ignore or x not in (None,''))
        if name=='TEXT':
            def fmt(x,pattern):
                pattern=text(pattern); x=num(x)
                if pattern=='@':return text(x)
                # Formats used by r42: 0, 0.0, 0.00, #,##0 and percentages.
                pct='%' in pattern
                cleaned=pattern.replace('%','')
                decimals=len(cleaned.split('.')[1]) if '.' in cleaned else 0
                return format(x*(100 if pct else 1),(',' if ',' in cleaned else '')+f'.{decimals}f')+('%' if pct else '')
            return lift(fmt,*vals)
        if name=='COMPLEX':
            def comp(x,y,suffix='i'):
                z=complex(num(x),num(y)); suffix=text(suffix)
                if not z.imag:return text(z.real)
                return (text(z.real) if z.real else '')+('+' if z.real and z.imag>=0 else '')+text(z.imag)+suffix
            return lift(comp,*vals)
        if name in ('IMABS','IMREAL','IMAGINARY','IMSUM'):
            def cx(x):
                x=text(x).replace('i','j').replace(' ','')
                return complex(x or '0')
            if name=='IMSUM':
                z=sum(cx(x) for x in flatten(vals));return str(z).strip('()').replace('j','i')
            return lift(lambda x:abs(cx(x)) if name=='IMABS' else cx(x).real if name=='IMREAL' else cx(x).imag,vals[0])
        if name=='PI':return math.pi
        if name=='TRUE':return True
        if name=='FALSE':return False
        if name=='NA':return Error('#N/A')
        self.diagnostics[(sheet,addr)]=Error('#UNSUPPORTED!',name)
        return Error('#UNSUPPORTED!',name)

"""Modelo de projeto, formulários, topologia e resultados rastreáveis."""
from __future__ import annotations
import copy
import gzip
import json
import math
import os
import re
import uuid
from .formula import Engine, Error, Grid, address, col_name, col_number, parse, scalar
from .motor import NativeEngine, model, compiled, ROOTS
from . import versoes
from . import nc_patch, dps_patch, catalog_icu, motors, selection, trecho, ajustes, topologia, numeros
from . import protection, protection_links
from .protection_schema import SOURCE_SHEET, CIRCUIT_SHEET, SOURCE, CIRCUIT, CCOL, RCOL
from .installation import FIELDS as INSTALL_FIELDS
from .installation import Installation, FIELDS as INSTALL_FIELDS, LABELS as INSTALL_LABELS, SETTING_KEYS, catalogs, method_number, migrate_inputs

IDENT='Identificação dos circuitos'
FONTE='Padrão de entrada'
CAPACITY=None  # v2.0: sem limite de circuitos
GROUPS=[
    ('identificacao','Identificação',IDENT,['B','C','D','E','P','F','M']),
    ('ambiente','Condições do circuito','Dados dos circuitos',list('BCDEFGHIJ')),
    ('instalacao','Instalação','Maneira de instalar',['B']),
    ('metodo','Método de instalação','Identificação-Método_Instal ',['B','C','H']),
    ('cabos','Condutores','Dados dos condutores ',['D','P','Q','E','F','I','J','L','N','O']),
    ('cargas','Cargas gerais por fase','Levantamento de carga',['D','E','H','I','L','M']),
    ('motores','Motores','Levantamento de carga',['T','U','V','W','X','AG','AH','AI','AJ','AK','AL','Y','AA','AB','AC','AD','AE','AF','AN','AO','AP','AQ']),
    ('secoes','Seções escolhidas','Seleção-Seção_Condutor',
     ['F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE']),
    ('partida','Partida dos motores','ΔV_Partida_Motores',
     ['W','X','D','O','P','AF','AG','AH','Y','Z','AA','M','AB','AC','AD','AE']),
    ('trecho','Dispositivos do trecho',trecho.SHEET,trecho.INPUTS),
    ('integrada','Vínculo e proteção do alimentador',CIRCUIT_SHEET,list(CCOL.values())),
    ('protecao','Dispositivo na origem — proteção e catálogo','Cálc-Prot_Cabos',
     ['J','K','S','T','Y','Z','AL','AM','AN','AO','AP','AQ','AR','AS','AT','AU','AA','AC','AD','BR','DN',
      'BG','BO','BQ','BX','BZ','CA','CF','CH','CX','CY','DS','BJ','CG']),
    ('choque','Seccionamento e choque','Cálc-Prot_Choque',['AE','AB','AC','AD']),
    ('dps','DPS e coordenação','DPS',['BT','BU','H','BW','BX','AT','AU','BH','BI','BP','BM','BJ','BK','BL','K','L','M','CB','CA','CC','N',
                                      'AE','AF','AG','AH','AI','AJ','AK','AN','AO','AP','BY','AL','BF']),
]
RESULTS={
    'p_w':('Carga nos circuitos','Y'), 's_va':('Carga nos circuitos','Z'), 'q_var':('Carga nos circuitos','AA'),
    'fp':('Carga nos circuitos','F'), 'pr':('Carga nos circuitos','P'), 'ps':('Carga nos circuitos','Q'), 'pt':('Carga nos circuitos','R'),
    'ir':('Corrente nominal','P'), 'is':('Corrente nominal','R'), 'it':('Corrente nominal','T'), 'ineutro':('Corrente nominal','V'),
    'sec_f':('Seleção-Seção_Condutor','T'), 'sec_n':('Seleção-Seção_Condutor','W'), 'sec_pe':('Seleção-Seção_Condutor','Z'),
    'sec_sugerida':('Seleção-Seção_Condutor','S'), 'iz':('Cálc-Prot_Cabos','F'),
    'dv':('Queda_Tens-Cond_Escolhido','U'), 'dv_total':('Queda_Tens-Cond_Escolhido','W'),
    'icc_max':('Cálc_Icc-Cond_Escolhido','S'), 'icc_min':('Cálc_Icc-Cond_Escolhido','K'),
    'icc_origem':(trecho.SHEET,trecho.COL['ik_origem']),  # Ik do quadro de instalação do dispositivo da origem (v1.10)
    'protecao':('Cálc-Prot_Cabos','DN'), 'recomendado':('Cálc-Prot_Cabos','CS'), 'ir_prot':('Cálc-Prot_Cabos','Y'),
    'ii_prot':('Cálc-Prot_Cabos','Z'), 'icu':('Cálc-Prot_Cabos','AA'), 'prot_status':('Cálc-Prot_Cabos','BJ'),
    'dps_modelo':('DPS','AV'), 'dps_status':('DPS','AS'), 'topologia':(IDENT,'K')}
# v1.5: dados adicionais para o unifilar, o quadro de cargas e o resumo dos circuitos. Ficam fora de
# RESULTS de propósito: a tela "Conferência com r42" compara só os indicadores originais (docs/VALIDACAO.md).
RESULTS_EXTRA={
    'tipo_circuito':('Carga nos circuitos','D'), 'fs':('Dados dos circuitos','H'),
    'q_r':('Carga nos circuitos','V'), 'q_s':('Carga nos circuitos','W'), 'q_t':('Carga nos circuitos','X'),
    's_r':('Carga nos circuitos','S'), 's_s':('Carga nos circuitos','T'), 's_t':('Carga nos circuitos','U'),
    'p_own_r':('Carga nos circuitos','J'), 'p_own_s':('Carga nos circuitos','K'), 'p_own_t':('Carga nos circuitos','L'),
    'q_own_r':('Carga nos circuitos','AB'), 'q_own_s':('Carga nos circuitos','AC'), 'q_own_t':('Carga nos circuitos','AD'),
    'fp_r':('Levantamento de carga','E'), 'fp_s':('Levantamento de carga','I'), 'fp_t':('Levantamento de carga','M'),
    'n_polo':('Dados dos condutores ','D'),
    'n_neutro':('Dados dos condutores ','R'), 'n_pe':('Dados dos condutores ','S'),  # v2.3.2: Nc adotados
    'ic':('Cálc-Prot_Cabos','D'), 'ip_motor':('Cálc-Prot_Cabos','I'),
    'in_frame':('Cálc-Prot_Cabos','AN'), 'in_sensor':('Cálc-Prot_Cabos','AO'),
    'iz_neutro':('Corrente_Max-Cond_Escolhido','O'),
    'fct':('Corrente_Max-Cond_Escolhido','G'), 'fcr':('Corrente_Max-Cond_Escolhido','H'), 'fca':('Corrente_Max-Cond_Escolhido','I'),
    'icc3f_max':('Cálc_Icc-Cond_Escolhido','H'), 'icc2f_max':('Cálc_Icc-Cond_Escolhido','I'), 'icc1f_max':('Cálc_Icc-Cond_Escolhido','J'),
    'icc1f_min':('Cálc_Icc-Cond_Escolhido','K'), 'icc2f_min':('Cálc_Icc-Cond_Escolhido','T'), 'icc3f_min':('Cálc_Icc-Cond_Escolhido','U'),
    'ip_crista':('Cálc_Icc-Cond_Escolhido','M'),
    'dv_sistema':('Queda_Tens-Cond_Escolhido','X'), 'dv_limite':('Queda_Tens-Cond_Escolhido','Y'),
    'tensao_contato':('Cálc-Prot_Choque','T'), 'tempo_tn_max':('Cálc-Prot_Choque','V'), 'tempo_tn_est':('Cálc-Prot_Choque','W'),
    'choque_status':('Cálc-Prot_Choque','Z'), 'seletividade':('Seletividade','V'),
    'dps_rec':('DPS','I'), 'dps_tipo':('DPS','J'), 'prot_tipo':('Cálc-Prot_Cabos','J'),
    # v1.10 — dispositivos do trecho (core/trecho.py) e DPS opcional.
    'sem_origem':(trecho.SHEET,trecho.COL['sem_origem']), 'tem_mb':(trecho.SHEET,trecho.COL['tem_mb']),
    'mb_modelo':(trecho.SHEET,trecho.COL['mb_modelo']), 'mb_in':(trecho.SHEET,trecho.COL['mb_in']),
    'mb_ir':(trecho.SHEET,trecho.COL['mb_ir']), 'mb_ii':(trecho.SHEET,trecho.COL['mb_ii']),
    'mb_icu':(trecho.SHEET,trecho.COL['mb_icu']), 'mb_status':(trecho.SHEET,trecho.COL['mb_status']),
    'mb_classe':(trecho.SHEET,trecho.COL['mb_classe']),
    'trecho_curto':(trecho.SHEET,trecho.COL['trecho_curto']), 'trecho_sobrecarga':(trecho.SHEET,trecho.COL['trecho_sobrecarga']),
    'trecho_choque':(trecho.SHEET,trecho.COL['trecho_choque']), 'justificativa_origem':(trecho.SHEET,trecho.COL['justificativa']),
    'dps_modo':('DPS','BT'), 'dps_montante':('DPS','U'), 'dps_montante_circuito':('DPS','BV'),
    'sel_montante':('Seletividade','W')}

ALL_RESULTS={**RESULTS,**RESULTS_EXTRA}

# v2.2.0 — rótulos, opções e orientações das perguntas novas e dos campos que passaram a ter padrão da norma.
FIELD_GUIDE={
    (IDENT,'P'):{'label':'Neutro distribuído no circuito?','empty_label':'Sim (padrão)','strict':True,
                 'hint':'Bifásico ou trifásico sem neutro (cargas só entre fases): o circuito passa a 2F+T ou 3F+T, com os condutores '
                        'carregados da Tabela 46 e sem condutor neutro. Circuito monofásico sempre tem neutro.'},
    ('Dados dos condutores ','N'):{'label':'Condutor de proteção (PE)','empty_label':'No mesmo cabo ou conduto das fases (padrão)','strict':True,
                                   'hint':'No mesmo cabo multipolar ou no mesmo conduto das fases: k da Tabela 55. Separado (outro conduto ou ao ar): '
                                          'k da Tabela 53 e seção mínima de 2,5 mm² Cu com proteção mecânica ou 4 mm² Cu sem (6.4.3.1.4). '
                                          'Em TN-C o PEN segue com as fases.'},
    # v2.3.2 — quantidade própria de condutores em paralelo do neutro/PEN e do PE
    ('Dados dos condutores ','P'):{'label':'Condutores em paralelo no neutro/PEN',
                                   'hint':'Vazio: igual ao número de condutores por polo das fases. Entra na ampacidade do neutro (corrente por condutor), '
                                          'na impedância e queda do neutro, no curto e na seção térmica do neutro. Pela NBR 5410 (6.2.5.7.2), '
                                          'cada grupo em paralelo deve conter todas as fases e o neutro: quantidade diferente exige estudo específico '
                                          'da divisão de corrente (6.2.5.7.1 b).'},
    ('Dados dos condutores ','Q'):{'label':'Condutores em paralelo no PE',
                                   'hint':'Vazio: igual ao número de condutores por polo das fases (um PE em cada grupo). Use 1 para um PE único comum aos '
                                          'paralelos. Entra na impedância do laço de falta (choque, Ik fase-terra, comprimento máximo) e na seção do PE '
                                          '(adiabática por condutor; Tabela 58 sobre a seção total das fases quando a quantidade difere). Em TN-C, o PEN usa '
                                          'a quantidade do neutro.'},
    ('Dados dos condutores ','O'):{'label':'Condição do condutor nu (Tabela 57)','empty_label':'Condições normais (padrão)','strict':True,
                                   'hint':'Só para condutor nu: define o k e a temperatura final no curto-circuito. A Tabela 30 não normaliza k '
                                          'para condutor de fase nu; o aplicativo usa a Tabela 57 e marca o resultado.'},
    ('Cálc-Prot_Choque','AE'):{'label':'Situação do local (Tabela C.1)','empty_label':'Situação 1 (padrão)','strict':True,
                               'option_labels':{'Situação 1':'Situação 1 — BB1/BB2 e BC1 a BC3 (condições usuais)',
                                                'Situação 2':'Situação 2 — BB3 ou BC4 (áreas externas, canteiros, banheiros, locais molhados)'},
                               'hint':'Define a coluna da Tabela 25. Situação 2: pele molhada (BB3) ou contato com o potencial da terra (BC4) — '
                                      'áreas externas, canteiros de obras, estabelecimentos agropecuários, volume 1 de banheiros e piscinas, '
                                      'dependências molhadas em uso normal (Anexo C).'},
    ('Cálc-Prot_Choque','AB'):{'label':'Circuito terminal só com equipamento fixo — até 5 s? (5.1.2.2.4.1 c)','empty_label':'Não informado — Tabela 25',
                               'strict':True,
                               'option_labels':{'PENDENTE':'Não informado — Tabela 25','SIM — 5 s APLICÁVEL':'Sim — só equipamento fixo: até 5 s',
                                                'SIM — OUTRO TEMPO':'Sim — tempo informado abaixo',
                                                'NÃO SE APLICA':'Não — alimenta tomadas ou equipamento portátil: Tabela 25'},
                               'hint':'Até 5 s só para circuito terminal que alimenta unicamente equipamentos fixos, desde que a falta não leve '
                                      'tensão de contato perigosa a equipamentos portáteis de outros circuitos. Nos demais casos vale a '
                                      'Tabela 25, qualquer que seja a corrente do circuito.'},
    ('Cálc-Prot_Choque','AC'):{'hint':'Usado só com “Sim — tempo informado”. Tempos acima de 5 s exigem as medidas de 5.1.2.2.4.1 d.'},
    ('Cálc-Prot_Cabos','DS'):{'label':'Sobrecarga prolongada prevista? (5.3.4.1, nota)','empty_label':'Não (padrão)','strict':True,
                              'option_labels':{'NÃO':'Não','SIM':'Sim — I2 ≤ Iz'},
                              'hint':'Sim quando a temperatura de sobrecarga da Tabela 35 puder durar mais de 100 h em 12 meses consecutivos '
                                     'ou 500 h ao longo da vida útil do condutor: a condição passa de I2 ≤ 1,45·Iz para I2 ≤ Iz.'},
    ('DPS','BW'):{'label':'Nível de proteção do SPDA (NP)','empty_label':'Não informado — Iimp mínima de 12,5 kA','strict':True,
                  'hint':'Com SPDA externo e NP conhecido, a Iimp exigida do DPS Classe I vem da NBR 5419-1 (I’F = ke·I/(n·n’), Anexo E). '
                         'Em branco vale o mínimo de 12,5 kA por modo da NBR 5410 (corrente não determinada).'},
    ('DPS','BX'):{'label':'Linhas e partes condutivas externas ligadas à estrutura (n)',
                  'hint':'Linhas de energia e de sinal e tubulações metálicas que entram na estrutura. Em branco: 1 (a favor da segurança).'},
    ('DPS','BY'):{'label':'Falha dos sistemas internos é crítica? (NBR 5419-2)','empty_label':'Não (padrão)','strict':True,
                  'option_labels':{'NÃO':'Não','SIM':'Sim — UP/F ≤ 0,5·Uw'},
                  'hint':'No circuito final, o equipamento fica protegido pelo DPS a montante com UP/F ≤ 0,8·Uw até 10 m, ou 0,5·Uw quando '
                         'a falha for crítica (NBR 5419-4, C.2.1.9). A distância é medida até o DPS que protege o circuito.'},
    ('ΔV_Partida_Motores','D'):{'hint':'Em branco: 0,3, fator de potência de rotor bloqueado indicado pela NBR 5410 na falta de dado do motor '
                                       '(6.5.1.3.3, nota 2).'},
    ('ΔV_Partida_Motores','O'):{'hint':'Em branco: o limite de 6.2.7 do circuito (nos demais pontos de utilização, durante a partida, valem os '
                                       'limites de 6.2.7.1).'},
    ('ΔV_Partida_Motores','P'):{'hint':'Em branco: 10% nos terminais do dispositivo de partida (6.5.1.3.3).'},
    # v2.2.0 (C12): condições que a Tabela 40 não cobre (nota de 6.2.5.3.3; Tabela 34, AN2/AN3; nota final da Tabela 33).
    ('Dados dos circuitos','B'):{'hint':'Temperatura do meio circundante com o condutor sem carga (6.2.5.3.1). A Tabela 40 não considera '
                                        'radiação solar nem outras radiações infravermelhas: cabos expostos ao sol (AN2 e AN3, Tabela 34) '
                                        'têm a capacidade calculada pela NBR 11301 (nota de 6.2.5.3.3). Em trechos verticais com '
                                        'ventilação restrita, use a temperatura do topo do trecho (nota final da Tabela 33).'},
    ('Dados dos circuitos','C'):{'hint':'Temperatura do solo na profundidade da linha. As capacidades das linhas enterradas são referidas a '
                                        '20 °C (6.2.5.3.2).'},
    ('Dados dos circuitos','G'):{'hint':'Entra na corrente de projeto (IB = I1·√(1 + h3²)) e, acima de 33%, na corrente do neutro (Anexo F).'},
    ('Dados dos circuitos','I'):{'hint':'Define a seção mínima pela Tabela 47 (circuitos de tomadas são circuitos de força).'},
    ('Dados dos circuitos','J'):{'hint':'Circuito terminal: no máximo 4% (6.2.7.2). O limite total da instalação vem de 6.2.7 pelo tipo de atendimento.'},
}
# Aba do formulário que resolve cada critério da Auditoria_Checklist (botão "Abrir" das verificações).
AUDIT_GROUPS={'C':'identificacao','D':'secoes','E':'secoes','F':'secoes','G':'secoes','H':'secoes','I':'protecao',
              'J':'protecao','K':'protecao','L':'choque','M':'partida','N':'dps','O':'protecao'}

# Resultados que dependem de uma instalação/cabos válidos (ver Project.circuits()).
# Ocupação da edificação (NBR 5410:2004, 6.2.3.8): decide o uso de condutores de alumínio.
OCUPACAO_SHEET='Projeto (EletroApp)'
OCUPACAO_FIELDS={
    'tipo':('Tipo de ocupação da edificação',['Residencial','Comercial','Industrial','Público / outros'],{}),
    'densidade':('Densidade de ocupação / fuga (Tabela 21)',['BD1','BD2','BD3','BD4'],
                 {'BD1':'BD1 — Normal (baixa densidade)','BD2':'BD2 — Longa','BD3':'BD3 — Tumultuada','BD4':'BD4 — Longa e tumultuada'}),
    'qualificado':('Instalação e manutenção por pessoas qualificadas (BA5)',['Sim','Não'],{}),
}
INSTALL_DEPENDENT=('iz','sec_sugerida','dv','dv_total','icc_max','icc_min','icc_origem','recomendado','prot_status',
                   'iz_neutro','fct','fcr','fca','icc3f_max','icc2f_max','icc1f_max','icc1f_min','icc2f_min','icc3f_min',
                   'ip_crista','dv_sistema','dv_limite')


def esquema_ligacao(tipo):
    """'3F+N+T' (modelo r42) -> '3F+N+PE' (nomenclatura da NBR 5410). PEN permanece PEN."""
    if not isinstance(tipo,str) or not tipo or tipo=='N/A':return None
    return '+'.join('PE' if parte=='T' else parte for parte in tipo.split('+'))


def _fmt_secao(v):
    if isinstance(v,bool) or not isinstance(v,(int,float)):return None
    return (f'{v:g}').replace('.',',')


def condutores_agrupados(tipo,n_polo,sec_f,sec_n,sec_pe,n_neutro=None,n_pe=None):
    """Notação agrupada, ex.: 1x{3#50mm²(25mm²)PE16mm²} = 1 condutor por polo; 3 fases de 50 mm²;
    neutro de 25 mm² entre parênteses; PE de 16 mm². Em TN-C o neutro/PE é o PEN: 1x{3#240mm²(PEN120mm²)}.
    v2.3.2: neutro ou PE com quantidade diferente das fases saem do grupo, com a própria quantidade:
    2x{3#240mm²(240mm²)} + 1xPE120mm² (PE único) ou 2x{3#240mm²PE120mm²} + 1x(240mm²) (neutro único)."""
    if not isinstance(tipo,str) or tipo in ('','N/A'):return None
    partes=tipo.split('+')
    try:fases=int(partes[0][0])
    except (ValueError,IndexError):return None
    f=_fmt_secao(sec_f)
    if f is None:return None
    n=_fmt_secao(sec_n);pe=_fmt_secao(sec_pe)
    if 'PEN' in partes:
        # Em TN-C o motor usa MAX(neutro, PE) para o PEN (Cálc_Imp-Cond_Escolhido e Seleção-Seção_Condutor!AB).
        vals=[x for x in (sec_n,sec_pe) if isinstance(x,(int,float)) and not isinstance(x,bool)]
        if vals:n=_fmt_secao(max(vals))
    cnt=lambda v,d:int(v) if isinstance(v,(int,float)) and not isinstance(v,bool) and v>=1 else d
    polo=cnt(n_polo,1);nn=cnt(n_neutro,polo);npe=cnt(n_pe,polo)
    corpo=f'{fases}#{f}mm²';fora=[]
    if 'PEN' in partes:
        txt=f'(PEN{n}mm²)' if n else '(PEN)'
        if nn==polo:corpo+=txt
        else:fora.append(f'{nn}x{txt}')
    else:
        if 'N' in partes:
            txt=f'({n}mm²)' if n else '(N)'
            if nn==polo:corpo+=txt
            else:fora.append(f'{nn}x{txt}')
        if 'T' in partes:
            txt=f'PE{pe}mm²' if pe else 'PE'
            if npe==polo:corpo+=txt
            else:fora.append(f'{npe}x{txt}')
    return ' + '.join([f'{polo}x{{{corpo}}}']+fora)

NUMERIC_COLUMNS={
    'Dados dos circuitos':set('BCDEFGHJ'), 'Identificação-Método_Instal ':{'B'},
    'Dados dos condutores ':{'D','P','Q'},
    'Levantamento de carga':{'D','E','H','I','L','M','T','V','Y','AA','AB',*motors.OVERRIDES},
    # X (Parâmetro do método, %) fica de fora de NUMERIC_COLUMNS de propósito:
    # só é um número quando o método de partida escolhido (W) realmente usa
    # um parâmetro (Soft-starter/Inversor/Reator); para Direta/Estrela-
    # triângulo o valor correto é o texto "N/A" (fator fixo, sem parâmetro).
    # Fica como texto livre nos dois sentidos; Y (fator de corrente) já
    # reconhece "N/A" e sinaliza "⏳ PENDENTE" se faltar o número nos métodos
    # que precisam dele.
    'Seleção-Seção_Condutor':{'T','W','Z'},'ΔV_Partida_Motores':{'D','O','P'},
    'Cálc-Prot_Cabos':{'K','Y','Z','BX','BZ','CX','CY'},
    'DPS':{'AH','AI','AJ','AK','AL','BX'},
    trecho.SHEET:set(trecho.NUMERIC),
}

# Colunas que aceitam OU um número OU um literal textual específico e
# conhecido (hoje só "N/A", quando o método de partida escolhido não usa
# parâmetro). Ficam fora de NUMERIC_COLUMNS porque nem todo valor válido é
# numérico — mas ao salvar, um valor que PARECE numérico precisa ser
# convertido para número de fato (não basta "parecer"): o motor de
# fórmulas usa ISNUMBER() para decidir se o parâmetro foi informado, e
# ISNUMBER() de uma string como "65" (mesmo vinda de um campo de texto)
# é FALSO. Sem esta conversão, salvar "65" em X deixava a célula com o
# texto "65" em vez do número 65, e a cascata inteira (Y/Z/AA/ΔV com
# método) caía silenciosamente em "⏳ PENDENTE" mesmo com o campo
# visualmente preenchido — só percebido ao testar o ciclo completo
# salvar→reabrir na interface, não nos testes diretos do motor de
# fórmulas (que já passavam valores Python nativos, nunca strings).
FLEXIBLE_NUMERIC_COLUMNS={'ΔV_Partida_Motores':{'X'},'Cálc-Prot_Cabos':{'BX'}}

# Campos sem dataValidation nativa no XLSX, mas com domínio de valores conhecido
# e seguro (levantado por inspeção cruzada com outras abas de referência da r42).
# Funciona como reforço do options(): só é usado quando a validação nativa não
# resolve nada. Nunca substitui uma lista já existente na planilha.
# Observação: "Dados dos condutores !G" (Tipo de condutor) FOI cogitado aqui,
# mas é uma célula de fórmula (=IF($A{r}="","",'Identificação-Método_Instal '!$C{r})),
# apenas espelhando Identificação-Método_Instal!C — que já é o campo editável
# correto e já está no grupo 'metodo'. Criar uma segunda "entrada" para o mesmo
# fato em Dados dos condutores!G seria redundante e, pior, inerte (célula de
# fórmula nunca vira <select> no formulário). Não adicionar aqui.
EXTRA_OPTIONS={}
EXTRA_OPTIONS.update({
    ('Levantamento de carga','AN'):[motors.ADD,motors.INCLUDED],
    ('Levantamento de carga','AO'):['R','S','T'],
    ('Levantamento de carga','AG'):[.7,.75,.8,.85,.9,.95],
    ('Levantamento de carga','AH'):[70,75,80,85,90,95],
    ('Levantamento de carga','AI'):[4,5,6,7,8,9],
    ('Levantamento de carga','AA'):[.7,.75,.8,.85,.9,.95],
    ('Levantamento de carga','AB'):[70,75,80,85,90,95],
    ('ΔV_Partida_Motores','D'):[.2,.25,.3,.35,.4],
    ('ΔV_Partida_Motores','O'):[3,4,5,6],
    ('ΔV_Partida_Motores','P'):[5,10,15],
    ('ΔV_Partida_Motores','X'):[25,33,40,50,60,65,70,80,90,100],
    ('Cálc-Prot_Cabos','BG'):['1P','2P','3P','4P'],
    ('Cálc-Prot_Cabos','BQ'):['PENDENTE','Neutro contínuo — confirmado','Neutro seccionado — confirmado','PEN contínuo — não seccionar','N/A'],
    (trecho.SHEET,trecho.COL['origem']):[trecho.ORIGEM_SIM,trecho.ORIGEM_NAO],
    (trecho.SHEET,trecho.COL['justificativa']):list(trecho.JUSTIFICATIVAS),
    (trecho.SHEET,trecho.COL['condicoes']):[trecho.SIM,trecho.NAO],
    (trecho.SHEET,trecho.COL['manut']):[trecho.NAO,trecho.SIM],
    ('DPS','BT'):list(trecho.DPS_OPCOES),
})

# Galeria, formulários, tabelas de consulta e validação usam a mesma matriz.
INSTALL_METHODS,LINHAS_METODO_MAPA=catalogs()
EXTRA_OPTIONS[('Identificação-Método_Instal ','B')]=list(dict.fromkeys(m['method'] for m in INSTALL_METHODS))
EXTRA_OPTIONS[('Identificação-Método_Instal ','C')]=['Condutor isolado','Cabo unipolar','Cabo multipolar']

# "Entrada e fontes" (aba Padrão de entrada): bloco a que cada linha de entrada
# pertence e, dentro do bloco MT-com-dados, o sub-modo ("Modo de entrada" em
# B11) que efetivamente consome aquela linha. Levantado diretamente das
# fórmulas do "bloco consolidado" (B135-B152) e de buscas exaustivas por
# referências cruzadas -- nunca dos títulos de seção sozinhos. Linhas fora
# deste mapa (nenhuma até hoje) caem em 'geral' por segurança.
SOURCE_ROW_BLOCK={
    4:'geral',5:'geral',6:'geral',78:'geral',
    9:'mt_dados',10:'mt_dados',11:'mt_dados',12:'mt_dados',13:'mt_dados',14:'mt_dados',15:'mt_dados',16:'mt_dados',
    75:'transformador',76:'transformador',77:'transformador',79:'transformador',80:'transformador',81:'transformador',97:'transformador',
    31:'bt_direta',32:'bt_direta',33:'bt_direta',34:'bt_direta',
    45:'gerador',46:'gerador',47:'gerador',48:'gerador',49:'gerador',50:'gerador',51:'gerador',58:'gerador',61:'gerador',68:'gerador',71:'gerador',
    160:'criterios',161:'criterios',
}
# Dentro do bloco 'mt_dados', linhas 12-16 só valem para um "Modo de entrada"
# específico (B11) -- ver fórmula de B19. As demais linhas do bloco (9,10,11)
# não têm submodo (sempre visíveis quando o bloco mt_dados está ativo).
SOURCE_ROW_SUBMODE={12:'Icc (kA)',13:'Icc (kA)',14:'Pcc (kVA)',15:'Zpu',16:'Zpu'}
SOURCE_BLOCK_SCENARIOS={
    'geral':None,
    'mt_dados':{'Rede MT/Trafo com dados'},
    'transformador':{'Rede MT/Trafo com dados','Rede MT/Trafo sem dados'},
    'bt_direta':{'Rede BT Direta'},
    'gerador':{'Gerador BT'},
    'criterios':None,
}
SOURCE_BLOCK_LABELS={
    'geral':'Informações gerais (aterramento e choque elétrico)',
    'mt_dados':'Média tensão — dados da concessionária',
    'transformador':'Transformador de potência',
    'bt_direta':'Baixa tensão — rede da concessionária',
    'gerador':'Gerador de baixa tensão',
    'criterios':'Critérios de projeto (queda de tensão e condutor de proteção)',
}


def _looks_numeric(x):
    return numeros.looks_numeric(x)

SAFE_ID=re.compile(r'[A-Za-z0-9_-]{1,64}')


def clean(value):
    if isinstance(value,Error):return {'error':value.code,'detail':value.detail}
    if isinstance(value,Grid):return [[clean(value.at(r,c)) for c in range(value.cols)] for r in range(value.rows)]
    return value


def value_label(value):
    return value.get('error','') if isinstance(value,dict) else value


def _num_br(t):
    return float(t.replace('.','').replace(',','.')) if ',' in t else float(t)

def _parse_passos(desc,lista,vmin,vmax,base,ref):
    """Interpreta o texto de passo de ajuste do catálogo.
    Devolve {'tipo': 'discreto'|'discreto_ir'|'continuo'|'nenhum'|'faixa', 'valores': [...], 'mult_ir': [...]}.
    'discreto': valores absolutos (A). 'discreto_ir': múltiplos de Ir (Isd). 'faixa': só min/max conhecidos."""
    out={'tipo':'faixa','valores':[],'mult_ir':[]}
    num=lambda x:isinstance(x,(int,float)) and not isinstance(x,bool)
    if isinstance(lista,str) and '|' in lista:
        vals=[_num_br(x) for x in lista.split('|') if re.fullmatch(r'\s*\d+(?:[.,]\d+)?\s*',x)]
        if vals:
            out['tipo']='discreto';out['valores']=[int(x) if float(x).is_integer() else x for x in vals];return out
    t=str(desc or '')
    low=t.lower()
    if 'não aplicável' in low:out['tipo']='nenhum';return out
    if low.startswith('fixo') or 'fixo' in low[:12]:out['tipo']='nenhum';return out
    if 'contínuo' in low or 'continuo' in low:out['tipo']='continuo';return out
    m=re.search(r'((?:\d+(?:,\d+)?\s*/\s*)+\d+(?:,\d+)?)\s*[×x]\s*(In|Ir)',t)
    if not m:
        m2=re.search(r':\s*((?:\d+(?:,\d+)?\s*/\s*)+\d+(?:,\d+)?)\s*\.?\s*(?:Ii|$)',t)
        if m2 and ref=='In' and 'posiç' in low and 'ir' in low:m=m2
    if not m:
        m3=re.search(r'(\d+(?:,\d+)?)\s*a\s*(\d+(?:,\d+)?)\s*[×x]\s*In\s*\((\d+)\s*posi',t)
        if m3 and num(base):
            lo,hi,n=_num_br(m3[1]),_num_br(m3[2]),int(m3[3])
            if n>=2:
                vals=[round(base*(lo+(hi-lo)*i/(n-1)),2) for i in range(n)]
                out['tipo']='discreto';out['valores']=[int(x) if float(x).is_integer() else x for x in vals]
        return out
    mults=[_num_br(x.strip()) for x in m[1].split('/')]
    alvo=m[2] if m.re.groups>=2 else 'Ir'
    if alvo=='Ir' or (ref=='In' and re.search(r'ISD|curto retardado|×Ir',t,re.I) and alvo!='In'):
        out['tipo']='discreto_ir';out['mult_ir']=mults;return out
    if alvo=='In' and num(base):
        vals=[round(base*x,2) for x in mults]
        vals=[int(x) if float(x).is_integer() else x for x in vals]
        if num(vmin) and num(vmax) and not all(vmin*0.99<=x<=vmax*1.01 for x in vals):return out
        out['tipo']='discreto';out['valores']=vals
    return out

class Project:
    """Projeto nativo: fonte, circuitos (entidades) e edições de fórmulas e tabelas.

    A interface interna por (grupo de origem, posição) — ``get``/``raw``/``put`` —
    é mantida para o código do aplicativo; o armazenamento e o cálculo são do
    motor nativo (``core.motor``)."""
    def __init__(self,data,base_model=None):
        if isinstance(data,dict) and 'sheets' in data:
            from .migracao import from_workbook
            data=from_workbook(data)
        if not isinstance(data,dict) or data.get('formato')!='eletroapp-projeto':
            raise ValueError('Arquivo de projeto não reconhecido.')
        self.model=base_model or model()
        self.doc=data;self.data=data
        data.setdefault('fonte',{});data.setdefault('circuitos',[]);data.setdefault('formulas',{});data.setdefault('tabelas',{})
        self.meta=data.setdefault('meta',{})
        versoes.migrate_native(data,self.model)
        migrate_inputs(data)
        self.meta.setdefault('title','Projeto elétrico')
        self.meta.setdefault('changes',0)
        self.circuits_doc=data['circuitos']
        seen={};names={}
        for i,c in enumerate(self.circuits_doc):
            if not isinstance(c,dict) or not isinstance(c.get('entradas',{}),dict):raise ValueError('Circuito inválido no arquivo.')
            c.setdefault('entradas',{})
            if not isinstance(c.get('id'),str) or not SAFE_ID.fullmatch(c['id']):c['id']=uuid.uuid4().hex
            # v2.1 — identificadores e nomes únicos: uma operação por identificador nunca pode atingir outro circuito.
            nome=str(c['entradas'].get('ident.nome') or '').strip()
            if c['id'] in seen:
                raise ValueError(f'Arquivo inválido: o identificador {c["id"]} se repete nos circuitos {seen[c["id"]]} e {nome or i+1}. '
                                 'Nada foi aberto; corrija o arquivo ou importe um backup íntegro.')
            seen[c['id']]=nome or i+1
            if nome:
                k=nome.casefold()
                if k in names:raise ValueError(f'Arquivo inválido: o nome de circuito “{nome}” se repete. Nada foi aberto.')
                names[k]=c['id']
        self._sanitize_meta()
        self._sync_ids()
        self.engine=NativeEngine(self)
        self.input_columns={}
        for _,_,sheet,cols in GROUPS:
            self.input_columns.setdefault(sheet,set()).update(cols)
        for v in self.model.inputs:self.input_columns.setdefault(v.sheet,set()).add(v.col)
        self.installation=Installation(self)
        self.installation.install()
        self.protection=protection.Protection(self)
        self.protection.install()
    # ---- armazenamento ---------------------------------------------------------
    def _sanitize_meta(self):
        """Projetos importados são dados não confiáveis: ids viram atributos HTML na interface (v1.12)."""
        if not isinstance(self.meta.get('title'),str):self.meta['title']=str(self.meta.get('title') or 'Projeto')[:160]
        for key in ('selection_modes','installation_settings','selection_results'):
            d=self.meta.get(key)
            if d is not None and not isinstance(d,dict):self.meta[key]={}
    def _sync_ids(self):
        self.meta['ids']={str(i+2):c['id'] for i,c in enumerate(self.circuits_doc)}
    def circuit_at(self,row):
        i=int(row)-2
        return self.circuits_doc[i] if 0<=i<len(self.circuits_doc) else None
    def input_value(self,var,row):
        c=self.circuit_at(row)
        if c is not None:
            found,value=protection_links.read_alias(self,var,row)
            if found:return value
        return None if c is None else c['entradas'].get(var.id)
    def fonte_value(self,var):
        return self.doc['fonte'].get(var.id,var.default) if var.id not in self.doc['fonte'] else self.doc['fonte'][var.id]
    def active_expression(self,var,escopo='comum'):
        """Expressão em uso num escopo (comum, raiz ou circuito:<id>), com o modelo como último nível."""
        kind,cid=versoes.parse_scope(escopo)
        top=self.doc['formulas'].get(var.id)
        if kind=='circuito':
            e=versoes.active(versoes.get_slot(self.doc['formulas'],var.id,'circuito',cid))
            if e:return e
            c=next((x for x in self.circuits_doc if x['id']==cid),None)
            kind='raiz' if c is not None and c['entradas'].get('ident.montante') in ROOTS and var.variants.get('raiz') else 'comum'
        if kind=='raiz' and var.variants.get('raiz'):
            return versoes.active(top.get('raiz') if isinstance(top,dict) else None) or var.variants['raiz']
        return versoes.active(top) or var.expr
    def expression_scope(self,var,row):
        """Escopo de versão que define a expressão de um circuito (comum, raiz ou circuito:<id>)."""
        c=self.circuit_at(row) if row is not None else None
        if c is None:return 'comum'
        if versoes.active(versoes.get_slot(self.doc['formulas'],var.id,'circuito',c['id'])):return 'circuito:'+c['id']
        if var.variants.get('raiz') and c['entradas'].get('ident.montante') in ROOTS:return 'raiz'
        return 'comum'
    def expression(self,var,row):
        top=self.doc['formulas'].get(var.id)
        c=self.circuit_at(row) if row is not None else None
        if top and c is not None:
            e=versoes.active(versoes.get_slot(self.doc['formulas'],var.id,'circuito',c['id']))
            if e:return e
        if c is not None and var.variants.get('raiz') and c['entradas'].get('ident.montante') in ROOTS:
            # A variante dos circuitos ligados à fonte só muda por versão própria (escopo raiz), nunca pela edição comum.
            return versoes.active(top.get('raiz') if isinstance(top,dict) else None) or var.variants['raiz']
        return versoes.active(top) or var.expr
    def table_cell(self,table,addr):
        ed=self.doc['tabelas'].get(table.id)
        if ed:
            cells=ed.get('celulas',{})
            if addr in cells:return cells[addr]
        return table.cells.get(addr)
    def var_at(self,sheet,a):
        """Variável do modelo correspondente a (grupo de origem, posição)."""
        if sheet in self.model.circuit_sheet_set:
            return self.model.by_legacy.get((sheet,re.match(r'[A-Z]+',a)[0]))
        return self.model.fixed.get((sheet,a))
    def active_rows(self):
        return list(range(2,len(self.circuits_doc)+2))
    def raw(self,sheet,a):
        a=a.replace('$','').upper()
        if sheet in self.model.circuit_sheet_set:
            row,_=address(a);var=self.var_at(sheet,a)
            if var is None:return None
            if row==1:return var.header
            if var.kind=='entrada':
                if hasattr(self,'engine'):self.engine.touch(sheet,a)  # regras em Python que leem dados de entrada entram na invalidação seletiva
                return self.input_value(var,row)
            return self.expression(var,row)
        if sheet in self.model.fixed_sheets:
            var=self.model.fixed.get((sheet,a))
            if var is None:
                if sheet==FONTE and a.startswith('A'):
                    lab=next((v for v in self.model.fonte if v.addr=='B'+a[1:]),None)
                    if lab:return lab.spec.get('rotulo_original',lab.label)
                return None
            return self.fonte_value(var) if var.kind=='entrada' else self.expression(var,None)
        t=self.model.table(sheet)
        if t is not None:
            cell=self.table_cell(t,a)
            return None if cell is None else (cell['f'] if 'f' in cell else cell.get('v'))
        return None
    def is_formula(self,sheet,a):
        var=self.var_at(sheet,a.replace('$','').upper())
        if var is not None:return var.kind=='formula'
        t=self.model.table(sheet)
        if t is not None:
            cell=self.table_cell(t,a);return bool(cell and 'f' in cell)
        return False
    def cell(self,sheet,a):
        """Descrição de um dado: fórmula?, valor bruto e formato (substitui o acesso direto à planilha)."""
        var=self.var_at(sheet,a)
        f=self.is_formula(sheet,a)
        return {'formula':f,'value':self.raw(sheet,a),'format':var.fmt if var else 'General','cache':None}
    def get(self,sheet,a):return clean(self.engine.get(sheet,a))
    def put(self,sheet,a,value):
        a=a.replace('$','').upper()
        var=self.var_at(sheet,a)
        if var is None or var.kind!='entrada':raise ValueError(f'{self._label(sheet,a)} não é um dado de entrada.')
        if var.scope=='circuito':
            c=self.circuit_at(address(a)[0])
            if c is None:raise ValueError('Circuito inexistente nesta posição.')
            if value in (None,''):c['entradas'].pop(var.id,None)
            else:c['entradas'][var.id]=value
            self.engine.input_changed(var,address(a)[0],c)  # o que depende deste dado é recalculado na próxima leitura
        else:
            self.doc['fonte'][var.id]=value
            self.engine.clear()
    def fork(self):
        """Cópia independente do projeto que aproveita o cálculo já feito (para alterações transacionais)."""
        q=Project(copy.deepcopy(self.doc),self.model if self.model is not model() else None)
        q.engine.adopt(self.engine)
        return q
    def row_for(self,uid):
        for i,c in enumerate(self.circuits_doc):
            if c['id']==uid:return i+2
        raise ValueError('Circuito não encontrado.')
    def options(self,sheet,a):
        var=self.var_at(sheet,a)
        if var is None or not var.options:return []
        if 'lista' in var.options:return list(var.options['lista'])
        try:
            v=self.engine.evaluate(compiled(var.options['formula']),sheet,a)
            seq=list(v.flat()) if isinstance(v,Grid) else [v]
            return list(dict.fromkeys(x for x in seq if x is not None and x!='' and not isinstance(x,Error)))[:800]
        except Exception:return []
    def has_list_validation(self,sheet,a):
        var=self.var_at(sheet,a)
        return bool(var and var.options)
    def table_get(self,sheet,a):
        """Valor (calculado) de uma célula de tabela técnica."""
        return self.get(sheet,a)
    def weg_catalog(self):
        # Lê o catálogo real (Biblioteca_Proteções_WEG, 567 linhas) uma única
        # vez por projeto e classifica cada modelo em 'fixo' ou 'ajustavel' —
        # base para a 1ª seleção pedida pelo usuário (Disjuntor fixo/ajustável/
        # Fusível). Critério (verificado linha a linha nas 567 entradas antes
        # de adotar): usar SOMENTE o eixo térmico (Ir mín/máx — colunas J/K)
        # quando ele é numérico, exatamente como a própria planilha já faz em
        # BR ("Disparo ajustável?"). Comparar o eixo magnético (M/N) por si só
        # classificaria errado ~78% das vezes: a maioria das linhas "Termomagnético
        # fixo" tem M≠N só porque M/N ali guardam a FAIXA DE TOLERÂNCIA DE FÁBRICA
        # de um único ponto de disparo fixo (ex.: "dispara entre 3× e 5× In"), não
        # um ajuste selecionável — e M/N nessas linhas quase sempre numéricos e
        # diferentes. O eixo térmico, ao contrário, não tem esse problema (0
        # divergências da classificação do próprio catálogo nas 567 linhas).
        # Só quando NÃO há eixo térmico numérico (ex.: "MTU — somente magnético",
        # sem elemento térmico, Ir mín/máx = texto "N/D — CONSULTAR WEG") é que o
        # eixo magnético decide: nesse caso M/N realmente é o único ajuste do
        # dispositivo (ex.: "6/7,2/8,4/9,6/10,8/12×In", degraus reais).
        if getattr(self,'_weg_catalog_cache',None) is not None:return self._weg_catalog_cache
        sheet='Biblioteca_Proteções_WEG'
        t=self.model.table(sheet);last=1
        for a,c in t.cells.items():
            r,cn=address(a)
            if cn==3 and r>1 and c.get('v') not in (None,''):last=max(last,r)
        rows=[]
        for r in range(2,last+1):
            def v(col):return self.get(sheet,col+str(r))
            modelo=v('C')
            if not modelo or isinstance(modelo,dict):continue
            ir_min,ir_max=v('J'),v('K')
            im_min,im_max=v('M'),v('N')
            ir_numeric=isinstance(ir_min,(int,float)) and isinstance(ir_max,(int,float))
            im_numeric=isinstance(im_min,(int,float)) and isinstance(im_max,(int,float))
            if ir_numeric:
                classe='ajustavel' if ir_max>ir_min else 'fixo'
            else:
                classe='ajustavel' if (im_numeric and im_max>im_min) else 'fixo'
            disp=str(v('P') or '')
            if classe=='fixo':sub='fixo'
            elif 'letr' in disp.lower() or disp.upper().startswith(('ETS','ETM','AG1')):sub='eletronico'
            else:sub='termomagnetico'
            frame=v('I')
            if isinstance(frame,(int,float)) and not isinstance(frame,bool):in_nominal=frame
            else:
                mm=re.search(r'In\s*=\s*(\d+(?:[.,]\d+)?)\s*A',str(frame or ''))
                in_nominal=float(mm.group(1).replace(',','.')) if mm else None
            if isinstance(in_nominal,float) and in_nominal.is_integer():in_nominal=int(in_nominal)
            ir_p=_parse_passos(v('L'),v('AI'),ir_min,ir_max,in_nominal,'In')
            im_p=_parse_passos(v('O'),v('AJ') if sub!='eletronico' else None,im_min,im_max,in_nominal,'In')
            ii_fixo=None
            mf=re.search(r'Ii\s*(?:\([^)]*\))?\s*(fixo)?[^=;.]{0,12}=\s*(\d+(?:,\d+)?)\s*[×x]\s*In',str(v('O') or ''))
            if mf and ('fixo' in mf.group(0).lower()) and in_nominal is not None:
                ii_fixo=round(in_nominal*_num_br(mf.group(2)),2)
                if float(ii_fixo).is_integer():ii_fixo=int(ii_fixo)
            rows.append({'subclasse':sub,'in_nominal':in_nominal,'ii_fixo':ii_fixo,'ir_ajuste':ir_p,'im_ajuste':im_p,
                         'ir_passos':ir_p['valores'],'im_passos':im_p['valores'],
                         'familia':v('B'),'modelo':modelo,'fabricante':v('A'),'aplicacao':v('E'),
                         'polos':v('G'),'frame':v('I'),'ir_min':ir_min,'ir_max':ir_max,'passo_ir_desc':v('L'),
                         'im_min':im_min,'im_max':im_max,'passo_im_desc':v('O'),'disparador':v('P'),
                         'curva':v('Q'),'icu':v('R'),'ics':v('S'),'observacoes':v('V'),
                         'passo_ir_lista':v('AI'),'passo_im_lista':v('AJ'),
                         'classe':classe,'somente_magnetico':not ir_numeric})
        self._weg_catalog_cache=rows
        return rows
    def weg_familias_por_classe(self):
        out={'fixo':set(),'termomagnetico':set(),'eletronico':set()}
        for row in self.weg_catalog():out[row['subclasse']].add(row['familia'])
        out['ajustavel']=out['termomagnetico']|out['eletronico']
        return {k:sorted(v) for k,v in out.items()}
    def weg_modelo_classe(self,modelo):
        for row in self.weg_catalog():
            if row['modelo']==modelo:return row
        return None
    @staticmethod
    def protecao_ajustes(classe,modelo):
        """Parâmetros que existem fisicamente para a classe/modelo (o restante é ocultado na interface)."""
        nada={'in_bloqueado':False,'ir':False,'im':False,'isd':False,'tsd':False,'i2t':False,'rotulo_im':'Ii/Im adotado (A)'}
        if classe in (None,'fusivel'):return nada
        if classe=='fixo':return {**nada,'in_bloqueado':modelo is not None and modelo.get('in_nominal') is not None}
        if classe=='eletronico':
            return {**nada,'in_bloqueado':modelo is not None and modelo.get('in_nominal') is not None,
                    'ir':True,'im':True,'isd':True,'tsd':True,'i2t':True,'rotulo_im':'Ii adotado (A) · instantâneo'}
        # termomagnético ajustável
        ir=im=True
        if modelo is not None:
            ir=not modelo.get('somente_magnetico') and (bool(modelo.get('ir_passos')) or (isinstance(modelo.get('ir_min'),(int,float)) and isinstance(modelo.get('ir_max'),(int,float)) and modelo['ir_max']>modelo['ir_min']))
            im=bool(modelo.get('im_passos')) or (isinstance(modelo.get('im_min'),(int,float)) and isinstance(modelo.get('im_max'),(int,float)) and modelo['im_max']>modelo['im_min'])
        return {**nada,'in_bloqueado':modelo is not None and modelo.get('in_nominal') is not None,'ir':ir,'im':im,'rotulo_im':'Ii/Im adotado (A)'}
    def protecao_padroes(self,modelo,ib):
        """Ajustes válidos para um modelo do catálogo (usados ao trocar de modelo)."""
        S='Cálc-Prot_Cabos'
        def lim(x):return x if isinstance(x,(int,float)) else None
        ir_a=modelo.get('ir_ajuste') or {}
        lo,hi=lim(modelo.get('ir_min')),lim(modelo.get('ir_max'))
        y=None
        if ir_a.get('tipo')=='discreto' and ir_a.get('valores'):
            vals=sorted(ir_a['valores']);y=next((v for v in vals if ib is None or v>=ib),vals[-1])
        elif lo is not None and hi is not None:
            alvo=math.ceil(ib) if isinstance(ib,(int,float)) else lo
            y=min(max(alvo,lo),hi)
        elif lim(modelo.get('in_nominal')) is not None:y=modelo['in_nominal']
        if isinstance(y,float) and y.is_integer():y=int(y)
        out={}
        if modelo.get('in_nominal') is not None:out['K']=modelo['in_nominal']
        if y is not None:out['Y']=y
        classe=modelo.get('subclasse')
        im_a=modelo.get('im_ajuste') or {}
        z=None
        if classe=='eletronico':z=modelo.get('ii_fixo')
        elif im_a.get('tipo')=='discreto' and im_a.get('valores'):z=sorted(im_a['valores'])[0]
        elif im_a.get('tipo')=='discreto_ir' and y is not None and im_a.get('mult_ir'):z=round(min(im_a['mult_ir'])*y,2)
        elif lim(modelo.get('im_min')) is not None:z=modelo['im_min']
        if isinstance(z,float) and z.is_integer():z=int(z)
        if z is not None:out['Z']=z
        if classe=='eletronico':
            isd=None
            if im_a.get('tipo')=='discreto_ir' and y is not None and im_a.get('mult_ir'):isd=round(min(im_a['mult_ir'])*y,2)
            elif im_a.get('tipo')=='discreto' and im_a.get('valores'):isd=sorted(im_a['valores'])[0]
            elif lim(modelo.get('im_min')) is not None:isd=modelo['im_min']
            if isinstance(isd,float) and isd.is_integer():isd=int(isd)
            if isd is not None:out['BX']=isd
            out['BZ']='100';out['CA']='OFF'
        else:
            out['BX']=out['BZ']=out['CA']='N/A'
        return out
    def resetar_ajustes(self,row,nome):
        S='Cálc-Prot_Cabos'
        modelo=next((m for m in self.weg_catalog() if m['modelo']==nome),None)
        if not modelo:return
        ib=self.get('Cálc-Prot_Cabos',f'D{row}')
        for col,val in self.protecao_padroes(modelo,ib if isinstance(ib,(int,float)) else None).items():
            self.put(S,f'{col}{row}',val)
    def ajustes_manutencao(self,modelo,ib):
        """Ajustes válidos do disjuntor de manutenção para um modelo (mesma regra do disjuntor da origem)."""
        d=self.protecao_padroes(modelo,ib)
        num=lambda v:v if isinstance(v,(int,float)) and not isinstance(v,bool) else None
        eletronico=modelo.get('subclasse')=='eletronico'
        return {'mb_ir':num(d.get('Y')),'mb_ii':num(d.get('Z')),'mb_isd':num(d.get('BX')) if eletronico else None,
                'mb_tsd':100 if eletronico else None}
    def resetar_ajustes_manutencao(self,row,nome):
        modelo=self.weg_modelo_classe(nome)
        if not modelo:return
        ib=self.get('Cálc-Prot_Cabos',f'D{row}')
        for k,v in self.ajustes_manutencao(modelo,ib if isinstance(ib,(int,float)) else None).items():
            self.put(trecho.SHEET,f'{trecho.COL[k]}{row}',v)
        if not self.raw(trecho.SHEET,f"{trecho.COL['mb_familia']}{row}"):
            self.put(trecho.SHEET,f"{trecho.COL['mb_familia']}{row}",modelo['familia'])
    def backup_disjuntor(self,row):
        """Disjuntores do catálogo WEG que servem de backup do DPS: mesmos polos, In entre o dimensionado e o
        máximo do fabricante e Icu aplicável ≥ Ik no ponto. Ordena por In, curva C e maior Icu."""
        S='DPS';W='Biblioteca_Proteções_WEG'
        polos=self.get(S,f'BN{row}');base=self.get(S,f'BO{row}');lim=self.get(S,f'AH{row}');ik=self.get(S,f'Q{row}')
        num=lambda x:isinstance(x,(int,float)) and not isinstance(x,bool)
        if not (isinstance(polos,str) and num(base) and num(lim)):return {'candidatos':[],'sugerido':None,'motivo':'sem modelo de DPS ativo ou limite de backup indefinido'}
        por={}
        for r in range(2,self.model.table(W).max_row+1):
            m=self.raw(W,f'C{r}')
            if m:por[m]=r
        out=[]
        for m in self.weg_catalog():
            if m['subclasse']=='eletronico' or not m['polos'] or not str(m['polos']).startswith(polos):continue
            i=m['in_nominal'];r=por.get(m['modelo'])
            if not num(i) or not base<=i<=lim or r is None:continue
            icu=self.raw(W,f'AA{r}')
            if not num(icu) or (num(ik) and icu<ik):continue
            volt=self.raw(W,f'AC{r}')
            voltage=self.get('Padrão de entrada','B135')
            if not num(voltage) or not num(volt) or volt<voltage:continue
            out.append({'modelo':m['modelo'],'in':i,'curva':m['curva'],'icu':icu,'tensao':volt,'familia':m['familia']})
        out.sort(key=lambda x:(x['in'],0 if x['curva']=='C' else 1 if x['curva']=='—' else 2,-x['icu'],x['modelo']))
        return {'candidatos':out,'sugerido':out[0]['modelo'] if out else None,
                'motivo':None if out else f'nenhum disjuntor do catálogo com {polos}, In de {base} a {lim} A e Icu ≥ Ik ({ik} kA)'}
    def backup_fusivel(self,row):
        """Fusíveis NH gG da biblioteca com In entre o dimensionado e o máximo do fabricante e Icu ≥ Ik."""
        S='DPS';F='Biblioteca_Fusiveis_NH'
        base=self.get(S,f'BO{row}');lim=self.get(S,f'AH{row}');ik=self.get(S,f'Q{row}')
        num=lambda x:isinstance(x,(int,float)) and not isinstance(x,bool)
        out=[]
        voltage=self.get('Padrão de entrada','B135')
        if not all(num(v) for v in (base,lim,ik,voltage)) or voltage>500:return {'candidatos':[]}
        for r in range(2,200):
            nome=self.raw(F,f'D{r}')
            if not nome:break
            i=self.raw(F,f'G{r}');icu=self.raw(F,f'H{r}')
            if num(base) and num(lim) and not base<=i<=lim:continue
            if num(ik) and icu<ik:continue
            out.append({'modelo':nome,'in':i,'icu':icu,'tamanho':self.raw(F,f'E{r}')})
        return {'candidatos':out}
    def sugerir_backup_disjuntor(self,row):
        self.engine.clear()
        b=self.backup_disjuntor(row)
        if b['sugerido']:self.put('DPS',f'BM{row}',b['sugerido']);self.engine.clear()
        return b
    def fusivel_opcoes(self):
        sheet='Tabela_Disjuntores'
        out=[]
        for r in range(2,40):
            a=self.get(sheet,f'A{r}')
            if isinstance(a,str) and a.startswith('Fusível'):out.append(a)
        return out
    # ---- v1.12: ajustes dos disjuntores conferidos no servidor -----------------
    def tsd_options(self,r):
        opts=self.options('Cálc-Prot_Cabos',f'BZ{r}') or ['50','100','200','300']
        return [o for o in opts if numeros.looks_numeric(o)] or list(ajustes.TSD_PADRAO)
    def ajustes_origem(self,r):
        """Problemas dos ajustes do disjuntor da origem frente ao catálogo (lista vazia = compatível ou sem modelo)."""
        P='Cálc-Prot_Cabos'
        if self.get(trecho.SHEET,f"{trecho.COL['sem_origem']}{r}") is True:return []
        if str(self.raw(P,f'J{r}') or '').startswith('Fusível'):return []
        nome=self.raw(P,f'AM{r}')
        if nome in (None,''):return []
        modelo=self.weg_modelo_classe(nome)
        if modelo is None:return [f'Disjuntor da origem: o modelo "{nome}" não existe no catálogo WEG.']
        raw=lambda c:self.raw(P,f'{c}{r}')
        return ajustes.validate(modelo,raw('Y'),raw('Z'),raw('BX'),raw('BZ'),self.tsd_options(r),'Disjuntor da origem')
    def ajustes_manutencao_problemas(self,r):
        C=trecho.COL;T=trecho.SHEET
        if self.get(T,f"{C['tem_mb']}{r}") is not True:return []
        nome=self.raw(T,f"{C['mb_modelo']}{r}")
        if nome in (None,''):return []
        modelo=self.weg_modelo_classe(nome)
        if modelo is None:return [f'Disjuntor de manutenção: o modelo "{nome}" não existe no catálogo WEG.']
        raw=lambda k:self.raw(T,f"{C[k]}{r}")
        return ajustes.validate(modelo,raw('mb_ir'),raw('mb_ii'),raw('mb_isd'),raw('mb_tsd'),self.tsd_options(r),'Disjuntor de manutenção')
    # ---- v1.12: topologia elétrica ---------------------------------------------
    def topologia_problemas(self,r,install=None):
        name=self.raw(IDENT,f'B{r}');parent=self.raw(IDENT,f'D{r}')
        node=lambda k:{'name':self.raw(IDENT,f'B{k}'),'tipo':self.get(IDENT,f'G{k}'),'phases':self.raw(IDENT,f'E{k}'),'earthing':self.raw(IDENT,f'F{k}')}
        if parent in topologia.ROOTS:up=None
        else:
            k=next((x for x in self.active_rows() if x!=r and self.raw(IDENT,f'B{x}')==parent),None)
            if k is None:return []  # montante ausente: já é pendência da r42 (coluna H)
            up=node(k)
        install=install or self.installation.state(r)
        secs=[v for v in (self.get('Seleção-Seção_Condutor',f'W{r}'),self.get('Seleção-Seção_Condutor',f'Z{r}')) if isinstance(v,(int,float)) and not isinstance(v,bool)]
        return topologia.check(node(r),up,source_earthing=self.raw('Padrão de entrada','B78'),
                               material=install['values'].get('material'),sec_pen=max(secs) if secs else None,
                               pen_seccionado=self.raw('Cálc-Prot_Cabos',f'BQ{r}')=='Neutro seccionado — confirmado')
    def field(self,sheet,a,label=None):
        c=self.cell(sheet,a)
        col=re.match(r'[A-Z]+',a)[0]
        options=[] if c.get('formula') else (self.options(sheet,a) or list(EXTRA_OPTIONS.get((sheet,col),[])))
        base_numeric=col in NUMERIC_COLUMNS.get(sheet,set()) or isinstance(c.get('value'),(int,float))
        # Um campo com lista de opções só é tratado como numérico quando TODAS as
        # opções realmente são números (ex.: bitolas, In comercial). Listas com
        # algum código textual (ex.: "N/A", "11A", "13_Cabo unipolar") não podem
        # forçar conversão numérica no salvamento — isso já quebrava a escolha de
        # "N/A" em campos como Cálc-Prot_Cabos!BZ antes desta correção.
        numeric=base_numeric and (not options or all(_looks_numeric(x) for x in options))
        pending_list=not options and not c.get('formula') and self.has_list_validation(sheet,a)
        spec=numeros.spec_for(sheet,col) if numeric else None
        var=self.var_at(sheet,a)
        return {'sheet':sheet,'address':a,'label':label or (var.label if var else col),'spec':spec,
                'var':var.id if var else None,'unit':var.unit if var else '',
                'value':self.get(sheet,a),'formula':c.get('value') if c.get('formula') else None,
                'saved':c.get('cache'),'format':c.get('format','General'),
                'numeric':numeric,'options':options,'pending_list':pending_list}
    def form(self,uid):
        r=self.row_for(uid); groups=[]; installation=self.installation.state(r)
        for key,label,sheet,cols in GROUPS:
            fields=[self.field(sheet,c+str(r)) for c in cols]
            if key=='motores':
                fields += [self.field(motors.CALC,c+str(r)) for c in ('D','E','F','G','H','I','J')]
            if sheet==IDENT:
                for f in fields:
                    if f['address'].startswith('D'):
                        # v2.0: qualquer circuito pode ser ligado à fonte; não se oferece um descendente (evita ciclo).
                        desc=self.descendants(r)
                        f['options']=['','Transformador','Fonte']+[self.raw(IDENT,f'B{x}') for x in self.active_rows() if x!=r and x not in desc]
                        f['option_labels']={'Transformador':'Transformador (fonte do projeto)','Fonte':'Fonte (rede ou gerador)'}
            for field in fields:
                col=re.match(r'[A-Z]+',field['address'])[0]
                name=next((k for k,(sh,c) in INSTALL_FIELDS.items() if sh==sheet and c==col),None)
                if name:
                    field['installation_key']=name
                    if not field['formula']:field['value']=installation['values'][name]
                    if name in installation['options']:
                        field['strict']=True
                        field['options']=installation['options'][name]
                        field['pending_list']=False
                        field['numeric']=False
                        field['disabled']=not bool(field['options'])
                    field['label']=INSTALL_LABELS.get(name,field['label'])
                    if name=='method':
                        # O número é a montagem física; a letra A1/A2/B... é
                        # a referência elétrica. Agrupe as variantes do tipo
                        # de linha para que 1/2 apareçam explicitamente como
                        # A1/A2, sem permitir métodos de outra linha.
                        catalog=self.installation.line(installation['values']['line']) or {}
                        labels={}
                        # NÃO reutilizar o nome `key` aqui: ele é a chave do grupo
                        # do formulário ('metodo', 'cabos'...). Sobrescrevê-lo fazia o
                        # grupo chegar ao navegador como "6" e a galeria de imagens
                        # dos métodos nunca era montada.
                        for variant in catalog.get('variants',installation['variants']):
                            mkey=str(variant['method'])
                            text=f"{variant['reference']} · método {method_number(variant['method'])} · {variant['cable']}"
                            labels.setdefault(mkey,[])
                            if text not in labels[mkey]:labels[mkey].append(text)
                        field['option_labels']={k:' / '.join(v) for k,v in labels.items()}
                    if name in ('temperature_soil','soil'):field['hidden']=not installation['underground']
                    if name=='temperature_air':field['hidden']=installation['underground']
                    if name=='circuits':field['hidden']=True # contagem física guiada no agrupamento
            for field in fields:
                guide=FIELD_GUIDE.get((sheet,re.match(r'[A-Z]+',field['address'])[0]))
                if guide:field.update(guide)
            group={'key':key,'label':label,'fields':fields}
            if key=='integrada':
                for f in fields:protection.decorate_field(self,f,r)
                group['protection']=self.protection.result(r)
                group['link']=protection_links.view(self,r)
                group['outgoing']=protection_links.outgoing(self,r)
            if key=='protecao':
                for f in fields:
                    if re.match('[A-Z]+',f['address'])[0]!='BG':continue
                    saved=str(f['value'] or '')
                    poles=re.match(r'^([1-4]P)\b',saved)
                    if poles and saved not in f['options']:
                        f['options']=list(f['options'])+[saved]
                        f['option_labels']={saved:poles[1]+' — seleção salva'}
            if key=='motores':
                labels={'T':'Polos do maior motor','V':'Potência do maior motor (cv)','Y':'Somatório dos demais motores (cv)',
                        'AA':'Fator de potência médio dos demais motores','AB':'Rendimento médio dos demais motores (%)'}
                for f in fields:
                    c=re.match('[A-Z]+',f['address'])[0]
                    if f['sheet']==motors.LOAD:
                        if c in labels:f['label']=labels[c]
                        if c=='V' and 0 not in f['options']:f['options']=[0]+f['options'];f['option_labels']={'0':'Sem maior motor local'}
                        if c in ('AN','AO'):f['strict']=True
            if key=='partida':
                for f in fields:
                    c=re.match('[A-Z]+',f['address'])[0]
                    if c=='W':f['strict']=True
            if key=='trecho':
                self._form_trecho(r,fields,group)
            if key=='identificacao':
                for f in fields:
                    if f['address'].startswith('M'):
                        f['hint']=('Define o tempo máximo de seccionamento (TN: 5 s para origem e distribuição), a aplicação sugerida do '
                                   'disjuntor e a recomendação de DPS: origem e distribuição recebem DPS; circuito final, não.')
            if key=='dps':
                bd=self.backup_disjuntor(r);group['backup_disjuntor']=bd
                bf=self.backup_fusivel(r)
                group['dps_montante']={'circuito':self.get('DPS',f'BV{r}'),'tipo':self.get('DPS',f'U{r}')}
                for f in fields:
                    dc=re.match('[A-Z]+',f['address'])[0]
                    empty={'BH':'Siemens (padrão)','BI':'Fusível gL/gG do catálogo (padrão)','BK':'Não (padrão)',
                           'BT':'Automático — pela natureza e posição do quadro'}
                    if dc in empty:f['empty_label']=empty[dc]
                    if dc=='BT':
                        f['option_labels']={trecho.DPS_NAO:'Não — sem DPS neste quadro',trecho.DPS_T2:'Sim — Tipo 2 / Classe II',
                                            trecho.DPS_T12:'Sim — Tipo 1+2 / Classe I+II'}
                    labels={'BH':'Fabricante do DPS','H':'Existe SPDA externo?','BT':'DPS neste quadro',
                            'BU':'Justificativa ou observação (opcional)',
                            'AU':'Modelo do DPS','BI':'Tipo de proteção de backup','BP':'Fusível de backup',
                            'BM':'Disjuntor de backup','BJ':'Poder de corte informado (kA)',
                            'BK':'Há declaração de coordenação / equivalência do fabricante?',
                            'BL':'Identificação do documento do fabricante'}
                    if dc in labels:f['label']=labels[dc]
                    if dc in ('BH','BI','BK','BT'):f['strict']=True
                    if f['address'].startswith('BP'):
                        f['options']=[x['modelo'] for x in bf['candidatos']];f['strict']=True;f['numeric']=False;f['pending_list']=False
                        f['option_labels']={x['modelo']:f"{x['modelo']} · {x['tamanho']} · Icu {x['icu']} kA (500 V AC)" for x in bf['candidatos']}
                    if f['address'].startswith('BM'):
                        f['options']=[x['modelo'] for x in bd['candidatos']][:80];f['strict']=True;f['numeric']=False;f['pending_list']=False
                        f['option_labels']={x['modelo']:f"{x['modelo']} · In {x['in']} A · curva {x['curva']} · Icu {x['icu']} kA ({x['tensao']} V)" for x in bd['candidatos']}
            if key=='metodo':
                group['installation']=installation
            if key=='secoes':
                # Mostra os critérios de dimensionamento (ampacidade, queda de
                # tensão, Icc, seção mínima, concessionária) lado a lado com a
                # maior seção calculada entre eles e a seção escolhida pelo
                # projetista — exatamente os campos que já existiam como
                # fórmulas na r42 (Seção 11/12/13 do projeto), só que nunca
                # tinham sido expostos no formulário resumido. Não decide nada:
                # é informação para o projetista escolher; o aviso de "menor
                # que o calculado" usa o próprio resultado "*: seção OK?" já
                # existente na planilha (AA/AB/AC), nunca um recálculo paralelo.
                def _fv(addr):
                    f=next((x for x in fields if x['address']==addr),None)
                    return f['value'] if f is not None else None
                specs=[('Fase',[('F','Ampacidade'),('G','Queda de tensão'),('H','Curto-circuito (Icc)'),
                                 ('I','Seção mínima normativa'),('J','Concessionária')],'S','T','AA',None),
                       ('Neutro',[('K','Ampacidade'),('L','Queda de tensão'),('M','Curto-circuito (Icc)'),
                                  ('N','Seção mínima/redução admitida'),('O','Concessionária')],'U','W','AB','V'),
                       ('PE',[('P','Seção mínima/redução admitida (adiabática)'),('Q','Curto-circuito (Icc)'),
                              ('R','Concessionária')],'X','Z','AC','Y')]
                blocos=[]
                for nome,criterios,maior_col,escolhida_col,ok_col,reduzida_col in specs:
                    blocos.append({'nome':nome,
                                    'criterios':[{'label':lbl,'value':_fv(c+str(r)),'sheet':sheet,'address':c+str(r)} for c,lbl in criterios],
                                    'enderecos':{'maior':maior_col+str(r),'escolhida':escolhida_col+str(r),'sheet':sheet},
                                    'maior':_fv(maior_col+str(r)),'escolhida':_fv(escolhida_col+str(r)),
                                    'reduzida':_fv(reduzida_col+str(r)) if reduzida_col else None,'ok':_fv(ok_col+str(r))})
                if installation['issues']:
                    motivo='Instalação pendente: '+' '.join(installation['issues'])
                    group['comparacao_aviso']=motivo
                    for b in blocos:
                        for c in b['criterios']:
                            # Erros estruturados já carregam a causa do cálculo.
                            # Só adapta o aviso genérico de expressões legadas.
                            if isinstance(c['value'],str) and ('inválida' in c['value'] or 'SEÇÃO/MÉTODO NÃO ENCONTRADO' in c['value']):
                                c['value']={'error':'#N/A','detail':motivo}
                group['comparacao']=blocos
            if key=='cabos':
                group['cabos_bloqueado']=not installation['selected']
                group['cabos_aviso']=None
                group['cabos_aviso_valor']=None
            if key=='protecao':
                # 1ª seleção pedida pelo usuário: Disjuntor fixo / Disjuntor
                # ajustável / Fusível — ANTES de família/modelo. J (lista legada
                # de 18 entradas, mistura classes de fusível com famílias de
                # curva genéricas que nenhuma fórmula a jusante usa — ver
                # weg_catalog()) passa a significar só "qual classe de fusível";
                # AL/AM (catálogo real) passam a ser filtrados pela classe
                # escolhida. Nunca apaga um valor salvo (Seção 34) — só restringe
                # as opções exibidas e avisa quando o valor atual não pertence
                # mais à classe escolhida.
                j_field=next((f for f in fields if f['address'].startswith('J')),None)
                al_field=next((f for f in fields if f['address'].startswith('AL')),None)
                am_field=next((f for f in fields if f['address'].startswith('AM')),None)
                j_val=j_field['value'] if j_field else None
                al_val=al_field['value'] if al_field else None
                am_val=am_field['value'] if am_field else None
                modelo_info=self.weg_modelo_classe(am_val) if isinstance(am_val,str) and am_val else None
                if isinstance(j_val,str) and j_val.startswith('Fusível'):
                    classe_atual='fusivel'
                elif modelo_info is not None:
                    classe_atual=modelo_info['subclasse']
                elif isinstance(al_val,str) and al_val:
                    classes_na_familia={row['subclasse'] for row in self.weg_catalog() if row['familia']==al_val}
                    classe_atual=classes_na_familia.pop() if len(classes_na_familia)==1 else None
                else:
                    classe_atual=None
                group['classe_atual']=classe_atual
                fusivel_opcoes=self.fusivel_opcoes()
                if j_field is not None:j_field['options']=fusivel_opcoes
                for f in fields:
                    if re.match('[A-Z]+',f['address'])[0]=='CX':
                        f['hint']='Somado ao tsd para estimar o tempo de eliminação no curto retardo (seccionamento TN e seção térmica do neutro).'
                    if re.match('[A-Z]+',f['address'])[0]=='BQ':
                        f['options']=['PENDENTE','Neutro contínuo — confirmado','Neutro seccionado — confirmado','PEN contínuo — não seccionar','N/A']
                        f['option_labels']={'N/A':'Não se aplica'}
                        bp=self.get('Cálc-Prot_Cabos',f'BP{r}')
                        f['needed']=isinstance(bp,str) and ('CONFIRMAR' in bp or '3P ou 4P' in bp)
                        f['hint']=('Exigida porque o circuito admite '+bp+'.' if f['needed'] else 'Não exigida para este esquema: '+str(bp or '—')+'.')
                familias_por_classe=self.weg_familias_por_classe()
                if al_field is not None and classe_atual in ('fixo','termomagnetico','eletronico'):
                    permitidas=set(familias_por_classe[classe_atual])
                    al_field['options']=[o for o in al_field['options'] if o in permitidas]
                    if al_val and al_val not in permitidas:
                        group['familia_aviso']=('✗ Família atual ("%s") não pertence à classe "%s" escolhida — escolha outra família '
                                                 'ou mude a classe.'%(al_val,classe_atual))
                if am_field is not None and classe_atual in ('fixo','termomagnetico','eletronico'):
                    permitidos={row['modelo'] for row in self.weg_catalog() if row['familia']==al_val and row['subclasse']==classe_atual}
                    am_field['options']=[o for o in am_field['options'] if o in permitidos]
                    if am_val and modelo_info is not None and modelo_info['subclasse']!=classe_atual:
                        group['modelo_aviso']=('✗ Modelo atual ("%s") é "%s", não "%s" — escolha outro modelo '
                                                'ou mude a classe.'%(am_val,modelo_info['subclasse'],classe_atual))
                group['modelo_info']=modelo_info
                group['fusivel_opcoes']=fusivel_opcoes
                # Seção 104 (revisão geral · listas antes de texto livre): Y/Z
                # ("Ir/Ii adotado") já se descrevem como "lista de passos do
                # modelo em uso" — AT/AU trazem exatamente essa lista, separada
                # por "|", só quando o modelo atual é ajustável de verdade (um
                # modelo fixo traz texto descritivo em AT/AU, sem "|": Ir=In
                # fixo não tem passo nenhum pra listar). Virar lista aqui é só
                # restringir a ENTRADA a posições reais do dial do fabricante —
                # nunca apaga um valor já salvo fora da lista (Seção 34): cai no
                # mesmo "Outro (digitar manualmente)" que fieldHTML já usa para
                # qualquer campo com opções e valor fora delas.
                y_field=next((f for f in fields if f['address'].startswith('Y')),None)
                z_field=next((f for f in fields if f['address'].startswith('Z')),None)
                at_field=next((f for f in fields if f['address'].startswith('AT')),None)
                au_field=next((f for f in fields if f['address'].startswith('AU')),None)
                if modelo_info is not None:
                    ir_a,im_a=modelo_info['ir_ajuste'],modelo_info['im_ajuste']
                    if y_field is not None and ir_a['tipo']=='discreto':y_field['options']=list(ir_a['valores'])
                    if z_field is not None:
                        if im_a['tipo']=='discreto':z_field['options']=list(im_a['valores'])
                        elif im_a['tipo']=='discreto_ir' and y_field is not None and isinstance(y_field['value'],(int,float)):
                            z_field['options']=[(lambda x:int(x) if float(x).is_integer() else x)(round(m*y_field['value'],2)) for m in im_a['mult_ir']]
                # Passos de dial não admitem valor intermediário: sem "Outro (digitar manualmente)".
                for f in (y_field,z_field):
                    if f is not None and f.get('options'):f['strict']=True
                group['ajustes']=self.protecao_ajustes(classe_atual,modelo_info)
                group['ajustes_problemas']=self.ajustes_origem(r)
                if group['ajustes_problemas']:
                    for f in fields:
                        if re.match('[A-Z]+',f['address'])[0]=='BJ':f['value']='✗ AJUSTES FORA DO CATÁLOGO — '+group['ajustes_problemas'][0]
            groups.append(group)
        # Endereços dos resultados mostrados no topo do formulário, para o botão "Ver cálculo".
        trace={k:{'sheet':sh,'address':c+str(r)} for k,(sh,c) in RESULTS.items() if k in ('sec_f','dv_total','icc_max','iz')}
        return {'id':uid,'row':r,'name':self.raw(IDENT,f'B{r}'),'groups':groups,'installation':installation,'trace':trace,'info':self.circuit_info(r),
                'choice_fields':selection.fields(self,r),'workflow':selection.form_info(self,r)}
    def _form_trecho(self,r,fields,group):
        """Rótulos, listas e estado do grupo Dispositivos do trecho."""
        C=trecho.COL;inv={v:k for k,v in C.items()}
        labels={'origem':'Dispositivo de proteção na origem (montante)',
                'justificativa':'Justificativa da ausência',
                'condicoes':'Condições da dispensa confirmadas?',
                'tempo_montante':'Tempo de eliminação da falta pela proteção a montante (s)',
                'desc_montante':'Proteção a montante (descrição)',
                'manut':'Disjuntor de manutenção na extremidade (jusante)',
                'mb_familia':'Linha/família','mb_modelo':'Modelo/referência','mb_ir':'Ir adotado (A)',
                'mb_ii':'Ii/Im adotado (A)','mb_isd':'Isd adotado (A)','mb_tsd':'tsd adotado (ms)'}
        hints={'condicoes':'Confirme que a linha foi executada de modo a reduzir ao mínimo o risco de curto-circuito e não está próxima de '
                            'material combustível (NBR 5410, 5.3.5.3). Se nenhum disjuntor a jusante protege o cabo contra sobrecarga (na '
                            'extremidade ou adiante, em cadeia sem derivações — 5.3.4.2.2), confirme também que a linha não é '
                            'suscetível de sobrecarga (5.3.4.3).',
               'tempo_montante':'Tempo total para a proteção a montante (fusível de MT, relé ou dispositivo da concessionária) eliminar uma '
                                'falta fase–PE no fim deste trecho. É usado no seccionamento automático e no PE pelo critério adiabático; '
                                'sem ele, o PE segue a tabela 58.',
               'desc_montante':'Ex.: chave fusível de MT 10K; disjuntor da concessionária.',
               'justificativa':'Escolha uma justificativa ou digite outra.'}
        empty={'origem':'SIM — dispositivo na origem (padrão)','condicoes':'Pendente','manut':'NÃO (padrão)'}
        option_labels={'origem':{trecho.ORIGEM_SIM:'Sim — disjuntor ou fusível na origem',trecho.ORIGEM_NAO:'Não — protegido a montante'},
                       'condicoes':{trecho.SIM:'Sim — condições atendidas',trecho.NAO:'Não — condições não atendidas'},
                       'manut':{trecho.NAO:'Não',trecho.SIM:'Sim — disjuntor de manutenção'}}
        familias=sorted({m['familia'] for m in self.weg_catalog() if not m['somente_magnetico'] and m['familia']})
        modelos=[m['modelo'] for m in self.weg_catalog() if not m['somente_magnetico']]
        for f in fields:
            k=inv.get(re.match('[A-Z]+',f['address'])[0])
            f['trecho_key']=k
            if k in labels:f['label']=labels[k]
            if k in hints:f['hint']=hints[k]
            if k in empty:f['empty_label']=empty[k]
            if k in option_labels:f['option_labels']=option_labels[k]
            if k in ('origem','condicoes','manut'):f['strict']=True
            if k=='mb_familia':f['options']=familias;f['strict']=True;f['pending_list']=False
            if k=='mb_modelo':f['options']=modelos;f['strict']=True;f['pending_list']=False
        group['trecho']=trecho.state(self,r)
        group['ajustes_problemas']=self.ajustes_manutencao_problemas(r)
    def source_form(self):
        fields=[]
        for var in self.model.fonte:
            if var.kind!='entrada':continue
            a=var.addr;r,col=address(a)
            if True:
                if True:
                    f=self.field(var.sheet,a,var.label)
                    if var.sheet==SOURCE_SHEET:
                        protection.decorate_field(self,f)
                        fields.append(f)
                        continue
                    # Hierarquia pedida pelo usuário: cada entrada carrega a que bloco
                    # (tipo de atendimento) pertence, e — dentro de MT-com-dados — a
                    # qual sub-modo de B11. B2 é a própria seleção-raiz que decide tudo;
                    # fica marcada 'tipo' para o frontend tratá-la à parte, sempre visível.
                    f['block']='tipo' if r==2 else SOURCE_ROW_BLOCK.get(r,'geral')
                    f['submode']=SOURCE_ROW_SUBMODE.get(r)
                    fields.append(f)
        oc=self.meta.get('ocupacao',{})
        for key,(label,options,labels) in OCUPACAO_FIELDS.items():
            fields.append({'sheet':OCUPACAO_SHEET,'address':key,'label':label,'value':oc.get(key),'formula':None,'saved':None,
                           'format':'General','numeric':False,'options':list(options),'option_labels':labels,'pending_list':False,
                           'strict':True,'virtual':True,'block':'geral','submode':None})
        return fields
    def ocupacao(self):
        return {k:self.meta.get('ocupacao',{}).get(k) for k in OCUPACAO_FIELDS}
    def aluminio_bloqueado(self):
        """Proibições que não dependem do circuito (6.2.3.8): None se o alumínio ainda pode ser avaliado."""
        oc=self.ocupacao()
        if oc['densidade']=='BD4':return 'Locais BD4: não é permitido, em nenhuma circunstância, o emprego de condutores de alumínio (NBR 5410, 6.2.3.8.3).'
        if oc['tipo']=='Residencial':return 'Instalações residenciais: o alumínio não é admitido (NBR 5410, 6.2.3.8 admite apenas estabelecimentos industriais e comerciais).'
        if oc['tipo']=='Público / outros':return 'Ocupação pública ou outra: o alumínio só é admitido em estabelecimentos industriais e comerciais (NBR 5410, 6.2.3.8).'
        return None
    def aluminio_regras(self,r=None):
        """Pendências de uso de alumínio que independem da seção escolhida."""
        oc=self.ocupacao()
        base=self.aluminio_bloqueado()
        if base:return [base]
        pref='Condutor de alumínio: '
        if not oc['tipo']:return [pref+'informe o tipo de ocupação em Entrada e fontes › Informações gerais (NBR 5410, 6.2.3.8).']
        out=[]
        if oc['tipo']=='Comercial' and oc['densidade']!='BD1':out.append(pref+'estabelecimento comercial exige local exclusivamente BD1 (6.2.3.8.2-b); informe a densidade de ocupação.')
        if oc['tipo']=='Industrial':
            tipo=self.raw('Padrão de entrada','B2')
            if tipo=='Rede BT Direta':out.append(pref+'estabelecimento industrial exige alimentação por subestação/transformador ou fonte própria (6.2.3.8.1-b); o tipo de atendimento é Rede BT direta.')
        if oc['qualificado']!='Sim':out.append(pref+'a instalação e a manutenção devem ser realizadas por pessoas qualificadas (BA5); informe “Sim” em Entrada e fontes (6.2.3.8).')
        return out
    @staticmethod
    def aluminio_secao_minima(tipo):
        return {'Comercial':50,'Industrial':16}.get(tipo)
    def circuits(self):
        return [self._circuit(r) for r in self.active_rows()]
    def _circuit(self,r):
        x={'id':self.meta['ids'][str(r)],'row':r,'name':self.raw(IDENT,f'B{r}'),
           'description':self.raw(IDENT,f'C{r}'),'parent':self.raw(IDENT,f'D{r}'),
           'kind':self.raw(IDENT,f'M{r}'),'phases':self.raw(IDENT,f'E{r}'),
           'earthing':self.raw(IDENT,f'F{r}'),'length':self.get('Dados dos circuitos',f'F{r}')}
        x.update({k:self.get(s,c+str(r)) for k,(s,c) in ALL_RESULTS.items()})
        x['selection_modes']=selection.modes(self,r)
        x['dps_status']=selection.dps_status(self,r)
        x['ib']=max((v for v in (x['ir'],x['is'],x['it']) if isinstance(v,(int,float))),default=None)
        checks=[]
        sem_origem=x.get('sem_origem') is True
        for message in motors.issues(self,r):checks.append({'label':'Motores','value':'⏳ '+message,'address':'V'+str(r),'group':'motores'})
        if isinstance(x['dps_status'],str) and x['dps_status'].startswith('Pendente:'):
            checks.append({'label':'Seleção do DPS','value':'⏳ '+x['dps_status'],'address':'AU'+str(r),'group':'dps'})
        for c in 'CDEFGHIJKLMNO':
            v=self.get('Auditoria_Checklist',c+str(r)); label=self.raw('Auditoria_Checklist',c+'1')
            if isinstance(v,dict) or isinstance(v,str) and any(t in v for t in ['✗','△','PENDENTE','⏳','N/D']):
                group=AUDIT_GROUPS.get(c)
                if sem_origem and c in 'IJKL':
                    group='trecho'
                    label={'I':'Proteção do trecho — sobrecarga','J':'Proteção do trecho — curto-circuito',
                           'K':'Disjuntor de manutenção','L':'Proteção contra choque (TN) — trecho'}[c]
                check={'label':label or c,'value':v,'address':c+str(r),'group':group}
                if isinstance(v,str) and 'TEMPO DE ABERTURA' in v:check['focus']={'sheet':'Cálc-Prot_Cabos','col':'CX'}
                checks.append(check)
        if x.get('tem_mb') is True and not sem_origem:
            v=x.get('mb_status')
            if isinstance(v,dict) or isinstance(v,str) and not v.startswith('✓'):
                checks.append({'label':'Disjuntor de manutenção','value':v,'address':trecho.COL['mb_status']+str(r),'group':'trecho'})
        install=self.installation.state(r)
        # v1.12 — ajustes conferidos no servidor: um ajuste inexistente no equipamento nunca aparece como compatível.
        prob=self.ajustes_origem(r)
        x['ajustes_origem']=prob
        if prob:
            checks.append({'label':'Ajustes do disjuntor da origem','value':'✗ '+' '.join(prob),'address':'Y'+str(r),'group':'protecao',
                           'focus':{'sheet':'Cálc-Prot_Cabos','col':'Y'}})
            x['prot_status']='✗ AJUSTES FORA DO CATÁLOGO — '+prob[0]
        prob=self.ajustes_manutencao_problemas(r)
        x['ajustes_manutencao']=prob
        if prob:
            checks.append({'label':'Ajustes do disjuntor de manutenção','value':'✗ '+' '.join(prob),'address':trecho.COL['mb_ir']+str(r),'group':'trecho'})
            x['mb_status']='✗ AJUSTES FORA DO CATÁLOGO — '+prob[0]
        # v2.1 — uma única descrição do dispositivo: divergência entre In/tipo informados e o modelo escolhido vira pendência.
        from . import curvas
        conf=curvas.device_conflicts(self,r)
        x['dispositivo_conflitos']=conf
        if conf:
            checks.append({'label':'Dados do dispositivo da origem','value':'△ '+' '.join(conf),'address':'K'+str(r),'group':'protecao',
                           'focus':{'sheet':'Cálc-Prot_Cabos','col':'K'}})
        # v1.12 — topologia elétrica (fases, neutro, PE/PEN e esquema de aterramento entre montante e jusante).
        topo=self.topologia_problemas(r,install)
        x['topologia_eletrica']=topo
        if topo:
            checks.append({'label':'Topologia elétrica','value':'✗ '+' '.join(topo),'address':'D'+str(r),'group':'identificacao'})
            x['topologia']='✗ TOPOLOGIA ELÉTRICA INCOMPATÍVEL — '+topo[0]
        if install['values'].get('material')=='Alumínio':
            minimo=self.aluminio_secao_minima(self.ocupacao()['tipo']);sec=x.get('sec_f')
            if minimo and isinstance(sec,(int,float)) and not isinstance(sec,bool) and sec<minimo:
                checks.append({'label':'Alumínio: seção mínima','value':f'✗ Condutor de alumínio em estabelecimento {self.ocupacao()["tipo"].lower()} exige seção nominal de pelo menos {minimo} mm² (NBR 5410, 6.2.3.8); seção da fase escolhida: {sec:g} mm².','address':'T'+str(r),'group':'secoes'})
        if install['issues']:
            checks.insert(0,{'label':'Instalação e cabos','value':'✗ '+' '.join(install['issues']),'address':'B'+str(r),'group':'metodo','blocks':True})
            for result in INSTALL_DEPENDENT:
                x[result]={'error':'#N/A','detail':'Instalação pendente: '+' '.join(install['issues'])}
        x['installation_valid']=install['valid']
        x['grouping']=install['grouping']
        integrated=self.protection.result(r)
        x['integrated_protection']=integrated
        x['protection_link']=protection_links.view(self,r)
        if integrated.get('active'):
            for label,k in [('Proteção integrada do alimentador','status'),('Suportabilidade térmica do cabo','thermal')]:
                value=integrated.get(k)
                if value and any(t in str(value) for t in ('✗','⏳','△')):
                    checks.append({'label':label,'value':value,'address':RCOL['estado']+str(r),'group':'integrada'})
            x['protection_integrated_status']=integrated.get('status')
        x['issues']=checks
        x['status']='error' if any(isinstance(c['value'],dict) or '✗' in str(c['value']) for c in checks) else 'pending' if checks else 'ok'
        x.update(self._derived(x,install))
        return x
    def _derived(self,x,install):
        """Campos de apresentação calculados a partir dos resultados já lidos (nada é recalculado aqui)."""
        num=lambda v:isinstance(v,(int,float)) and not isinstance(v,bool)
        d={}
        d['esquema_ligacao']=esquema_ligacao(x.get('tipo_circuito'))
        d['condutores']=condutores_agrupados(x.get('tipo_circuito'),x.get('n_polo'),x.get('sec_f'),x.get('sec_n'),x.get('sec_pe'),x.get('n_neutro'),x.get('n_pe'))
        t=x.get('tipo_circuito');sn,sp=x.get('sec_n'),x.get('sec_pe')
        d['condutores_nota']=None
        if isinstance(t,str) and 'PEN' in t.split('+') and num(sn) and num(sp) and sn!=sp:
            d['condutores_nota']=f'PEN adotado = maior entre as seções escolhidas do neutro ({_fmt_secao(sn)} mm²) e do PE ({_fmt_secao(sp)} mm²).'
        # Corrente nominal do dispositivo (In): sensor quando existe, senão o frame do catálogo.
        in_dev=x['in_sensor'] if num(x.get('in_sensor')) else x['in_frame'] if num(x.get('in_frame')) else None
        d['in_prot']=in_dev
        def a(v):return f'{v:g}'.replace('.',',')
        if num(in_dev) and num(x.get('ir_prot')):d['protecao_ajuste']=f"In{a(in_dev)}A_Ir{a(x['ir_prot'])}A"
        elif num(x.get('ir_prot')):d['protecao_ajuste']=f"Ir{a(x['ir_prot'])}A"
        else:d['protecao_ajuste']=None
        d['q_own']=sum(x[k] for k in ('q_own_r','q_own_s','q_own_t') if num(x.get(k)))
        d['p_own']=sum(x[k] for k in ('p_own_r','p_own_s','p_own_t') if num(x.get(k)))
        v=install.get('values',{})
        d['instalacao']={'linha':v.get('line'),'metodo':v.get('method'),'referencia':install.get('reference'),
                         'cabo':v.get('cable'),'material':v.get('material'),'isolacao':v.get('insulation'),
                         'tensao_isolacao':v.get('voltage')}
        d['avisos_paralelo']=self.avisos_paralelo(x,v)
        d['dps_recomendado']=isinstance(x.get('dps_rec'),str) and x['dps_rec'].startswith('✓')
        d['prot_classe']='fusivel' if isinstance(x.get('prot_tipo'),str) and x['prot_tipo'].startswith('Fusível') else 'disjuntor'
        # v1.10 — dispositivos do trecho
        d['origem_ausente']=x.get('sem_origem') is True
        d['dps_ausente']=isinstance(x.get('dps_modo'),str) and x['dps_modo'].startswith('NÃO')
        if d['origem_ausente']:
            d['protecao_origem_ajuste']=d['protecao_ajuste'];d['protecao_ajuste']=None
        d['manutencao']=None
        if x.get('tem_mb') is True:
            mb_in,mb_ir=x.get('mb_in'),x.get('mb_ir')
            if num(mb_in) and num(mb_ir):notation=f"In{a(mb_in)}A_Ir{a(mb_ir)}A"
            elif num(mb_ir):notation=f"Ir{a(mb_ir)}A"
            else:notation=None
            d['manutencao']={'modelo':x.get('mb_modelo'),'in':mb_in,'ir':mb_ir,'ii':x.get('mb_ii'),'icu':x.get('mb_icu'),
                             'classe':x.get('mb_classe'),'status':x.get('mb_status'),'ajuste':notation}
        return d
    @staticmethod
    def avisos_paralelo(x,v):
        """Alertas da NBR 5410:2004 (6.2.5.7, 6.2.10.4 e 5.3.5.4) para circuitos com Nc >= 2.
        O cálculo supõe divisão igual de corrente entre os condutores em paralelo."""
        n=x.get('n_polo')
        isn=lambda q:isinstance(q,(int,float)) and not isinstance(q,bool)
        t=str(x.get('tipo_circuito') or '');partes=t.split('+')
        tem_n='N' in partes or 'PEN' in partes;tem_pe='T' in partes or 'PEN' in partes
        nn=int(x['n_neutro']) if isn(x.get('n_neutro')) else None;npe=int(x['n_pe']) if isn(x.get('n_pe')) else None
        extra=[]
        if isn(n) and n>=1:
            # v2.3.2: neutro/PE com quantidade de condutores diferente das fases
            if tem_n and nn is not None and nn!=int(n):
                extra.append({'nivel':'aviso','ref':'NBR 5410, 6.2.5.7.2',
                              'texto':f'Neutro{"/PEN" if "PEN" in partes else ""} com {nn} condutor(es) em paralelo e fases com {int(n)}: a divisão igual de corrente '
                                      'pressupõe cada grupo com todas as fases e o respectivo neutro. Com quantidades diferentes, é necessário estudo '
                                      'específico da divisão de corrente (6.2.5.7.1 b). O cálculo usa a quantidade informada para o neutro na ampacidade, '
                                      'na impedância, na queda, no curto e na seção térmica, e a seção total equivalente na Tabela 48.'})
            if tem_pe and 'PEN' not in partes and npe is not None and npe!=int(n):
                extra.append({'nivel':'info','ref':'NBR 5410, 6.4.3.1',
                              'texto':f'PE com {npe} condutor(es) e fases com {int(n)} por polo: a impedância do laço de falta (choque, Ik fase-terra, '
                                      'comprimento máximo) usa o PE informado; a seção adiabática é calculada por condutor de PE, e a Tabela 58 é aplicada '
                                      'sobre a seção total das fases e repartida entre os condutores de PE, com arredondamento para a seção superior '
                                      '(critério interno; a Tabela 58 não trata paralelos explicitamente).'
                                      +(' Com cabos multipolares, cada cabo normalmente já leva a sua veia de PE: confira se a quantidade informada '
                                        'corresponde à instalação.' if any(w in str(v.get('cable') or '').lower() for w in ('multipolar','multiplex')) else '')})
        if not isn(n) or n<2:return extra
        n=int(n);cabo=str(v.get('cable') or '');material=v.get('material')
        sec=x.get('sec_f');multipolar='multipolar' in cabo.lower() or 'multiplex' in cabo.lower()
        limite=70 if material=='Alumínio' else 50
        out=[{'nivel':'info','ref':'NBR 5410, 6.2.5.7.1',
              'texto':f'{n} condutores por polo: o cálculo (Iz, queda de tensão e curto-circuito) supõe divisão igual de corrente entre os condutores em paralelo. É preciso garantir essa divisão (6.2.5.7.2) ou fazer estudo específico da divisão de corrente (6.2.5.7.1 b).'},
             {'nivel':'aviso','ref':'NBR 5410, 6.2.5.7.2',
              'texto':'A divisão igual só é considerada atendida se os condutores em paralelo tiverem a mesma constituição, a mesma seção nominal, aproximadamente o mesmo comprimento e nenhuma derivação ao longo do percurso.'}]
        if multipolar:
            out.append({'nivel':'info','ref':'NBR 5410, 6.2.5.7.2 a',
                        'texto':'Veias de cabos multipolares ou multiplexados em paralelo: condição atendida em qualquer seção, desde que cada cabo contenha todas as fases e o neutro (se existir).'})
        elif isinstance(sec,(int,float)) and not isinstance(sec,bool) and sec>limite:
            out.append({'nivel':'aviso','ref':'NBR 5410, 6.2.5.7.2 c',
                        'texto':f'Cabos unipolares de {sec:g} mm² (acima de {limite} mm² em {str(material).lower()}): é exigido agrupamento em configurações especiais, com cada grupo contendo todas as fases e o neutro, de modo a obter o maior equilíbrio possível entre as impedâncias dos condutores de cada fase.'})
        else:
            out.append({'nivel':'info','ref':'NBR 5410, 6.2.5.7.2 b',
                        'texto':f'Condutores isolados ou cabos unipolares (até {limite} mm² em {str(material).lower()}) em paralelo: use trifólio, formação plana ou conduto fechado, com cada grupo ou conduto contendo todas as fases e o neutro (se existir).'})
        out.append({'nivel':'aviso','ref':'NBR 5410, 6.2.10.4',
                    'texto':f'Reunir os condutores em {n} grupos, cada um com um condutor de cada fase ou polaridade, instalados nas proximidades imediatas uns dos outros. Em condutos metálicos fechados, todos os condutores vivos do mesmo circuito devem estar no mesmo conduto.'})
        out.append({'nivel':'aviso','ref':'NBR 5410, 5.3.5.4',
                    'texto':'Proteção contra curto-circuito de condutores em paralelo: um único dispositivo só é admitido se atuar mesmo para falta no ponto mais desfavorável (considerando a divisão da corrente e a alimentação da falta pelas duas extremidades). Caso contrário: com 2 condutores, um dispositivo na origem de cada condutor; com mais de 2, um dispositivo em cada extremidade de cada condutor.'})
        return extra+out
    def circuit_info(self,r):
        """Todas as informações calculadas de um circuito, organizadas em subgrupos para o formulário.
        Somente leitura: cada item com 'sheet'/'address' tem o botão "Ver cálculo" na interface."""
        x=self._circuit(r)
        install_ok=x['installation_valid']
        num=lambda v:isinstance(v,(int,float)) and not isinstance(v,bool)
        blocked={'error':'#N/A','detail':'Corrija a instalação e os cabos antes de usar este resultado.'}
        def key(label,k,unit='',digits=2,scale=None):
            sheet,col=ALL_RESULTS[k]; v=x.get(k)
            if scale and num(v):v=v*scale
            return {'label':label,'value':v,'unit':unit,'digits':digits,'sheet':sheet,'address':col+str(r)}
        def cell(label,sheet,col,unit='',digits=2,dep=False,scale=None):
            v=blocked if dep and not install_ok else self.get(sheet,col+str(r))
            if scale and num(v):v=v*scale
            return {'label':label,'value':v,'unit':unit,'digits':digits,'sheet':sheet,'address':col+str(r)}
        def text(label,v):return {'label':label,'value':v,'unit':'','digits':None}
        def matrix(title,cols,rows):return {'title':title,'matrix':{'columns':cols,'rows':rows}}
        def mrow(label,vals,unit,digits=2):return {'label':label,'unit':unit,'digits':digits,'values':vals}
        k3=lambda a,b,c:[x.get(a),x.get(b),x.get(c)]
        def sub(vals,fn):
            return [fn(v) if num(v) else v for v in vals]
        p_own=k3('p_own_r','p_own_s','p_own_t'); q_own=k3('q_own_r','q_own_s','q_own_t')
        s_own=[(p*p+q*q)**.5 if num(p) and num(q) else None for p,q in zip(p_own,q_own)]
        p_tot=k3('pr','ps','pt'); q_tot=k3('q_r','q_s','q_t'); s_tot=k3('s_r','s_s','s_t')
        kw=lambda v:v/1000
        three=lambda vals:sum(v for v in vals if num(v)) if any(num(v) for v in vals) else None
        s3=(three(p_own) or 0,three(q_own) or 0)
        fp_own=[ (p/s if num(p) and num(s) and s else None) for p,s in zip(p_own,s_own)]
        fp_in=k3('fp_r','fp_s','fp_t')
        cols=['Fase R','Fase S','Fase T','Total 3F']
        cargas=[
            matrix('Carga própria do circuito',cols,[
                mrow('Potência ativa P',sub(p_own,kw)+[(three(p_own) or 0)/1000 if three(p_own) is not None else None],'kW'),
                mrow('Potência reativa Q',sub(q_own,kw)+[(three(q_own) or 0)/1000 if three(q_own) is not None else None],'kvar'),
                mrow('Potência aparente S',sub(s_own,kw)+[((s3[0]**2+s3[1]**2)**.5)/1000],'kVA'),
                mrow('Fator de potência informado',fp_in+[ (s3[0]/((s3[0]**2+s3[1]**2)**.5) if (s3[0]**2+s3[1]**2)>0 else None)],'',3)]),
            matrix('Total do circuito (própria + jusante, com fator de simultaneidade)',cols,[
                mrow('Potência ativa P',sub(p_tot,kw)+[x['p_w']/1000 if num(x.get('p_w')) else x.get('p_w')],'kW'),
                mrow('Potência reativa Q',sub(q_tot,kw)+[x['q_var']/1000 if num(x.get('q_var')) else x.get('q_var')],'kvar'),
                mrow('Potência aparente S',sub(s_tot,kw)+[x['s_va']/1000 if num(x.get('s_va')) else x.get('s_va')],'kVA'),
                mrow('Fator de potência',[None,None,None,x.get('fp')],'',3)]),
            {'title':'Simultaneidade','items':[key('Fator de simultaneidade (Fs)','fs','',2),key('Fator de potência do circuito','fp','',3)]}]
        correntes={'title':'Correntes de projeto','items':[
            key('Corrente nominal — fase R','ir','A'),key('Corrente nominal — fase S','is','A'),key('Corrente nominal — fase T','it','A'),
            key('Corrente nominal — neutro','ineutro','A'),
            {**key('Corrente máxima do circuito (Ic)','ic','A'),'note':'maior corrente de fase; é a base do cálculo da proteção (Ib ≤ Ir ≤ Iz)'},
            key('Corrente de partida do maior motor (Ip)','ip_motor','A')]}
        oc=self.ocupacao()
        geral=[{'title':'Ocupação e uso de alumínio (definido em Entrada e fontes › Informações gerais)','items':[
                text('Tipo de ocupação',oc['tipo'] or 'Não informado'),text('Densidade de ocupação',oc['densidade'] or 'Não informada'),
                text('Pessoas qualificadas (BA5)',oc['qualificado'] or 'Não informado'),
                text('Material deste circuito',x['instalacao']['material']),
                text('Alumínio neste circuito',(' '.join(self.aluminio_regras(x['row'])) or 'Admitido nas condições informadas') if x['instalacao']['material']=='Alumínio' else 'Não se aplica (cobre)')]},
            {'title':'Identificação','items':[
                text('Circuito',x['name']),text('Descrição',x['description']),text('Circuito a montante',x['parent'] or 'Desvinculado'),
                text('Natureza do circuito',x['kind']),text('Esquema de ligação',x['esquema_ligacao']),
                text('Esquema de aterramento',x['earthing']),
                {**cell('Comprimento','Dados dos circuitos','F','m',1)},
                text('Topologia',value_label(x.get('topologia')))]},
               {'title':'Valores-chave','items':[
                {'label':'Corrente nominal (Ib, maior fase)','value':x['ib'],'unit':'A','digits':2},
                key('Corrente máxima (Ic)','ic','A'),key('Corrente admissível do cabo (Iz)','iz','A'),
                key('Queda de tensão no trecho','dv','%'),key('Queda de tensão total','dv_total','%'),
                key('Icc máxima','icc_max','kA',3),key('Icc mínima','icc_min','kA',3),
                text('Proteção (In/Ir)',x['protecao_ajuste'])]}]
        instalacao=[{'title':'Instalação e método','items':[
                text('Linha elétrica',x['instalacao']['linha']),
                text('Método de instalação',x['instalacao']['metodo']),text('Método de referência',x['instalacao']['referencia']),
                text('Tipo de condutor',x['instalacao']['cabo']),
                text('Contagem física no trecho',x['grouping'].get('count_explanation','Pendente')),
                cell('Temperatura ambiente','Dados dos circuitos','B','°C',0),
                cell('Temperatura do solo','Dados dos circuitos','C','°C',0),
                cell('Resistividade térmica do solo','Dados dos circuitos','D','K·m/W',1)]},
            {'title':'Fatores de correção da corrente','items':[
                key('Fator de temperatura (FCT)','fct','',3),key('Solo × profundidade (correção complementar quando aplicável)','fcr','',3),
                key('Fator único de agrupamento (FCA)','fca','',3),
                text('Origem do FCA',x['grouping'].get('source') or 'Pendente'),
                text('Tabela e condição',x['grouping'].get('coordinate') or 'Pendente'),
                text('Base térmica do grupo',str(x['grouping'].get('temperature'))+' °C'),
                cell('Carregamento do neutro (separado do FCA)','Corrente-Calc_Ampacidade ','W','',2),
                text('Registro do agrupamento',self.installation.group_trace(x['row'])),
                text('Seção mínima do neutro','Redução somente com equilíbrio, harmônicas ≤15% e proteção contra sobrecorrentes demonstrados (6.2.6.2.6).'),
                text('Piso de corrente do neutro','15% por condutor: premissa interna opcional, não normativa; dividido por Nc uma única vez.')]}]
        alertas=[{'title':f"Alertas da NBR 5410 — condutores em paralelo (fases: {x['n_polo']:g} por polo)" if num(x.get('n_polo')) else 'Alertas da NBR 5410 — condutores em paralelo','alerts':x['avisos_paralelo']}] if x['avisos_paralelo'] else []
        condutores=alertas+[{'title':'Condutores','items':[
                text('Esquema de ligação',x['esquema_ligacao']),text('Condutores (agrupado)',x['condutores']),
                key('Condutores por polo','n_polo','',0),
                key('Condutores em paralelo — neutro/PEN (adotado)','n_neutro','',0),key('Condutores em paralelo — PE (adotado)','n_pe','',0),
                text('Material',x['instalacao']['material']),text('Isolação',x['instalacao']['isolacao']),
                text('Tensão de isolação',x['instalacao']['tensao_isolacao']),
                key('Seção da fase','sec_f','mm²',1),key('Seção do neutro','sec_n','mm²',1),key('Seção do PE','sec_pe','mm²',1),
                key('Seção sugerida (fase)','sec_sugerida','mm²',1)]},
            {'title':'Corrente máxima do cabo na situação da instalação','items':[
                key('Iz da fase (corrigida)','iz','A'),key('Iz do neutro (corrigida)','iz_neutro','A'),
                {**key('Corrente máxima do circuito (Ic)','ic','A'),'note':'para comparação com Iz'}]},
            {'title':'Queda de tensão','items':[
                key('Queda no trecho','dv','%',3),key('Queda acumulada da instalação','dv_total','%',3),
                key('Queda do sistema (fonte + instalação)','dv_sistema','%',3),key('Limite por trecho','dv_limite','%',2)]}]
        icc=[{'title':'Correntes de curto-circuito (valor simétrico)','items':[
                key('Icc trifásica máxima','icc3f_max','kA',3),key('Icc bifásica máxima','icc2f_max','kA',3),
                key('Icc monofásica máxima','icc1f_max','kA',3),key('Icc trifásica mínima','icc3f_min','kA',3),
                key('Icc bifásica mínima','icc2f_min','kA',3),key('Icc monofásica mínima','icc1f_min','kA',3),
                key('Icc máxima do tipo de circuito','icc_max','kA',3),
                key('Valor de crista (ip, trifásico)','ip_crista','kA',3)]},
            {'title':'Contribuição de motores','items':[
                cell('Contribuição de motores (3F)','Cálc_Icc-Motores','AO','kA',3,dep=True)]}]
        C=trecho.COL;TS=trecho.SHEET
        def tcell(label,k,unit='',digits=2):return cell(label,TS,C[k],unit,digits)
        sem_origem=x['origem_ausente'];mb=x['manutencao']
        trecho_items=[text('Dispositivo na origem','Não — '+(x.get('justificativa_origem') or 'justificativa pendente') if sem_origem else 'Sim')]
        if sem_origem:
            trecho_items+=[tcell('Proteção contra curtos-circuitos do trecho','trecho_curto'),
                           tcell('Proteção contra sobrecargas do trecho','trecho_sobrecarga'),
                           tcell('Seccionamento — falta no próprio trecho','trecho_choque_cabo'),
                           tcell('Tempo da proteção a montante','tempo_montante','s',2)]
        trecho_items.append(text('Disjuntor de manutenção na extremidade',(mb['modelo'] or 'modelo pendente') if mb else 'Não'))
        if mb:
            trecho_items+=[tcell('In do disjuntor de manutenção','mb_in','A',0),tcell('Ir adotado','mb_ir','A',0),
                           tcell('Ii/Im adotado','mb_ii','A',0),tcell('Icu no catálogo','mb_icu','kA',1),
                           tcell('Ik máximo no ponto de instalação','ik_max','kA',3),
                           tcell('Seccionamento — falta no quadro','mb_tn'),tcell('Status do disjuntor de manutenção','mb_status')]
            if not sem_origem:trecho_items.append(tcell('Origem × manutenção (pré-seletividade)','mb_x_origem'))
        trecho_items.append(key('Dispositivo a montante considerado na seletividade','sel_montante'))
        protecao=[{'title':'Dispositivos do trecho','items':trecho_items},
                  {'title':'Dispositivo de proteção na origem'+(' — não previsto' if sem_origem else ''),'items':[
                cell('Fabricante','Cálc-Prot_Cabos','AK'),cell('Família / linha','Cálc-Prot_Cabos','AL'),
                key('Modelo em uso','protecao'),text('In / Ir (notação)',x['protecao_ajuste']),
                key('Corrente nominal do disjuntor (In)','in_frame','A',0) if not num(x.get('in_sensor')) else key('Corrente nominal do disjuntor (In)','in_sensor','A',0),
                key('Ir adotado','ir_prot','A',0),key('Ii/Im adotado','ii_prot','A',0),
                cell('Isd adotado','Cálc-Prot_Cabos','BX','A',0),cell('tsd adotado','Cálc-Prot_Cabos','BZ','ms',0),
                key('Icu','icu','kA',1),cell('Ics','Cálc-Prot_Cabos','AB','kA',1),
                key('Ik máximo no quadro de instalação (base do Icu/Ics)','icc_origem','kA',3),
                key('Status final','prot_status'),key('Recomendação do modelo','recomendado')]},
            {'title':'Seccionamento automático (choque elétrico)','items':[
                key('Tensão de contato','tensao_contato','V',1),cell('Corrente presumida de choque','Cálc-Prot_Choque','U','A',2,dep=True),
                cell('Ik do laço de falta','Cálc-Prot_Choque','X','A',0,dep=True),
                key('Tempo máximo (TN)','tempo_tn_max','s',2),key('Tempo estimado da proteção','tempo_tn_est','s',2),
                key('Seccionamento TN','choque_status')]},
            {'title':'Seletividade','items':[key('Pré-checagem de seletividade','seletividade')]}]
        dps=[{'title':'Proteção contra surtos','items':[
                text('DPS neste quadro',x.get('dps_modo') or 'Automático — pela natureza e posição do quadro'),
                key('DPS recomendado neste quadro?','dps_rec'),key('Tipo / classe','dps_tipo'),
                key('DPS a montante (tipo)','dps_montante'),key('DPS a montante (quadro)','dps_montante_circuito'),
                key('Modelo ativo','dps_modelo'),key('Coordenação e backup','dps_status'),
                cell('Uc mínimo exigido','DPS','K','V',0),cell('Up de referência máximo','DPS','L','kV',2),
                cell('Iimp / In mínimo exigido','DPS','M','kA',2)]}]
        tabs=[('geral','Informações gerais',geral,['identificacao','ambiente']),
              ('cargas','Cargas gerais',cargas+[correntes],['cargas']),
              ('motores','Motores',[],['motores','partida']),
              ('instalacao','Instalação',instalacao,['instalacao','metodo']),
              ('condutores','Condutores',condutores,['cabos','secoes']),
              ('curto','Curto-circuito',icc,[]),
              ('protecoes','Proteções',protecao,['integrada','trecho','protecao','choque']),
              ('dps','DPS',dps,['dps'])]
        return [{'key':k,'label':l,'sections':sec,'groups':g} for k,l,sec,g in tabs]
    ORIGEM_OBRIGATORIOS={
        'Rede MT/Trafo com dados':['B9','B10','B11','B75','B80','B81','B78'],
        'Rede MT/Trafo sem dados':['B9','B75','B80','B81','B78'],
        'Rede BT Direta':['B31','B32','B33','B34','B78'],
        'Gerador BT':['B45','B46','B47','B48','B49','B50','B51','B78'],
    }
    ORIGEM_POR_MODO={'Icc (kA)':['B12','B13'],'Pcc (kVA)':['B14'],'Zpu':['B15','D15','B16','D16']}
    def origem_pendencias(self):
        """Pendências de preenchimento da entrada (nenhum cálculo é refeito aqui)."""
        raw=lambda a:self.raw('Padrão de entrada',a)
        tipo=raw('B2')
        if tipo in (None,''):return [('error' if False else 'pending','Selecione o tipo de atendimento (rede MT/transformador, rede BT direta ou gerador).')]
        req=list(self.ORIGEM_OBRIGATORIOS.get(tipo,[]))
        if tipo=='Rede MT/Trafo com dados':req+=self.ORIGEM_POR_MODO.get(raw('B11'),[])
        out=[]
        for a in req:
            v=raw(a)
            label=str(self.raw('Padrão de entrada','A'+a[1:]) or a).split(' [')[0]
            if v in (None,''):out.append(('pending',f'Preencha: {label}.'))
            elif isinstance(v,(int,float)) and not isinstance(v,bool) and v<0:out.append(('error',f'Valor inválido em: {label}.'))
        out.extend(('pending',m) for m in protection.source_status(self)['issues'])
        return out
    def origem(self):
        """Dados da fonte (Padrão de entrada) para o símbolo de origem do unifilar."""
        g=lambda a:self.get('Padrão de entrada',a)
        tipo=g('B2')
        out={'tipo':tipo,'tensao_ff':g('B135'),'potencia_kva':g('B136'),'esquema':g('B78')}
        if tipo in ('Rede MT/Trafo com dados','Rede MT/Trafo sem dados'):
            out.update({'tensao_mt':g('B9'),'trafo_kva':g('B75'),'grupo_ligacao':g('B81'),'tensao_secundario':g('B80')})
        elif tipo=='Gerador BT':out.update({'gerador_kva':g('B46'),'fp':g('B47')})
        elif tipo=='Rede BT Direta':out.update({'in_medicao':g('B34')})
        pend=self.origem_pendencias()
        out['pendencias']=[m for _,m in pend]
        out['status']='error' if any(k=='error' for k,_ in pend) else 'pending' if pend else 'ok'
        out['tipos']=self.options('Padrão de entrada','B2')
        out['protection']=protection.source_status(self)
        return out
    def summary(self):
        circuits=self.circuits(); names={x['name'] for x in circuits}
        roots=[x for x in circuits if x['parent'] in ('Fonte','Transformador')]
        def total(k):
            vals=[x[k] for x in roots]
            return sum(vals) if vals and all(isinstance(v,(int,float)) for v in vals) else None
        return {'title':self.meta['title'],'source':self.meta.get('source'),'changes':self.meta.get('changes',0),
                'origem':self.origem(),
                'capacity':CAPACITY,'circuits':circuits,'p_w':total('p_w'),'s_va':total('s_va'),
                'formula_count':self.model.formula_count,'circuit_variables':len(self.model.circuit),
                'pending':sum(x['status']!='ok' for x in circuits),
                'disconnected':sum(x['parent'] not in names|{'Fonte','Transformador'} for x in circuits),
                'tables':[{'id':t.id,'nome':t.name} for t in self.model.tables.values()],
                'diagnostics':[{'sheet':s,'address':a,**clean(v)} for (s,a),v in self.engine.diagnostics.items()],
                'recalculated':len(self.engine.cache)}
    def _validate_value(self,sheet,a,value):
        if isinstance(value,(dict,list,bool)) or isinstance(value,float) and not math.isfinite(value):
            raise ValueError(f'Valor inválido em {self._label(sheet,a)}.')
        if isinstance(value,str) and len(value)>5000:raise ValueError('Texto muito longo.')
        if sheet in (SOURCE_SHEET,CIRCUIT_SHEET):
            var=self.var_at(sheet,a)
            if var.kind!='entrada':raise ValueError('Resultado calculado automaticamente.')
            return protection.validate_value(self,var,value)
        c=self.cell(sheet,a)
        if c.get('formula'):raise ValueError(f'{self._label(sheet,a)} é calculado automaticamente.')
        col=re.match('[A-Z]+',a)[0]
        positive=(sheet=='Dados dos circuitos' and col in ('D','E','F','J') or
                  sheet==trecho.SHEET and col in trecho.NUMERIC or
                  sheet=='Seleção-Seção_Condutor' and col in ('T','W','Z') or
                  sheet=='Dados dos condutores ' and col=='D')
        if value is None or value=='':return value
        flex_reserved=FLEXIBLE_NUMERIC_COLUMNS.get(sheet,set())
        if col in flex_reserved and isinstance(value,str) and value!='N/A' and _looks_numeric(value):
            # Valor digitado parece número (ex.: "65" ou "65,5") — converte de
            # fato, não só valida, para que ISNUMBER() funcione no motor.
            value=numeros.parse_br(value)
        motors.validate(sheet,col,value)
        allowed_text={(trecho.SHEET,trecho.COL['origem']):[trecho.ORIGEM_SIM,trecho.ORIGEM_NAO],
                      (trecho.SHEET,trecho.COL['condicoes']):[trecho.SIM,trecho.NAO],
                      (trecho.SHEET,trecho.COL['manut']):[trecho.SIM,trecho.NAO],
                      ('DPS','BT'):trecho.DPS_OPCOES}.get((sheet,col))
        if allowed_text is not None and value not in allowed_text:raise ValueError('Seleção inválida: '+str(value))
        if sheet==trecho.SHEET and col==trecho.COL['tempo_montante'] and isinstance(value,(int,float)) and value>3600:
            raise ValueError('Tempo da proteção a montante: informe um valor em segundos (até 3600 s).')
        old=c.get('value')
        if col in NUMERIC_COLUMNS.get(sheet,set()) and isinstance(value,str) and numeros.looks_numeric(value):
            value=numeros.parse_br(value)  # API: "1.000,00" chega como texto
        if (isinstance(old,(float,int)) or col in NUMERIC_COLUMNS.get(sheet,set())) and not isinstance(value,(float,int)):
            allowed=self.options(sheet,a) or list(EXTRA_OPTIONS.get((sheet,col),[]))
            if col in flex_reserved:allowed=[*allowed,'N/A']
            # Exceção 1: se o valor enviado é uma das opções válidas da própria lista
            # (ex.: "N/A", "11A", um código de método), aceita como texto — a lista
            # é quem define o domínio válido, não o tipo numérico do valor antigo.
            # Exceção 2: se o valor enviado é EXATAMENTE o que já está salvo, aceita
            # mesmo sem lista — reenviar um override textual pré-existente (ex.:
            # Cálc-Prot_Cabos!BX com "N/A" herdado do próprio arquivo de referência,
            # numa coluna marcada como numérica mas sem dataValidation) não pode ser
            # bloqueado só porque nada nela mudou. Isto nunca afrouxa a validação
            # para um valor textual NOVO — só permite reafirmar o que já existia.
            # (Para colunas em FLEXIBLE_NUMERIC_COLUMNS, "N/A" é sempre aceito,
            # mesmo na primeira vez: é o literal reservado para "sem parâmetro",
            # não um texto arbitrário novo — ex.: voltar de Reator/65 para Direta.)
            if not any(str(value)==str(o) for o in allowed) and str(value)!=str(old):
                raise ValueError(f'{self._label(sheet,a)}: informe um número (use vírgula ou ponto decimal).')
        if positive and (not isinstance(value,(float,int)) or value<=0):
            raise ValueError(f'{self._label(sheet,a)}: informe um número maior que zero.')
        if sheet=='Levantamento de carga' and col in ('E','I','M','AA'):
            if not isinstance(value,(int,float)) or not 0<value<=1:raise ValueError('O fator de potência deve estar entre 0 e 1, excluindo zero.')
        if sheet=='Dados dos circuitos' and col=='H':
            if not isinstance(value,(int,float)) or not 0<=value<=1:raise ValueError('Simultaneidade deve estar entre 0 e 1.')
        if sheet=='Levantamento de carga' and col in ('D','H','L','V','Y'):
            if not isinstance(value,(int,float)) or value<0:raise ValueError('Carga ou potência não pode ser negativa.')
        if sheet==IDENT and col in ('B','D','E','F','M'):
            if not isinstance(value,str):raise ValueError('Este campo exige texto.')
            allowed={'E':['Monofásico','Bifásico','Trifásico'],'F':['TN-S','TN-C'],
                     'M':['Origem','Distribuição','Circuito final','Não aplicável']}.get(col)
            if allowed and value not in allowed:raise ValueError('Seleção inválida: '+value)
        if isinstance(value,(int,float)) and not isinstance(value,bool):
            label=self.raw(sheet,col+'1')
            value=numeros.check(sheet,col,value,re.sub(r'\s+',' ',label).split(' [')[0].strip() if isinstance(label,str) else None)
        return value
    def update(self,changes,installation=None,validate_installation=True):
        if not isinstance(changes,list) or len(changes)>1000:raise ValueError('Lista de alterações inválida.')
        # A camada HTTP trabalha sobre uma cópia; erro algum grava alterações parciais.
        renames={}; installation_rows=set(); modelo_novo={}; disj_novo=set(); mb_novo={}
        curve_uids=set()
        ajuste_origem=set(); ajuste_mb=set()  # v1.12: uids cujos ajustes de disjuntor serão conferidos
        for x in changes:
            s,a,v=x['sheet'],x['address'],x.get('value')
            if s==selection.SHEET:
                selection.update_mode(self,a,v)
                continue
            if s==OCUPACAO_SHEET:
                if a not in OCUPACAO_FIELDS:raise ValueError('Campo de ocupação inválido.')
                if v not in (None,'') and v not in OCUPACAO_FIELDS[a][1]:raise ValueError('Seleção inválida: '+str(v))
                self.meta.setdefault('ocupacao',{})[a]=None if v in (None,'') else v
                continue
            if not isinstance(a,str) or not re.fullmatch('[A-Z]{1,3}[1-9][0-9]{0,4}',a) or self.var_at(s,a) is None:raise ValueError('Campo inválido.')
            row,col=address(a)
            fv=self.model.fixed.get((s,a))
            allowed=(s in (FONTE,SOURCE_SHEET) and fv is not None and fv.kind=='entrada') or (s in self.model.circuit_sheet_set and row in self.active_rows() and col_name(col) in self.input_columns.get(s,set()))
            if not allowed:raise ValueError(f'{self._label(s,a)} não é uma entrada editável.')
            v=self._validate_value(s,a,v)
            if s==CIRCUIT_SHEET and col_name(col)==CCOL['curva_corrente'] and v:
                curve_uids.add(self.meta['ids'][str(row)])
            if s=='Cálc-Prot_Cabos' and col_name(col) in protection_links.SHARED and protection_links.requested(self,row) and v!=self.raw(s,a):
                raise ValueError('Este disjuntor está vinculado ao quadro precedente. Edite o cadastro do disjuntor nesse quadro.')
            if s=='Cálc-Prot_Cabos' and col_name(col) in ('J','AL','AM','Y','Z','BX','BZ') and v!=self.raw(s,a):
                ajuste_origem.add(self.meta['ids'][str(row)])
            if s==trecho.SHEET and col_name(col) in set(trecho.MB_INPUTS)|{trecho.COL['manut'],trecho.COL['origem']} and v!=self.raw(s,a):
                ajuste_mb.add(self.meta['ids'][str(row)])
            # APIs/importações antigas que editam um dispositivo diretamente
            # representam uma escolha manual. Um modo enviado explicitamente
            # no mesmo pedido tem prioridade.
            mode_key=None
            if s=='DPS' and col_name(col) in ('BI','BP','BM','BJ'):mode_key='backup'
            if s=='DPS' and col_name(col)=='AU':mode_key='dps'
            if s=='Cálc-Prot_Cabos' and col_name(col) in ('J','K','AL','AM','Y','Z','BX','BZ','CA'):mode_key='protecao'
            if s==trecho.SHEET and col_name(col) in trecho.MB_INPUTS:mode_key='manutencao'
            if mode_key and v!=self.raw(s,a):
                uid=self.meta['ids'][str(row)]
                if not any(z['sheet']==selection.SHEET and z['address']==mode_key+':'+uid for z in changes):
                    self.meta.setdefault('selection_modes',{}).setdefault(uid,{})[mode_key]=selection.MANUAL
                    if mode_key=='dps':self.put('DPS',f'AT{row}','MANUAL — OUTRO MODELO DO CATÁLOGO')
            if s=='DPS' and col_name(col)=='BM' and v not in (None,'') and not any(m['modelo']==v for m in self.weg_catalog()):
                raise ValueError('Disjuntor de backup inexistente no catálogo WEG: '+str(v))
            if s=='DPS' and col_name(col)=='BP' and v not in (None,'') and not any(self.raw('Biblioteca_Fusiveis_NH',f'D{k}')==v for k in range(2,40)):
                raise ValueError('Fusível de backup inexistente na biblioteca NH: '+str(v))
            if s=='DPS' and col_name(col)=='BI' and v=='DISJUNTOR (equivalência)' and v!=self.raw(s,a):disj_novo.add(row)
            if s==trecho.SHEET and col_name(col)==trecho.COL['mb_modelo'] and v not in (None,''):
                modelo=self.weg_modelo_classe(v)
                if modelo is None:raise ValueError('Disjuntor de manutenção inexistente no catálogo WEG: '+str(v))
                if modelo['somente_magnetico']:raise ValueError('O disjuntor de manutenção precisa de disparo térmico; '+str(v)+' é somente magnético.')
                if v!=self.raw(s,a):mb_novo[row]=v
            if s==trecho.SHEET and col_name(col)==trecho.COL['mb_familia'] and v not in (None,'') and not any(m['familia']==v for m in self.weg_catalog()):
                raise ValueError('Família inexistente no catálogo WEG: '+str(v))
            if s==IDENT and col==2:
                v=(v or '').strip()
                if not v or v in ('Fonte','Transformador'):raise ValueError('Informe um nome de circuito distinto de Fonte e Transformador.')
                renames[self.raw(s,a)]=v
            if s=='Cálc-Prot_Cabos' and col_name(col)=='AM' and v not in (None,'') and v!=self.raw(s,a):modelo_novo[row]=v
            self.put(s,a,v)
            if (s,col_name(col)) in INSTALL_FIELDS.values() or (s==IDENT and col_name(col)=='E'):
                installation_rows.add(row)
        # Trocar o modelo do disjuntor invalida os ajustes do modelo anterior: recarrega os valores válidos.
        for row,nome in modelo_novo.items():
            ajustados={a for sh,a in ((x['sheet'],x['address']) for x in changes if x['sheet']=='Cálc-Prot_Cabos') if address(a)[0]==row and re.match(r'(Y|Z|BX|BZ|CA)\d',a)}
            if not ajustados:self.resetar_ajustes(row,nome)
        mb_cols={trecho.COL[k] for k in ('mb_ir','mb_ii','mb_isd','mb_tsd')}
        for row,nome in mb_novo.items():
            enviados=any(x['sheet']==trecho.SHEET and re.match(r'[A-Z]+',x['address'])[0] in mb_cols and address(x['address'])[0]==row for x in changes)
            if not enviados:self.resetar_ajustes_manutencao(row,nome)
        if installation is not None:
            r=self.row_for(installation['id'])
            settings=installation.get('settings',{})
            if not isinstance(settings,dict) or set(settings)-SETTING_KEYS:
                raise ValueError('Condições de instalação inválidas.')
            self.meta.setdefault('installation_settings',{})[installation['id']]=dict(settings)
            installation_rows.add(r)
        self.engine.clear()
        # Ajuste sem aplicação não deve sobreviver oculto à troca de montagem.
        for r in installation_rows:
            method_changed=any(x['sheet']=='Identificação-Método_Instal ' and x['address'] in (f'B{r}',f'C{r}') for x in changes)
            adjustment_sent=any(x['sheet']=='Identificação-Método_Instal ' and x['address']==f'H{r}' for x in changes)
            if method_changed and not adjustment_sent:
                choices=self.installation.state(r)['options']['adjustment']
                if len(choices)==1:self.put('Identificação-Método_Instal ',f'H{r}',choices[0])
        self.engine.clear()
        if validate_installation:
            for r in installation_rows:self.installation.verify(r)
            if installation is not None and installation.get('reference')!=self.installation.state(self.row_for(installation['id']))['reference']:
                raise ValueError('O método de referência não corresponde à montagem e ao cabo selecionados.')
            if installation is not None:
                st=self.installation.state(self.row_for(installation['id']))
                self.meta['installation_settings'][installation['id']]['group_signature']=st['grouping']['signature']
        if renames:
            for r in self.active_rows():
                parent=self.raw(IDENT,f'D{r}')
                if parent in renames:self.put(IDENT,f'D{r}',renames[parent])
        explicit={(x['sheet'],x['address']) for x in changes if x['sheet'] not in (OCUPACAO_SHEET,selection.SHEET)}
        if explicit and any(s!='Cálc-Prot_Cabos' or not a.startswith('CF') for s,a in explicit):
            for r in self.active_rows():
                if ('Cálc-Prot_Cabos',f'CF{r}') not in explicit:self.put('Cálc-Prot_Cabos',f'CF{r}','PENDENTE')
        self.reorder()
        self.meta['changes']+=1
        self.engine.clear()
        for row in disj_novo:
            if not any(x['sheet']=='DPS' and x['address']==f'BM{row}' for x in changes) and self.raw('DPS',f'BM{row}') in (None,''):
                self.sugerir_backup_disjuntor(row)
        # Direta e estrela-triângulo não têm parâmetro percentual editável.
        for r in self.active_rows():
            if any(x['sheet']==motors.START and x['address']==f'W{r}' for x in changes):
                if self.raw(motors.START,f'W{r}') in ('Direta','Estrela-triângulo'):self.put(motors.START,f'X{r}','N/A')
        self.engine.clear()
        selection.apply(self)
        protection.update_curves(self,changes,curve_uids)
        if any(x['sheet']==CIRCUIT_SHEET and x['address'].startswith(CCOL['vinculo']) for x in changes):
            errors=[protection_links.problem(self,r) for r in self.active_rows() if protection_links.requested(self,r)]
            if any(errors):raise ValueError(' '.join(x for x in errors if x))
        if validate_installation and (ajuste_origem or ajuste_mb):
            problems=[]
            for uid in ajuste_origem:
                try:problems+=self.ajustes_origem(self.row_for(uid))
                except ValueError:pass
            for uid in ajuste_mb:
                try:problems+=self.ajustes_manutencao_problemas(self.row_for(uid))
                except ValueError:pass
            if problems:
                raise ValueError('Ajustes incompatíveis com o catálogo do fabricante; nada foi gravado. '+' '.join(dict.fromkeys(problems)))
    def _snapshot_inputs(self,r):
        c=self.circuit_at(r);out={}
        for v in self.model.inputs:out[(v.sheet,v.col)]=copy.deepcopy(c['entradas'].get(v.id)) if c else None
        return out
    def _write_inputs(self,r,inputs):
        c=self.circuit_at(r)
        if c is None:return
        for (s,col),val in inputs.items():
            var=self.model.by_legacy.get((s,col))
            if var is None or var.kind!='entrada':continue
            if val in (None,''):c['entradas'].pop(var.id,None)
            else:c['entradas'][var.id]=copy.deepcopy(val)
    def reorder(self):
        """Ordem topológica: cada circuito depois do seu montante. Sem posições fixas nem limite de quantidade."""
        items=list(self.circuits_doc)
        names=[str(c['entradas'].get('ident.nome') or '').strip() for c in items]
        if any(not n for n in names):raise ValueError('Todo circuito precisa de um nome.')
        if len({n.casefold() for n in names})!=len(names):raise ValueError('Os nomes dos circuitos devem ser únicos.')
        if any(n in ROOTS for n in names):raise ValueError('“Fonte” e “Transformador” são reservados para a origem.')
        byname={c['entradas']['ident.nome']:c for c in items};seen=set();visiting=set();ordered=[]
        def visit(c):
            n=c['entradas']['ident.nome']
            if n in seen:return
            if n in visiting:raise ValueError('Esta ligação criaria um ciclo elétrico.')
            visiting.add(n);parent=c['entradas'].get('ident.montante')
            if parent in byname:visit(byname[parent])
            elif parent not in (*ROOTS,'',None):raise ValueError('Circuito a montante não encontrado: '+str(parent))
            visiting.remove(n);seen.add(n);ordered.append(c)
        for c in items:visit(c)
        self.circuits_doc[:]=ordered
        self._sync_ids()
        self.engine.clear()
    def add(self,name,parent,duplicate=None,reselect=True):
        rows=self.active_rows()
        name=str(name or '').strip()
        if not name or name in ROOTS:raise ValueError('Informe um nome válido.')
        if len(name)>80:raise ValueError('Nome muito longo (máximo de 80 caracteres).')
        template=self.row_for(duplicate) if duplicate else (rows[-1] if rows else None)
        inputs=self._snapshot_inputs(template) if template else {}
        # Circuitos novos usam entradas explícitas e não herdam confirmações de catálogo.
        inputs[(IDENT,'B')]=name;inputs[(IDENT,'C')]='';inputs[(IDENT,'D')]=parent
        inputs[(IDENT,'M')]='Circuito final'
        if not duplicate:
            inputs.update({(IDENT,'E'):'Monofásico',(IDENT,'F'):'TN-S',
                ('Dados dos circuitos','B'):30,('Dados dos circuitos','C'):20,('Dados dos circuitos','D'):2.5,
                ('Dados dos circuitos','E'):1,('Dados dos circuitos','F'):10,('Dados dos circuitos','G'):0,
                ('Dados dos circuitos','H'):1,('Dados dos circuitos','I'):'Força',('Dados dos circuitos','J'):1,
                # Método 5, não 6: a Tabela 33 (NBR 5410) só permite "Cabo
                # multipolar" no método 6 — "Condutor isolado"/"Cabo unipolar" são
                # do método 5 (mesma situação física, eletroduto aparente não
                # circular sobre parede). A revisão desta sessão corrigiu o
                # casamento Método<->Tipo de condutor; manter B=6 e trocar C para
                # "Cabo multipolar" soaria mais "correto" à primeira vista, mas
                # Tab_Imped-Cabos não tem impedância cadastrada para cabo
                # multipolar de 2 condutores em PVC/450-750V (confirmado por
                # teste de regressão — fica "⏳ PENDENTE"), enquanto o combo
                # unipolar+PVC+450-750V já adotado abaixo está testado e
                # cadastrado. Método 5 preserva o restante do modelo tal como
                # validado, sem depender de uma célula da tabela de referência
                # que nunca foi preenchida para essa combinação.
                ('Maneira de instalar','B'):'Eletroduto aparente',('Identificação-Método_Instal ','B'):5,
                ('Identificação-Método_Instal ','C'):'Condutor isolado',('Identificação-Método_Instal ','H'):'N/A',
                ('Dados dos condutores ','D'):1,('Dados dos condutores ','E'):'Sim',('Dados dos condutores ','F'):'Cobre',
                ('Dados dos condutores ','I'):'PVC',('Dados dos condutores ','J'):'450/750V',
                ('Dados dos condutores ','L'):'2 - condutores unipolares/isolados - próximos',
                ('Seleção-Seção_Condutor','T'):2.5,('Seleção-Seção_Condutor','W'):2.5,('Seleção-Seção_Condutor','Z'):2.5,
                ('Cálc-Prot_Cabos','J'):'Disjuntor_C - In <= 63A',('Cálc-Prot_Cabos','K'):16,
                ('Cálc-Prot_Cabos','Y'):16,('Cálc-Prot_Cabos','Z'):160,('Cálc-Prot_Cabos','AL'):'',
                ('Cálc-Prot_Cabos','AM'):'',('Cálc-Prot_Cabos','CH'):'MANTER SELEÇÃO ATUAL',('DPS','H'):'Não'})
            for c in ('D','H','L','V','Y'):inputs[('Levantamento de carga',c)]=0
            for c in ('E','I','M','AA'):inputs[('Levantamento de carga',c)]=1
            inputs[('Levantamento de carga','AB')]=100
            inputs[('Levantamento de carga','T')]=4
            for c in motors.OVERRIDES:inputs[(motors.LOAD,c)]=None
            inputs[(motors.LOAD,'AN')]=motors.ADD
            inputs[(motors.LOAD,'AO')]='R'
            inputs[(motors.START,'W')]='Direta'
            inputs[(motors.START,'X')]='N/A'
            inputs[(motors.START,'D')]=.25
            inputs[(motors.START,'O')]=6
            inputs[(motors.START,'P')]=10
            for c in ('AU','BI','BM','BP','BJ','BK','BL','BR','BS','BT','BU'):inputs[('DPS',c)]=None
            for c in trecho.INPUTS:inputs[(trecho.SHEET,c)]=None
        inputs[('Cálc-Prot_Cabos','CF')]='PENDENTE'
        uid=uuid.uuid4().hex
        self.circuits_doc.append({'id':uid,'entradas':{}})
        r=len(self.circuits_doc)+1
        self._sync_ids()
        self._write_inputs(r,inputs)
        self.meta.setdefault('selection_modes',{})[uid]=copy.deepcopy(
            selection.modes(self,self.row_for(duplicate)) if duplicate else self.meta.get('selection_defaults',{k:selection.AUTO for k in selection.KEYS}))
        if duplicate:
            for vid,top in self.doc['formulas'].items():
                src=versoes.get_slot(self.doc['formulas'],vid,'circuito',duplicate)
                if src is not None:
                    top.setdefault('circuitos',{})[uid]=versoes.copy_slot(src,vid,'circuito',duplicate,'circuito',uid)
            cfg=self.meta.get('installation_settings',{}).get(duplicate)
            if cfg is not None:self.meta.setdefault('installation_settings',{})[uid]=copy.deepcopy(cfg)
        self.reorder();self.meta['changes']+=1
        if not duplicate:self.complete_installation(self.row_for(uid))
        if reselect:selection.apply(self)  # importação em lote: a seleção roda uma vez ao final
        return uid
    def complete_installation(self,r):
        """Reconcilia escolhas inferíveis sem confirmar geometria ou grupo desconhecido."""
        st=self.installation.state(r,reconcile=True)
        for k,(sh,c) in INSTALL_FIELDS.items():
            v=st['values'].get(k)
            if v is not None:self.put(sh,f'{c}{r}',v)
        st=self.installation.state(r)
        uid=self.meta['ids'][str(r)]
        cfg=self.meta.setdefault('installation_settings',{}).setdefault(uid,{})
        if st['settings'].get('group'):cfg.setdefault('group',st['settings']['group'])
        cfg.setdefault('group_mode','auto');cfg.setdefault('depth',.7)
        self.engine.clear()
    def delete(self,uid):
        r=self.row_for(uid)
        name=self.raw(IDENT,f'B{r}')
        children=[self.raw(IDENT,f'B{x}') for x in self.active_rows() if self.raw(IDENT,f'D{x}')==name]
        if children:raise ValueError('Transfira ou desvincule primeiro os circuitos filhos: '+', '.join(children))
        del self.circuits_doc[r-2]
        self.reorder();self.meta['changes']+=1
        self.engine.clear();selection.apply(self)  # v1.12: a seleção automática acompanha a nova topologia
    def descendants(self,r):
        name=self.raw(IDENT,f'B{r}');out=set();frontier={name}
        while frontier:
            nxt={self.raw(IDENT,f'B{x}') for x in self.active_rows() if self.raw(IDENT,f'D{x}') in frontier}
            nxt-={self.raw(IDENT,f'B{x}') for x in out}
            out|={x for x in self.active_rows() if self.raw(IDENT,f'B{x}') in nxt}
            frontier=nxt
        return out
    def _label(self,sheet,a):
        """Nome legível de um campo: variável e circuito (sem endereço de planilha)."""
        var=self.var_at(sheet,a)
        if var is None:return 'Campo'
        if var.scope=='circuito':
            c=self.circuit_at(address(a)[0])
            nome=c['entradas'].get('ident.nome') if c else None
            return f'{var.label} ({nome})' if nome else var.label
        return var.label
    def describe(self,sheet,a):
        var=self.var_at(sheet,a)
        if var is None:
            t=self.model.table(sheet)
            return {'var':None,'rotulo':(t.name+' · '+a) if t else a,'circuito':None,'tabela':t.id if t else None}
        c=self.circuit_at(address(a)[0]) if var.scope=='circuito' else None
        return {'var':var.id,'rotulo':var.label,'unidade':var.unit,'circuito':c['entradas'].get('ident.nome') if c else None}
    def packed(self):return gzip.compress(json.dumps(self.doc,ensure_ascii=False,separators=(',',':')).encode(),compresslevel=6)


def unpack(raw):
    if len(raw)>30_000_000:raise ValueError('Arquivo excede 30 MB.')
    import io
    with gzip.GzipFile(fileobj=io.BytesIO(raw)) as f:
        decoded=f.read(100_000_001)
    if len(decoded)>100_000_000:raise ValueError('Projeto descompactado excede 100 MB.')
    data=json.loads(decoded)
    if not isinstance(data,dict):raise ValueError('Projeto inválido.')
    return data

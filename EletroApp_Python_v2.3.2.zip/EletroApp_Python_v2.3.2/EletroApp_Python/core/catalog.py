"""Catálogo de cálculos do motor nativo (v2.0): rastreável, editável e justificado.

Cada variável calculada do modelo (por circuito, da fonte ou do projeto) é uma
entrada do catálogo, com expressão nomeada, parâmetros (dependências) com rótulo
e unidade, dependentes, saída, referências normativas, versão, autor e histórico.
As regras implementadas em Python (instalação, agrupamento, seleção automática,
ajustes de disjuntores, topologia, dispositivos do trecho e coordenação) também
aparecem no catálogo, como regras do aplicativo, não editáveis pela interface.

A edição de uma expressão é feita pelo revisor, com simulação em todos os
circuitos, bloqueio de novos erros nos cálculos obrigatórios, justificativa
obrigatória e histórico com restauração.
"""
from __future__ import annotations

import copy
import datetime as dt
import json
import re
from functools import lru_cache
from pathlib import Path

from .formula import CalculationError, Error, Grid, parse
from .expressao import names as expr_names, walk, text, transform, unparse
from . import versoes
from .motor import APP_VERSION, compiled, model

ROOT = Path(__file__).resolve().parent.parent
NORMREF_DIR = ROOT / 'data' / 'normrefs'
BASELINE = 'modelo nativo v2.0'
REVIEWER_MIN_JUSTIFICATION = 15

# Variáveis cujo cálculo é uma regra Python do aplicativo (core/installation.py).
INSTALL_FUNCTIONS = {'INSTALLREF', 'INSTALLTABLE', 'INSTALLARRANGEMENT', 'INSTALLSOIL', 'INSTALLGROUP', 'GROUPTRACE',
                     'GROUPTEMPERATURE', 'NEUTRALHEATING', 'NEUTRALHEATINGINFO', 'NEUTRALCURRENT', 'NEUTRALMIN'}
# Compatibilidade com a migração (colunas reescritas pela camada de instalação na v1.x).
INSTALL_COLUMNS = {('Identificação-Método_Instal ', 'F'), ('Dados dos condutores ', 'M'),
                   ('Cálc_Seç-Ampacidade', 'N'), ('Corrente-Calc_Ampacidade ', 'N'), ('Corrente-Calc_Ampacidade ', 'O')}
INSTALL_COLUMNS.update({('Cálc_Seç-Ampacidade', c) for c in ('D', 'E', 'F', 'G', 'S')})
INSTALL_COLUMNS.update({('Corrente-Calc_Ampacidade ', c) for c in ('M', 'P', 'Q', 'R', 'S', 'V', 'W')})
INSTALL_COLUMNS.update({(s, c) for s in ('Corrente_Max-Cond_Escolhido', 'Corrente_Max-Cond_Sugerido') for c in ('K', 'O')})
INSTALL_COLUMNS.update({('Cálc_Seç_Red_N-T-Cond Sugerido', 'G'), ('Cálc_Seç_Red_N_PE-Cond escolhid', 'C')})
INSTALL_COLUMNS.add(('Temp_Operacional', 'I'))

PYTHON_RULES = [
    {'id':'regra.protecao_integrada','nome':'Proteções da entrada e corrente variável do gerador',
     'modulo':'core/protection.py, core/fault_time.py, core/protection_links.py','funcoes':['PROTECTIONVALUE','PROTECTIONARRIVAL'],
     'descricao':'Vínculo único do disjuntor ao quadro precedente; curva do elo MT, funções 50/51/50N/51N e interrupção separada. '
                 'Integra ∫dt/t(I)=1 e ∫I²dt; curvas por ponto sem extrapolação. Modelo por reatâncias com excitação constante identificado como estimativa. '
                 'Reset imediato abaixo da partida; verifica a permanência acima de pickup para tempo definido. '
                 'Energia conservadora: envelope Imax até o maior tempo de eliminação; critério adiabático somente de 0,1 a 5 s.',
     'refs':['NBR5410-5.3.5','IEC60947-2']},
    {'id': 'regra.instalacao', 'nome': 'Método de referência, tabela de ampacidade e arranjo', 'modulo': 'core/installation.py',
     'funcoes': ['INSTALLREF', 'INSTALLTABLE', 'INSTALLARRANGEMENT', 'THERMALINSULATION', 'AMPACITYERROR'],
     'descricao': 'Relaciona linha elétrica, montagem, tipo de cabo e isolação ao método de referência (A1…G) e à tabela de capacidade de condução. A validação térmica conserva suas restrições e independe da pendência de arranjo para impedância; falhas de consulta conservam a causa.',
     'refs': ['NBR5410-T33', 'NBR5410-T36', 'NBR5410-T37', 'NBR5410-T38', 'NBR5410-T39']},
    {'id': 'regra.agrupamento', 'nome': 'Fator de agrupamento e temperatura', 'modulo': 'core/grouping.py, core/installation.py',
     'funcoes': ['INSTALLGROUP', 'GROUPTRACE', 'GROUPTEMPERATURE', 'INSTALLSOIL'],
     'descricao': 'Contagem física por trecho, fator único de agrupamento, correção de temperatura e de resistividade do solo.',
     'refs': ['NBR5410-T40', 'NBR5410-T41', 'NBR5410-T42', 'NBR5410-T43', 'NBR5410-T44', 'NBR5410-T45']},
    {'id': 'regra.neutro', 'nome': 'Neutro carregado e seção mínima do neutro', 'modulo': 'core/installation.py',
     'funcoes': ['NEUTRALHEATING', 'NEUTRALHEATINGINFO', 'NEUTRALCURRENT', 'NEUTRALMIN'],
     'descricao': 'Carregamento do neutro (fator 0,86 de 6.2.5.6.1, dispensável acima de 45% de 3ª harmônica com fases iguais ao neutro — '
                  'Anexo F, F.2 e F.3), corrente de neutro (N/A em circuito sem neutro) e redução de seção pela Tabela 48 da Base técnica, '
                  'somente com as condições demonstradas.',
     'refs': ['NBR5410-6.2.5.6', 'NBR5410-6.2.6.2', 'NBR5410-T48', 'NBR5410-F.1']},
    {'id': 'regra.selecao', 'nome': 'Seleção automática de disjuntor, DPS e backup', 'modulo': 'core/selection.py', 'funcoes': [],
     'descricao': 'Escolhe no catálogo o primeiro modelo que atende polos, tensão, Ib ≤ Ir ≤ Iz, partida, Ik mínimo e Icu; DPS por classe, Uc, Up e Iimp/In.',
     'refs': ['NBR5410-5.3.4.1', 'NBR5410-5.3.5', 'NBR5410-6.3.5']},
    {'id': 'regra.ajustes', 'nome': 'Ajustes dos disjuntores conferidos no servidor', 'modulo': 'core/ajustes.py', 'funcoes': [],
     'descricao': 'Ir, Ii/Im, Isd e tsd devem existir no modelo escolhido; Ir ≤ In e Ir ≤ Isd ≤ Ii.', 'refs': ['IEC60947-2']},
    {'id': 'regra.topologia', 'nome': 'Topologia elétrica entre montante e jusante', 'modulo': 'core/topologia.py', 'funcoes': [],
     'descricao': 'Fases disponíveis, neutro, PE/PEN, TN-C a jusante de TN-S, seção mínima e seccionamento do PEN.',
     'refs': ['NBR5410-6.4.3.4', 'NBR5410-5.6.2.2', 'NBR5410-5.4.3.6']},
    {'id': 'regra.trecho', 'nome': 'Dispositivos do trecho', 'modulo': 'core/trecho.py', 'funcoes': ['TRECHO_SE'],
     'descricao': 'Dispensa do dispositivo na origem, disjuntor de manutenção e proteção do trecho por dispositivo a montante ou a jusante.',
     'refs': ['NBR5410-5.3.4.2.2', 'NBR5410-5.3.4.3', 'NBR5410-5.3.5.2', 'NBR5410-5.3.5.3']},
    {'id': 'regra.coordenacao', 'nome': 'Coordenação e seletividade por curvas', 'modulo': 'core/curvas.py', 'funcoes': [],
     'descricao': 'Compara as curvas tempo × corrente dos dispositivos em série (genéricas ou do fabricante) e as tabelas oficiais de seletividade.',
     'refs': ['IEC60947-2', 'IEC60898-1']},
    {'id': 'regra.motores', 'nome': 'Dados de motores e partida', 'modulo': 'core/motors.py', 'funcoes': [],
     'descricao': 'Substituição dos dados tabelados pelos de placa e inclusão da potência dos motores nas cargas.', 'refs': []},
]

RULE_VERSION = APP_VERSION
RULE_INPUTS = {
    'regra.protecao_integrada': ['fonte.tipo_atendimento','entrada.tipo','entrada.fusivel_tipo','entrada.fusivel_in','entrada.fusivel_curva',
        'entrada.interrupcao_ms','entrada.50_corrente','entrada.50_tempo','entrada.51_corrente','entrada.51_tempo','entrada.51_curva',
        'entrada.50N_corrente','entrada.50N_tempo','entrada.51N_corrente','entrada.51N_tempo','entrada.51N_curva','entrada.qta','entrada.medicao',
        'entrada.gerador_modo','fonte.reatancia_sub_transitoria_percentual_x','fonte.reatancia_sincrona_percentual_xs',
        'entrada.gerador_xd_linha','entrada.gerador_td_linha','entrada.gerador_td_duas','integrada.curva_corrente','integrada.vinculo',
        'integrada.instantaneo_s','integrada.mb_interrupcao_s','integrada.mb_instantaneo_s','integrada.mb_i2t','protecao.modelo',
        'protecao.isd_a','protecao.tsd_ms','protecao.ii_a','secoes.fase_mm2','secoes.neutro_mm2','secoes.pe_mm2'],
    'regra.selecao': ['protecao.ib_a', 'protecao.iz_a', 'icc.ik_max_ka', 'icc.ik_min_1f_ka', 'fonte.tensao_linha_v', 'protecao.familia'],
    'regra.ajustes': ['protecao.modelo', 'protecao.ir_a', 'protecao.ii_a', 'protecao.isd_a', 'protecao.tsd_ms'],
    'regra.topologia': ['ident.montante', 'ident.ligacao', 'ident.aterramento', 'secoes.fase_mm2', 'secoes.neutro_mm2', 'secoes.pe_mm2'],
    'regra.coordenacao': ['protecao.ir_a', 'protecao.ii_a', 'protecao.isd_a', 'protecao.tsd_ms', 'trecho.ik_origem', 'icc.ik_max_ka'],
    'regra.motores': ['cargas.pot_cv', 'cargas.soma_pot_cv', 'cargas.polos', 'cargas.fp_medio', 'cargas.rend_medio_pct', 'cargas.inclusao_dos_motores_na_carga'],
}


# v2.1 — saídas e efeitos das regras que não aparecem como função nas expressões (gravam dados, validam ou classificam).
RULE_OUTPUTS = {
    'regra.selecao': ['protecao.familia', 'protecao.modelo', 'protecao.tipo_protecao', 'protecao.in_a', 'protecao.ir_a', 'protecao.ii_a',
                      'protecao.isd_a', 'protecao.tsd_ms', 'protecao.i2t_on_off', 'protecao.comando_de_selecao',
                      'dps.comando_de_selecao', 'dps.modelo_manual_se_comando_manual', 'dps.modelo_automatico_calculado_pelo_eletroapp',
                      'dps.tipo_de_backup_adotado_vazio_fusivel_do', 'dps.modelo_do_disjuntor_de_backup_catalogo_weg',
                      'dps.icu_do_backup_adotado_ka', 'dps.fusivel_de_backup_catalogo_nh_gg_so_se', 'dps.modo_de_escolha_do_backup_eletroapp',
                      'trecho.mb_familia', 'trecho.mb_modelo', 'trecho.mb_ir', 'trecho.mb_ii', 'trecho.mb_isd', 'trecho.mb_tsd'],
    'regra.ajustes': [],
    'regra.topologia': [],
    'regra.coordenacao': [],
    'regra.motores': ['cargas.pot_total_motores_cv', 'cargas.pot_total_motores_w', 'cargas.in_total_motores_a',
                      'cargas.potencia_eletrica_dos_motores_w', 'cargas.potencia_reativa_dos_motores_var'],
}
RULE_EFFECTS = {
    'regra.protecao_integrada': ['Relaciona cada disjuntor de saída ao quadro precedente e reutiliza a identidade física quando há vínculo explícito.',
                               'Calcula atuação, interrupção completa, integral térmica e pendências para a fonte e os circuitos; não valida a temporização do gerador somente pelo curto inicial.'],
    'regra.selecao': ['Grava família, modelo, tipo, In e ajustes do disjuntor da origem, o DPS, o backup do DPS e o disjuntor de manutenção '
                      'nos circuitos em modo Automático; registra a mensagem de cada escolha (meta.selection_results).',
                      'Roda depois de cada alteração de dados, edição de expressão ou de tabela e exclusão de circuito.'],
    'regra.ajustes': ['Recusa a gravação de ajustes inexistentes no modelo escolhido.',
                      'Pendência “Ajustes do disjuntor da origem/manutenção” e situação da proteção “✗ AJUSTES FORA DO CATÁLOGO”.'],
    'regra.topologia': ['Pendência “Topologia elétrica” e situação “✗ TOPOLOGIA ELÉTRICA INCOMPATÍVEL” no circuito.'],
    'regra.coordenacao': ['Pares montante × jusante (inclusive origem × manutenção) com nível de evidência, situação e limite (página Coordenação).',
                          'Pendência “Dados do dispositivo” quando o In ou o tipo informados divergem do modelo escolhido.'],
    'regra.motores': ['Substitui os dados tabelados do motor pelos de placa e soma a potência dos motores às cargas conforme a opção do circuito.'],
    'regra.instalacao': ['Resolve o método de referência e a tabela usados no cálculo de ampacidade, preservando as restrições térmicas e a causa de falhas.',
                        'Valida separadamente o arranjo usado no cálculo de impedância e exigido para concluir a instalação.'],
    'regra.agrupamento': ['Fator de agrupamento, correção de temperatura e de resistividade do solo aplicados a Iz.'],
    'regra.neutro': ['Corrente e seção mínima do neutro, com o fator de carregamento por harmônicas.'],
    'regra.trecho': ['Envolve os cálculos afetados pela dispensa do dispositivo na origem (TRECHO_SE) e calcula o dispositivo efetivo do trecho.'],
}


def rule_view(rule, model_):
    """Regra em Python com o mesmo tipo de rastreabilidade das expressões: entradas, resultados, versão e autoria."""
    funcs = set(rule['funcoes'])
    results, params = [], []
    for v in model_.by_id.values():
        if v.kind != 'formula' or not funcs:
            continue
        tree = compiled(v.expr)
        if any(n[0] == 'call' and n[1] in funcs for n in walk(tree)):
            results.append(v.id)
            params += [n[1] for n in walk(tree) if n[0] == 'name' and n[1] in model_.by_id and n[1] not in params]
    params += [x for x in RULE_INPUTS.get(rule['id'], []) if x in model_.by_id and x not in params]
    results += [x for x in RULE_OUTPUTS.get(rule['id'], []) if x in model_.by_id and x not in results]
    params = [x for x in params if x not in results]
    lab = lambda i: {'id': i, 'rotulo': model_.by_id[i].label, 'unidade': model_.by_id[i].unit}
    return {**rule, 'parametros': [lab(i) for i in params[:40]], 'resultados': [lab(i) for i in results[:40]],
            'n_resultados': len(results), 'efeitos': RULE_EFFECTS.get(rule['id'], []), 'versao': RULE_VERSION, 'autor': 'EletroApp (código-fonte do aplicativo)',
            'edicao': 'Lógica controlada pelo código-fonte e coberta por testes; não editável no aplicativo. '
                      'As referências normativas atribuídas são editáveis pelo revisor.',
            'historico': [{'versao': '2.0.0', 'data': '2026-10-06', 'nota': 'Regra registrada no catálogo do modelo nativo.'},
                          {'versao': '2.1.1', 'data': '2026-10-08',
                           'nota': 'Revisão do conjunto de regras: coordenação por dados efetivos, escopos e bases operacionais arquivadas.'},
                          {'versao': '2.1.2', 'data': '2026-10-09',
                           'nota': 'Revisão do conjunto de regras: validação térmica independente do arranjo de impedância e diagnóstico de ampacidade.'},
                          {'versao': '2.2.0', 'data': '2026-10-12',
                           'nota': 'Revisão do conjunto de regras após a auditoria das tabelas contra a NBR 5410 e a NBR 5419:2026: neutro sem o '
                                   'fator 0,86 nas condições do Anexo F (F.2/F.3), circuitos sem neutro, Tabela 48 lida da Base técnica, '
                                   'método 28 tratado como 21, seleção de DPS sem o contorno da biblioteca Siemens (Uc, Up, Iimp e In lidos das '
                                   'mesmas colunas que as fórmulas) e topologia do PEN citando 6.4.3.4.1, 6.4.3.4.3 e 5.6.2.2.'},
                          {'versao': '2.3.0', 'data': '2026-10-13',
                           'nota': 'Proteções da entrada, vínculo físico com o quadro precedente, tempo de interrupção e evolução I(t) do gerador; integral térmica e estados não verificados para dados ausentes.'},
                          {'versao': RULE_VERSION, 'data': '2026-10-14',
                           'nota': 'Condutores em paralelo do neutro/PEN e do PE com quantidade própria (vazio = igual às fases): corrente por condutor '
                                   'e Tabela 48 do neutro, integral térmica da verificação integrada por condutor de neutro e de PE.'}]}


# Referências padrão por grupo/variável: localizadores (item/tabela), sem texto da norma. Conferir na edição vigente.
DEFAULT_LINKS = [
    (r'^amp_secao\.|^amp_corrente\.|^iz\.|^sug_iz\.', ['NBR5410-T36', 'NBR5410-T37', 'NBR5410-T38', 'NBR5410-T39', 'NBR5410-T40', 'NBR5410-T42']),
    (r'^amp_corrente\.(ib_neutro|fc_3oh|motivo)', ['NBR5410-F.1', 'NBR5410-6.2.5.6']),
    (r'^corrente\.(fator_ib|i_[rst]_a)', ['NBR5410-6.2.6.1', 'NBR5410-F.1']),
    (r'^condutores\.no_de_condutores|^amp_secao\.no_de_condutores', ['NBR5410-T46', 'NBR5410-6.2.5.6']),
    (r'^condutores\.(por_polo|nc_)', ['NBR5410-6.2.5.7']),  # v2.3.2: Nc das fases, do neutro/PEN e do PE
    (r'^secao_min\.', ['NBR5410-T47']),
    (r'^secao_queda\.|^queda\.', ['NBR5410-6.2.7']),
    (r'^secao_icc\.', ['NBR5410-5.3.5.5', 'NBR5410-T30', 'NBR5410-T35', 'NBR5410-T53', 'NBR5410-T55', 'NBR5410-T57', 'NBR5410-T58']),
    (r'^reducao\.|^sug_reducao\.', ['NBR5410-6.2.6.2', 'NBR5410-T48', 'NBR5410-T58']),
    (r'^sug_pe\.', ['NBR5410-6.4.3.1', 'NBR5410-T58', 'NBR5410-T53', 'NBR5410-T55', 'NBR5410-T57']),
    (r'^imp\.|^sug_imp\.|^icc\.|^sug_icc\.', ['IEC60909-0']),
    (r'^protecao\.', ['NBR5410-5.3.4.1', 'NBR5410-5.3.5']),
    (r'^choque\.', ['NBR5410-5.1.2.2.4', 'NBR5410-T25', 'NBR5410-TC1']),
    (r'^dps\.', ['NBR5410-6.3.5', 'NBR5410-T31', 'NBR5410-T49', 'NBR5419-1-E', 'NBR5419-4-T1', 'NBR5419-4-C.2.1']),
    (r'^partida\.', ['NBR5410-6.2.7', 'NBR5410-6.5.1']),
    (r'^metodo\.|^instalacao\.', ['NBR5410-T33']),
    (r'^fonte\.(cmax|cmin|r1_|x1_|r0_|x0_)', ['IEC60909-0']),
]


class CatalogError(ValueError):
    pass


@lru_cache(maxsize=1)
def normref_registry():
    registry = {}
    if NORMREF_DIR.is_dir():
        for path in sorted(NORMREF_DIR.glob('*.json')):
            for item in json.loads(path.read_text(encoding='utf-8')):
                registry[item['id']] = item
    return registry


@lru_cache(maxsize=1)
def dependency_index():
    """Dependentes de cada variável no modelo base (quem usa quem)."""
    m = model()
    out = {}
    for v in m.by_id.values():
        if v.kind != 'formula':
            continue
        for n in expr_names(compiled(v.expr)):
            out.setdefault(n, set()).add(v.id)
    return out


def _now():
    return dt.datetime.now().astimezone().isoformat(timespec='seconds')


def _fmt_value(v):
    if isinstance(v, Error):
        return str(v)
    if v is None or v == '':
        return '""'
    if isinstance(v, bool):
        return 'VERDADEIRO' if v else 'FALSO'
    if isinstance(v, float):
        return ('%.10g' % v).replace('.', ',') if v != int(v) or abs(v) > 1e15 else str(int(v))
    if isinstance(v, int):
        return str(v)
    return '"' + str(v).replace('"', '""') + '"'


def _plain(v):
    if isinstance(v, Error):
        return {'error': str(v), 'detail': v.detail}
    if isinstance(v, float) and v != v:
        return None
    if isinstance(v, Grid):
        return None
    return v


def _same(a, b):
    if isinstance(a, Error) or isinstance(b, Error):
        return str(a) == str(b)
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool):
        return abs(a - b) <= max(1e-9, abs(a) * 1e-9)
    return (a if a is not None else '') == (b if b is not None else '')


def _scope_label(v):
    return {'circuito': 'por circuito', 'fonte': 'fonte de energia', 'projeto': 'projeto inteiro'}[v.scope]


class Catalog:
    def __init__(self, project, integrity=True):
        self.p = project
        self.m = project.model
        self._use_integrity = integrity
        self.versions = project.doc.setdefault('formulas', {})
        self.links = project.meta.setdefault('formula_normrefs', {})
        self.norm_overrides = project.meta.setdefault('normref_overrides', {})
        self.groups = {g['id']: g['nome'] for g in self.m.groups}

    # ---- entradas --------------------------------------------------------------
    def entries(self):
        return [v for v in self.m.by_id.values() if v.kind == 'formula']

    def get(self, entry_id):
        v = self.m.by_id.get(entry_id)
        if v is None or v.kind != 'formula':
            raise CatalogError('Cálculo não encontrado no catálogo.')
        return v

    def managed(self, v):
        """Regra do aplicativo (Python): a expressão só chama a função; não é editável aqui."""
        if v.scope == 'circuito' and (v.sheet, v.col) in INSTALL_COLUMNS:
            return True
        return any(n[0] == 'call' and n[1] in INSTALL_FUNCTIONS for n in walk(compiled(v.expr)))

    def version_number(self, entry_id, escopo='comum'):
        kind, cid = versoes.parse_scope(escopo)
        slot = versoes.get_slot(self.versions, entry_id, kind, cid)
        return slot.get('ativa', 0) if slot else 0

    def _check_scope(self, v, escopo):
        kind, cid = versoes.parse_scope(escopo)
        if kind == 'raiz' and not v.variants.get('raiz'):
            raise CatalogError('Este cálculo não tem variante para circuitos ligados diretamente à fonte.')
        if kind == 'circuito':
            if v.scope != 'circuito':
                raise CatalogError('Versão por circuito só existe para cálculos de circuito.')
            if not any(c['id'] == cid for c in self.p.circuits_doc):
                raise CatalogError('Circuito não encontrado.')
        return kind, cid

    def scope_views(self, v):
        """Escopos com versão registrada (raiz e circuitos específicos), para o detalhe do catálogo."""
        from .integridade import scope_statuses
        names = {c['id']: c['entradas'].get('ident.nome') for c in self.p.circuits_doc}
        out = []
        for kind, cid, st in scope_statuses(self.p, v.id):
            if kind == 'comum':
                continue
            esc = versoes.scope_name(kind, cid)
            out.append({'escopo': esc, 'rotulo': 'Circuitos ligados à fonte' if kind == 'raiz' else f'Circuito {names.get(cid, cid)}',
                        'expressao': self.p.active_expression(v, esc), 'versao_ativa': self.version_number(v.id, esc), 'situacao': st,
                        'historico': self.history(v.id, esc)})
        return out

    def group_name(self, v):
        if v.scope == 'fonte':
            return 'Fonte de energia'
        if v.scope == 'projeto':
            return 'Verificações do projeto'
        return self.groups.get(v.group, v.group)

    def default_refs(self, entry_id):
        out = []
        for pattern, refs in DEFAULT_LINKS:
            if re.search(pattern, entry_id):
                out += [r for r in refs if r not in out]
        return [r for r in out if r in normref_registry()]

    def ref_ids(self, entry_id):
        if entry_id in self.links:
            return list(self.links[entry_id])
        return self.default_refs(entry_id)

    def entry_view(self, v, detail=False):
        n = self.version_number(v.id)
        slot = self.versions.get(v.id) or {}
        from .integridade import formula_status
        integ = formula_status(self.p, v.id) if self._use_integrity else ('editada' if n else 'modelo')
        external = integ in ('alterada', 'invalida')
        out = {'id': v.id, 'grupo': v.group or v.scope, 'grupo_nome': self.group_name(v), 'escopo': v.scope, 'escopo_rotulo': _scope_label(v),
               'descricao': v.label, 'unidade': v.unit, 'expressao': self.p.active_expression(v), 'expressao_baseline': v.expr,
               'variantes': v.variants, 'versao_ativa': n, 'baseline': BASELINE,
               'expressao_raiz': self.p.active_expression(v, 'raiz') if v.variants.get('raiz') else None,
               'versao_ativa_raiz': self.version_number(v.id, 'raiz') if v.variants.get('raiz') else None,
               'status': 'alterada' if external else 'editada' if versoes.any_active(slot) else ('regra_python' if self.managed(v) else 'modelo'),
               'integridade': integ,
               'gerida_por_instalacao': self.managed(v), 'saida': {'rotulo': v.label, 'unidade': v.unit},
               'refs_normativas': self.refs_for(v.id), 'sem_justificativa': not self.ref_ids(v.id),
               'refs_padrao': v.id not in self.links and bool(self.default_refs(v.id))}
        if detail:
            out['parametros'] = self.parameters(v)
            out['dependentes'] = [{'id': d, 'rotulo': self.m.by_id[d].label} for d in sorted(dependency_index().get(v.id, ()))][:60]
            out['historico'] = self.history(v.id)
            out['escopos'] = self.scope_views(v)
            out['n_circuitos'] = len(self.p.active_rows()) if v.scope == 'circuito' else 1
        return out

    def parameters(self, v):
        tree = compiled(self.p.active_expression(v))
        out, seen = [], set()
        for n in walk(tree):
            if n[0] == 'name' and n[1] not in seen:
                seen.add(n[1])
                dep = self.m.by_id.get(n[1])
                if dep is not None:
                    origem = {'entrada': 'dado informado', 'formula': 'cálculo'}[dep.kind]
                    out.append({'ref': dep.id, 'rotulo': dep.label, 'unidade': dep.unit, 'escopo': _scope_label(dep), 'origem': origem,
                                'grupo': self.group_name(dep)})
                else:
                    out.append({'ref': n[1], 'rotulo': 'Intervalo de tabela técnica', 'unidade': '', 'escopo': 'tabela',
                                'origem': 'tabela técnica', 'destino': self.m.names.get(n[1])})
            elif n[0] == 'ref' and ('ref', n[1], n[2]) not in seen:
                seen.add(('ref', n[1], n[2]))
                t = self.m.table(n[1] or '')
                out.append({'ref': f'{n[1]}!{n[2]}' + (f':{n[3]}' if n[3] != n[2] else ''), 'rotulo': t.name if t else str(n[1]),
                            'unidade': '', 'escopo': 'tabela', 'origem': 'tabela técnica', 'tabela': t.id if t else None})
        return out

    def refs_for(self, entry_id):
        return [r for r in (self.ref_view(i) for i in self.ref_ids(entry_id)) if r]

    def ref_view(self, rid):
        base = normref_registry().get(rid)
        over = self.norm_overrides.get(rid)
        if base is None and over is None:
            return None
        ref = {**(base or {}), **(over or {}), 'id': rid}
        ref.setdefault('verbatim', False)
        ref.setdefault('trecho', None)
        ref.setdefault('verificado_por', None)
        ref.setdefault('verificado_em', None)
        ref['verificada'] = bool(ref['verificado_por'])
        if ref['trecho'] and not ref['verbatim']:
            ref['aviso'] = 'Paráfrase — não é transcrição literal. Confira o item/tabela na norma.'
        elif not ref['trecho']:
            ref['aviso'] = 'Localizador (item/tabela), sem texto da norma. Confira na edição vigente.'
        if not ref['verificada']:
            ref['aviso_verificacao'] = 'Referência ainda não verificada por um revisor.'
        return ref

    def all_refs(self):
        ids = set(normref_registry()) | set(self.norm_overrides)
        return [self.ref_view(i) for i in sorted(ids)]

    def list(self, q='', aba='', norma='', status='', limit=60, offset=0):
        qn = q.casefold().strip()
        out = []
        for v in self.entries():
            if aba and (v.group or v.scope) != aba:
                continue
            e = self.entry_view(v)
            if status and e['status'] != status and not (status == 'sem_justificativa' and e['sem_justificativa']):
                continue
            if norma and not any(norma in (r['id'], r.get('norma'), r.get('item'), r.get('tabela')) or norma.casefold() in (r.get('norma') or '').casefold()
                                 for r in e['refs_normativas']):
                continue
            if qn and qn not in ' '.join([e['id'], e['descricao'], e['grupo_nome'], e['expressao']]).casefold():
                continue
            out.append(e)
        groups = [{'id': g['id'], 'nome': g['nome']} for g in self.m.groups] + [{'id': 'fonte', 'nome': 'Fonte de energia'},
                                                                                 {'id': 'projeto', 'nome': 'Verificações do projeto'}]
        entries = self.entries()
        rules = [{**rule_view(r, self.m), 'refs_normativas': [x for x in (self.ref_view(i) for i in self.links.get(r['id'], r['refs'])) if x]}
                 for r in PYTHON_RULES]
        return {'total': len(out), 'entradas': out[offset:offset + limit], 'grupos': groups, 'abas': [g['id'] for g in groups],
                'baseline': BASELINE, 'total_formulas': len(entries), 'total_entradas': len(entries),
                'editadas': sum(1 for s in self.versions.values() if versoes.any_active(s)),
                'sem_justificativa': sum(1 for v in entries if not self.ref_ids(v.id)),
                'regras_python': rules,
                'normas': sorted({r.get('norma') for r in self.all_refs() if r and r.get('norma')})}

    def history(self, entry_id, escopo='comum'):
        v = self.get(entry_id)
        kind, cid = versoes.parse_scope(escopo)
        slot = versoes.get_slot(self.versions, entry_id, kind, cid) or {}
        base_expr = v.variants['raiz'] if kind == 'raiz' and v.variants.get('raiz') else v.expr
        base_txt = ('Variante do modelo para circuitos ligados à fonte (imutável).' if kind == 'raiz' else
                    'Sem versão própria: vale a expressão comum (ou a variante da fonte).' if kind == 'circuito' else
                    'Expressão do modelo nativo do aplicativo (imutável).')
        hist = [{'versao': 0, 'tipo': 'modelo', 'autor': None, 'ts': None, 'justificativa': base_txt,
                 'expressao': base_expr, 'ativa': slot.get('ativa', 0) == 0}]
        for item in slot.get('versoes', []):
            hist.append({**{k: item.get(k) for k in ('versao', 'tipo', 'autor', 'ts', 'justificativa')}, 'expressao': item['expressao'],
                         'impacto': item.get('impacto'), 'ativa': slot.get('ativa') == item['versao']})
        return hist

    def rule_application(self, rule_id, uid):
        """Aplicação de uma regra em Python a um circuito: dados usados, resultados e efeitos registrados."""
        rule = next((r for r in PYTHON_RULES if r['id'] == rule_id), None)
        if rule is None:
            raise CatalogError('Regra não encontrada.')
        p = self.p
        r = p.row_for(uid)
        view = rule_view(rule, self.m)

        def val(i):
            v = self.m.by_id[i]
            return _plain(p.engine.get(v.sheet, f'{v.col}{r}') if v.scope == 'circuito' else p.engine.get(v.sheet, v.addr))
        out = {'regra': rule_id, 'nome': rule['nome'], 'circuito': p.raw('Identificação dos circuitos', f'B{r}'),
               'dados': [{**x, 'valor': val(x['id'])} for x in view['parametros']],
               'resultados': [{**x, 'valor': val(x['id'])} for x in view['resultados']], 'efeitos': []}
        if rule_id == 'regra.selecao':
            msg = p.meta.get('selection_results', {}).get(uid) or {}
            from . import selection
            out['efeitos'] = [f'Modo: {k} = {m}' for k, m in selection.modes(p, r).items()] + [f'{k}: {m}' for k, m in msg.items()]
        elif rule_id == 'regra.ajustes':
            out['efeitos'] = (p.ajustes_origem(r) + p.ajustes_manutencao_problemas(r)) or ['Ajustes conferidos com o catálogo: sem problemas.']
        elif rule_id == 'regra.topologia':
            out['efeitos'] = p.topologia_problemas(r) or ['Topologia compatível com o montante.']
        elif rule_id == 'regra.coordenacao':
            from . import curvas
            name = out['circuito']
            out['efeitos'] = [f"{x.get('trecho') or 'Par'}: {curvas.LEVELS[x['nivel']]} — {curvas.STATUS[x['situacao']]}"
                              + (f" (≈ {x['limite_ka']:g} kA)" if x.get('limite_ka') is not None else '')
                              for x in curvas.coordination(p)['pares'] if x['circuito'] == name and x.get('aplicavel')] or ['Sem par a avaliar.']
            out['efeitos'] += curvas.device_conflicts(p, r)
        elif rule_id == 'regra.motores':
            from . import motors
            out['efeitos'] = motors.issues(p, r) or ['Sem pendência nos dados de motores.']
        return out

    # ---- trilha de cálculo --------------------------------------------------
    def _resolve(self, uid, campo, aba):
        """Aceita o identificador da variável (preferencial) ou a referência interna (grupo!posição)."""
        campo = (campo or '').strip()
        if campo in self.m.by_id:
            v = self.m.by_id[campo]
            if v.scope == 'circuito':
                if not uid:
                    raise CatalogError('Informe o circuito.')
                return v, v.sheet, f'{v.col}{self.p.row_for(uid)}'
            return v, v.sheet, v.addr
        if '!' in campo:
            aba, campo = campo.rsplit('!', 1)
            aba = aba.strip("'")
        campo = campo.replace('$', '').upper()
        if re.fullmatch(r'[A-Z]{1,3}', campo):
            if not uid:
                raise CatalogError('Informe o circuito.')
            campo += str(self.p.row_for(uid))
        if not re.fullmatch(r'[A-Z]{1,3}\d{1,5}', campo or ''):
            raise CatalogError('Campo inválido.')
        return self.p.var_at(aba, campo), aba, campo

    def trace(self, uid, campo, aba=''):
        v, sheet, addr = self._resolve(uid, campo, aba)
        p = self.p
        value = p.engine.get(sheet, addr)
        if v is None:
            t = self.m.table(sheet)
            return {'id': None, 'rotulo': (t.name if t else sheet) + ' · ' + addr, 'origem': 'tabela técnica' if t else 'dado',
                    'eh_formula': p.is_formula(sheet, addr), 'valor_atual': _plain(value), 'expressao': p.raw(sheet, addr),
                    'precedentes': [], 'tabela': t.id if t else None, 'circuito': None}
        circuit = p.describe(sheet, addr).get('circuito')
        circuit_id = p.meta['ids'].get(re.search(r'\d+', addr)[0]) if v.scope == 'circuito' else None
        out = {'id': v.id, 'rotulo': v.label, 'unidade': v.unit, 'grupo': self.group_name(v), 'escopo': _scope_label(v),
               'circuito': circuit, 'eh_formula': v.kind == 'formula', 'valor_atual': _plain(value),
               'origem': 'dado informado' if v.kind == 'entrada' else 'cálculo', 'catalogo_id': v.id if v.kind == 'formula' else None,
               'campo': v.id, 'circuito_id': circuit_id}
        if v.kind != 'formula':
            out.update(expressao=None, precedentes=[], substituicao=None, recalculado=_plain(value), editada=None)
            return out
        row = int(re.search(r'\d+', addr)[0]) if v.scope == 'circuito' else None
        expr = p.expression(v, row)
        out['expressao'] = expr
        out['variante'] = 'raiz' if v.variants.get('raiz') == expr and v.expr != expr else None
        tree = compiled(expr)
        vector_names = {a[1] for x in walk(tree) if x[0] == 'call' and x[1] == 'CIRCUITOS' for a in x[2] if a[0] == 'name'}
        precedents, seen = [], set()
        for n in walk(tree):
            if n[0] == 'name' and n[1] not in seen:
                seen.add(n[1])
                dep = self.m.by_id.get(n[1])
                if dep is None:
                    precedents.append({'ref': n[1], 'tipo': 'nome', 'rotulo': 'Intervalo de tabela técnica', 'valor': None,
                                       'origem': 'tabela técnica', 'destino': self.m.names.get(n[1])})
                    continue
                vector = n[1] in vector_names
                if dep.scope == 'circuito':
                    if v.scope != 'circuito':
                        vector = True
                    a = f'{dep.col}{row}' if row else None
                else:
                    a = dep.addr
                val = None if vector or a is None else p.engine.get(dep.sheet, a)
                precedents.append({'ref': dep.id, 'tipo': 'vetor' if vector else 'variavel', 'rotulo': dep.label, 'unidade': dep.unit,
                                   'valor': _plain(val), 'origem': 'dado informado' if dep.kind == 'entrada' else 'cálculo',
                                   'catalogo_id': dep.id if dep.kind == 'formula' else None, 'escopo': _scope_label(dep)})
            elif n[0] == 'ref':
                key = ('ref', n[1], n[2], n[3])
                if key in seen:
                    continue
                seen.add(key)
                t = self.m.table(n[1] or '')
                precedents.append({'ref': f'{n[1]}!{n[2]}' + (f':{n[3]}' if n[3] != n[2] else ''), 'tipo': 'tabela',
                                   'rotulo': t.name if t else n[1], 'valor': None, 'origem': 'tabela técnica', 'tabela': t.id if t else None})
        out['precedentes'] = precedents
        out['funcoes_python'] = sorted({n[1] for n in walk(tree) if n[0] == 'call' and n[1] in p.engine.functions})
        out['substituicao'] = self._substitute(tree, sheet, addr, vector_names)
        base = self.baseline_project()
        edited = base is not p
        out['recalculado'] = _plain(base.engine.get(sheet, addr)) if edited else _plain(value)
        scope = p.expression_scope(v, row) if v.scope == 'circuito' else 'comum'
        out['editada'] = _plain(value) if edited and self.version_number(v.id, scope) > 0 else None
        out['baseline_diverge'] = edited and not _same(base.engine.get(sheet, addr), value)
        from .integridade import cell_status
        out['integridade'] = cell_status(p, sheet, addr)
        return out

    def _substitute(self, tree, sheet, addr, vector_names=()):
        """Expressão com os valores atuais no lugar das variáveis do circuito e da fonte."""
        p = self.p
        row = re.search(r'\d+', addr)[0] if addr and sheet in self.m.circuit_sheet_set else None

        def fn(n):
            if n[0] == 'call' and n[1] in ('CIRCUITOS', 'FAIXA', 'ANTERIOR'):
                return ('name', n[1] + '(' + ','.join(a[1] for a in n[2] if a[0] == 'name') + ')')
            if n[0] == 'name' and n[1] not in vector_names:
                dep = self.m.by_id.get(n[1])
                if dep is None:
                    return n
                if dep.scope == 'circuito' and row:
                    return ('name', _fmt_value(p.engine.get(dep.sheet, f'{dep.col}{row}')))
                if dep.scope != 'circuito':
                    return ('name', _fmt_value(p.engine.get(dep.sheet, dep.addr)))
            return n
        return '=' + unparse(transform(tree, fn))

    # ---- simulação e edição --------------------------------------------------
    def baseline_project(self):
        if not any(versoes.any_active(s) for s in self.versions.values()):
            return self.p
        cache = getattr(self.p, '_baseline_cache', None)
        stamp = json.dumps([self.versions, self.p.doc.get('circuitos'), self.p.doc.get('fonte'), self.p.doc.get('tabelas')],
                           sort_keys=True, default=str)
        if cache and cache[0] == stamp:
            return cache[1]
        from .project import Project
        doc = copy.deepcopy(self.p.doc)
        doc['formulas'] = {}
        proj = Project(doc)
        self.p._baseline_cache = (stamp, proj)
        return proj

    def _validate_expression(self, text_):
        text_ = (text_ or '').strip()
        if not text_.startswith('='):
            raise CatalogError('A expressão deve começar com "=".')
        try:
            tree = parse(text_)
        except CalculationError as e:
            raise CatalogError('Expressão inválida: ' + str(e.value.detail or e.value.code))
        except Exception as e:  # noqa: BLE001
            raise CatalogError('Expressão inválida: ' + str(e))
        known_names = {k.casefold() for k in self.m.names}
        unknown = [n for n in expr_names(tree) if n not in self.m.by_id and n.casefold() not in known_names]
        if unknown:
            raise CatalogError('Variável ou nome desconhecido: ' + ', '.join(sorted(unknown)[:8]))
        for n in walk(tree):
            if n[0] in ('ref', 'columns') and (n[1] is None or self.m.table(n[1]) is None):
                raise CatalogError('Referências a células não são aceitas; use o nome da variável. '
                                   'Intervalos só de tabelas técnicas (ex.: tab_weg_protecoes!J2:J568).')
        return text(tree)

    def _check_editable(self, v):
        if self.managed(v):
            raise CatalogError('Este cálculo é uma regra do aplicativo em Python (camada de instalação); não é editável como expressão.')

    def snapshot(self, project=None):
        """Valores de todos os cálculos dos circuitos ativos, da fonte e do projeto."""
        p = project or self.p
        snap = {}
        rows = p.active_rows()
        for v in p.model.circuit:
            if v.kind != 'formula':
                continue
            for r in rows:
                snap[(v.sheet, f'{v.col}{r}')] = p.engine.get(v.sheet, f'{v.col}{r}')
        for v in p.model.fonte + p.model.project:
            if v.kind == 'formula':
                snap[(v.sheet, v.addr)] = p.engine.get(v.sheet, v.addr)
        return snap

    def diff(self, before, after, limit=300):
        rows = {}
        circuits = set()
        errors = 0
        for key, old in before.items():
            new = after.get(key)
            if _same(old, new):
                continue
            sheet, a = key
            v = self.p.var_at(sheet, a)
            vid = v.id if v else f'{sheet}!{a}'
            item = rows.setdefault(vid, {'id': vid, 'rotulo': v.label if v else vid, 'unidade': v.unit if v else '', 'celulas': 0,
                                         'circuitos': set(), 'exemplos': [], 'delta_rel_max': None})
            item['celulas'] += 1
            ident = self.p.describe(sheet, a).get('circuito') or '(projeto)'
            item['circuitos'].add(ident)
            circuits.add(ident)
            if isinstance(new, Error) and not isinstance(old, Error):
                errors += 1
            if isinstance(old, (int, float)) and isinstance(new, (int, float)) and not isinstance(old, bool):
                rel = abs(new - old) / abs(old) if old else (None if new == 0 else float('inf'))
                if rel is not None and rel != float('inf') and (item['delta_rel_max'] is None or rel > item['delta_rel_max']):
                    item['delta_rel_max'] = rel
            if len(item['exemplos']) < 3:
                item['exemplos'].append({'circuito': ident, 'antes': _plain(old), 'depois': _plain(new)})
        fields = [{**item, 'circuitos': sorted(item['circuitos']), 'n_circuitos': len(item['circuitos'])}
                  for item in sorted(rows.values(), key=lambda x: (-x['celulas'], x['id']))]
        return {'campos_afetados': len(fields), 'celulas_afetadas': sum(f['celulas'] for f in fields),
                'circuitos_afetados': len(circuits), 'circuitos': sorted(circuits), 'novos_erros': errors,
                'campos': fields[:limit], 'truncado': len(fields) > limit}

    def mandatory_keys(self, project=None):
        from .project import ALL_RESULTS
        p = project or self.p
        keys = set()
        for r in p.active_rows():
            for sheet, col in ALL_RESULTS.values():
                keys.add((sheet, f'{col}{r}'))
            for col in 'CDEFGHIJKLMNO':
                keys.add(('Auditoria_Checklist', f'{col}{r}'))
        return keys

    def new_errors(self, before, after, keys=None):
        return [key for key, new in after.items() if (keys is None or key in keys) and isinstance(new, Error)
                and not isinstance(before.get(key), Error)]

    def _gate(self, before, after, project=None):
        keys = self.mandatory_keys(project)
        mand = self.new_errors(before, after, keys)
        total = self.new_errors(before, after)
        examples = []
        for s, a in sorted(mand)[:12]:
            d = (project or self.p).describe(s, a)
            examples.append({'variavel': d.get('var'), 'rotulo': d.get('rotulo'), 'circuito': d.get('circuito'), 'erro': str(after[(s, a)])})
        return {'bloqueada': bool(mand), 'erros_obrigatorios': len(mand), 'erros_totais': len(total), 'exemplos_erros': examples,
                'motivo': (f'A expressão cria {len(mand)} erro(s) novo(s) em cálculos obrigatórios (resultados dos circuitos e '
                           f'verificações). A ativação foi bloqueada; a simulação continua disponível para análise.') if mand else None}

    def _activate(self, project, v, expression, info, escopo='comum'):
        kind, cid = versoes.parse_scope(escopo)
        slot = versoes.get_slot(project.doc['formulas'], v.id, kind, cid, create=True)
        n = len(slot['versoes']) + 1
        from .integridade import stamp
        slot['versoes'].append(stamp('formula', versoes.seal_key(v.id, kind, cid),
                                     {'versao': n, 'expressao': expression, 'ts': _now(), 'escopo': versoes.scope_name(kind, cid), **info}))
        slot['ativa'] = n
        project.engine.clear()
        return n

    def preview_edit(self, entry_id, expressao, escopo='comum'):
        from .project import Project
        v = self.get(entry_id)
        self._check_editable(v)
        self._check_scope(v, escopo)
        new = self._validate_expression(expressao)
        if parse(new) == parse(self.p.active_expression(v, escopo)):
            raise CatalogError('A expressão é igual à versão ativa.')
        before = self.snapshot()
        cand = Project(copy.deepcopy(self.p.doc))
        Catalog(cand)._activate(cand, v, new, {'tipo': 'simulacao'}, escopo)
        after = self.snapshot(cand)
        d = self.diff(before, after)
        gate = self._gate(before, after, cand)
        kind, cid = versoes.parse_scope(escopo)
        slot = versoes.get_slot(self.versions, entry_id, kind, cid) or {}
        out = {'id': entry_id, 'escopo': escopo, 'celulas_alteradas': self._scope_count(v, escopo), 'diff': d, **gate,
               'versao_proposta': len(slot.get('versoes', [])) + 1, 'expressao_proposta': new,
               'reabre_confirmacoes': len(self.p.active_rows())}
        if v.variants.get('raiz') and kind == 'comum':
            out['aviso_variante'] = ('Esta edição vale para os circuitos comuns. Os circuitos ligados diretamente à fonte continuam com a '
                                     'variante própria; para alterá-la, edite o escopo “circuitos ligados à fonte”.')
        base = self.baseline_project()
        out['diff_baseline'] = self.diff(self.snapshot(base), after) if base is not self.p else d
        return out

    def _scope_count(self, v, escopo):
        if v.scope != 'circuito':
            return 1
        return sum(1 for r in self.p.active_rows() if self.p.expression_scope(v, r) == escopo) or 0

    def commit_edit(self, project, entry_id, expressao, autor, justificativa, tipo='edicao', escopo='comum'):
        cat = Catalog(project)
        v = cat.get(entry_id)
        cat._check_editable(v)
        cat._check_scope(v, escopo)
        justificativa = (justificativa or '').strip()
        if len(justificativa) < REVIEWER_MIN_JUSTIFICATION:
            raise CatalogError(f'Justificativa obrigatória (mínimo {REVIEWER_MIN_JUSTIFICATION} caracteres).')
        new = cat._validate_expression(expressao)
        from .integridade import formula_status
        if parse(new) == parse(project.active_expression(v, escopo)):
            if formula_status(project, v.id, escopo) not in ('alterada', 'invalida'):
                raise CatalogError('A expressão é igual à versão ativa.')
            tipo = 'regularizacao'  # o revisor assume, com justificativa, uma expressão alterada fora do aplicativo
        before = cat.snapshot()
        n = cat._activate(project, v, new, {'tipo': tipo, 'autor': autor, 'justificativa': justificativa}, escopo)
        after = cat.snapshot(project)
        gate = cat._gate(before, after, project)
        if gate['bloqueada']:
            raise CatalogError(gate['motivo'] + ' Exemplos: ' + '; '.join(f"{x['circuito'] or 'projeto'} · {x['rotulo']} = {x['erro']}"
                                                                         for x in gate['exemplos_erros'][:4]))
        impacto = cat.diff(before, after, limit=0)
        kind, cid = versoes.parse_scope(escopo)
        slot = versoes.get_slot(project.doc['formulas'], v.id, kind, cid)
        slot['versoes'][-1]['impacto'] = {k: impacto[k] for k in ('campos_afetados', 'celulas_afetadas', 'circuitos_afetados', 'novos_erros')}
        cat._reopen_confirmations(project)
        selecao = cat._reselect(project)
        return {'versao': n, 'escopo': escopo, 'impacto': slot['versoes'][-1]['impacto'], 'selecao': selecao}

    def rollback(self, project, entry_id, versao, autor, escopo='comum'):
        cat = Catalog(project)
        v = cat.get(entry_id)
        cat._check_editable(v)
        kind, cid = cat._check_scope(v, escopo)
        slot = versoes.get_slot(project.doc['formulas'], entry_id, kind, cid)
        atual = slot['ativa'] if slot else 0
        if versao == atual:
            raise CatalogError('Esta já é a versão ativa.')
        if versao == 0:
            target = v.variants['raiz'] if kind == 'raiz' else (project.active_expression(v, 'comum') if kind == 'circuito' else v.expr)
        else:
            if not slot or not 1 <= versao <= len(slot['versoes']):
                raise CatalogError('Versão inexistente.')
            target = slot['versoes'][versao - 1]['expressao']
        before = cat.snapshot()
        cat._activate(project, v, target, {'tipo': 'rollback', 'autor': autor,
                                           'justificativa': f'Restauração da versão {versao}' + (' (modelo do aplicativo)' if versao == 0 else '')}, escopo)
        slot = versoes.get_slot(project.doc['formulas'], v.id, kind, cid)
        if versao == 0:
            slot['ativa'] = 0
            project.engine.clear()
        after = cat.snapshot(project)
        if versao != 0:
            gate = cat._gate(before, after, project)
            if gate['bloqueada']:
                raise CatalogError(gate['motivo'])
        impacto = cat.diff(before, after, limit=0)
        slot['versoes'][-1]['impacto'] = {k: impacto[k] for k in ('campos_afetados', 'celulas_afetadas', 'circuitos_afetados', 'novos_erros')}
        cat._reopen_confirmations(project)
        selecao = cat._reselect(project)
        return {'versao': slot['ativa'], 'escopo': escopo, 'impacto': slot['versoes'][-1]['impacto'], 'selecao': selecao}

    def _reselect(self, project):
        from . import selection
        project.engine.clear()
        before = {uid: dict(v) for uid, v in project.meta.get('selection_results', {}).items()}
        selection.apply(project)
        after = project.meta.get('selection_results', {})
        return {'circuitos_reavaliados': len(project.active_rows()),
                'mensagens_alteradas': sum(1 for uid, v in after.items() if before.get(uid) != v)}

    def _reopen_confirmations(self, project):
        for r in project.active_rows():
            project.put('Cálc-Prot_Cabos', f'CF{r}', 'PENDENTE')
        project.meta['changes'] = project.meta.get('changes', 0) + 1
        project.engine.clear()

    def divergences(self):
        from .integridade import formula_status
        names = {c['id']: c['entradas'].get('ident.nome') for c in self.p.circuits_doc}
        items = []
        hist = []
        for eid, top in self.versions.items():
            if eid not in self.m.by_id:
                continue
            v = self.m.by_id[eid]
            for kind, cid, slot in versoes.scopes(top):
                esc = versoes.scope_name(kind, cid)
                for x in slot.get('versoes', []):
                    hist.append({'id': eid, 'escopo': esc, 'versao': x.get('versao'), 'tipo': x.get('tipo'), 'autor': x.get('autor'),
                                 'ts': x.get('ts'), 'justificativa': x.get('justificativa')})
                if (slot.get('ativa') or 0) <= 0:
                    continue
                try:
                    ver = slot['versoes'][slot['ativa'] - 1]
                except (IndexError, KeyError, TypeError):
                    ver = {}
                base_expr = v.variants['raiz'] if kind == 'raiz' and v.variants.get('raiz') else v.expr
                items.append({'id': eid, 'escopo': esc,
                              'escopo_rotulo': 'todos os circuitos' if kind == 'comum' else ('circuitos ligados à fonte' if kind == 'raiz'
                                                                                            else f'circuito {names.get(cid, cid)}'),
                              'grupo': self.group_name(v), 'descricao': v.label, 'versao': ver.get('versao'), 'tipo': ver.get('tipo'),
                              'integridade': formula_status(self.p, eid, esc),
                              'autor': ver.get('autor'), 'ts': ver.get('ts'), 'justificativa': ver.get('justificativa'),
                              'expressao_baseline': base_expr, 'expressao': ver.get('expressao'), 'impacto_na_edicao': ver.get('impacto')})
        out = {'itens': items, 'diff_baseline': None}
        base = self.baseline_project()
        if items and base is not self.p:
            out['diff_baseline'] = self.diff(self.snapshot(base), self.snapshot(), limit=200)
        out['historico_completo'] = sorted(hist, key=lambda x: str(x['ts']))
        return out

    # ---- referências normativas --------------------------------------------
    def set_links(self, project, entry_id, ref_ids):
        cat = Catalog(project)
        if entry_id not in self.m.by_id and not any(r['id'] == entry_id for r in PYTHON_RULES):
            raise CatalogError('Cálculo não encontrado no catálogo.')
        known = set(normref_registry()) | set(cat.norm_overrides)
        bad = [r for r in ref_ids if r not in known]
        if bad:
            raise CatalogError('Referência normativa desconhecida: ' + ', '.join(bad))
        cat.links[entry_id] = list(dict.fromkeys(ref_ids))

    def save_ref(self, project, ref, autor, verificar):
        cat = Catalog(project)
        rid = str(ref.get('id', '')).strip()
        if not re.fullmatch(r'[A-Za-z0-9._-]{3,60}', rid):
            raise CatalogError('Identificador inválido (use letras, números, ponto, hífen).')
        norma = str(ref.get('norma', '')).strip()
        item = (str(ref.get('item') or '').strip() or None)
        tabela = (str(ref.get('tabela') or '').strip() or None)
        if not norma or not (item or tabela):
            raise CatalogError('Informe a norma e o item ou a tabela.')
        trecho = (str(ref.get('trecho') or '').strip() or None)
        cond = ref.get('condicoes') or []
        if isinstance(cond, str):
            cond = [x.strip() for x in cond.split(';') if x.strip()]
        data = {'norma': norma, 'item': item, 'tabela': tabela, 'condicoes': cond[:20], 'trecho': trecho,
                'verbatim': bool(ref.get('verbatim')) and bool(trecho)}
        data['verificado_em'] = dt.date.today().isoformat() if verificar else None
        data['verificado_por'] = autor if verificar else None
        cat.norm_overrides[rid] = data
        return rid

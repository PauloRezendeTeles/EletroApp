"""Motor de cálculo nativo do EletroApp (v2.0).

O modelo (``data/modelo``) define variáveis nomeadas por circuito, da fonte e do
projeto, com expressões que referenciam outras variáveis pelo nome. As tabelas
técnicas ficam em ``data/tabelas`` e podem receber edições versionadas por
projeto. O motor avalia as expressões sob demanda, com cache e detecção de ciclos.

Os circuitos são entidades com identificador próprio; a posição de cada um
(2, 3, 4…) é apenas a ordem topológica atual (montante antes de jusante) e não
há limite de quantidade. As funções e a semântica das expressões são as do
interpretador ``core.formula`` — o mesmo método de cálculo, sem endereços de
célula. Internamente, cada variável conserva a identificação de origem
(``legado``) apenas para compatibilidade com o código do aplicativo.
"""
from __future__ import annotations

import copy
import json
import math
import re
from functools import lru_cache
from pathlib import Path

from .formula import CalculationError, Engine, Error, Grid, address, col_name, col_number, parse, scalar

ROOT = Path(__file__).resolve().parent.parent
MODEL_DIR = ROOT / 'data' / 'modelo'
TABLE_DIR = ROOT / 'data' / 'tabelas'
ROOTS = ('Fonte', 'Transformador')
MIN_ROWS = 101  # posições avaliadas nos vetores (as vazias devolvem "", como na origem do modelo)


class Var:
    __slots__ = ('id', 'kind', 'sheet', 'col', 'addr', 'label', 'unit', 'group', 'expr', 'variants', 'options', 'default',
                 'header', 'fmt', 'scope', 'spec')

    def __init__(self, spec, scope):
        self.spec = spec
        self.id = spec['id']
        self.kind = spec['tipo']
        self.scope = scope
        leg = spec.get('legado') or [None, None]
        self.sheet = leg[0]
        if scope == 'circuito':
            self.col, self.addr = leg[1], None
        else:
            self.col, self.addr = None, leg[1]
        self.label = spec.get('rotulo') or self.id
        self.unit = spec.get('unidade') or ''
        self.group = spec.get('grupo')
        self.expr = spec.get('expressao')
        self.variants = spec.get('variantes') or {}
        self.options = spec.get('opcoes')
        self.default = spec.get('padrao')
        self.header = spec.get('cabecalho', self.label)
        self.fmt = spec.get('formato', 'General')


class Table:
    def __init__(self, spec, meta=None):
        self.id = spec['id']
        self.name = spec.get('nome', self.id)
        self.legacy = spec.get('legado')
        self.columns = spec.get('colunas', [])
        self.cells = spec['celulas']
        self.meta = meta or {}
        self.max_row = max((address(a)[0] for a in self.cells), default=1)
        self.max_col = max((address(a)[1] for a in self.cells), default=1)


APP_VERSION = '2.3.2'
CODE_DIR = ROOT / 'core'
RULE_FILES = ('installation_rules.json', 'metodos_instalacao.json', 'metodos_por_linha.json')


class Model:
    """Modelo de cálculo: variáveis, nomes definidos e base técnica.

    ``source`` (opcional) é um retrato serializado (``serialize``) — usado para recalcular um projeto com a base
    em que ele foi revisado, guardada no arquivo de bases do aplicativo."""

    def __init__(self, source=None):
        if source is None:
            load = lambda name: json.loads((MODEL_DIR / name).read_text(encoding='utf-8'))
            circ, fonte, proj, names = load('circuito.json'), load('fonte.json'), load('projeto.json'), load('nomes.json')
            meta_path = TABLE_DIR / '_metadados.json'
            metas = json.loads(meta_path.read_text(encoding='utf-8')) if meta_path.exists() else {}
            table_specs = [json.loads(path.read_text(encoding='utf-8')) for path in sorted(TABLE_DIR.glob('tab_*.json'))]
            self.rules = {name: json.loads((ROOT / 'data' / name).read_text(encoding='utf-8')) for name in RULE_FILES}
            self.code_hash = _static_components()['codigo.regras']
            self.app_version = APP_VERSION
        else:
            source = copy.deepcopy(source)
            circ, fonte, proj, names = source['circuito'], source['fonte'], source['projeto'], source['nomes']
            table_specs = [dict(t) for t in source['tabelas']]
            metas = {t['id']: t.get('meta') for t in table_specs}
            self.rules = source.get('regras') or {}
            self.code_hash = source.get('codigo')
            self.app_version = source.get('app', 'anterior a 2.1.1')
        self.missing_rules = [name for name in RULE_FILES if name not in self.rules]
        self.groups = circ['grupos']
        self.circuit = [Var(v, 'circuito') for v in circ['variaveis']]
        self.fonte = [Var(v, 'fonte') for v in fonte['variaveis']]
        self.project = [Var(v, 'projeto') for v in proj['variaveis']]
        self.fonte_sections = fonte.get('secoes', [])
        self.by_id = {v.id: v for v in self.circuit + self.fonte + self.project}
        self.by_legacy = {(v.sheet, v.col): v for v in self.circuit}
        self.fixed = {(v.sheet, v.addr): v for v in self.fonte + self.project}
        self.circuit_sheets = list(dict.fromkeys(v.sheet for v in self.circuit))
        self.circuit_sheet_set = set(self.circuit_sheets)
        self.fixed_sheets = {v.sheet for v in self.fonte + self.project}
        self.names = names
        self.tables = {}
        for spec in table_specs:
            spec.pop('meta', None)
            self.tables[spec['id']] = Table(spec, metas.get(spec['id']))
        self.table_alias = {}
        for t in self.tables.values():
            self.table_alias[t.id] = t
            if t.legacy:
                self.table_alias[t.legacy] = t
        self.inputs = [v for v in self.circuit if v.kind == 'entrada']
        self.formula_count = sum(1 for v in self.by_id.values() if v.kind == 'formula') + \
            sum(1 for t in self.tables.values() for c in t.cells.values() if 'f' in c)

    # ---- retrato e manifesto da base -----------------------------------------
    @staticmethod
    def _var_spec(v):
        spec = dict(v.spec)
        spec.update(tipo=v.kind, expressao=v.expr, variantes=v.variants or None, opcoes=v.options, padrao=v.default)
        return spec

    def serialize(self):
        """Retrato completo dos dados do modelo em uso (o que de fato é calculado), em formato recarregável."""
        return {'formato': 'eletroapp-base', 'versao': 2, 'app': self.app_version, 'codigo': self.code_hash,
                'regras': self.rules,
                'circuito': {'grupos': self.groups, 'variaveis': [self._var_spec(v) for v in self.circuit]},
                'fonte': {'variaveis': [self._var_spec(v) for v in self.fonte], 'secoes': self.fonte_sections},
                'projeto': {'variaveis': [self._var_spec(v) for v in self.project]},
                'nomes': self.names,
                'tabelas': [{'id': t.id, 'nome': t.name, 'legado': t.legacy, 'colunas': t.columns, 'celulas': t.cells, 'meta': t.meta}
                            for t in self.tables.values()]}

    def manifest(self):
        """Identificação verificável da base: resumo de cada componente (variáveis, nomes, cada tabela, regras e código)."""
        snap = self.serialize()
        comp = {}
        for key in ('circuito', 'fonte', 'projeto', 'nomes'):
            comp['modelo.' + key] = _digest(snap[key])
        for t in snap['tabelas']:
            comp['tabela.' + t['id']] = _digest(t)
        comp.update({'regras.' + name: _digest(data) for name, data in self.rules.items()})
        comp['codigo.regras'] = self.code_hash
        overall = _digest(sorted(comp.items()))
        return {'formato': 1, 'app': self.app_version, 'hash': overall,
                'dados': _digest(sorted((k, v) for k, v in comp.items() if not k.startswith('codigo.'))),
                'codigo': comp.get('codigo.regras'), 'componentes': comp}

    def table(self, name):
        return self.table_alias.get(name)


def _digest(obj):
    import hashlib
    raw = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str)
    return hashlib.blake2b(raw.encode(), digest_size=16).hexdigest()


@lru_cache(maxsize=1)
def _static_components():
    """Arquivos de regras e o código das regras em Python (lidos uma vez por execução)."""
    import hashlib
    out = {}
    for name in RULE_FILES:
        path = ROOT / 'data' / name
        if path.exists():
            out['regras.' + name] = hashlib.blake2b(path.read_bytes(), digest_size=16).hexdigest()
    h = hashlib.blake2b(digest_size=16)
    for path in sorted(CODE_DIR.glob('*.py')):
        h.update(path.name.encode())
        h.update(path.read_bytes())
    out['codigo.regras'] = h.hexdigest()
    return out


_STATIC = {}
_META_VOLATILE = ('selection_results', 'selection_modes', 'changes', 'revision', 'migracao', 'curvas', 'formula_normrefs',
                  'normref_overrides', 'title', 'ids', 'atualizacoes_base')


@lru_cache(maxsize=1)
def model():
    return Model()


@lru_cache(maxsize=200000)
def compiled(expression):
    return parse(expression)


class NativeEngine(Engine):
    """Avalia o modelo nativo. As chaves internas de cache são (grupo de origem, posição)."""

    def __init__(self, project):
        self.p = project
        self.m = project.model
        self.data = None
        self.cache, self.stack, self.diagnostics = {}, set(), {}
        self.ranges = {}
        self.static = {}
        self._stamp = None
        self._structure = None
        self._inputs = None
        self.rdeps = {}   # dado → cálculos que o leram (invalidação seletiva)
        self.trail = []
        self.names = {k.casefold(): v for k, v in self.m.names.items()}
        self.functions = {}

    def clear(self):
        """Invalida o cálculo. Se só mudaram dados de circuitos, invalida apenas o que depende deles."""
        self.stack.clear()
        self.trail.clear()
        stamp = json.dumps([self.p.doc.get('fonte'), self.p.doc.get('tabelas'), self.p.doc.get('formulas')],
                           sort_keys=True, default=str)
        structure = json.dumps([[c['id'] for c in self.p.circuits_doc],
                                {k: v for k, v in self.p.meta.items() if k not in _META_VOLATILE}], sort_keys=True, default=str)
        snapshot = {c['id']: dict(c['entradas']) for c in self.p.circuits_doc}
        if stamp != self._stamp:
            # Fonte, tabelas ou expressões mudaram: tudo é recalculado.
            self.ranges.clear()
            self.static.clear()
            self._stamp = stamp
            self._structure = None
        if structure != self._structure or self._inputs is None:
            self.cache.clear()
            self.diagnostics.clear()
            self.rdeps.clear()
        else:
            dirty = []
            for i, c in enumerate(self.p.circuits_doc):
                old, new = self._inputs.get(c['id'], {}), snapshot[c['id']]
                if old == new:
                    continue
                for vid in set(old) | set(new):
                    if old.get(vid) != new.get(vid):
                        var = self.m.by_id.get(vid)
                        if var is not None and var.scope == 'circuito':
                            dirty.append((var.sheet, f'{var.col}{i + 2}'))
            self._invalidate(dirty)
        self._structure = structure
        self._inputs = snapshot

    def input_changed(self, var, row, circuit):
        """Um dado de circuito foi gravado: invalida só os cálculos que o leram."""
        self._invalidate([(var.sheet, f'{var.col}{row}')])
        if self._inputs is not None and circuit['id'] in self._inputs:
            self._inputs[circuit['id']] = dict(circuit['entradas'])

    def adopt(self, other):
        """Herda o cálculo de outro motor sobre um documento idêntico (cópia do projeto)."""
        if other._inputs is None or other._structure is None:
            return
        self.cache = dict(other.cache)
        self.diagnostics = dict(other.diagnostics)
        self.rdeps = {k: set(v) for k, v in other.rdeps.items()}
        self.ranges = dict(other.ranges)
        self.static = dict(other.static)
        self._stamp, self._structure = other._stamp, other._structure
        self._inputs = {k: dict(v) for k, v in other._inputs.items()}
        self.clear()  # confere carimbos e diferenças (o construtor pode ter saneado o documento)

    def _invalidate(self, keys):
        seen = set()
        work = list(keys)
        while work:
            k = work.pop()
            if k in seen:
                continue
            seen.add(k)
            self.cache.pop(k, None)
            self.diagnostics.pop(k, None)
            work.extend(self.rdeps.pop(k, ()))

    def touch(self, sheet, addr):
        """Registra que o cálculo em andamento leu este dado (usado pelas regras em Python)."""
        if self.trail:
            self.rdeps.setdefault((sheet, addr.replace('$', '').upper()), set()).add(self.trail[-1])

    def max_row(self):
        return max(MIN_ROWS, len(self.p.circuits_doc) + 1)

    # ------------------------------------------------------------ células
    def get(self, sheet, addr):
        addr = addr.replace('$', '').upper()
        key = (sheet, addr)
        if self.trail:
            self.rdeps.setdefault(key, set()).add(self.trail[-1])
        if key in self.cache:
            return self.cache[key]
        if key in self.stack:
            return Error('#CYCLE!', f'{sheet}!{addr}')
        try:
            kind, payload = self._resolve(sheet, addr)
        except CalculationError as e:
            return e.value
        if kind == 'value':
            return payload
        self.stack.add(key)
        self.trail.append(key)
        try:
            value = scalar(self.evaluate(compiled(payload), sheet, addr))
            if isinstance(value, float) and not math.isfinite(value):
                value = Error('#NUM!', 'Resultado não finito')
        except CalculationError as e:
            value = e.value
        except (ValueError, TypeError, OverflowError, ZeroDivisionError) as e:
            value = Error('#VALUE!', str(e))
        except RecursionError:
            value = Error('#CYCLE!', 'Profundidade excessiva de dependências')
        finally:
            self.stack.discard(key)
            self.trail.pop()
        if isinstance(value, Error):
            self.diagnostics[key] = value
        self.cache[key] = value
        return value

    def _resolve(self, sheet, addr):
        """('value', v) para dados e ('formula', expressão) para cálculos."""
        m = self.m
        if sheet in m.circuit_sheet_set:
            row, cn = address(addr)
            var = m.by_legacy.get((sheet, col_name(cn)))
            if var is None:
                return 'value', None
            if row == 1:
                return 'value', var.header
            if var.kind == 'entrada':
                return 'value', self.p.input_value(var, row)
            return 'formula', self.p.expression(var, row)
        if sheet in m.fixed_sheets:
            var = m.fixed.get((sheet, addr))
            if var is None:
                return 'value', None
            if var.kind == 'entrada':
                return 'value', self.p.fonte_value(var)
            return 'formula', self.p.expression(var, None)
        table = m.table(sheet)
        if table is not None:
            cell = self.p.table_cell(table, addr)
            if cell is None:
                return 'value', None
            if 'f' in cell:
                return 'formula', cell['f']
            if cell.get('erro'):
                raise CalculationError(str(cell.get('v') or '#VALUE!'), 'Erro já presente na tabela')
            return 'value', cell.get('v')
        raise CalculationError('#REF!', sheet)

    def range(self, sheet, start, end):
        r1, c1 = address(start)
        r2, c2 = address(end)
        if r2 < r1 or c2 < c1 or (r2 - r1 + 1) * (c2 - c1 + 1) > 250000:
            return Error('#REF!', 'Intervalo inválido ou muito grande')
        rows, cols = r2 - r1 + 1, c2 - c1 + 1
        getter = lambda r, c: self.get(sheet, f'{col_name(c + c1)}{r + r1}')
        if rows * cols > 1 and sheet not in self.m.circuit_sheet_set and sheet not in self.m.fixed_sheets:
            # Intervalos de tabelas técnicas: lidos uma vez por cálculo e compartilhados por todos os circuitos.
            key = (sheet, r1, c1, r2, c2)
            vals = self.ranges.get(key)
            if vals is None:
                vals = [Grid.at(Grid(rows, cols, getter), r, c) for r in range(rows) for c in range(cols)]
                if any(isinstance(v, Error) and v.code == '#CYCLE!' for v in vals):
                    return Grid(rows, cols, getter, (sheet, r1, c1))
                self.ranges[key] = vals
            return Grid(rows, cols, getter, (sheet, r1, c1), vals)
        return Grid(rows, cols, getter, (sheet, r1, c1))

    # ------------------------------------------------------------ subexpressões constantes
    _ROW_DEPENDENT = frozenset(('FAIXA', 'ANTERIOR', 'INDIRECT', 'OFFSET', 'ROW', 'COLUMN', 'RAND', 'NOW', 'TODAY'))

    def _is_static(self, node):
        """Subexpressão que não depende do circuito em cálculo (só tabelas, fonte e literais)."""
        hit = _STATIC.get(id(node))
        if hit is not None and hit[0] is node:
            return hit[1]
        kind = node[0]
        if kind == 'lit':
            flag = True
        elif kind == 'name':
            var = self.m.by_id.get(node[1])
            flag = var is None or var.scope != 'circuito'
        elif kind in ('ref', 'columns'):
            flag = (node[1] or '') not in self.m.circuit_sheet_set and bool(node[1])
        elif kind == 'call':
            flag = node[1] not in self._ROW_DEPENDENT and node[1] != 'CIRCUITOS' and all(self._is_static(a) for a in node[2])
        elif kind == 'bin':
            flag = node[1] != ':' and self._is_static(node[2]) and self._is_static(node[3])
        elif kind == 'unary':
            flag = self._is_static(node[2])
        elif kind == 'array':
            flag = all(self._is_static(x) for row in node[1] for x in row)
        else:
            flag = False
        _STATIC[id(node)] = (node, flag)
        return flag

    # ------------------------------------------------------------ nomes
    def _evaluate(self, node, sheet, addr):
        kind = node[0]
        if kind in ('call', 'bin', 'unary') and self._is_static(node):
            # O mesmo valor serve a todos os circuitos neste cálculo (ex.: buscas de texto nas tabelas).
            hit = self.static.get(id(node))
            if hit is not None and hit[0] is node:
                return hit[1]
            value = self._evaluate_dynamic(node, sheet, addr)
            if not isinstance(value, Grid) or value.values is not None:
                if not (isinstance(value, Error) and value.code == '#CYCLE!'):
                    self.static[id(node)] = (node, value)
            return value
        return self._evaluate_dynamic(node, sheet, addr)

    def _evaluate_dynamic(self, node, sheet, addr):
        kind = node[0]
        if kind == 'name':
            var = self.m.by_id.get(node[1])
            if var is not None:
                if var.scope == 'circuito':
                    row = self._row(sheet, addr, node[1])
                    a = f'{var.col}{row}'
                    return self.range(var.sheet, a, a)
                return self.range(var.sheet, var.addr, var.addr)
            return super()._evaluate(node, sheet, addr)
        if kind == 'call' and node[1] in ('CIRCUITOS', 'FAIXA', 'ANTERIOR'):
            vars_ = [self.m.by_id.get(a[1]) if a[0] == 'name' else None for a in node[2]]
            if not vars_ or any(v is None or v.scope != 'circuito' for v in vars_):
                return Error('#NAME?', f'{node[1]} exige variáveis de circuito')
            first, last = vars_[0], vars_[-1]
            if first.sheet != last.sheet:
                return Error('#REF!', 'As variáveis do bloco devem ser do mesmo grupo')
            if node[1] == 'CIRCUITOS':
                return self.range(first.sheet, f'{first.col}2', f'{last.col}{self.max_row()}')
            row = self._row(sheet, addr, node[1])
            if node[1] == 'ANTERIOR':
                row -= 1
                if row < 2:
                    return Error('#N/A', 'Sem circuito anterior')
            return self.range(first.sheet, f'{first.col}{row}', f'{last.col}{row}')
        if kind == 'columns':
            target = node[1] or sheet
            t = self.m.table(target)
            if t is None:
                return Error('#REF!', 'Colunas inteiras só em tabelas técnicas')
            return self.range(target, node[2] + '1', node[3] + str(t.max_row))
        return super()._evaluate(node, sheet, addr)

    def _row(self, sheet, addr, what):
        if sheet not in self.m.circuit_sheet_set:
            raise CalculationError('#REF!', f'{what}: variável de circuito fora do contexto de um circuito')
        return address(addr)[0]

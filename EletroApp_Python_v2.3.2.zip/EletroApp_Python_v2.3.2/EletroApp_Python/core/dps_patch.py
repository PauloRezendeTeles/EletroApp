"""DPS: fabricante selecionável (Siemens 5SD7 ou Clamper), tipo de backup e declaração do fabricante.

A r42 original só lê a biblioteca Clamper na aba DPS. Este módulo, aplicado ao carregar o modelo:
 - reaponta toda leitura da biblioteca para Clamper OU Siemens, conforme a entrada BH
   (vazio = SIEMENS; as duas bibliotecas têm o mesmo layout de colunas);
 - cria entradas BH (fabricante), BI (tipo de backup), BJ (Icu do backup), BK (declaração do
   fabricante recebida?) e BL (documento da declaração);
 - reescreve backup (AE..AK, AO..AS, S, T) para usar o catálogo escolhido, o tipo de backup adotado
   e a declaração do fabricante.
Fontes Siemens: manual de configuração de DPS 5SD7 (backup gL/gG máximo por modelo; Isccr com backup:
Tipo 1 = 50 kA, Tipo 1+2 e Tipo 2 = 25 kA; "recomenda-se fusíveis em vez de disjuntores").
O patch é idempotente.
"""
import re

FAB_LIST='SIEMENS,CLAMPER'
BACKUP_FUS='FUSÍVEL gL/gG (catálogo)'
BACKUP_DISJ='DISJUNTOR (equivalência)'
NEW_HEADERS={
 'BH':'Fabricante do DPS (vazio = SIEMENS)',
 'BI':'Tipo de backup adotado (vazio = fusível do catálogo; disjuntor = escolhe-se o modelo WEG abaixo)',
 'BJ':'Icu do backup adotado (kA) [opcional — substitui o valor de referência]',
 'BK':'Declaração escrita do fabricante recebida? SIM = o fabricante confirmou a coordenação entre estágios, o Icu do backup e (se disjuntor) a equivalência com o fusível. Em branco = NÃO',
 'BL':'Documento da declaração (nº da carta/e-mail/ficha) — preencher quando a declaração = SIM',
 'BM':'Modelo do disjuntor de backup (catálogo WEG — só se backup = disjuntor)',
 'BN':'Polos do DPS ativo (auto)',
 'BO':'In sugerido por tipo — base (auto)',
 'BP':'Fusível de backup (catálogo NH gG — só se backup = fusível; vazio = automático: menor In ≥ dimensionado)',
 'BQ':'Índice do fusível adotado na biblioteca (auto)',
}
WEG='Biblioteca_Proteções_WEG'
FUS_SHEET='Biblioteca_Fusiveis_NH'
FUS='Biblioteca_Fusiveis_NH'
# Fusíveis NH gG (IEC 60269-2). Icu nominal 120 kA a 500 V AC, conferido em fichas/lojas de:
#  - Siemens SENTRON 3NA3344 (250 A) e 3NA3 360 (400 A): gG, 500 V AC, 120 kA (AC) / 25 kA (440 V DC);
#  - Hager LNH0032M (NH000, 32 A): gG, 500 V, 120 kA.
# Correntes nominais da série NH; tamanho = menor tamanho IEC que comporta a corrente (os tamanhos se sobrepõem).
FUS_IN=[6,10,16,20,25,32,35,40,50,63,80,100,125,160,200,224,250,315,355,400,500,630]
def _tam(i):return 'NH000' if i<=100 else 'NH00' if i<=160 else 'NH1' if i<=250 else 'NH2' if i<=400 else 'NH3'
FUS_FONTE='Siemens SENTRON 3NA3 (fichas 3NA3344 e 3NA3 360) e Hager LNH0032M: gG, 500 V AC, 120 kA; norma IEC 60269-2'
FUS_HEAD=['Chave (uso interno)','Fabricante / linha','Classe','Designação','Tamanho (menor IEC)','Un AC (V)','In (A)','Icu / poder de corte AC (kA)','Fonte','Observações']

# Isccr do DPS com o backup máximo do fabricante (kA) — Siemens 5SD7, manual de configuração:
# Tipo 1 (5SD7 41x) 50 kArms; Tipo 1+2 (5SD7 44x) 25 kArms; Tipo 2 padrão (5SD7 46x) 25 kArms.
SIEMENS_ISCCR={2:50,3:50,4:50,5:25,6:25,7:25,13:25,15:25,16:25}

def _lib(col,r):
    return ('IF($BH%d="CLAMPER",Biblioteca_DPS_Clamper!$%s$2:$%s$13,Biblioteca_DPS_Siemens!$%s$2:$%s$24)'
            %(r,col,col,col,col))

def _fab(r):return 'IF($BH%d="CLAMPER","Clamper","Siemens")'%r
def _fus(r):return '$BI%d<>"%s"'%(r,BACKUP_DISJ)

def _repoint(f,r):
    if '$BH' in f:return f
    f=re.sub(r'Biblioteca_DPS_Clamper!\$([A-Z]+)\$2:\$\1\$13',lambda m:_lib(m.group(1),r),f)
    f=f.replace('$AT%d="MANUAL — OUTRO MODELO CLAMPER"'%r,'LEFT($AT%d,6)="MANUAL"'%r)
    f=f.replace('"SEM MODELO CLAMPER COMPATÍVEL','"SEM MODELO DE DPS COMPATÍVEL')
    f=f.replace('nenhum modelo Clamper compatível','nenhum modelo de DPS compatível')
    f=f.replace('"Consultar fabricante Clamper — ','"Consultar fabricante "&%s&" — '%_fab(r))
    return f

def _ov(body):return '=IF($A{r}="","",IF($J{r}="—","N/A",'+body+'))'

def _fus_sheet():
    cells={}
    for i,h in enumerate(FUS_HEAD):cells['%s1'%'ABCDEFGHIJ'[i]]={'value':h,'formula':False}
    for k,i in enumerate(FUS_IN):
        r=k+2;nome='NH gG %d A'%i
        vals=[nome,'Siemens SENTRON 3NA3 / série NH IEC 60269-2','gG',nome,_tam(i),500,i,120,FUS_FONTE,
              'Icu 120 kA conferido nas fichas Siemens 250 A e 400 A e Hager 32 A; demais correntes seguem o valor nominal da série NH gG — confirmar na ficha do fusível adquirido. Vale também a 220 V (Icu não diminui com a tensão menor).']
        for j,v in enumerate(vals):cells['%s%d'%('ABCDEFGHIJ'[j],r)]={'value':v,'formula':False}
    return {'cells':cells,'validations':[],'state':'visible'}
NF=len(FUS_IN)+1
def _fus_rng(col):return '%s!$%s$2:$%s$%d'%(FUS,col,col,NF)
def _in_f(r):return 'IFERROR(INDEX(%s,$BQ%d),"")'%(_fus_rng('G'),r)
def _icu_f(r):return 'IFERROR(INDEX(%s,$BQ%d),"")'%(_fus_rng('H'),r)
def _des_f(r):return 'IFERROR(INDEX(%s,$BQ%d),"")'%(_fus_rng('D'),r)

def _in_bm(r):return 'IFERROR(INDEX(%s!$BM$2:$BM$568,MATCH($BM%d,%s!$C$2:$C$568,0)),"")'%(WEG,r,WEG)
def _icu_bm(r):return 'IFERROR(INDEX(%s!$AA$2:$AA$568,MATCH($BM%d,%s!$C$2:$C$568,0)),"")'%(WEG,r,WEG)

def _formulas(r):
    A,J=_ov,None
    fab,fus=_fab(r),_fus(r)
    inf,icf,desf=_in_f(r),_icu_f(r),_des_f(r)
    q=_lib('Q',r);s=_lib('S',r)
    sie_isccr='Biblioteca_DPS_Siemens!$AA$2:$AA$24'
    F={}
    F['AE']=_ov('IF(ISNUMBER($AW{r}),IF(AND(NOT(%s),$BM{r}<>""),"WEG (disjuntor do catálogo; DPS "&%s&")",IF(AND(%s,ISNUMBER(%s)),"Fusível NH gG do catálogo do app (DPS "&%s&")","Genérico (backup indicado pela "&%s&")")),"—")'%(fus,fab,fus,inf,fab,fab))
    inb,icb=_in_bm(r),_icu_bm(r)
    F['AF']=_ov('IF(AND(NOT(%s),$BM{r}<>"",ISNUMBER(%s)),$BM{r}&" · In "&%s&" A · Icu "&%s&" kA",IF(AND(%s,ISNUMBER(%s)),%s&" · In "&%s&" A · Icu "&%s&" kA (500 V AC)","—"))'%(fus,inb,inb,icb,fus,inf,desf,inf,icf))
    F['BQ']=_ov('IF(%s,IF($BP{r}<>"",IFERROR(MATCH($BP{r},%s,0),"—"),IF(ISNUMBER($BO{r}),COUNTIF(%s,"<"&$BO{r})+1,"—")),"—")'%(fus,_fus_rng('D'),_fus_rng('G')))
    F['AG']=_ov('IFERROR(IF(%s,INDEX(%s,$AW{r}),"Disjuntor (equivalência — o catálogo indica "&INDEX(%s,$AW{r})&")"),"—")'%(fus,s,s))
    F['AI']=_ov('IF(ISNUMBER($BJ{r}),$BJ{r},IF(AND(NOT(%s),ISNUMBER(%s)),%s,IF(AND(%s,ISNUMBER(%s)),%s,IFERROR(VLOOKUP($S{r},Tabela_Disjuntores,8,FALSE),"N/D — informar o Icu do backup em BJ"))))'%(fus,icb,icb,fus,icf,icf))
    F['BO']='=IF($A{r}="","",IF($J{r}="—","—",IF($J{r}="Tipo 1+2 / Classe I+II",80,IF($J{r}="Tipo 2 / Classe II",63,25))))'
    F['R']='=IF($A{r}="","",IF($J{r}="—","—",IF(AND(NOT(%s),ISNUMBER(%s)),%s,IF(AND(%s,ISNUMBER(%s)),%s,$BO{r}))))'%(fus,inb,inb,fus,inf,inf)
    F['BN']=_ov('IFERROR(INDEX(%s,$AW{r}),"—")'%_lib('F',r))
    F['AJ']=_ov('IF($BH{r}="CLAMPER","N/D — não tabelada por modelo neste catálogo Clamper — consultar fabricante",'
        'IF(ISNUMBER($AW{r}),IF(ISNUMBER(INDEX(%s,$AW{r})),INDEX(%s,$AW{r}),'
        '"N/D — Isccr com backup não extraída para este modelo Siemens — consultar fabricante"),"N/A"))'%(sie_isccr,sie_isccr))
    F['AK']=_ov('IF($BH{r}="CLAMPER","Consultar fabricante — Clamper não declara critério geral de distância neste catálogo",'
        '"Consultar fabricante — Siemens não declara critério de distância no manual 5SD7 (cabo de ligação ≤ 0,5 m)")')
    F['AO']=_ov('IF(ISNUMBER($AW{r}),IF(ISNUMBER(INDEX(%s,$AW{r})),IF(%s,"✓ SIM — corrente máxima de back-up (fusível) declarada pela "&%s,'
        'IF($BK{r}="SIM","✓ SIM — disjuntor aceito por declaração do fabricante","△ NÃO — "&%s&" declara fusível; disjuntor exige equivalência declarada")),'
        '"✗ NÃO — modelo compatível não possui back-up declarado pela "&%s&" para esta configuração"),"✗ SEM REFERÊNCIA (sem modelo ativo)")'%(q,fus,fab,fab,fab))
    F['AP']=_ov('IF($BK{r}="SIM","✓ DECLARADA PELO FABRICANTE"&IF($BL{r}<>""," ("&$BL{r}&")",""),"✗ NÃO DECLARADA NESTE CATÁLOGO — consultar "&%s)'%fab)
    F['AQ']=_ov('IF(NOT(ISNUMBER($AW{r})),"✗ SEM MODELO ATIVO",IF(AND(ISNUMBER($R{r}),ISNUMBER($AH{r}),$R{r}<=$AH{r}),'
        'IF(AND(NOT(%s),$BK{r}<>"SIM"),"△ ADOTADO ("&$R{r}&"A) DENTRO DO LIMITE, MAS DISJUNTOR SEM EQUIVALÊNCIA DECLARADA PELO FABRICANTE",'
        '"✓ ADOTADO ("&$R{r}&"A) DENTRO DO LIMITE DO FABRICANTE ("&$AH{r}&"A)"),'
        '"✗ ADOTADO ("&$R{r}&"A) EXCEDE OU NÃO CONFIRMA O LIMITE DO FABRICANTE ("&$AH{r}&"A)"))'%fus)
    F['AR']=_ov('IF(OR($U{r}="N/A",$U{r}="—",$U{r}="MONTANTE SEM DPS"),"✓ SEM DPS A MONTANTE PARA COORDENAR",'
        'IF($BK{r}="SIM","✓ DECLARADA PELO FABRICANTE","✗ NÃO CONFIRMADA — coordenação entre estágios não declarada pelo fabricante "&%s))'%fab)
    p1='IF(LEFT($AR{r},1)="✗","COORDENAÇÃO ENTRE ESTÁGIOS NÃO CONFIRMADA PELO FABRICANTE; ","")'
    p2='IF(OR(ISNUMBER($BJ{r}),AND(NOT(%s),ISNUMBER(%s)),AND(%s,ISNUMBER(%s))),"",'%(fus,icb,fus,icf)+'"ICU DO BACKUP SÓ POR REFERÊNCIA GENÉRICA (INFORMAR O ICU DO FUSÍVEL/DISJUNTOR EM BJ); ")'
    p3='IF(%s,"","EQUIVALÊNCIA FUSÍVEL→DISJUNTOR NÃO DECLARADA PELO FABRICANTE; ")'%fus
    F['AS']=_ov('IF(NOT(ISNUMBER($AW{r})),"✗ SEM MODELO COMPATÍVEL — CONSULTAR FABRICANTE",'
        'IF(LEFT($AQ{r},1)="✗","✗ BACKUP ADOTADO INCOMPATÍVEL COM O DPS SELECIONADO",'
        'IF(LEFT($T{r},1)="✗","✗ ICU DO BACKUP INSUFICIENTE PARA A Ik NO PONTO",'
        'IF(AND(ISNUMBER($AJ{r}),ISNUMBER($Q{r}),$Q{r}>$AJ{r}),"✗ Ik NO PONTO EXCEDE A CORRENTE DE CURTO SUPORTADA PELO CONJUNTO DPS+BACKUP ("&$AJ{r}&" kA)",'
        'IF($BK{r}="SIM","✓ CONFIRMADO POR DECLARAÇÃO DO FABRICANTE ("&%s&")"&IF($BL{r}<>""," — "&$BL{r},""),'
        'IF(%s&%s&%s="","✓ MODELO "&UPPER(%s)&" CONFIRMADO — BACKUP DENTRO DO LIMITE E ICU DE CATÁLOGO/INFORMADO",'
        '"△ MODELO "&UPPER(%s)&" CONFIRMADO — PENDENTE: "&%s&%s&%s))))))'%(fab,p1,p2,p3,fab,fab,p1,p2,p3))
    # S/T não seguem o molde (sem teste de J no mesmo formato)
    F['S']='=IF($A{r}="","",IF($J{r}="—","—",IF(%s,"Fusível_gG",IF($R{r}<=63,"Disjuntor_C - In <= 63A","Disjuntor_C - In > 63A"))))'%fus
    F['T']='=IF($A{r}="","",IF($S{r}="—","N/A",IF(ISNUMBER($AI{r}),IF($AI{r}>=$Q{r},"✓ OK","✗ NOK — Icu insuficiente"),"N/A")))'
    return {k:v.replace('{r}',str(r)) for k,v in F.items()}

def apply(data):
    sh=data['sheets']
    dps=sh.get('DPS');sie=sh.get('Biblioteca_DPS_Siemens')
    if not dps or not sie or 'BH1' in dps['cells']:return 0
    cells=dps['cells'];n=0
    for r in range(2,102):
        for a,c in list(cells.items()):
            pass
    for r in range(2,102):
        for col in ('BN','BO','BQ'):cells.setdefault('%s%d'%(col,r),{'value':'','formula':True})
        for col in list(_formulas(r)):
            a='%s%d'%(col,r)
            if a in cells and cells[a].get('formula'):
                cells[a]['value']=_formulas(r)[col];n+=1
    for a,c in list(cells.items()):
        m=re.fullmatch(r'([A-Z]+)(\d+)',a)
        if not m or not c.get('formula') or not 2<=int(m.group(2))<=101:continue
        new=_repoint(c['value'],int(m.group(2)))
        if new!=c['value']:c['value']=new;n+=1
    for col,h in NEW_HEADERS.items():
        cells[col+'1']={'value':h,'formula':False}
    vals=dps.setdefault('validations',[])
    for v in vals:
        if v.get('range')=='AT2:AT111':v['f1']='"AUTOMÁTICO (RECOMENDADO),MANUAL — OUTRO MODELO DO CATÁLOGO"'
    vals+= [{'range':'BH2:BH111','type':'list','f1':'"%s"'%FAB_LIST,'f2':None},
            {'range':'BI2:BI111','type':'list','f1':'"%s,%s"'%(BACKUP_FUS,BACKUP_DISJ),'f2':None},
            {'range':'BK2:BK111','type':'list','f1':'"SIM,NÃO"','f2':None}]
    sh.setdefault(FUS_SHEET,_fus_sheet())
    sc=sie['cells']
    sc['AA1']={'value':'Isccr do DPS com backup máximo (kA) [manual Siemens 5SD7 — só onde extraído]','formula':False}
    for r,v in SIEMENS_ISCCR.items():sc['AA%d'%r]={'value':v,'formula':False}
    ac=sh.get('Auditoria_Checklist',{}).get('cells',{}).get('S6')
    if ac and isinstance(ac['value'],str):ac['value']=ac['value'].replace('MODELO CLAMPER COMPATÍVEL','MODELO DE DPS COMPATÍVEL')
    return n

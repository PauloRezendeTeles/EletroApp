"""Importação de quadros de cargas e unifilares com revisão antes de gravar (v1.12).

Fluxo:

1. ``preview``: lê um ou mais documentos (CSV, XLSX e, com a extração assistida
   por IA habilitada, PDF e imagens), identifica as colunas, normaliza os dados e
   devolve cada circuito com a origem de cada valor, ausências e conflitos.
   Nada é gravado.
2. O projetista revisa a tabela (inclui, ignora ou corrige linhas).
3. ``apply``: revalida tudo no servidor e grava numa única transação. Os
   resultados (correntes, seções, quedas, curto-circuito, proteções) são sempre
   recalculados pelo motor do EletroApp.

Um XLSX fornece apenas valores: as fórmulas da planilha nunca são executadas e o
projeto não fica dependente do arquivo. A IA, quando usada, só interpreta o
documento; não calcula nada.
"""
from __future__ import annotations

import base64
import csv
import io
import json
import os
import re
import unicodedata
import urllib.error
import urllib.request

from . import numeros, topologia

IDENT = 'Identificação dos circuitos'
LOAD = 'Levantamento de carga'
DATA = 'Dados dos circuitos'
SEC = 'Seleção-Seção_Condutor'
ROOTS = ('Fonte', 'Transformador')
SECOES = [0.5, 0.75, 1, 1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240, 300, 400, 500, 630, 800, 1000]
MAX_ROWS = 400
TABULAR = ('.csv', '.txt', '.xlsx')
DOCUMENTS = {'.pdf': 'application/pdf', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp'}

FIELDS = {
    'nome': 'Circuito / quadro', 'descricao': 'Descrição', 'montante': 'Circuito a montante', 'ligacao': 'Ligação',
    'natureza': 'Natureza', 'aterramento': 'Esquema de aterramento', 'fase': 'Fase(s) de ligação',
    'p_r': 'P fase R (W)', 'p_s': 'P fase S (W)', 'p_t': 'P fase T (W)', 'potencia': 'Potência total (W)',
    'fp': 'Fator de potência', 'fs': 'Fator de simultaneidade', 'comprimento': 'Comprimento (m)',
    'sec_f': 'Seção da fase (mm²)', 'sec_n': 'Seção do neutro (mm²)', 'sec_pe': 'Seção do PE (mm²)',
    'disjuntor': 'Disjuntor do documento (A)',
}

# Cabeçalhos reconhecidos (sem acentos, minúsculos, só letras e números).
SYNONYMS = {
    'nome': ['circuito', 'circ', 'ckt', 'nomedocircuito', 'nome', 'circuitoquadro', 'identificacao', 'tag', 'no', 'n', 'numero', 'item'],
    'descricao': ['descricao', 'descricaodocircuito', 'carga', 'cargas', 'uso', 'ambiente', 'finalidade', 'local', 'designacao'],
    'montante': ['montante', 'circuitoamontante', 'alimentadopor', 'quadrodeorigem', 'quadropai', 'quadro', 'painel', 'origem', 'qd'],
    'ligacao': ['ligacao', 'fases', 'nfases', 'numerodefases', 'sistema', 'tipodeligacao', 'tipodecircuito', 'tipo'],
    'natureza': ['natureza', 'categoria', 'funcao', 'naturezadocircuito'],
    'aterramento': ['aterramento', 'esquema', 'esquemadeaterramento'],
    'fase': ['fase', 'faseligada', 'fasesligadas', 'ligadoem'],
    'p_r': ['pr', 'faser', 'fasea', 'r', 'a', 'pfaser', 'potenciar', 'cargar'],
    'p_s': ['ps', 'fases_', 'faseb', 's', 'b', 'pfases', 'potencias', 'cargas_'],
    'p_t': ['pt', 'faset', 'fasec', 't', 'c', 'pfaset', 'potenciat', 'cargat'],
    'potencia': ['potencia', 'pot', 'potenciatotal', 'potenciainstalada', 'cargainstalada', 'ptotal', 'potenciaativa', 'p', 'total', 'demanda', 'potenciaaparente', 's'],
    'fp': ['fp', 'fatordepotencia', 'cosphi', 'cosfi', 'cos', 'fpot'],
    'fs': ['fs', 'fd', 'fatordesimultaneidade', 'simultaneidade', 'fatordedemanda'],
    'comprimento': ['comprimento', 'compr', 'distancia', 'extensao', 'l'],
    'sec_f': ['secao', 'secaofase', 'secaodafase', 'bitola', 'bitolafase', 'condutor', 'cabo', 'fase_mm', 'sf', 'secaodocondutor'],
    'sec_n': ['secaoneutro', 'secaodoneutro', 'neutro', 'bitolaneutro', 'sn'],
    'sec_pe': ['secaope', 'secaodope', 'pe', 'terra', 'protecao_mm', 'bitolape', 'spe', 'condutordeprotecao'],
    'disjuntor': ['disjuntor', 'dj', 'in', 'protecao', 'correntenominal', 'disj', 'disjuntora'],
}


def _key(text):
    t = unicodedata.normalize('NFKD', str(text or '')).encode('ascii', 'ignore').decode().casefold()
    return re.sub(r'[^0-9a-z]+', '', t)


def _unit(header):
    h = str(header or '').casefold()
    m = re.search(r'\(([^)]*)\)|\[([^\]]*)\]', h)
    u = (m[1] or m[2] or '') if m else ''
    for token in (u, h):
        token = token.replace(' ', '')
        if 'kva' in token:
            return 'kVA'
        if 'kw' in token:
            return 'kW'
        if 'va' in token and 'var' not in token:
            return 'VA'
        if re.search(r'(^|[^k])w($|[^a-z])', token) or token.endswith('(w)'):
            return 'W'
        if 'cv' in token:
            return 'cv'
    return None


def _match_header(header):
    """Campo canônico para um cabeçalho, ou None."""
    raw = str(header or '').strip()
    if not raw:
        return None
    k = _key(re.sub(r'\(.*?\)|\[.*?\]', '', raw))
    full = _key(raw)
    low = raw.casefold()
    if 'mm' in low:
        if 'neutro' in low:
            return 'sec_n'
        if re.search(r'\bpe\b|terra|prote', low):
            return 'sec_pe'
        return 'sec_f'
    if re.search(r'fase\s*r\b|\bp\s*r\b|^r\s*\(', low) and _unit(raw):
        return 'p_r'
    if re.search(r'fase\s*s\b|\bp\s*s\b|^s\s*\(', low) and _unit(raw) and _unit(raw) not in ('VA', 'kVA'):
        return 'p_s'
    if re.search(r'fase\s*t\b|\bp\s*t\b|^t\s*\(', low) and _unit(raw):
        return 'p_t'
    for field, names in SYNONYMS.items():
        if k in names or full in names:
            if field in ('p_s', 'p_t', 'p_r') and k in ('s', 'b', 'c', 't', 'a', 'r') and not _unit(raw):
                continue  # "S" ou "T" sozinhos são ambíguos sem unidade
            return field
    for field, names in SYNONYMS.items():
        if any(len(n) >= 5 and n in k for n in names):
            return field
    return None


# ---------------------------------------------------------------- leitura
def _decode(raw):
    for enc in ('utf-8-sig', 'cp1252', 'latin-1'):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    raise ValueError('Não foi possível ler o texto do arquivo.')


def read_csv(raw, filename):
    text = _decode(raw)
    sample = text[:4000]
    delim = max([';', ',', '\t', '|'], key=lambda d: sample.count(d))
    rows = list(csv.reader(io.StringIO(text), delimiter=delim))
    return [{'planilha': filename, 'linhas': [[c.strip() for c in r] for r in rows]}]


def read_xlsx_values(raw, filename):
    """Valores das abas de um XLSX. Fórmulas não são executadas: usa-se o valor salvo no arquivo."""
    from .xlsx_reader import read_xlsx
    from .formula import address
    data = read_xlsx(raw, filename)
    out = []
    for name, body in data['sheets'].items():
        grid = {}
        for a, c in body['cells'].items():
            r, col = address(a)
            if r > MAX_ROWS + 60 or col > 60:
                continue
            v = c.get('cache') if c.get('formula') else c.get('value')
            if v is not None:
                grid.setdefault(r, {})[col] = v
        if not grid:
            continue
        maxc = max(max(row) for row in grid.values())
        rows = [[grid.get(r, {}).get(c) for c in range(1, maxc + 1)] for r in range(1, max(grid) + 1)]
        out.append({'planilha': name, 'linhas': rows})
    return out


def _detect_table(sheet):
    """Linha de cabeçalho com mais campos reconhecidos (precisa ter o nome do circuito)."""
    best = None
    for i, row in enumerate(sheet['linhas'][:40]):
        mapped = {}
        for j, h in enumerate(row):
            f = _match_header(h)
            if f and f not in mapped:
                mapped[f] = j
        if 'nome' not in mapped and 'descricao' in mapped and any(k in mapped for k in ('potencia', 'p_r')):
            mapped['nome'] = mapped.pop('descricao')  # tabela sem coluna de código: a descrição identifica o circuito
        score = len(mapped) + (3 if 'nome' in mapped else 0)
        if 'nome' in mapped and len(mapped) >= 2 and (best is None or score > best[0]):
            best = (score, i, mapped)
    return best


def _cell_ref(sheet, row, col):
    from .formula import col_name
    return f'{sheet}!{col_name(col + 1)}{row + 1}'


def tabular_records(sheets, filename):
    found = []
    for sh in sheets:
        t = _detect_table(sh)
        if t:
            found.append((t[0], sh, t[1], t[2]))
    if not found:
        raise ValueError(f'{filename}: nenhuma tabela reconhecida. A primeira linha da tabela precisa ter ao menos o nome do circuito '
                         'e outra coluna conhecida (potência, fases, descrição, montante…).')
    found.sort(key=lambda x: -x[0])
    _, sh, hrow, mapped = found[0]
    header = sh['linhas'][hrow]
    # "Quadro" e "Circuito" juntos: o quadro é o montante.
    records = []
    units = {f: _unit(header[j]) for f, j in mapped.items()}
    for i in range(hrow + 1, min(len(sh['linhas']), hrow + 1 + MAX_ROWS)):
        row = sh['linhas'][i]
        if not any(v not in (None, '') for v in row):
            continue
        rec = {'dados': {}, 'fontes': {}, 'documento': filename}
        for f, j in mapped.items():
            v = row[j] if j < len(row) else None
            if v in (None, ''):
                continue
            rec['dados'][f] = v
            rec['fontes'][f] = _cell_ref(sh['planilha'] if not filename.lower().endswith(('.csv', '.txt')) else filename, i, j)
        if not rec['dados'].get('nome'):
            continue
        name = str(rec['dados']['nome']).strip().casefold()
        if name.startswith(('total', 'subtotal', 'soma')):
            continue
        rec['origem'] = f"{sh['planilha'] if not filename.lower().endswith(('.csv', '.txt')) else filename}, linha {i + 1}"
        rec['unidades'] = units
        records.append(rec)
    ignored = [str(h) for j, h in enumerate(header) if h not in (None, '') and j not in mapped.values()]
    info = {'documento': filename, 'planilha': sh['planilha'], 'linha_cabecalho': hrow + 1,
            'mapeamento': {f: str(header[j]) for f, j in mapped.items()}, 'colunas_ignoradas': ignored}
    return records, info


# ---------------------------------------------------------------- extração assistida por IA (opcional)
AI_PROMPT = """Você recebe um documento de projeto elétrico de baixa tensão (quadro de cargas, diagrama unifilar ou ambos).
Extraia SOMENTE o que está escrito no documento; não calcule, não estime e não complete valores ausentes.
Responda apenas com um objeto JSON neste formato:
{"circuitos":[{"nome":"","descricao":"","montante":"","ligacao":"Monofásico|Bifásico|Trifásico","natureza":"Origem|Distribuição|Circuito final",
"aterramento":"TN-S|TN-C","fase":"R|S|T|RS|RST","p_r":null,"p_s":null,"p_t":null,"potencia_w":null,"fp":null,"fs":null,
"comprimento_m":null,"secao_fase_mm2":null,"secao_neutro_mm2":null,"secao_pe_mm2":null,"disjuntor_a":null,
"origem":"página e tabela/região do documento","confianca":0.0}],"observacoes":[""]}
Use null para o que não estiver no documento. "montante" é o quadro que alimenta o circuito (no unifilar, a barra de origem).
Potências em watts. "confianca" de 0 a 1 para a leitura de cada linha."""

AI_MAP = {'nome': 'nome', 'descricao': 'descricao', 'montante': 'montante', 'ligacao': 'ligacao', 'natureza': 'natureza',
          'aterramento': 'aterramento', 'fase': 'fase', 'p_r': 'p_r', 'p_s': 'p_s', 'p_t': 'p_t', 'potencia_w': 'potencia', 'fp': 'fp',
          'fs': 'fs', 'comprimento_m': 'comprimento', 'secao_fase_mm2': 'sec_f', 'secao_neutro_mm2': 'sec_n',
          'secao_pe_mm2': 'sec_pe', 'disjuntor_a': 'disjuntor'}


def ai_available():
    return bool(os.environ.get('ANTHROPIC_API_KEY')) and os.environ.get('ELETROAPP_IA', '1') != '0'


def _ai_transport(payload):
    """Chamada HTTP à API (substituível nos testes)."""
    req = urllib.request.Request('https://api.anthropic.com/v1/messages', data=json.dumps(payload).encode(),
                                 headers={'x-api-key': os.environ['ANTHROPIC_API_KEY'], 'anthropic-version': '2023-06-01',
                                          'content-type': 'application/json'}, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise ValueError(f'A extração assistida por IA falhou (HTTP {e.code}). Use CSV/XLSX ou tente novamente.') from e
    except (urllib.error.URLError, TimeoutError) as e:
        raise ValueError('Sem conexão com a API para a extração assistida por IA. Use CSV/XLSX ou confira a internet.') from e


def ai_records(raw, filename, transport=None):
    ext = os.path.splitext(filename.lower())[1]
    if not ai_available():
        raise ValueError(f'{filename}: PDF e imagens são lidos pela extração assistida por IA, que está desativada '
                         '(defina a variável ANTHROPIC_API_KEY antes de iniciar o aplicativo). Enquanto isso, use CSV ou XLSX.')
    media = DOCUMENTS[ext]
    block = {'type': 'document' if ext == '.pdf' else 'image',
             'source': {'type': 'base64', 'media_type': media, 'data': base64.b64encode(raw).decode()}}
    payload = {'model': os.environ.get('ELETROAPP_IA_MODELO', 'claude-sonnet-5-5'), 'max_tokens': 8000,
               'messages': [{'role': 'user', 'content': [block, {'type': 'text', 'text': AI_PROMPT}]}]}
    resp = (transport or _ai_transport)(payload)
    text = ''.join(b.get('text', '') for b in resp.get('content', []) if isinstance(b, dict))
    i, j = text.find('{'), text.rfind('}')
    if i < 0 or j <= i:
        raise ValueError(f'{filename}: a IA não devolveu uma tabela reconhecível.')
    try:
        parsed = json.loads(text[i:j + 1])
    except json.JSONDecodeError as e:
        raise ValueError(f'{filename}: resposta da IA em formato inválido.') from e
    records = []
    for n, item in enumerate(parsed.get('circuitos') or [], 1):
        if not isinstance(item, dict) or not item.get('nome'):
            continue
        rec = {'dados': {}, 'fontes': {}, 'documento': filename, 'unidades': {}, 'ia': True}
        where = str(item.get('origem') or f'item {n}')[:160]
        for k, f in AI_MAP.items():
            v = item.get(k)
            if v not in (None, ''):
                rec['dados'][f] = v
                rec['fontes'][f] = f'{filename} — {where} (IA)'
        rec['origem'] = f'{filename} — {where} (leitura por IA)'
        conf = item.get('confianca')
        rec['confianca'] = conf if isinstance(conf, (int, float)) else None
        records.append(rec)
    info = {'documento': filename, 'planilha': None, 'linha_cabecalho': None, 'mapeamento': {'IA': 'campos do modelo de extração'},
            'colunas_ignoradas': [], 'observacoes': [str(x) for x in parsed.get('observacoes') or [] if x][:20], 'ia': True}
    return records, info


# ---------------------------------------------------------------- normalização
def _num(v):
    if v in (None, ''):
        return None
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v)
    t = re.sub(r'[^\d,.\-+eE]', '', str(v))
    try:
        return numeros.parse_br(t)
    except ValueError:
        return 'invalido'


def _ligacao(v):
    k = _key(v)
    if not k:
        return None
    if k in ('mono', 'monofasico', '1f', 'fn', '1fn', '1', '1fnt', 'f', '1fpen', 'fnpe'):
        return 'Monofásico'
    if k in ('bi', 'bifasico', '2f', 'ff', '2', '2fn', '2fnt', '2ft', 'ffn', 'ffpe'):
        return 'Bifásico'
    if k in ('tri', 'trifasico', '3f', 'fff', '3', '3fn', '3fnt', '3ft', '3fpen', 'fffn'):
        return 'Trifásico'
    if k.startswith('mono'):
        return 'Monofásico'
    if k.startswith('bi'):
        return 'Bifásico'
    if k.startswith('tri'):
        return 'Trifásico'
    return 'invalido'


def _natureza(v):
    k = _key(v)
    if not k:
        return None
    if k in ('origem', 'entrada', 'geral'):
        return 'Origem'
    if k.startswith(('distrib', 'alimentador', 'quadro', 'qd', 'subquadro', 'painel')):
        return 'Distribuição'
    if k.startswith(('final', 'terminal', 'circuitofinal', 'carga')):
        return 'Circuito final'
    return 'invalido'


def _aterramento(v):
    k = _key(v)
    if not k:
        return None
    if k in ('tns', 'tn-s', 'tncs'):
        return 'TN-S'
    if k == 'tnc':
        return 'TN-C'
    return 'invalido'


def _phases_for(fase, ligacao):
    k = _key(fase).upper()
    map3 = {'A': 'R', 'B': 'S', 'C': 'T'}
    letters = [map3.get(ch, ch) for ch in k if ch in 'RSTABC']
    letters = list(dict.fromkeys(letters))
    n = topologia.PHASES.get(ligacao, 0)
    if n and len(letters) == n:
        return letters
    return ['R', 'S', 'T'][:n] if n else []


def normalize(rec, existing_names, file_names):
    """Converte um registro bruto em dados do EletroApp e lista ausências, conflitos e avisos."""
    d = rec['dados']
    units = rec.get('unidades') or {}
    out = {}
    conflicts, missing, notes = [], [], []

    def text(f, n=160):
        v = d.get(f)
        return str(v).strip()[:n] if v not in (None, '') else None

    out['nome'] = text('nome', 80)
    if out['nome'] and re.fullmatch(r'\d+(\.0)?', out['nome']):
        out['nome'] = out['nome'].split('.')[0]
    out['descricao'] = text('descricao', 300)
    out['montante'] = text('montante', 80)
    for f, fn in (('ligacao', _ligacao), ('natureza', _natureza), ('aterramento', _aterramento)):
        v = fn(d.get(f))
        if v == 'invalido':
            conflicts.append(f'{FIELDS[f]}: valor "{d.get(f)}" não reconhecido.')
            v = None
        out[f] = v
    for f in ('p_r', 'p_s', 'p_t', 'potencia', 'fp', 'fs', 'comprimento', 'sec_f', 'sec_n', 'sec_pe', 'disjuntor'):
        v = _num(d.get(f))
        if v == 'invalido':
            conflicts.append(f'{FIELDS[f]}: "{d.get(f)}" não é um número.')
            v = None
        out[f] = v
    # unidades de potência
    for f in ('p_r', 'p_s', 'p_t', 'potencia'):
        u = units.get(f)
        if out[f] is not None and u in ('kW', 'kVA'):
            out[f] *= 1000
        if out[f] is not None and u in ('VA', 'kVA'):
            if out['fp']:
                out[f] = out[f] * out['fp']
                notes.append(f'{FIELDS[f]} informada em {u}; convertida em W com o fator de potência {str(out["fp"]).replace(".", ",")}.')
            else:
                conflicts.append(f'{FIELDS[f]} informada em {u} sem fator de potência: não é possível obter a potência ativa.')
                out[f] = None
        if out[f] is not None and u == 'cv':
            conflicts.append(f'{FIELDS[f]} em cv: cadastre motores na aba Motores do circuito.')
            out[f] = None
        if out[f] is not None and out[f] < 0:
            conflicts.append(f'{FIELDS[f]} negativa.')
            out[f] = None
    if out['fp'] is not None and not 0 < out['fp'] <= 1:
        if 1 < out['fp'] <= 100:
            out['fp'] = out['fp'] / 100
            notes.append('Fator de potência em porcentagem convertido para fração.')
        else:
            conflicts.append('Fator de potência fora do intervalo (0; 1].')
            out['fp'] = None
    if out['fs'] is not None and not 0 <= out['fs'] <= 1:
        conflicts.append('Fator de simultaneidade fora do intervalo [0; 1].')
        out['fs'] = None
    if out['comprimento'] is not None and out['comprimento'] <= 0:
        conflicts.append('Comprimento deve ser maior que zero.')
        out['comprimento'] = None
    for f in ('sec_f', 'sec_n', 'sec_pe'):
        if out[f] is not None and not any(abs(out[f] - s) < 1e-9 for s in SECOES):
            conflicts.append(f'{FIELDS[f]}: {str(out[f]).replace(".", ",")} mm² não é uma seção nominal.')
            out[f] = None
    # ligação e distribuição da potência por fase
    per_phase = [out[k] for k in ('p_r', 'p_s', 'p_t')]
    used = [k for k, v in zip('RST', per_phase) if v]
    if not out['ligacao'] and used:
        out['ligacao'] = {1: 'Monofásico', 2: 'Bifásico', 3: 'Trifásico'}[len(used)]
        notes.append(f'Ligação deduzida das fases com carga: {out["ligacao"]}.')
    if not out['ligacao']:
        missing.append('Ligação (mono/bi/trifásico) — o circuito será criado como monofásico; revise.')
        out['ligacao'] = 'Monofásico'
    n = topologia.PHASES[out['ligacao']]
    if any(v is not None for v in per_phase):
        if len(used) > n:
            conflicts.append(f'Carga em {len(used)} fase(s) para uma ligação {out["ligacao"].lower()}.')
        if out['potencia'] is not None:
            soma = sum(v or 0 for v in per_phase)
            if abs(soma - out['potencia']) > max(1.0, 0.01 * out['potencia']):
                conflicts.append(f'Soma das fases ({soma:,.0f} W) diferente da potência total ({out["potencia"]:,.0f} W).'.replace(',', '.'))
        out['p'] = {k: (v or 0) for k, v in zip('RST', per_phase)}
    elif out['potencia'] is not None:
        phases = _phases_for(d.get('fase'), out['ligacao'])
        each = out['potencia'] / len(phases)
        out['p'] = {k: (round(each, 2) if k in phases else 0) for k in 'RST'}
        notes.append(f'Potência total distribuída igualmente nas fases {", ".join(phases)}.')
    else:
        out['p'] = None
        missing.append('Potência — o circuito será criado sem carga.')
    if out['fp'] is None:
        missing.append('Fator de potência — será usado 1,00; revise.')
    if out['comprimento'] is None:
        missing.append('Comprimento — será usado 10 m; revise.')
    if out['sec_f'] is None:
        missing.append('Seção da fase — será usada 2,5 mm²; confira com os critérios de dimensionamento.')
    if out['disjuntor'] is not None:
        notes.append(f'Disjuntor do documento: {str(out["disjuntor"]).replace(".", ",")} A. A proteção é escolhida e conferida no EletroApp (Proteções).')
    # identidade e vínculo
    if not out['nome']:
        conflicts.append('Sem nome do circuito.')
    elif out['nome'] in ROOTS:
        conflicts.append('“Fonte” e “Transformador” são reservados para a origem.')
    if out['montante'] and out['montante'].casefold() == (out['nome'] or '').casefold():
        conflicts.append('O circuito não pode ser o próprio montante.')
    if not out['montante']:
        conflicts.append('Circuito a montante não informado: escolha o quadro que alimenta este circuito.')
    elif out['montante'] not in existing_names and out['montante'] not in file_names and out['montante'] not in ROOTS:
        conflicts.append(f'Montante “{out["montante"]}” não existe no projeto nem no documento.')
    elif out['montante'] in ROOTS:
        conflicts.append('Neste modelo, a ligação direta à fonte é reservada à entrada; vincule o circuito a um quadro existente.')
    if rec.get('confianca') is not None and rec['confianca'] < 0.7:
        notes.append(f'Leitura por IA com confiança baixa ({rec["confianca"]:.0%}); confira no documento.'.replace('.', ','))
    return out, conflicts, missing, notes


def _merge(records):
    """Une registros do mesmo circuito vindos de documentos diferentes; divergências viram conflito."""
    merged, order = {}, []
    for rec in records:
        key = _key(rec['dados'].get('nome'))
        if key not in merged:
            merged[key] = {**rec, 'dados': dict(rec['dados']), 'fontes': dict(rec['fontes']), 'divergencias': [],
                           'documentos': [rec['documento']], 'origens': [rec.get('origem')]}
            order.append(key)
            continue
        m = merged[key]
        if rec['documento'] in m['documentos']:
            m['divergencias'].append(f'Circuito repetido em {rec["documento"]} ({rec.get("origem")}).')
            continue
        m['documentos'].append(rec['documento'])
        m['origens'].append(rec.get('origem'))
        for f, v in rec['dados'].items():
            old = m['dados'].get(f)
            if old in (None, ''):
                m['dados'][f] = v
                m['fontes'][f] = rec['fontes'].get(f)
            elif _key(old) != _key(v) and _num(old) != _num(v):
                m['divergencias'].append(f'{FIELDS.get(f, f)}: “{old}” ({m["fontes"].get(f)}) × “{v}” ({rec["fontes"].get(f)}).')
        for u, v in (rec.get('unidades') or {}).items():
            m.setdefault('unidades', {}).setdefault(u, v)
    return [merged[k] for k in order]


def preview(project, raw, filename):
    """Lê um ou mais documentos e devolve a tabela para revisão (nada é gravado)."""
    files = []
    if filename.lower().endswith('.json') or raw[:1] == b'{':
        body = json.loads(raw or b'{}')
        for item in body.get('arquivos', [])[:6]:
            files.append((str(item.get('nome') or 'documento')[:120], base64.b64decode(item.get('conteudo') or '')))
    else:
        files.append((filename, raw))
    if not files:
        raise ValueError('Nenhum documento enviado.')
    records, infos = [], []
    for name, data in files:
        ext = os.path.splitext(name.lower())[1]
        if ext in ('.csv', '.txt'):
            r, i = tabular_records(read_csv(data, name), name)
        elif ext == '.xlsx':
            r, i = tabular_records(read_xlsx_values(data, name), name)
        elif ext in DOCUMENTS:
            r, i = ai_records(data, name)
        elif ext == '.dxf':
            raise ValueError('DXF ainda não é aceito; está previsto para uma etapa posterior. Use PDF, imagem, CSV ou XLSX.')
        else:
            raise ValueError(f'{name}: formato não aceito. Use CSV, XLSX, PDF ou imagem.')
        records += r
        infos.append(i)
    return build_rows(project, records, infos)


def build_rows(project, records, infos):
    existing = {project.raw(IDENT, f'B{r}'): r for r in project.active_rows()}
    merged = _merge(records)
    file_names = {str(m['dados'].get('nome')).strip() for m in merged if m['dados'].get('nome')}
    parents_in_file = {str(m['dados'].get('montante')).strip() for m in merged if m['dados'].get('montante')}
    rows = []
    for n, m in enumerate(merged, 1):
        data, conflicts, missing, notes = normalize(m, set(existing), file_names)
        conflicts = m['divergencias'] + conflicts
        exists = data['nome'] in existing
        if not data['natureza']:
            data['natureza'] = 'Distribuição' if data['nome'] in parents_in_file else 'Circuito final'
            notes.append(f'Natureza deduzida: {data["natureza"]}.')
        rows.append({'id': n, 'acao': 'ignorar' if conflicts else ('atualizar' if exists else 'incluir'), 'existe': exists,
                     'dados': data, 'fontes': m['fontes'], 'origem': ' · '.join(x for x in m['origens'] if x),
                     'documentos': m['documentos'], 'conflitos': conflicts, 'ausentes': missing, 'avisos': notes})
    _check_topology(project, rows, existing)
    novos = sum(1 for r in rows if r['acao'] == 'incluir')
    return {'documentos': infos, 'linhas': rows, 'campos': FIELDS, 'capacidade': {'livres': None, 'novos': novos},
            'resumo': {'total': len(rows), 'incluir': novos, 'atualizar': sum(1 for r in rows if r['acao'] == 'atualizar'),
                       'com_conflito': sum(1 for r in rows if r['conflitos'])},
            'aviso_capacidade': None}


def _check_topology(project, rows, existing):
    """Fases e esquema de aterramento entre montante e jusante, com dados do documento e do projeto."""
    by_name = {r['dados']['nome']: r for r in rows if r['dados']['nome']}

    def node(name):
        if name in by_name and by_name[name]['acao'] != 'ignorar':
            d = by_name[name]['dados']
            lig = d['ligacao']
            earth = d['aterramento'] or (project.raw(IDENT, f'F{existing[name]}') if name in existing else 'TN-S')
        elif name in existing:
            r = existing[name]
            lig, earth = project.raw(IDENT, f'E{r}'), project.raw(IDENT, f'F{r}')
        else:
            return None
        n = topologia.PHASES.get(lig)
        if not n:
            return None
        tipo = f'{n}F+' + ('PEN' if earth == 'TN-C' else 'N+T')
        return {'name': name, 'tipo': tipo}
    for r in rows:
        d = r['dados']
        if not d['nome'] or not d['montante'] or d['montante'] in ROOTS:
            continue
        me, up = node(d['nome']), node(d['montante'])
        if me is None:
            me = {'name': d['nome'], 'tipo': f"{topologia.PHASES[d['ligacao']]}F+" + ('PEN' if d['aterramento'] == 'TN-C' else 'N+T')}
        if up is None:
            continue
        problems = topologia.check(me, up)
        if problems:
            r['conflitos'] += problems
            r['acao'] = 'ignorar'
    # ciclos dentro do documento
    for r in rows:
        seen, cur = set(), r['dados']['nome']
        while cur in by_name and cur not in seen:
            seen.add(cur)
            cur = by_name[cur]['dados']['montante']
        if cur in seen and cur is not None:
            r['conflitos'].append('Os vínculos do documento formam um ciclo.')
            r['acao'] = 'ignorar'


# ---------------------------------------------------------------- gravação
def _changes(r, d, creating):
    ch = [('E', IDENT, d['ligacao']), ('M', IDENT, d['natureza'])]
    if d.get('descricao') is not None:
        ch.append(('C', IDENT, d['descricao']))
    if d.get('aterramento'):
        ch.append(('F', IDENT, d['aterramento']))
    if d.get('p'):
        ch += [('D', LOAD, d['p']['R']), ('H', LOAD, d['p']['S']), ('L', LOAD, d['p']['T'])]
    fp = d.get('fp')
    if fp is not None:
        ch += [('E', LOAD, fp), ('I', LOAD, fp), ('M', LOAD, fp)]
    elif creating:
        ch += [('E', LOAD, 1), ('I', LOAD, 1), ('M', LOAD, 1)]
    if d.get('comprimento') is not None:
        ch.append(('F', DATA, d['comprimento']))
    if d.get('fs') is not None:
        ch.append(('H', DATA, d['fs']))
    for k, col in (('sec_f', 'T'), ('sec_n', 'W'), ('sec_pe', 'Z')):
        v = d.get(k) if d.get(k) is not None else (d.get('sec_f') if k != 'sec_f' and creating and d.get('sec_f') is not None else None)
        if v is not None:
            ch.append((col, SEC, v))
    return [{'sheet': s, 'address': f'{c}{r}', 'value': v} for c, s, v in ch]


def apply(project, rows, options=None):
    """Grava as linhas revisadas. Revalida tudo: o que vem do navegador não é confiável."""
    if not isinstance(rows, list) or len(rows) > MAX_ROWS:
        raise ValueError('Lista de circuitos inválida.')
    existing = {project.raw(IDENT, f'B{r}'): r for r in project.active_rows()}
    records = []
    for row in rows:
        if not isinstance(row, dict) or row.get('acao') not in ('incluir', 'atualizar'):
            continue
        dados = row.get('dados') or {}
        raw = {k: dados.get(k) for k in ('nome', 'descricao', 'montante', 'ligacao', 'natureza', 'aterramento', 'fp', 'fs',
                                          'comprimento', 'sec_f', 'sec_n', 'sec_pe', 'disjuntor')}
        p = dados.get('p') or {}
        raw.update(p_r=p.get('R'), p_s=p.get('S'), p_t=p.get('T'))
        records.append({'dados': {k: v for k, v in raw.items() if v not in (None, '')}, 'fontes': {}, 'documento': 'revisão',
                        'origem': None, 'unidades': {}, 'acao': row['acao']})
    if not records:
        raise ValueError('Nenhum circuito selecionado para gravar.')
    file_names = {str(r['dados'].get('nome')).strip() for r in records}
    prepared = []
    for rec in records:
        d, conflicts, _, _ = normalize(rec, set(existing), file_names)
        if conflicts:
            raise ValueError(f'{d.get("nome") or "Linha"}: ' + ' '.join(conflicts))
        if rec['acao'] == 'atualizar' and d['nome'] not in existing:
            raise ValueError(f'{d["nome"]}: não existe no projeto para ser atualizado.')
        if rec['acao'] == 'incluir' and d['nome'] in existing:
            raise ValueError(f'{d["nome"]}: já existe no projeto; escolha “atualizar”.')
        prepared.append((rec['acao'], d))
    novos = [d for a, d in prepared if a == 'incluir']
    # pais antes dos filhos
    pending = {d['nome']: d for d in novos}
    ordered, guard = [], 0
    while pending and guard < 1000:
        guard += 1
        for name, d in list(pending.items()):
            if d['montante'] not in pending:
                ordered.append(d)
                pending.pop(name)
    if pending:
        raise ValueError('Os vínculos do documento formam um ciclo: ' + ', '.join(pending))
    existing_uid = {name: project.meta['ids'][str(r)] for name, r in existing.items()}
    uids = {}
    for d in ordered:
        uids[d['nome']] = project.add(d['nome'], d['montante'], reselect=False)
    changes = []
    for action, d in prepared:
        r = project.row_for(uids[d['nome']] if action == 'incluir' else existing_uid[d['nome']])
        changes += _changes(r, d, action == 'incluir')
        if action == 'atualizar' and d['montante'] != project.raw(IDENT, f'D{r}'):
            changes.append({'sheet': IDENT, 'address': f'D{r}', 'value': d['montante']})
    touched = [uids[d['nome']] for d in ordered] + [existing_uid[d['nome']] for a, d in prepared if a == 'atualizar']
    for i in range(0, len(changes), 900):
        project.update(changes[i:i + 900], validate_installation=False)
    for uid in touched:
        project.complete_installation(project.row_for(uid))
    project.engine.clear()
    from . import selection
    selection.apply(project)
    return {'incluidos': len(ordered), 'atualizados': sum(1 for a, _ in prepared if a == 'atualizar'),
            'ids': [uids[d['nome']] for d in ordered]}

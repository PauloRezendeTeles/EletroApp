"""Escolhas automáticas explícitas, persistentes e reversíveis por circuito.

Só usa dados numéricos aplicáveis do catálogo. Uma seleção não confirma
seletividade, tempo TN ou declaração de fabricante em nome do projetista.
"""
import math
import re
from . import motors, dps_patch, trecho

SHEET='Escolhas (EletroApp)'
P='Cálc-Prot_Cabos'
D='DPS'
AUTO='Automático'
MANUAL='Manual'
KEYS={'protecao':'Disjuntor / proteção','dps':'DPS','backup':'Backup do DPS','manutencao':'Disjuntor de manutenção'}
T=trecho.SHEET
TC=trecho.COL

def install(data):
    cells=data['sheets'][D]['cells']
    if 'BS1' in cells:return
    previous='BR1' in cells
    cells['BR1']={'value':'Modelo automático calculado pelo EletroApp','formula':False}
    cells['BS1']={'value':'Modo de escolha do backup (EletroApp)','formula':False}
    for r in range(2,102):
        cells.setdefault(f'BR{r}',{'value':None,'formula':False})
        cells[f'BS{r}']={'value':None,'formula':False}
        a=f'AV{r}';old=cells.get(a)
        if old and old.get('formula') and not previous:
            old['value']=f'=IF(LEFT($AT{r},6)="MANUAL",IF($AU{r}="","",$AU{r}),IF($BR{r}<>"",$BR{r},{old["value"][1:]}))'
        old=cells.get(f'BQ{r}')
        if old and old.get('formula'):
            old['value']=f'=IF(AND($BS{r}="Manual",$BP{r}=""),"—",{old["value"][1:]})'

def number(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)

def modes(p,r):
    uid=p.meta['ids'][str(r)]
    saved=p.meta.get('selection_modes',{}).get(uid,{})
    legacy={'protecao':AUTO if p.raw(P,f'CH{r}')=='USAR RECOMENDAÇÃO' else MANUAL,
            'dps':MANUAL if str(p.raw(D,f'AT{r}') or '').startswith('MANUAL') else AUTO,
            'backup':MANUAL if any(p.raw(D,f'{c}{r}') not in ('',None) for c in ('BI','BM','BP','BJ')) else AUTO,
            # v1.10: projetos anteriores não têm disjuntor de manutenção; um modelo já informado é escolha manual.
            'manutencao':MANUAL if p.raw(T,f"{TC['mb_modelo']}{r}") not in ('',None) else AUTO}
    return {k:saved.get(k,legacy[k]) for k in KEYS}

def fields(p,r):
    uid=p.meta['ids'][str(r)];values=modes(p,r)
    return [{'sheet':SHEET,'address':f'{k}:{uid}','label':v,'value':values[k],
             'formula':None,'numeric':False,'virtual':True,'strict':True,
             'options':[AUTO,MANUAL]} for k,v in KEYS.items()]

def update_mode(p,address,value):
    key,_,uid=address.partition(':')
    if key not in KEYS or value not in (AUTO,MANUAL):raise ValueError('Modo de escolha inválido.')
    r=p.row_for(uid)
    previous=modes(p,r)[key]
    p.meta.setdefault('selection_modes',{}).setdefault(uid,{}).update({key:value})
    # Mantém os valores adotados ao voltar para Manual.
    if key=='protecao':
        p.put(P,f'CH{r}','MANTER SELEÇÃO ATUAL')
        if previous!=value:p.put(P,f'CF{r}','PENDENTE')
    if key=='dps':
        if value==MANUAL:
            model=p.get(D,f'AV{r}')
            if model not in (None,'','—','N/A'):p.put(D,f'AU{r}',model)
        p.put(D,f'AT{r}','AUTOMÁTICO (RECOMENDADO)' if value==AUTO else 'MANUAL — OUTRO MODELO DO CATÁLOGO')
    if key=='backup':p.put(D,f'BS{r}',value)
    if key=='backup' and previous!=value and value==MANUAL and p.raw(D,f'BP{r}') in (None,''):
        choices=p.backup_fusivel(r)['candidatos']
        if choices:p.put(D,f'BP{r}',choices[0]['modelo'])
        if not p.raw(D,f'BI{r}'):p.put(D,f'BI{r}',dps_patch.BACKUP_FUS)

def _pole_count(p,r):
    circuit=p.get('Identificação dos circuitos',f'G{r}') or ''
    if circuit in ('1F+N+T','2F+T'):return '2P'
    if 'PEN' in circuit:return str(circuit[0])+'P'
    if circuit=='3F+T':return '3P'
    selected=re.match(r'^([1-4]P)',str(p.raw(P,f'BG{r}') or ''))
    if selected:return selected[1]
    return None

def breaker_candidates(p,r):
    # Icu ≥ Ik do quadro onde o disjuntor da origem fica instalado (v1.10).
    ib,iz,ik,ikmin,ip=[p.get(s,f'{c}{r}') for s,c in [(P,'D'),(P,'F'),(T,TC['ik_origem']),(P,'E'),(P,'I')]]
    voltage=p.get('Padrão de entrada','B135');poles=_pole_count(p,r)
    reason=[]
    for label,val in [('corrente de projeto',ib),('capacidade do cabo',iz),('curto-circuito máximo',ik),('curto-circuito mínimo',ikmin),('tensão da rede',voltage)]:
        if not number(val) or val<=0:reason.append('Informe / revise '+label+'.')
    if not poles:reason.append('Escolha o tratamento do neutro / número de polos.')
    reason.extend(p.installation.state(r)['issues'])
    # Um motor incompleto a jusante também impede uma escolha no alimentador.
    downstream={p.raw('Identificação dos circuitos',f'B{r}')};changed=True
    while changed:
        before=len(downstream)
        downstream.update(p.raw('Identificação dos circuitos',f'B{k}') for k in p.active_rows() if p.raw('Identificação dos circuitos',f'D{k}') in downstream)
        changed=len(downstream)>before
    for k in p.active_rows():
        if p.raw('Identificação dos circuitos',f'B{k}') in downstream:reason.extend(motors.issues(p,k))
    if reason:return {'items':[],'reason':' '.join(reason),'ib':ib,'iz':iz,'ik':ik,'poles':poles}
    if ib>iz:return {'items':[],'reason':'A corrente de projeto excede a capacidade do cabo. Revise os condutores.','ib':ib,'iz':iz,'ik':ik,'poles':poles}
    cat='Biblioteca_Proteções_WEG'
    rows={p.raw(cat,f'C{k}'):k for k in range(2,569)}
    out=[];minimum=1.2*ip if number(ip) and ip>0 else 0
    for model in p.weg_catalog():
        if model['polos']!=poles or model['somente_magnetico'] or not number(model['in_nominal']):continue
        k=rows[model['modelo']]
        icu=p.get(cat,f'AA{k}');rated=p.get(cat,f'AC{k}')
        if not number(icu) or icu<ik or not number(rated) or rated<voltage:continue
        defaults=p.protecao_padroes(model,ib);ir=defaults.get('Y')
        if not number(ir) or not ib<=ir<=iz:continue
        lo,hi=model['im_min'],model['im_max'];a=model.get('im_ajuste',{})
        if not number(lo) or not number(hi):continue
        if model['subclasse']=='fixo':
            if lo<minimum or hi>ikmin:continue
            defaults['Z']=lo
        else:
            if a.get('tipo')=='discreto':values=a.get('valores',[])
            elif a.get('tipo')=='discreto_ir':values=[round(x*ir,2) for x in a.get('mult_ir',[])]
            elif a.get('tipo')=='continuo':values=[max(lo,math.ceil(minimum))]
            else:continue # nunca inventa posições do dial
            viable=[v for v in values if lo<=v<=hi and minimum<=v<=ikmin]
            if not viable:continue
            trip=min(viable)
            if model['subclasse']=='eletronico':
                # Abertura temporizada exige estudo/curva. O instantâneo deve
                # garantir a detecção do Ik mínimo nesta seleção automática.
                ii=model.get('ii_fixo')
                if not number(ii) or ii<minimum or ii>ikmin:continue
                defaults.update(Z=ii,BX=trip)
            else:defaults['Z']=trip
        out.append({'modelo':model['modelo'],'familia':model['familia'],'classe':model['subclasse'],
                    'in':model['in_nominal'],'ir':ir,'icu':icu,'poles':poles,'ajustes':defaults})
    out.sort(key=lambda m:(m['ir'],m['in'] if number(m['in']) else float('inf'),m['classe']!='fixo',m['modelo']))
    return {'items':out,'reason':None if out else 'Nenhum modelo com dados suficientes atende simultaneamente polos, tensão, Ib ≤ Ir ≤ Iz, partida, Ik mínimo e Icu. Use Manual para revisar o projeto.',
            'ib':ib,'iz':iz,'ik':ik,'poles':poles}

def maintenance_candidates(p,r):
    """Disjuntores do catálogo WEG para a extremidade (jusante) do circuito.

    Mesmos critérios do disjuntor da origem, com duas diferenças: o Icu é
    comparado com o Ik no próprio ponto de instalação (fim do cabo) e Ir ≤ Iz só
    é exigido quando não há dispositivo na origem, caso em que este disjuntor é
    a proteção do cabo contra sobrecarga (NBR 5410, 5.3.4.2.2)."""
    ib,iz,ikmin,ip=[p.get(P,f'{c}{r}') for c in ('D','F','E','I')]
    ik=p.get('Cálc_Icc-Cond_Escolhido',f'S{r}')
    voltage=p.get('Padrão de entrada','B135');poles=_pole_count(p,r)
    protects=p.get(T,f"{TC['sem_origem']}{r}") is True
    base={'items':[],'ib':ib,'iz':iz,'ik':ik,'poles':poles,'protege_cabo':protects}
    reason=[]
    checks=[('corrente de projeto',ib),('curto-circuito máximo',ik),('curto-circuito mínimo',ikmin),('tensão da rede',voltage)]
    if protects:checks.append(('capacidade do cabo',iz))
    for label,val in checks:
        if not number(val) or val<=0:reason.append('Informe / revise '+label+'.')
    if not poles:reason.append('Escolha o tratamento do neutro / número de polos.')
    reason.extend(p.installation.state(r)['issues'])
    if reason:return {**base,'reason':' '.join(reason)}
    if protects and ib>iz:return {**base,'reason':'A corrente de projeto excede a capacidade do cabo. Revise os condutores.'}
    cat='Biblioteca_Proteções_WEG'
    rows={p.raw(cat,f'C{k}'):k for k in range(2,569)}
    out=[];minimum=1.2*ip if number(ip) and ip>0 else 0
    for model in p.weg_catalog():
        if model['polos']!=poles or model['somente_magnetico'] or not number(model['in_nominal']):continue
        k=rows[model['modelo']]
        icu=p.get(cat,f'AA{k}');rated=p.get(cat,f'AC{k}')
        if not number(icu) or icu<ik or not number(rated) or rated<voltage:continue
        defaults=p.protecao_padroes(model,ib);ir=defaults.get('Y')
        if not number(ir) or ir<ib or (protects and ir>iz):continue
        lo,hi=model['im_min'],model['im_max'];a=model.get('im_ajuste',{})
        if not number(lo) or not number(hi):continue
        adj={'mb_ir':ir,'mb_ii':None,'mb_isd':None,'mb_tsd':None}
        if model['subclasse']=='fixo':
            if lo<minimum or hi>ikmin:continue
            adj['mb_ii']=lo
        else:
            if a.get('tipo')=='discreto':values=a.get('valores',[])
            elif a.get('tipo')=='discreto_ir':values=[round(x*ir,2) for x in a.get('mult_ir',[])]
            elif a.get('tipo')=='continuo':values=[max(lo,math.ceil(minimum))]
            else:continue
            viable=[v for v in values if lo<=v<=hi and minimum<=v<=ikmin]
            if not viable:continue
            trip=min(viable)
            if model['subclasse']=='eletronico':
                ii=model.get('ii_fixo')
                if not number(ii) or ii<minimum or ii>ikmin:continue
                adj.update(mb_ii=ii,mb_isd=trip,mb_tsd=100)
            else:adj['mb_ii']=trip
        out.append({'modelo':model['modelo'],'familia':model['familia'],'classe':model['subclasse'],
                    'in':model['in_nominal'],'ir':ir,'icu':icu,'poles':poles,'ajustes':adj})
    out.sort(key=lambda m:(m['ir'],m['in'] if number(m['in']) else float('inf'),m['classe']!='fixo',m['modelo']))
    reason=None if out else ('Nenhum modelo com dados suficientes atende polos, tensão, Ib ≤ Ir'+(' ≤ Iz' if protects else '')+
                             ', partida, Ik mínimo e Icu no ponto. Use Manual para revisar o projeto.')
    return {**base,'items':out,'reason':reason}

def dps_catalog(p,r):
    manufacturer=p.raw(D,f'BH{r}') or 'SIEMENS'
    sheet='Biblioteca_DPS_Clamper' if manufacturer=='CLAMPER' else 'Biblioteca_DPS_Siemens'
    kind=p.get(D,f'J{r}');earthing=p.get(D,f'E{r}')
    circuit=p.get('Identificação dos circuitos',f'G{r}')
    poles={'1F+N+T':'2P','2F+T':'2P','2F+N+T':'3P','3F+N+T':'4P','3F+T':'3P','3F+PEN':'3P','1F+PEN':'1P','2F+PEN':'2P'}.get(circuit)
    umin=p.get(D,f'K{r}');upmax=p.get(D,f'L{r}');surge=p.get(D,f'M{r}')
    out=[]
    for k in range(2,25 if manufacturer!='CLAMPER' else 14):
        v=lambda c:p.get(sheet,f'{c}{k}')
        code=v('D')
        if not code:continue
        notes=[]
        if v('E')!=kind:notes.append('classe diferente')
        if v('F')!=poles:notes.append('polos diferentes')
        if v('H')!=earthing:notes.append('aterramento diferente')
        # v2.2.0: a biblioteca Siemens tem Uc (K) e Up (L) nas colunas certas, e as colunas Y/Z leem o Iimp/In por polo,
        # fase ou modo. A seleção lê os mesmos valores extraídos (W, X, Y, Z) que as fórmulas, sem regra própria.
        # Valor ausente fica "a confirmar".
        uc,up,current=v('W'),v('X'),v('Y' if '1+2' in str(kind) else 'Z')
        if not number(uc) or not number(umin):notes.append('Uc a confirmar')
        elif uc<umin:notes.append('Uc insuficiente')
        if not number(up) or not number(upmax):notes.append('Up a confirmar')
        elif up>upmax:notes.append('Up superior ao limite')
        if not number(current) or not number(surge):notes.append('Iimp/In a confirmar')
        elif current<surge:notes.append('Iimp/In insuficiente')
        out.append({'modelo':code,'row':k,'fabricante':manufacturer,'classe':v('E'),'polos':v('F'),
                    'uc':uc,'up':up,'corrente':current,'compatible':not notes,'notes':notes})
    return out

def dps_status(p,r):
    if str(p.raw(D,f'BT{r}') or '').startswith('NÃO'):
        return 'Sem DPS neste quadro (definido pelo projetista).'
    if p.get(D,f'J{r}')=='—':return 'Não aplicável: pela regra r42, circuito final não recebe DPS.'
    current=p.get(D,f'AV{r}');item=next((x for x in dps_catalog(p,r) if x['modelo']==current),None)
    if not item:return 'Pendente: escolha um modelo do catálogo para este circuito.'
    if not item['compatible']:
        msg='Pendente: '+', '.join(item['notes'])+'.'
        if all(n.endswith('a confirmar') for n in item['notes']):
            # v2.2.0: mesma leitura das fórmulas (colunas W/X/Y/Z do catálogo). Texto com mais de um valor
            # (por modo de ligação) ou sem valor não é extraído: o projetista confirma na ficha do modelo.
            msg+=' O catálogo não traz valor único para este modelo (valores por modo de ligação ou ausentes); confira a ficha técnica.'
        return msg
    if modes(p,r)['backup']==MANUAL:
        col='BM' if p.raw(D,f'BI{r}')==dps_patch.BACKUP_DISJ else 'BP'
        if not p.raw(D,f'{col}{r}'):return 'Pendente: selecione o dispositivo de backup no modo manual.'
    status=p.get(D,f'AS{r}')
    if not number(p.get(D,f'AJ{r}')):
        return 'Pendente: confirmar Isccr do conjunto DPS + backup com o fabricante. '+str(status or '')
    return status

def apply(p):
    """Roda depois das entradas/topologia, nunca a partir de um resultado de UI."""
    log=p.meta.setdefault('selection_results',{})
    for r in p.active_rows():
        uid=p.meta['ids'][str(r)];mode=modes(p,r);result={}
        # É chamado depois de uma edição/prévia, nunca ao abrir o projeto.
        # Congela o modo inferido ANTES de preencher um modelo automático.
        active=mode
        p.meta.setdefault('selection_modes',{})[uid]=dict(mode)
        p.put(D,f'BS{r}',mode['backup'])
        sem_origem=p.get(T,f"{TC['sem_origem']}{r}") is True
        from . import protection_links
        if protection_links.requested(p,r):
            result['protecao']='Disjuntor vinculado: modelo e ajustes pertencem ao quadro precedente.'
        elif active.get('protecao')==AUTO and sem_origem:
            # Sem dispositivo na origem: a escolha automática não se aplica e os dados são preservados.
            result['protecao']='Sem dispositivo na origem: a seleção automática do disjuntor da origem não se aplica.'
        elif active.get('protecao')==AUTO:
            cand=breaker_candidates(p,r);best=next(iter(cand['items']),None)
            result['protecao']=cand['reason'] or 'Modelo e ajustes selecionados pelos dados atuais. Revise as verificações de proteção abaixo.'
            p.put(P,f'CH{r}','MANTER SELEÇÃO ATUAL')
            if best:
                for c,value in {'AL':best['familia'],'AM':best['modelo'],'J':'Disjuntor_C - In <= 63A' if best['in']<=63 else 'Disjuntor_C - In > 63A',**best['ajustes']}.items():p.put(P,f'{c}{r}',value)
            else:
                for c in ('AL','AM','K','Y','Z','BX','BZ','CA'):p.put(P,f'{c}{r}',None)
            p.engine.clear()
        if active.get('dps')==AUTO:
            p.put(D,f'AT{r}','AUTOMÁTICO (RECOMENDADO)');p.put(D,f'AU{r}',None)
            p.engine.clear()
            catalog=dps_catalog(p,r)
            compatible=[x for x in catalog if x['compatible']]
            # v1.10: um dado ausente no catálogo ("a confirmar") não é incompatibilidade. Sem modelo
            # plenamente confirmado, mantém o melhor candidato e a pendência fica visível no status.
            if not compatible:compatible=[x for x in catalog if x['notes'] and all(n.endswith('a confirmar') for n in x['notes'])]
            p.put(D,f'BR{r}',compatible[0]['modelo'] if compatible else 'N/A' if p.get(D,f'J{r}')=='—' else 'SEM MODELO COMPATÍVEL')
            p.engine.clear()
            result['dps']=dps_status(p,r)
        if active.get('manutencao')==AUTO and p.get(T,f"{TC['tem_mb']}{r}") is True:
            cand=maintenance_candidates(p,r);best=next(iter(cand['items']),None)
            result['manutencao']=cand['reason'] or 'Modelo e ajustes do disjuntor de manutenção selecionados pelos dados atuais.'
            values={'mb_familia':best['familia'],'mb_modelo':best['modelo'],**best['ajustes']} if best else {k:None for k in ('mb_familia','mb_modelo','mb_ir','mb_ii','mb_isd','mb_tsd')}
            for k,value in values.items():p.put(T,f"{TC[k]}{r}",value)
            p.engine.clear()
        if active.get('backup')==AUTO and p.get(D,f'J{r}')=='—':
            result['backup']='Não se aplica: sem DPS neste quadro.'
        elif active.get('backup')==AUTO:
            p.put(D,f'BI{r}',dps_patch.BACKUP_FUS);p.put(D,f'BM{r}',None);p.put(D,f'BJ{r}',None);p.put(D,f'BP{r}',None)
            p.engine.clear()
            eligible=p.backup_fusivel(r)['candidatos']
            voltage=p.get('Padrão de entrada','B135');limit=p.get(D,f'AH{r}');ik=p.get(D,f'Q{r}')
            if number(voltage) and voltage<=500 and number(limit) and number(ik) and eligible:
                p.put(D,f'BP{r}',eligible[0]['modelo'])
                result['backup']='Fusível escolhido pelo limite do DPS e pela corrente de curto-circuito. Confirme a ficha do produto adquirido.'
            else:
                # Um código impossível desativa a procura automática legada;
                # evita que o formulário mostre um backup velho como válido.
                p.put(D,f'BP{r}','SEM BACKUP COMPATÍVEL')
                result['backup']='Pendente: não há backup com dados suficientes para a tensão, Ik e limite do DPS.'
            p.engine.clear()
        if active:log[uid]=result

def form_info(p,r):
    return {'modes':modes(p,r),'results':p.meta.get('selection_results',{}).get(p.meta['ids'][str(r)],{}),
            'breakers':breaker_candidates(p,r),'dps_catalog':dps_catalog(p,r),'dps_status':dps_status(p,r),
            'maintenance':maintenance_candidates(p,r),'trecho':trecho.state(p,r),
            'motor_issues':motors.issues(p,r),
            'dps_summary':{key:p.get(D,f'{col}{r}') for key,col in [('modelo','AV'),('tipo','J'),('backup','AF'),('limite','AH'),('ik','Q'),('icu','AI')]}}

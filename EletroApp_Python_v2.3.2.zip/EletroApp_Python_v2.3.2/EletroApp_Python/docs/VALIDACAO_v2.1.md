# Validação — EletroApp 2.1.0

Data: 07/10/2026. Resposta aos 13 achados da análise técnica da versão 2.0.0. Para cada achado: a correção e o teste que reproduz o caso da análise.

| Nº | Achado | Correção | Teste (`tests/test_v21.py`) |
|---:|---|---|---|
| 1 | Coordenação usava o In do campo antigo (500 A) | Descrição única do dispositivo efetivo a partir do modelo escolhido (In de sensor/frame, característica e curva B/C/D da biblioteca); divergências viram pendência do circuito | `F01EffectiveDevice` — In = 80 A, ponto de 10 × In = 800 A |
| 2 | Tempo mínimo ausente tratado como não atuação | Montante sem tempo mínimo ou jusante sem tempo máximo → indeterminado; cai para a aproximação com o motivo na trilha | `test_missing_minimum_time_is_not_favorable_evidence` |
| 3 | Extrapolação além do último ponto | Envelope sem valor fora do domínio; resultado “verificada só até o limite indicado” | `test_no_extrapolation_beyond_documented_points` — curvas até 200 A → limitada a 0,2 kA |
| 4 | Cruzamento perdido pela amostragem | Comparação exata em todos os vértices das duas curvas e nos segmentos (log-log), com localização do cruzamento por bisseção; região instantânea (< 10 ms) não é demonstrada por curvas | `test_crossing_between_vertices_is_detected` — cruzamento entre 990 e 995 A; `test_instantaneous_region_is_not_proven_by_curves` |
| 5 | Dados vinculados só pelo nome do modelo | Condições de validade (tensão, Ir, Isd, tsd, Ii, I²t) por linha da tabela e por curva; nível verificado só com condições presentes e coincidentes; `T` limitado ao Icu do jusante | `F05Conditions` — 380 V × 220 V, Ir 320 × 160 A, ajustes ausentes, `T` → 5 kA |
| 6 | Par origem × manutenção omitido | Sequência elétrica de dispositivos por circuito; pares consecutivos com o Ik do ponto correspondente | `F06SeriesPairs` |
| 7 | Migração por fórmula representativa | Comparação circuito a circuito; versões nos escopos comum, raiz e circuito; valores fixos preservados; não convertidas listadas como pendência com conferência do revisor; histórico completo da v1.x; variações conhecidas da r42 (`data/modelo/variantes_legado.json`) não viram alteração | `F07Migration` — P5 = 123456 só no QDFL-01; fórmula de P4 × 2 só no QGBT-01; referência a outra linha → pendência; histórico com duas versões |
| 8 | Projeto sem vínculo com a base | Manifesto verificável (variáveis, nomes, cada tabela, regras, código) gravado no projeto; retrato de cada base guardado no banco; comparação de resultados e adoção registrada | `F08BaseManifest` — expressão de referência trocada para `=777` é apontada, comparada e adotada com registro |
| 9 | Dados de coordenação fora da integridade | Selo nos registros de fabricante; registro sem selo válido aparece na integridade e é desconsiderado | `F09ManufacturerDataIntegrity` |
| 10 | Edição comum substituía a variante da fonte | Escopo `raiz` com versões próprias; a edição comum não altera os circuitos ligados à fonte | `F10Variants` — IFERROR na expressão comum mantém 0,007986 Ω no circuito raiz |
| 11 | Base editável desconectada da regra | Uso de cada tabela calculado a partir das expressões e das regras Python; tabelas documentais (Tabela 33, ajuda de métodos) e posições sem uso não são editáveis; regras operacionais listadas com resumo | `F11OperationalTables` |
| 12 | IDs duplicados aceitos | Identificador e nome repetidos recusam a abertura do arquivo | `F12DuplicateIds` |
| 13 | Regras Python sem resultados | Saídas e efeitos declarados por regra; consulta da aplicação a um circuito (`/api/rule`) | `F13PythonRules` |

## Resultados

- `python -m unittest discover -s tests` — **210 testes, todos passando**.
- Paridade com a v1.12 (`tools/paridade.py`, 7 cenários): mesmas 31 diferenças conhecidas da 2.0.0; as correções não mudaram cálculos.
- Interface conferida em navegador: variante da fonte no catálogo, aplicação de regra a um circuito, coordenação com importação de condições, base técnica com tabelas documentais, integridade com base de cálculo e conversões pendentes.

## Limites que permanecem

- Os adaptadores internos por grupo/posição e o interpretador de fórmulas continuam como camada de compatibilidade; não afetam o funcionamento independente.
- Regras em Python são consultáveis e rastreáveis, mas não editáveis como expressões.
- A comparação com uma base anterior reproduz as diferenças de dados (variáveis e tabelas); mudanças no código das regras são identificadas pelo resumo, mas não podem ser recalculadas com o código antigo.
- Conferência normativa das tabelas e das referências continua pendente, como declarado na base técnica.

# EletroApp 2.1.2 — instalação e ampacidade

Revisão de 09/10/2026. A correção parte da versão 2.1.1 entregue e do diagnóstico reproduzido na categoria Eletrocalha.

## Correções

1. **Validação térmica própria.** `Installation.state()` distingue `ampacity_valid` e `ampacity_issues` da validade geral. A tabela de ampacidade e o fator de agrupamento usam a validação térmica. A ausência ou incompatibilidade do arranjo de impedância não suprime um cálculo térmico disponível; o cálculo de impedância e a conclusão/salvamento da instalação continuam exigindo o arranjo correto.
2. **Prévia do quadro de seções.** `previewWorkflow()` incorpora os novos critérios e renderiza novamente o quadro visível de fase, neutro e PE. As respostas superadas por novas edições ou pela abertura de outro circuito são descartadas.
3. **Troca de fases.** A mudança do tipo de ligação aciona a atualização das opções de instalação. As disposições incompatíveis com o novo número de condutores carregados são reconciliadas; a confirmação geométrica anterior não é reaproveitada quando seu contexto muda.
4. **Diagnóstico estruturado.** O ramo de erro de oito expressões de consulta chama `AMPACITYERROR`, mantendo as consultas numéricas `INDEX/MATCH` existentes. A pendência de instalação ou de uma dependência é preservada; seção e corrente sem correspondência têm mensagens próprias. Esses erros propagam-se como erros estruturados, sem virar texto submetido a multiplicação.
5. **Causa preservada na interface.** O quadro de comparação mantém o diagnóstico específico de cada cálculo. O aviso geral de instalação não sobrescreve um erro de corrente fora da tabela, por exemplo.
6. **Compatibilidade e rastreabilidade.** As expressões permanecem editáveis. Fórmulas personalizadas e históricos são conservados na gravação/reabertura; as expressões originais anteriores são reconhecidas na conversão de projetos da v1.x. A nova base e o código são identificados pelo mecanismo existente de versões e integridade.

As relações de instalação, os valores das tabelas de ampacidade e os fatores numéricos de agrupamento não foram alterados nesta revisão.

## Todas as combinações do catálogo

A varredura cobre os seguintes eixos finitos do cadastro:

| Eixo | Cobertura |
|---|---|
| Tipo de linha | 32 tipos |
| Montagem e cabo | 94 relações, com 56 códigos de montagem distintos |
| Condutores carregados | 2 e 3 |
| Material | Cobre e alumínio |
| Isolação do condutor isolado | PVC e LSHF/A |
| Isolação do cabo unipolar/multipolar | PVC, EPR, HEPR e XLPE |
| Disposição | N/A; justapostos/trifólio em F; horizontal/vertical em G, conforme o número de condutores |
| Arranjo de impedância | Todas as opções oferecidas para cada combinação |

**Condições de referência do ensaio:** ar a 30 °C; solo a 20 °C, resistividade 2,5 K·m/W e profundidade 0,70 m quando aplicável; um conjunto no trecho e um condutor por polo. Os casos de alumínio usam estabelecimento industrial, atendimento pelo transformador do exemplo e pessoal qualificado. As condições geométricas exigidas são explicitamente confirmadas nos dados sintéticos.

| Verificação | Resultado |
|---|---:|
| Cenários da matriz completa | 1.816 |
| Combinações com cálculo numérico validado | 1.744 |
| Bloqueios esperados e identificados | 72 |
| Divergências inesperadas na matriz | 0 |
| Relações incompatíveis linha × montagem × cabo rejeitadas | 5.282 |
| Cenários pela API, 94 relações × 2 números de carregados | 188 |

Os **72 bloqueios esperados** correspondem ao método G com dois condutores carregados, cruzado com os materiais, isolações, disposições e arranjos oferecidos. A base não contém coluna de ampacidade para esses casos de cabos isolados. A aplicação identifica a limitação e pede cálculo específico; não usa uma coluna de três condutores ou de outro método como substituta.

Na matriz calculável, a seção mínima por ampacidade e sua capacidade são confrontadas com uma busca independente nas células da coluna selecionada. A Iz do condutor escolhido é confrontada com essa coluna e os fatores aplicáveis. Esse ensaio verifica seleção e cálculo com os dados da base; não equivale a uma nova conferência normativa de cada célula.

O arquivo `matriz_instalacoes_v2.1.2.csv` registra todas as 1.816 linhas, incluindo entradas, tabela selecionada, seção calculada, ampacidades e resultado. Os 5.282 casos incompatíveis completam o produto de 32 linhas × 56 montagens × 3 tipos de cabo, descontadas as 94 relações cadastradas.

## Regressões funcionais

- Falta de arranjo: ampacidade numérica, impedância pendente e salvamento recusado sem alteração da revisão.
- Arranjo compatível preenchido: salvamento aceito e resultados numéricos.
- Método, cabo ou isolação incompatível, quantidade inválida, agrupamento pendente, geometria não confirmada e proibição de alumínio: bloqueios mantidos.
- Erros preservados na seção de fase, neutro e cadeia de Iz.
- Seção e corrente fora da tabela: diagnóstico específico, sem `#VALUE!` causado por mensagens textuais.
- Conversão das expressões originais e conservação de fórmula personalizada após exportar/reabrir.
- Função JavaScript original da prévia executada com respostas reais do motor e DOM mínimo simulado, incluindo respostas obsoletas.
- Evento original de mudança de ligação executado em JavaScript para confirmar a atualização das escolhas de instalação.

O teste antigo que fixava a versão das regras em `2.0.0` foi atualizado para conferir a versão efetiva do aplicativo. O histórico do catálogo distingue a revisão 2.1.1 da revisão 2.1.2; nenhuma expectativa numérica foi relaxada nessa atualização de metadados.

Não foi executada inspeção visual em navegador: o ambiente não dispõe do binário Chromium. A verificação funcional da interface usa JavaScript, respostas reais e DOM simulado, além dos contratos HTTP.

## Como repetir

Suíte completa, incluindo as versões anteriores:

```bash
python -m unittest discover -s tests -v
```

Gerar novamente a matriz:

```bash
python -m tests.installation_matrix --output docs/matriz_instalacoes_v2.1.2.csv
```

O teste funcional JavaScript requer Node somente no ambiente de testes; o aplicativo continua precisando apenas de Python e navegador para uso normal. O resultado final da suíte e da abertura do pacote está em `RESULTADO_TESTES.txt`.

## Atualização

Feche o aplicativo anterior, extraia esta versão em uma nova pasta e transfira a pasta `projetos` inteira para conservar projetos, revisões e bases. O ZIP não inclui banco de projetos pessoais. Fórmulas personalizadas mantidas pelo usuário continuam prevalecendo sobre a fórmula padrão; eventuais mensagens antigas em uma expressão personalizada podem ser conferidas no catálogo.

O escopo “todas as combinações” refere-se aos eixos do catálogo acima. Temperaturas, correntes, quantidades de circuitos, dimensões e fórmulas editadas admitem outros valores; não constituem um universo finito esgotado por essa matriz. Os controles de agrupamento e das demais condições também são exercitados pela suíte de regressão existente.

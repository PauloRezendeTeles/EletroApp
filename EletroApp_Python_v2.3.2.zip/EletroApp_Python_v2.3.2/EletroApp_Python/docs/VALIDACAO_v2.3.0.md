# EletroApp 2.3.0 — implementação e validação

Data: 13/10/2026. Base de trabalho: pacote 2.2.1, mantendo as correções de UTF-8 no Windows e de queda de tensão pendente.

## Entregas

- Perfis de proteção MT por elo fusível ou relé 50/51/50N/51N, com correntes, tempos, curvas e interrupção do disjuntor.
- Limite da medição para rede BT e indicação de proteção externa não verificável.
- Quadro de transferência e seus dados de disjuntor; trecho anterior atribuído ao fabricante do gerador.
- Curto inicial preservado; evolução I(t) por parâmetros ou curvas documentadas por ponto; integração de atuação e energia térmica.
- Relação da proteção de saída com o quadro precedente; vínculo de um mesmo disjuntor com identidade única, sem duplicar cadastro, símbolo ou par de seletividade.
- Formulários condicionais, gráficos I(t), unifilar, relatório e variáveis/regras no catálogo rastreável.
- Migração de fórmulas originais reconhecida; entradas, edições particulares e históricos preservados.

Os métodos, dados de entrada e limites estão detalhados em `PROTECOES_v2.3.0.md`. Esta versão não inclui curvas fictícias de fabricante.

## Resultados dos testes

**328 testes distintos verificados com êxito.**

1. Suíte completa: **326 testes, todos aprovados, em 363,439 s**. Registro: `testes_v2.3.0.log`.
2. Depois foram acrescentados dois testes: comportamento dos formulários/SVG e coeficientes térmicos do PEN pela seção física comum. Também foram ajustados o reconhecimento da base de cálculo nas confirmações de I(t) e o tratamento da seção comum do PEN.
3. Repetição final dos grupos afetados, incluindo todos os 25 testes novos da 2.3.0, os 9 testes da 2.2.1 e os 13 de migração/histórico: **47 testes, todos aprovados, em 34,435 s**, com erro obrigatório para leituras sem codificação explícita. Registro: `testes_v2.3.0_reteste_final.log`.

Comandos:

```sh
python -m unittest discover -s tests -v
python -X warn_default_encoding -W error::EncodingWarning -m unittest tests.test_v230 tests.test_v221 tests.test_v21.F07Migration tests.test_v211.MigrationRegression -v
```

A suíte da versão distribuída contém os 328 testes, inclusive os dois adicionados após a execução completa.

## Ensaios novos

| Área | Conferência |
| --- | --- |
| Relé + disjuntor | 0,30 s de atuação + 0,06 s de interrupção = 0,36 s; tempo atualizado nas verificações, seção sugerida e relatório |
| Curvas IEC | Comparação com solução analítica para corrente constante: inversa normal, muito inversa e extremamente inversa |
| Curto decrescente | Corrente inicial acima da partida que cai antes do retardo não confirma atuação |
| Retenção do comando | Comando emitido antes da queda da corrente mantém a abertura; curva precisa cobrir a interrupção completa |
| Reset | Interrupções de corrente abaixo da partida não somam indevidamente retardo de tempo definido |
| Integral térmica | Comparação com integrais analíticas de correntes constantes e lineares |
| Fusível | Interpolação logarítmica, validação dos pontos, proibição de extrapolação e perda de confirmação ao mudar o elo |
| Dyn e funções N | Corrente residual primária zero para falta à terra secundária; função N isolada não comprova proteção |
| Rede BT | Trechos até a medição não verificáveis; identidade da medição preservada após renomear |
| Gerador | Sem dados temporais: mantém curto inicial, não aprova temporização; cabo até transferência atribuído ao fabricante |
| I(t) documentada | Ensaio com eliminação em 0,16 s; curva decrescente de outro ensaio não atua no horizonte |
| Modelo por parâmetros | Corrente em t=0 compatível com o cálculo inicial; decaimento preservando a impedância do cabo; resultado identificado como estimativa |
| Confirmação da curva | Trocar cabo invalida; renomear e salvar/reabrir conserva; reordenar mantém os pontos no circuito correto |
| Vínculo físico | Ajuste do precedente aparece no alimentador; edição por cadastro duplicado bloqueada; não há par de um disjuntor consigo mesmo |
| Derivação nova | Invalida vínculo de saída única; não volta a usar os antigos ajustes do alimentador |
| Primeiro dispositivo | Par MT×BT usa o disjuntor de chegada quando esse é o primeiro equipamento efetivo |
| PEN | k térmico do neutro/PE usa a seção comum adotada, inclusive na passagem acima de 300 mm² |
| API/persistência | Novos campos salvam com revisão; entrada inválida é recusada sem gravação parcial; dados aparecem no relatório |
| Formulários | Campos por perfil/função; CSV multilinha; seleção do QTA por identidade; ocultação do cadastro vinculado; abertura visível para disjuntor de saída do gerador |
| SVG e texto | Diagramas vertical/horizontal sem NaN/undefined; vínculo sem símbolo duplicado; texto escapado antes de gerar HTML |

Todos os dados usados nos ensaios de proteção são sintéticos e estão identificados assim nos testes. Eles não são configurações recomendadas para uma instalação.

## Ajustes nas expectativas de testes anteriores

As expectativas antigas que aceitavam somente o tempo manual de montante ou uma justificativa física como comprovação de curto/choque foram atualizadas: agora exigem dados da proteção efetiva. O tempo antigo continua salvo. A justificativa/condição física da dispensa continua sendo verificada e a condição “NÃO” continua reprovando.

Também foram atualizadas as expectativas de presença do novo grupo de formulário, pendência do elo MT no exemplo e existência do par MT×primeiro disjuntor. O exemplo não recebe uma curva presumida só para aparecer aprovado.

Os testes de migração que inicialmente detectavam novos campos como alterações particulares foram corrigidos no conversor de variantes: ausência das novas células em projetos v1.x é reconhecida como estado original. Os testes de preservação de edições particulares/histórico passaram integralmente.

## Ambiente e limites da validação

- Linux, Python 3.12; aplicativo continua usando apenas a biblioteca padrão do Python. Node é usado somente pelos testes de JavaScript.
- Validação de sintaxe dos arquivos Python e JavaScript alterados; API HTTP real com banco temporário e revisões.
- O ensaio CP1252 em processo separado cobre a falha de leitura relatada no Windows. Não foi executada sessão nativa de Windows/Python 3.14.
- Formulários testados com respostas reais do servidor e DOM mínimo; SVGs gerados e desenhos verticais inspecionados após renderização. A interface completa não foi exercitada em navegador neste ambiente: o navegador local não estava disponível e o navegador remoto não alcançou o servidor local.
- Não houve certificação normativa independente, ensaio físico de relé/disjuntor ou validação com curva de um equipamento real. As condições de excitação, memória dinâmica e energia passante que faltarem continuam explicitamente não verificadas.

O pacote não contém banco de dados nem projetos pessoais. Inclui o código, dados de referência do aplicativo, testes, guia de uso e registros da validação.

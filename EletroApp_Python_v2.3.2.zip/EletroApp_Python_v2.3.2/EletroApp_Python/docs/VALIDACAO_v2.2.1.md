# EletroApp 2.2.1 — correções de abertura e queda de tensão

Revisão do pacote EletroApp_Python_v2.2.0.zip enviado pelo usuário, em 12/10/2026 (America/Bahia).

## Falhas reproduzidas e correções

### 1. UnicodeDecodeError na abertura no Windows

`core/installation.py` carregava `data/installation_rules.json` com `Path.read_text()` sem codificação. O arquivo é UTF-8; a leitura em CP1252 reproduziu exatamente o erro informado: byte `0x9d`, posição `54148`.

A leitura agora especifica `encoding='utf-8'`. As outras leituras de texto do aplicativo já indicavam UTF-8. Duas leituras dos testes antigos de instalação e a captura de saída do subprocesso Node no teste da prévia JavaScript também passaram a indicar UTF-8 para evitar dependência da codificação padrão.

O ensaio automatizado usa um processo novo, desliga o modo UTF-8 do Python e simula CP1252 nas chamadas a `Path.read_text` que omitirem a codificação. Dentro desse processo, importa o aplicativo, cria e reabre o banco temporário, inicia o servidor HTTP e consulta a página inicial, os resultados, o relatório, o catálogo de instalação e a base técnica. As leituras explícitas em UTF-8 preservam os acentos.

### 2. Queda total indicada como excedida antes do cálculo

As fórmulas `queda.dv_v_instalacao_ok` e `queda.dv_v_trecho_ok` comparavam os operandos sem exigir que fossem números. Textos de pendência podiam resultar em aprovação ou reprovação indevida; erros de cálculo também impediam uma mensagem clara de pendência.

As duas fórmulas agora verificam o tipo dos operandos antes da comparação:

| Condição | Resultado |
| --- | --- |
| Circuito inexistente | Campo vazio |
| Queda ainda sem valor numérico | PENDENTE — queda total/do trecho não calculada |
| Limite ainda sem valor numérico | PENDENTE — limite total/do trecho não calculado |
| Queda e limite numéricos; queda ≤ limite | OK |
| Queda e limite numéricos; queda > limite | EXCEDE |

Valores zero são válidos. Texto numérico, booleano, vazio ou erro não são tratados como resultado calculado. No QDFL-01 e no QDFL-03 do exemplo, a auditoria da queda total passa a indicar `⏳ PENDENTE — queda total não calculada`. As pendências de instalação e suas causas continuam disponíveis. O cálculo físico da queda e os limites permanecem definidos pelas mesmas variáveis e tabelas da 2.2.0.

A mesma correção foi aplicada à verificação por trecho porque ela tinha a mesma comparação sem validação numérica. API, checklist e relatório consomem essas fórmulas e recebem o resultado corrigido.

## Compatibilidade e rastreabilidade

- As expressões continuam no modelo nativo, acessíveis para consulta e edição.
- As duas expressões anteriores foram registradas em `data/modelo/variantes_legado.json`, evitando classificá-las como alterações particulares ao converter projetos da v1.x.
- Fórmulas particulares em projetos nativos continuam prevalecendo, com seu estado de integridade. Uma fórmula que o usuário editou não é substituída por esta atualização.
- A versão apresentada no aplicativo, servidor e relatório é 2.2.1.
- A mudança de código e de fórmulas altera a identificação da base de cálculo. O fluxo existente de comparação e adoção da base permanece ativo para projetos salvos. Como o código mudou, a comparação histórica pode informar que não dispõe do código antigo.

## Ensaios

Os nove testes novos em `tests/test_v221.py` cobrem:

1. Abertura, API, relatório e persistência com simulação do padrão CP1252.
2. Queda ausente, vazia, textual, booleana ou com erro.
3. Limite ausente, vazio, textual, booleano ou com erro.
4. Resultados abaixo, exatamente no limite e acima dele, incluindo zero.
5. Linhas sem circuito.
6. Os dois circuitos reportados pelo usuário, no checklist e relatório.
7. Recalcular depois de completar a instalação, exceder o limite e tornar a instalação pendente novamente.
8. Conversão e reabertura de um projeto legado com as fórmulas originais.
9. Preservação de fórmula particular de projeto nativo após exportação e reabertura.

Comando da suíte completa:

```sh
python -X warn_default_encoding -W error::EncodingWarning -m unittest discover -s tests -v
```

A suíte executou 303 testes: 302 passaram e um foi interrompido por `EncodingWarning` no próprio teste da prévia JavaScript, que capturava a saída do Node sem codificação explícita. Esse subprocesso recebeu `encoding='utf-8'` e o único teste afetado passou na repetição isolada, sob a mesma verificação rigorosa de codificação. Nenhum código do aplicativo foi alterado entre as duas execuções. O registro original completo, inclusive essa ocorrência, está em `testes_v2.2.1.log`; a repetição está em `testes_v2.2.1_reteste_previa.log`. Os tempos medidos constam em `../RESULTADO_TESTES.txt`.

Comparação direta com o ZIP original, em processos separados: 6.411 valores por cenário (circuitos, fonte e projeto). Na abertura, houve 10 diferenças, todas nas mensagens das verificações de queda e nos respectivos resumos de auditoria de QDFL-01 e QDFL-03. Com a instalação completada e no cenário de queda efetivamente excedida (QDFL-01 com 500 m), não houve nenhuma diferença. Nenhum resultado numérico mudou nos três cenários, totalizando 19.233 comparações.

Ambiente de execução: Linux, Python 3.12.14. O cenário CP1252 é uma simulação automatizada da leitura que falhou; não foi executada uma sessão nativa no Windows/Python 3.14. Nenhuma revisão normativa ou conferência adicional de catálogos foi realizada nesta correção.

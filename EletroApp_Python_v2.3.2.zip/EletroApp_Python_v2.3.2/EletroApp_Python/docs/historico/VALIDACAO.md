# Validação da migração r42 para Python

Data: 30/09/2026. Ambiente de execução: Linux, Python 3.12.

## Dados e fórmulas

O XLSX foi lido diretamente como OOXML, preservando as fórmulas matriciais. Foram identificadas 58 abas e 94.440 registros de fórmulas.

Todas as 94.440 expressões foram analisadas sintaticamente e avaliadas. A varredura final não apresentou função desconhecida nem falha de interpretação. Restaram seis resultados `#VALUE!` em `Identificação-Método_Instal !E2:E7`, associados às ilustrações em células da origem. Os indicadores principais dos seis circuitos foram calculados sem erros do interpretador.

Na comparação numérica ampla com os caches disponíveis, 5.656 resultados coincidiram dentro da tolerância e 157 divergiram. Essa comparação inclui tabelas intermediárias e valores auxiliares. Não equivale a uma validação normativa ou à prova de que todo cache divergente está errado.

Na comparação dos indicadores expostos pelo aplicativo, 140 resultados possuíam cache de origem: 122 coincidiram e 18 divergiram. `conferencia_r42.csv` registra essas diferenças. As células sem cache foram recalculadas, mas não contadas como coincidências.

Exemplos de divergência que exigem rastreabilidade:

- A recomendação de alguns disjuntores recalculada pelas fórmulas atuais difere da referência salva no XLSX.
- Há caches de códigos antigos de DPS enquanto as fórmulas atuais consultam a biblioteca Clamper.
- O critério atual de DPS depende da natureza Origem / Distribuição / Circuito final, o que altera resultados em relação a alguns caches.
- Alguns curtos mínimos diferem em 0,001 a 0,002 kA dos valores salvos.

Esses resultados aparecem na interface de comparação. Não foram forçados a coincidir por substituição pelo cache.

## Indicadores conferidos no projeto inicial

| Circuito | ΔV do trecho (%) | ΔV acumulada (%) | Ik máximo com a regra de motores da r42 (kA) |
|---|---:|---:|---:|
| Ramal de entrada | 0,580 | 0,580 | 14,426 |
| QM-01 | 1,287 | 1,867 | 9,864 |
| QGBT-01 | 0,912 | 2,779 | 7,853 |
| QDFL-01 | 0,902 | 3,681 | 2,524 |
| QDFL-02 | 1,129 | 3,908 | 3,930 |
| QDFL-03 | 0,879 | 3,658 | 1,372 |

Potência ativa na origem: **76.700 W**. Potência aparente: **91.482,57 VA**. A potência total da interface usa a origem e não soma alimentadores com seus circuitos filhos.

## Testes automatizados

Os **13 testes automatizados passaram**. Foram cobertos:

- Arredondamento compatível com as funções utilizadas, números complexos, matrizes, procuras e referências dinâmicas.
- Avaliação condicional sem executar ramos desnecessários, erros explícitos e soma condicional sem ciclo artificial.
- Resultados de carga, corrente, curto e queda de tensão da origem.
- Aumento de comprimento com aumento de queda e redução do curto disponível.
- Renomeação de quadro com atualização das referências dos filhos.
- Transferência para um quadro que estava abaixo na lista, com reorganização dos dados e novo total de carga.
- Criação, edição, exclusão e restauração de circuito por backup.
- Rejeição de ciclos, duplicidade de nome e fator de potência inválido.
- Persistência em SQLite e reversão completa de alteração rejeitada.
- API de formulários, consulta de tabelas, relatório, CSV e importação de backup.
- Rejeição de chamadas de alteração sem token válido ou de origem incompatível.

Os testes cobrem mudanças de entradas e efeitos observáveis, além da leitura da configuração original. Eles não cobrem todas as combinações possíveis de materiais, métodos, seções e dispositivos da biblioteca.

## Adaptações intencionais

1. A identificação da primeira linha é ativada pelo nome da própria entrada (`B2`), corrigindo a dependência de `B3` existente em `A2` da origem.
2. Os circuitos possuem identificador estável. Nas alterações de topologia, os dados são reordenados mantendo as fórmulas das posições do modelo e preservando os vínculos por nome.
3. Nomes duplicados, ciclos e montantes inexistentes são rejeitados antes da gravação. A edição ocorre sobre cópia e só é confirmada integralmente após validação.
4. Alterações de dados reabrem a confirmação dos dispositivos para impedir que uma confirmação anterior seja reutilizada sem revisão.
5. O relatório da interface é gerado em HTML. Os memoriais da planilha continuam consultáveis no explorador de abas.

## Limitações de verificação

A sintaxe JavaScript foi verificada e os endpoints foram exercitados. **Não foi concluída uma revisão visual em navegador gráfico:** o ambiente não dispunha de navegador instalado e o download do navegador de teste falhou. A execução por duplo clique no Windows e a impressão em PDF também não foram ensaiadas neste ambiente Linux.

O pacote é uma primeira versão funcional e rastreável do aplicativo, com código-fonte e testes. As pendências de projeto, curvas de fabricante, seletividade, coordenação de DPS e conformidade normativa permanecem sob os critérios e dados da r42.

## Correções aplicadas em auditoria independente (30/09/2026)

Auditoria externa comparou os resultados deste aplicativo contra um recálculo genuíno da r42.xlsx via LibreOffice/UNO (`document.calculateAll()`, não o cache do próprio XLSX nem apenas as 140 células já comparadas acima) — foram conferidos **todos os 5.894 resultados numéricos de fórmula do workbook inteiro**, não só os 18 indicadores já listados em `conferencia_r42.csv`. Dois bugs reais foram encontrados em `core/formula.py` e corrigidos:

1. **`ROUND()`** (função `rnd`, ramo `if name=='ROUND'`): a conversão `Decimal(str(x))` toma o float resultante de uma soma/produto ao pé da letra. Quando essa soma cai, por ruído de ponto flutuante IEEE754, um ULP abaixo do decimal exato (ex.: `0,00225+3×0,0045` armazenado como `0,015749999999999997` em vez de `0,01575`), isso empurra um empate exato de arredondamento para o lado errado (0,0157 em vez de 0,0158). Excel/LibreOffice limpam o valor para ~15 dígitos significativos antes de decidir a direção do arredondamento; a correção replica essa limpeza formatando `x` com `%.15g` antes de construir o `Decimal`. Afetava `Cálc_Icc-Cond_Escolhido!K4/K5/K7` (Ik mínimo de QGBT-01/QDFL-01/QDFL-03) em 0,001–0,002 kA — após a correção, os três batem exatamente com o recálculo genuíno (3,318 / 1,996 / 1,005).
2. **`num()`**: tratava `v == ''` (texto vazio, tipicamente produzido por uma fórmula do tipo `IF(condição;"";valor)`) exatamente como `v is None` (célula genuinamente em branco), retornando `0` para ambos. No Excel genuíno, uma função numérica aplicada a texto vazio (ex. `SQRT("")`) é `#VALUE!`, erro que um `IFERROR` externo captura corretamente. Corrigido para que só `None` (célula em branco de verdade) vire `0`; `''` agora propaga como erro, capturado normalmente pelos `IFERROR` já existentes nas fórmulas da r42. Afetava 5 células da linha "Ramal de entrada" (ex. `Seleção-Seção_Condutor!S2`, que aprovava silenciosamente com `240` em vez de mostrar a pendência correta) — após a correção, essas 5 células voltam a propagar corretamente o estado `⏳ PENDENTE`/texto vazio, idêntico ao recálculo genuíno.

**Verificação pós-correção:**
- Suite de 13 testes automatizados: **13/13 passam** (`python -m unittest discover -s tests -v`), sem regressão.
- Varredura ampla dos 5.894 resultados numéricos originais contra o mesmo recálculo genuíno via UNO: **5.880 coincidência exata + 9 dentro de 1e-6 (ruído de ponto flutuante comum a qualquer motor, já presente antes da correção e sem relação com os dois bugs) = 5.889/5.889, zero divergência remanescente, zero divergência nova introduzida.** As 5 células do item 2 saem corretamente da contagem de resultados numéricos (passam a ser texto/pendência, como no Excel genuíno), o que explica a diferença de 5.894→5.889 células comparáveis.
- `docs/conferencia_r42.csv` foi atualizado nas 4 linhas afetadas (S2, K4, K5, K7), mantendo o valor histórico "Valor salvo XLSX" e marcando o "Recalculado Python" corrigido com a data desta auditoria.

**Verificado e não alterado:** `ROUNDDOWN`/`ROUNDUP` usam uma lógica diferente (`math.floor`/`math.ceil` sobre `abs(x)*10**d`) com a mesma classe teórica de sensibilidade a ruído de ponto flutuante em fronteiras exatas. `ROUNDDOWN` aparece em 100 fórmulas e `ROUNDUP` em 1 no workbook real da r42; a varredura ampla acima (que cobre literalmente todo resultado numérico de fórmula do workbook, antes e depois da correção) não encontrou nenhuma divergência atribuível a essas duas funções — ou seja, o problema não se manifesta nos dados reais desta planilha hoje. Não foram alteradas para manter o escopo da correção restrito a bugs confirmados e verificados, não a uma reescrita preventiva.

## Usabilidade, imagens e assistente local (30/09/2026)

Rodada de melhorias de usabilidade solicitada pelo usuário: (A) restaurar/reforçar a seleção por lista onde ela se perdia, sempre com opção de valor manual; (B) imagens para o método de instalação; (C) imagens em outros pontos úteis, a critério técnico; (D) um assistente de IA local e offline para refinar proteção e seletividade.

### A. Seleção por lista

**Investigação, não presunção.** Antes de alterar qualquer campo, foi feita uma varredura de todas as linhas ativas (2–7) e de um circuito recém-criado, comparando, para cada campo do formulário: existe `dataValidation` do tipo lista na célula do XLSX original? Se sim, `options()` (mecanismo já existente) consegue resolver algum valor agora?

- Uma hipótese inicial (herdada de uma investigação de fase anterior) apontava `Dados dos condutores !G` como campo de lista "perdido". A varredura mostrou que essa hipótese estava **errada**: G é uma célula de **fórmula** (`=IF($A{lin}="","",'Identificação-Método_Instal '!$C{lin})`), apenas espelhando `Identificação-Método_Instal!C` — que já é o campo editável correto e já estava no formulário. Criar uma segunda "entrada" em G seria redundante e, pior, inerte (célula de fórmula nunca vira campo editável). A tentativa foi revertida antes da entrega; nenhuma mudança ficou no pacote final por causa dela.
- A varredura real encontrou exatamente **um** caso de lista que resolve vazio apesar de ter `dataValidation` nativa: `Cálc-Prot_Cabos!AM` (Modelo/referência do disjuntor) quando `AL` (Linha/família) ainda não foi escolhida — a fórmula da própria planilha é `INDIRECT("WEG_"&AL{lin})`, que no Excel genuíno também retornaria `#NAME?` nessa condição. **Não é um bug do aplicativo**, é o comportamento em cascata da própria planilha. A correção não foi "inventar" uma lista, e sim expor esse fato ao usuário: um novo sinalizador `pending_list` (em `core/project.py`, método `field()`) identifica quando uma célula tem lista nativa mas ela não resolveu, e a interface mostra uma nota explicando a causa (depende de outra seleção acima) em vez de um campo mudo.
- **Correção de efeito colateral, achada ao investigar:** alguns campos com lista misturam valores numéricos e códigos textuais (ex.: `Cálc-Prot_Cabos!BZ` tem as opções `50,100,200,300,N/A`; o código do método de instalação inclui `11A`, `13_Cabo unipolar` etc.). Esses campos estavam marcados como `numeric` mesmo quando a lista continha texto, e o JavaScript tentava converter o valor escolhido em número antes de salvar — `Number("N/A")` é `NaN`, então **escolher "N/A" nesses campos já falhava antes desta correção**, silenciosamente, com a mensagem "Número inválido". Corrigido em `core/project.py.field()`: um campo com opções só é tratado como numérico se **todas** as opções realmente forem numéricas; `_validate_value()` também passou a aceitar, como texto, qualquer valor que seja uma das opções válidas da própria lista.
- **Novo padrão de interface, aplicado a toda lista do formulário:** todo `<select>` populado por opções agora tem uma opção adicional "Outro (digitar manualmente)…", que revela um campo de texto ao lado. O valor atual do campo, mesmo que não esteja entre as opções conhecidas, nunca é escondido — aparece automaticamente no modo manual. Implementado de forma genérica em `fieldHTML()`/`collect()` (`static/app.js`), não campo a campo.

### B. Imagens do método de instalação

A coluna `Identificação-Método_Instal !E` usa "Inserir dados de imagem" do Excel 365 com busca própria por linha — esse mecanismo é específico do Excel 365 e não é replicável fora dele (por isso aparece como `#VALUE!` na leitura do valor, o que **não é erro de cálculo**, conforme já indicado nas instruções do projeto). A alternativa usada foi ler a cadeia `richData` do OOXML diretamente (`vm=` → `xl/metadata.xml` → `xl/richData/rdrichvalue.xml` → `xl/richData/richValueRel.xml` → `xl/media/`) para a aba `Tabelas_33_NBR`, que carrega uma ilustração por linha da Tabela 33 (NBR 5410) e cujo código (coluna A) é o mesmo valor que `Identificação-Método_Instal!D{linha}` já calcula. As 59 linhas foram resolvidas com **zero falhas** e conferidas visualmente por amostragem (3 imagens, todas consistentes com a descrição textual do método). As 52 imagens únicas foram extraídas para `static/img/metodos/` e catalogadas em `data/metodos_instalacao.json`; `core/project.py.form()` anexa ao grupo "Método de instalação" a imagem cujo código bate com `D{linha}` (com normalização para texto, já que o valor pode chegar como número inteiro em circuito novo). A interface mostra a imagem no formulário do circuito e oferece um catálogo navegável com todos os métodos ilustrados.

### C. Imagens em outros pontos

Decisão deliberada de **não inventar** ilustrações técnicas (DPS, partida de motor) sem base real: a varredura do `richData` do workbook confirmou que a única ilustração embutida na planilha de origem é a Tabela 33. Em vez de desenhar diagramas de maior risco normativo, foi acrescentado **um** esquemático simples, original e de baixo risco — TN-S vs. TN-C — junto da escolha do esquema de aterramento (campo presente em todo circuito), claramente identificado como "esquemático simplificado" e sem substituir o projeto de aterramento.

### D. Assistente local de proteção, seletividade e DPS (`core/advisor.py`)

100% local e offline (sem rede, sem IA generativa, sem chave de API — nenhuma chamada sai do processo Python em execução), conforme escolha do usuário. Estritamente consultivo (Seção 34 do escopo do projeto): nunca grava nem decide; apenas monta listas ordenadas e textos de pré-verificação, e o preenchimento de um campo a partir de uma sugestão ("Usar") passa pelo mesmo mecanismo de lista+valor manual do item A — o salvamento continua exigindo ação explícita do usuário.

- **Proteção:** para a família de disjuntor já escolhida, cruza os candidatos do catálogo `Biblioteca_Proteções_WEG` (mesma lista que já alimenta o campo nativo) com Ib/Iz do circuito (já calculados pelo motor de fórmulas), classificando cada um como "atende Ib≤Ir≤Iz", "não atende" (com o motivo) ou "dados insuficientes" — nunca escondendo os que não atendem. **Não tenta interpretar Icu automaticamente**: a coluna de Icu do catálogo é texto livre com condições de tensão diferentes por linha (ex.: "85kA@380/415V; 70kA@440/460V..."), e reinterpretar isso por código seria um risco real de comparação de segurança incorreta — em vez disso, a sugestão sempre reexibe o texto original do catálogo pedindo conferência manual contra o Ik,máx calculado.
- **Seletividade:** pré-verificação conservadora por razão de correntes entre o circuito e seu montante direto (Ir/Ii já escolhidos), usando **somente o vocabulário que a Seção 25 do escopo do projeto já prevê** ("Pré-verificação atendida", "Seletividade provável", "Critério instantâneo atendido", "Verificar curva/tabela do fabricante") — nunca "seletividade total". Inclui uma verificação de segurança adicional: se a proteção a montante não for estritamente maior que a de jusante, sinaliza risco de seletividade invertida em vez de aplicar a regra de razão.
- **DPS:** lista candidatos dos catálogos `Biblioteca_DPS_Clamper`/`Biblioteca_DPS_Siemens` cujo esquema de aterramento bate com o do circuito. Não decide Tipo 1/2/3 nem confirma coordenação entre estágios — a Seção 26 do escopo exige dado de fabricante para isso, que este módulo não possui; quando não há candidato compatível, diz isso explicitamente em vez de forçar uma sugestão.

**Verificação:** exercitado nos 6 circuitos reais do projeto inicial (ver saída completa nos logs de verificação desta sessão) — produziu resultados fisicamente coerentes, incluindo um alerta genuíno de possível seletividade invertida tanto em "QM-01" (frente ao seu montante direto, "Ramal de entrada") quanto em "QGBT-01" (frente ao seu montante direto, "QM-01") — em ambos os pares, montante e jusante têm Ir=320A no projeto original, ou seja, a razão upstream/downstream não é maior que 1 — e a rejeição correta, com o motivo explicitado, de dois modelos de disjuntor subdimensionados (Ir máximo abaixo de Ib) para QDFL-02, mantendo visível o modelo que atende. Testado de ponta a ponta via HTTP real: sugestão → preencher campo ("Usar") → salvar via `/api/changes` → valor persistido corretamente, incluindo para um modelo de disjuntor (texto, não numérico) e um código de método de instalação não numérico.

### Verificação pós-mudanças desta rodada

- Suite de 13 testes automatizados: **13/13 passam**, sem regressão.
- Sintaxe Python (`py_compile`) e JavaScript (`node --check`) validadas em todos os arquivos alterados.
- Servidor real exercitado via HTTP (não só chamadas diretas ao `Project`): `/api/state`, `/api/form` (todos os 6 circuitos), `/api/advisor` (todos os 6 circuitos), `/api/metodos`, `/img/metodos/*.png`, e `/api/changes` com valores vindos do fluxo de sugestão.
- Segurança da nova rota de imagens (`/img/metodos/...`) testada com tentativas de travessia de diretório (`..%2f`, `....//`) via socket bruto (sem passar por normalização de cliente HTTP) e com extensão de arquivo não permitida — todas corretamente rejeitadas com HTTP 400, por checagem explícita no servidor, não por acaso do parsing.
- Nenhum arquivo do pacote (XLSX de referência, dados extraídos, testes) foi removido ou sobrescrito de forma destrutiva. Arquivos **novos**: `core/advisor.py`, `data/metodos_instalacao.json`, `static/img/metodos/*.png`. Arquivos **editados** (sem remover nada do que já existia): `core/project.py`, `app.py`, `static/app.js`, `static/style.css`, `static/index.html` (versão exibida), `LEIA-ME.md`, `docs/VALIDACAO.md`.

### Limitações desta rodada, declaradas

- A sugestão de proteção não avalia partida de motor nem Icu numericamente (por design, ver acima) — é um filtro de Ib/Iz, não uma seleção completa.
- A pré-verificação de seletividade é uma triagem por razão de correntes, não uma análise de curvas tempo×corrente reais — o próprio texto de cada resultado deixa isso explícito.
- O esquemático TN-S/TN-C é ilustrativo (esquemático simplificado), não um diagrama unifilar de aterramento do projeto.
- Não foi feita revisão visual em navegador gráfico neste ambiente (mesma limitação já registrada na auditoria anterior); a interface foi validada por leitura de código, sintaxe e por todas as chamadas HTTP reais que o navegador faria.

## Cascata Instalação→Métodos→Condutores e hierarquia de Entrada e fontes (30/09/2026)

Pedido do usuário: (1) a escolha do método de instalação deve ser por clique na foto, com o número do método sempre correspondendo à foto clicada, e as opções restritas às compatíveis com a "Instalação" já escolhida, respeitando a sequência Instalação → Métodos → Condutores, com aviso quando uma etapa anterior não estiver selecionada; (2) em Entrada e fontes, hierarquia equivalente: o dashboard deve restringir as seleções visíveis conforme o "Tipo de atendimento" escolhido (ex.: Gerador BT mostra só as caixas necessárias ao gerador).

Desta vez a revisão foi feita com testes reais em navegador (Playwright/Chromium), não só leitura de código e chamadas HTTP diretas — o que permitiu encontrar defeitos que só se manifestam na interação real do JavaScript com o DOM, fora do alcance da suíte de testes Python existente (que não exercita `static/app.js`).

### 1. Galeria de métodos por clique, restrita pela Instalação

A lista de métodos compatíveis por categoria de "Instalação" (`Maneira de instalar`) foi extraída da própria aba de referência `Metodos_Inst_Ajuda` do r42.xlsx (named ranges `Metodo_Ajuda`, `Metodo_Tab_N`, `Metodo_Cabo_Tab_N`), não inventada: **32 categorias**, salvas em `data/metodos_por_linha.json`, cada uma com seus métodos-base, códigos de imagem e, quando aplicável, variantes sem imagem cadastrada no arquivo original.

- `core/project.py.form()` agora publica, no grupo "Método de instalação", a galeria já restrita (`method_gallery`) a partir dessa tabela, além de um indicador `atual` por item (para destacar o método já calculado em `D{linha}`) e um aviso (`metodo_aviso`) quando a Instalação ainda não foi escolhida ou quando seu valor não consta no catálogo de referência (caso em que a galeria completa é mostrada, com aviso, em vez de travar o formulário).
- `static/app.js` passou a renderizar essa galeria como blocos clicáveis (`.method-tile`), com o rótulo explícito "INSTALAÇÃO → MÉTODOS → CONDUTORES · CLIQUE NA FOTO PARA ESCOLHER". Clicar num bloco grava B/C (e, para os métodos 13–16, que combinam número e tipo de condutor, resolve a combinação correta) e recalcula a pré-visualização ao vivo, sem precisar salvar para conferir.
- O grupo "Condutores" mostra um aviso equivalente quando o Método ainda não foi escolhido, bloqueando visualmente a continuidade da cascata sem impedir que os dados já preenchidos sejam preservados.
- **Testado ponta a ponta com salvamento real:** clicar num método diferente do atual, salvar, fechar e reabrir o mesmo circuito a partir de uma nova consulta ao servidor, e conferir que o código ativo (recalculado pela fórmula `D` da planilha) bate exatamente com o que foi clicado — não é uma conferência cosmética do lado do navegador.
- Conforme a Seção 34 do escopo: limpar a Instalação bloqueia a galeria com aviso, mas **não apaga** o Método já escolhido (nem o contrário); a cascata nunca sobrescreve silenciosamente uma escolha do projetista.

**Bug pré-existente, achado durante a varredura das 32 categorias (não introduzido nesta rodada):** algumas categorias da própria planilha têm espaço em branco no fim do nome como parte do texto oficial (ex.: `"Eletroduto embutido em parede isolante "`, `"Diretamente enterrado "`). O código de busca aplicava `.strip()` ao valor de "Instalação" antes de procurar no catálogo, o que quebrava silenciosamente essa busca para essas categorias (caía no catálogo completo de 59 métodos em vez da lista restrita, sem aviso de que algo saiu do esperado). Corrigido para checar apenas se o valor é vazio/só-espaço, sem alterar o texto usado na busca. Conferido por varredura direta das 6 linhas ativas do projeto de referência: zero casos remanescentes de fallback indevido.

**Exceções documentadas, herdadas da própria planilha (não são bugs do aplicativo):** a categoria `"17_unipolar"` tem um erro de digitação na planilha de origem (falta o prefixo "Cabo "), tratado com tolerância explícita no mapeamento; as variantes do método 28 não têm nenhuma imagem cadastrada no arquivo original (aparecem na galeria como opção sem foto, com texto explicativo, em vez de foto ausente sem explicação).

### 2. Hierarquia em Entrada e fontes

A tela "Entrada e fontes" foi reorganizada em blocos recolhíveis — `geral` (sempre visível), `mt_dados`, `transformador`, `bt_direta`, `gerador` — a partir do mapeamento linha-a-bloco já existente (`SOURCE_ROW_BLOCK`) e de qual "Tipo de atendimento" cada bloco atende (`SOURCE_BLOCK_SCENARIOS`, em `core/project.py` e espelhado em `static/app.js` para reatividade sem round-trip ao servidor).

- O campo "Tipo de atendimento" (`B2`) fica fora de qualquer bloco, sempre visível no topo, como raiz da hierarquia.
- Trocar o Tipo de atendimento abre automaticamente o(s) bloco(s) aplicável(is) e recolhe os demais, marcando-os "· não se aplica a '\<tipo escolhido\>' — dados preservados": os valores continuam gravados (nunca apagados), conforme a Seção 3 do escopo (dados de MT/Transformador preenchidos, por exemplo, permanecem armazenados mesmo sob "Rede BT Direta", só não participam do cálculo).
- Dentro do bloco `mt_dados`, um terceiro nível filtra pelos campos visíveis conforme o "Modo de entrada" escolhido (Icc / Pcc / Zpu) — sub-cascata dentro da própria hierarquia Tipo→Bloco→Modo.
- Tudo isso é reativo ao vivo (antes de salvar), a partir dos valores correntes do formulário — não exige recarregar a página para conferir o efeito de uma troca.
- **Testado nos 4 cenários do escopo** (Rede MT/Trafo com dados, Rede MT/Trafo sem dados, Rede BT Direta, Gerador BT): em cada um, exatamente os blocos esperados abrem/ficam aplicáveis e os demais são marcados corretamente, incluindo a sub-cascata de Modo de entrada. Um salvamento real de uma troca de Tipo de atendimento (Rede MT/Trafo sem dados → Rede BT Direta) foi exercitado ponta a ponta contra o servidor, sem erro.

### 3. Defeitos pré-existentes achados e corrigidos durante os testes desta rodada

Nenhum foi pedido pelo usuário; todos foram descobertos ao testar a cascata acima de ponta a ponta num navegador real, e diretamente atrapalhavam o uso da funcionalidade entregue — por isso foram corrigidos, com escopo mínimo, sem alterar validação além do necessário.

1. **Colisão de identificadores `field-N`/`source-N`.** Quando o drawer do circuito e a tela de Entrada e fontes coexistem no DOM (ver item 3 abaixo), duas funções auxiliares (`liveValue`, `setFieldValue`, em `static/app.js`) escolhiam automaticamente entre `#field-N` e `#source-N` por tentativa (`$('#field-'+idx)||$('#source-'+idx)`), podendo ler o elemento errado — observado como o aviso de bloco mostrando o **nome do circuito** em vez do "Tipo de atendimento" real. Corrigido exigindo um parâmetro `prefix` explícito nas duas funções, igual ao padrão já seguro usado em `collect()`.
2. **Campo numérico com valor textual legítimo ("N/A") impedia salvar o circuito inteiro.** `Cálc-Prot_Cabos!BX` ("Isd adotado") é uma coluna marcada como numérica mas sem lista nativa; a planilha original já guarda `"N/A"` nessa célula para alguns circuitos. Reenviar esse mesmo valor sem alteração (ex.: ao salvar depois de só trocar o método de instalação) era rejeitado tanto no backend (`_validate_value`) quanto no frontend (`collect()`) com "Número inválido: NaN", travando **Salvar** para o circuito inteiro, mesmo sem tocar nesse campo. Corrigido nas duas camadas para aceitar quando o valor reenviado é idêntico (como texto) ao já salvo — sem afrouxar a rejeição de um valor genuinamente novo e não numérico, reconfirmada por teste dedicado.
3. **Navegação por hash com o drawer aberto não o fechava.** O listener de `hashchange` só verificava alterações pendentes da tela de Entrada e fontes (`sourceDirty`); nunca chamava `closeDrawer()`. Um clique do mouse num link da barra lateral já era bloqueado pelo `#drawer-shade` (que cobre a tela toda, inclusive a barra lateral, e fecha o drawer ao ser clicado) — mas o botão Voltar/Avançar do navegador, um link direto ou qualquer troca programática de hash **não passa pelo shade** e deixava o painel do circuito flutuando por cima da nova tela, com o formulário de fundo escondido atrás dele. Corrigido para que toda troca de hash feche o drawer primeiro (perguntando antes, se havia alteração não salva, com o mesmo texto de confirmação já usado no botão ✕); se o usuário cancelar, a navegação é revertida para a tela anterior em vez de deixar a URL mudar com o drawer ainda aberto por trás.

### Verificação desta rodada

- Suite de 13 testes automatizados Python: **13/13 passam**, sem regressão (`python -m unittest discover -s tests -v`).
- Sintaxe verificada (`node --check static/app.js`, `python3 -c "compile(...)"` equivalente) a cada alteração.
- Testes em navegador real (Playwright/Chromium) cobrindo: cascata Instalação→Método→Condutores com avisos e sem apagar escolhas ao limpar uma etapa anterior; salvamento real com clique→salvar→reabrir→conferir o valor persistido pelo servidor; hierarquia de Entrada e fontes nos 4 cenários de atendimento, incluindo a sub-cascata de Modo de entrada; o cenário específico de colisão de ids (hash-navegação com o drawer aberto); os três casos do fechamento automático do drawer (sem alteração, com alteração + cancela, com alteração + confirma); rejeição de um valor numérico genuinamente inválido digitado num campo livre; e uma varredura salvando, sem nenhuma alteração, os 6 circuitos do projeto de referência — todos sem erro, confirmando que a correção do item 2 não mascara nenhum outro campo com o mesmo problema latente. Zero erros de console/página do navegador em qualquer teste.
- Capturas de tela do estado final revisadas visualmente (galeria com o método certo destacado; aviso de cascata bloqueada; blocos de Entrada e fontes recolhidos/marcados ao trocar para Gerador BT).

### Limitações desta rodada, declaradas

- O catálogo de 32 categorias reflete exatamente a aba `Metodos_Inst_Ajuda` do r42.xlsx; uma categoria de Instalação fora desse catálogo (ex.: digitada manualmente pela opção "Outro") faz a galeria cair no catálogo completo de 59 métodos, com aviso — não há como restringir algo que a própria planilha de referência não classifica.
- As variantes do método 28 continuam sem imagem (ausência no arquivo original, não uma falha de extração), e a categoria "17_unipolar" carrega a tolerância a um erro de digitação da planilha de origem — ambos documentados no próprio `data/metodos_por_linha.json` (`nota`) para rastreabilidade.
- Não foi feita varredura de toque/mobile (viewport estreito) nem de leitor de tela nesta rodada; os testes cobriram interação de mouse/teclado em viewport padrão de desktop.

## Matriz NBR 5410, seções, partida de motores, proteção por catálogo e revisão de listas (30/09/2026)

Pedido do usuário, em nove partes: (1) restringir Tipo de condutor pela matriz real método×condutor da NBR 5410; (2) aba "Ajuste requerido para este método"; (3) restringir a seção de Condutores por Método+Tipo de condutor; (4) reformar "Seção escolhida" com múltiplos critérios; (5) partida de motores (métodos e cálculos); (6) proteção e catálogo — hierarquia Disjuntor fixo/Disjuntor ajustável/Fusível, com o catálogo real da WEG; (7) revisão geral da aplicação — informação de apoio só no back-end, listas antes de texto livre onde a planilha oferece uma lista real; (8) reordenar a navegação principal na sequência lógica do fluxo. Todas as nove partes foram concluídas e reverificadas nesta rodada.

### 1–4. Matriz NBR 5410 (método×tipo de condutor), ajuste requerido, seção de condutores e "Seção escolhida"

A matriz método×tipo de condutor foi extraída da própria NBR 5410 (Tabela 33 e correlatas, já anexada ao projeto) em vez de presumida. `core/project.py` passou a restringir o Tipo de condutor às combinações realmente previstas na norma para o método já escolhido, com aviso — nunca apagamento silencioso — quando a combinação salva deixa de ser válida após uma troca de Método. A aba "Ajuste requerido para este método" (campo H, antes um texto cru) passou a ser uma galeria de blocos clicáveis (`.ajuste-tile`) com as opções reais do método (ex.: "Trifólio"), e a seção de Condutores foi restringida de forma equivalente por Método+Tipo de condutor. "Seção escolhida" foi reformada para comparar explicitamente os múltiplos critérios de dimensionamento (ampacidade, queda de tensão, seção mínima normativa, térmica por curto-circuito e, quando aplicável, concessionária) e adotar a maior seção entre eles, com aviso vermelho quando a seção escolhida pelo projetista fica abaixo do mínimo calculado — sem jamais substituir a escolha do projetista pela sugerida (Seção 34 do escopo do projeto).

**Verificação nesta rodada:** suite de 13 testes automatizados (sem regressão); testes em navegador real (Playwright/Chromium) cobrindo clique na galeria de ajuste com confirmação de `dirty`/valor gravado, clique num método com tipo de condutor único, e um ciclo completo de clicar→salvar→reabrir em QGBT-01 sem erro de console. O detalhe linha a linha de pequenas correções feitas durante o desenvolvimento desta etapa específica (antes desta rodada de documentação) não ficou registrado neste relatório; o que se reporta aqui é o comportamento final, reverificado agora com o aplicativo já na configuração de entrega.

### 5. Partida de motores

Adicionados os métodos de partida direta, estrela-triângulo, soft-starter, reator série e inversor de frequência, cada um com sua corrente/tensão de partida e o parâmetro próprio do método (ex.: % de tensão do reator ou soft-starter). A tela compara explicitamente a partida direta (pior caso, referência) com o método escolhido, mostrando a queda de tensão na rede e nos terminais do motor para os dois, com status "Rede"/"Motor" separados — a proteção continua sendo avaliada em conjunto com partida, ampacidade, sobrecarga e curto-circuito (Seção 22 do escopo), nunca resolvendo a partida apenas por aumento de In.

**Verificação nesta rodada:** `test_partida_full.py`, reexecutado nesta entrega **num projeto recém-criado (banco SQLite vazio)**, cobre partida direta em QGBT-01, estrela-triângulo em QDFL-01 (razão Ip/In⁄3 confirmada em 0,334, esperado ~0,333), reator série 65% em QDFL-02 (razão confirmada em 0,6497, esperado ~0,65 — e com o status "Rede: ✗ EXCEDE" corretamente mantido, não escondido), inversor de frequência 50% em QDFL-03, soft-starter sem parâmetro informado em QM-01 (mensagem orientando a preencher o parâmetro, sem travar nem assumir um valor) e um circuito sem motor (mensagem de não aplicabilidade). Zero erros de console/página. **Nota metodológica para quem for reexecutar esta suíte depois:** os scripts de teste desta rodada não são isolados entre si — todos leem/escrevem o mesmo projeto salvo em `projetos/eletroapp.sqlite3`. Executá-los em sequência sem recriar o banco entre um e outro pode fazer um script herdar o estado deixado por outro (ex.: uma seção ou método trocado por um teste anterior altera a ΔV% que o teste de partida espera encontrar), produzindo falhas que não são defeitos do aplicativo — como de fato ocorreu numa primeira rodada de regressão desta entrega e foi confirmado, reexecutando `test_partida_full.py` isoladamente contra um banco recém-criado, que o resultado correto é o acima. Recomenda-se sempre apagar `projetos/eletroapp.sqlite3` antes de cada script, como os demais testes desta rodada já fazem.

### 6. Proteção e catálogo: hierarquia Disjuntor fixo / Disjuntor ajustável / Fusível

A aba Proteção passou a pedir, antes de família e modelo, qual das três classes está sendo instalada. A escolha filtra a lista de famílias (campo "Linha/família") e de modelos ("Modelo/referência") para mostrar somente as combinações do catálogo real `Biblioteca_Proteções_WEG` (567 linhas; 441 classificadas como disjuntor fixo, 126 como ajustável, por regra do próprio campo Ir do catálogo com reforço pelo campo magnético — confirmado por varredura completa, com 33 famílias únicas e apenas duas, DWB160 e DWB250, que legitimamente misturam as duas classes) compatíveis com a classe escolhida — nunca inventando uma família ou modelo que não exista no catálogo. Um disjuntor ajustável agora mostra, ao lado do modelo, a faixa permitida e o passo real de ajuste de Ir (térmico) e de Ii/Im (magnético) extraídos do próprio catálogo, para orientar a escolha do projetista (pedido explícito do escopo original, Seção 21). Um novo endpoint `/api/protecao-catalogo` expõe esse catálogo para a interface. Em nenhum ponto uma troca de classe/família apaga o valor já salvo quando ele deixa de pertencer à classe escolhida — a interface mostra o aviso de incompatibilidade e preserva o valor (mecanismo já existente de "Outro/valor manual", reaproveitado).

**Bug real de fórmula encontrado e corrigido nesta rodada (`data/r42.json.gz`, aba `Cálc-Prot_Cabos`, linhas 2–101):** as colunas `P`/`Q` (correntes de ajuste calculadas a partir de `Tabela_Disjuntores`) multiplicavam incondicionalmente o resultado de um `VLOOKUP` por `$K`. Para as 7 linhas de fusível dessa tabela, as colunas F/G de origem guardam o texto `"N/A"` em vez de um multiplicador numérico — então, ao escolher um fusível, `P`/`Q` produziam `#VALUE!` em vez de um resultado coerente ("não se aplica a fusível"). Corrigido com uma guarda `ISNUMBER()` em `P`/`Q` (retornam `"N/A"` quando a origem não é numérica) e um ajuste equivalente em `V` (que consumia `P` para verificar `Ii≥1,2×Ip`), para que trate um `P` não numérico do mesmo jeito que já tratava `$I=0`. Verificado por comparação direta antes/depois no motor de fórmulas: **zero mudança no caminho normal de disjuntor** (não-fusível); confirmado também, por varredura de todo o workbook (`check_legacy_refs.py`), que nenhuma outra aba depende dessas colunas — a correção é local e sem efeito colateral.

**Dois defeitos de interface encontrados e corrigidos durante o desenvolvimento desta funcionalidade (antes da entrega, não after-the-fact):**
1. A lista de modelos ("Modelo/referência") renderizada pelo servidor já vem pré-filtrada para a família salva — então, ao trocar a família pela lista nativa do navegador, a lista de modelos ficava momentaneamente vazia (continha só os modelos da família antiga, todos incompatíveis com a nova). Corrigido reconstruindo as duas listas (família e modelo) inteiramente a partir de um catálogo já carregado no navegador, a cada mudança, em vez de apenas habilitar/desabilitar as opções já existentes.
2. Os indicadores "Ib≤Ir≤Iz?" e "Ii≥1,2×Ip partida?" retornam booleano puro do motor de cálculo (diferente da maioria dos outros indicadores da planilha, que já retornam texto formatado como "✓ OK"). O painel-resumo construído nesta rodada inicialmente exibia o booleano convertido para texto literal ("true"/"false"). Corrigido com uma função dedicada que traduz para "✓ Atende"/"✗ Não atende" antes de exibir.

**Verificação nesta rodada:** suite de 13 testes automatizados (sem regressão); `test_pq_fix.py` (comparação direta do motor de fórmulas antes/depois, fusível e disjuntor); `test_protecao.py` e `test_protecao_save.py` (Playwright) cobrindo as três classes, o aviso de incompatibilidade com preservação do valor, a reversão da lente ao reabrir sem salvar, a reconstrução ao vivo da lista de modelos ao trocar família, e dois ciclos completos de salvar→reabrir (disjuntor fixo trocado e fusível escolhido do zero). Todos sem erro de console/página.

### 7. Revisão geral: informação de apoio só no back-end, listas antes de texto livre

Varredura sistemática de todos os onze grupos do formulário de circuito, campo a campo, num circuito totalmente preenchido (QGBT-01), para identificar texto livre onde a planilha de origem já oferece uma lista real de opções discretas. A maior parte dos campos "livres" revisados são legitimamente contínuos (comprimentos, potências, fatores) e foram deixados como estavam. Foi encontrado e corrigido um caso claro: os campos Y/Z ("Ir adotado"/"Ii/Im adotado") passaram a ser listas (`<select>`) com os valores reais de passo do catálogo (extraídos das colunas AT/AU) quando o modelo escolhido é ajustável — o próprio rótulo do campo na planilha original já pedia isso ("lista de passos do modelo em uso"). Quando o modelo é fixo (sem passos reais) ou nenhum modelo foi escolhido ainda, o campo continua sendo um número livre, como antes.

**Dois defeitos cosméticos encontrados e corrigidos ao validar esta própria funcionalidade (antes da entrega):** a lista de passos (AT/AU) chegava ao painel-resumo como uma string crua separada por `|` (ex. `"160|180|200|...|400"`); corrigido com uma função que a formata como "160 | 180 | ... | 400 A". O segundo defeito é o mesmo item do booleano `AC`/`AD` já descrito na seção 6 acima — foi achado justamente ao revisar visualmente este painel.

**Verificação nesta rodada:** `test_ir_ii_lista.py` (Playwright) — QGBT-01 (modelo ajustável) mostra Y/Z como lista com o passo correto e o valor salvo pré-selecionado; trocar Y para um passo real (340) e salvar persiste corretamente e atualiza o resumo; QDFL-01 (modelo fixo) mantém Y como número livre. Zero erro de console/página.

**Escopo deliberadamente fora desta etapa:** os grupos "Choque" e "DPS" também misturam campos de fórmula não encapsulados com campos de decisão, mas isso nunca fez parte dos nove itens pedidos nesta rodada — alterá-los agora seria escopo não solicitado (Seção 37 do projeto). Ficam registrados aqui como candidatos a uma eventual rodada futura, não como pendência desta entrega.

### 8. Navegação principal reordenada na sequência lógica do fluxo

A barra lateral e a validação de hash em `static/app.js` foram reordenadas de "Visão geral, Diagrama unifilar, Quadros e circuitos, Entrada e fontes, Proteções, DPS, Verificações" para a sequência do próprio fluxo de dimensionamento: **Visão geral → Entrada e fontes → Quadros e circuitos → Diagrama unifilar → Proteções → DPS → Verificações**, seguido do separador "REFERÊNCIA" com Dados e fórmulas, Conferência com r42 e Como usar (inalterados). Mudança só de ordem de apresentação — nenhuma URL (`#hash`), rota de API ou lógica de cálculo foi alterada.

**Verificação nesta rodada:** suite de 13 testes automatizados (sem regressão); teste em navegador real confirmando a nova ordem no DOM e navegação sem erro por todas as dez telas, nessa ordem.

### Verificação consolidada desta rodada completa (#96–#105)

- Suite de 13 testes automatizados Python: **13/13 passam**, sem regressão (`python -m unittest discover -s tests -v`), executada ao final desta rodada contra o código já na configuração de entrega.
- Sintaxe verificada (`node --check static/app.js`) a cada alteração em JavaScript.
- Cada cenário Playwright acima foi reexecutado **individualmente, contra um banco de projeto recém-criado**, para eliminar o risco de contaminação cruzada entre scripts de teste (ver nota metodológica na seção 5) — todos passaram sem erro de console/página nessa condição.
- Integridade do pacote: nenhuma imagem, `richData`, drawing ou validação nativa foi tocada nesta rodada; as únicas alterações binárias foram as três fórmulas de `data/r42.json.gz` descritas na seção 6 (com backup preservado em `data/r42.json.gz.bak_before_pq_fix`).

### Limitações desta rodada, declaradas

- A restrição método×tipo de condutor segue a Tabela 33/correlatas da NBR 5410 já anexada ao projeto; não cobre combinações fora dessa tabela.
- A galeria de "Ajuste requerido" e a lista de passos de Ir/Ii (item 7) refletem exatamente o que o catálogo/planilha de origem já contêm; um modelo ou família digitados manualmente (opção "Outro") não têm passo de catálogo para listar e caem no campo numérico livre.
- A classificação fixo/ajustável do catálogo WEG usa o critério do próprio eixo Ir com reforço pelo eixo magnético; as duas famílias que legitimamente misturam as duas classes (DWB160, DWB250) aparecem corretamente nas duas listas, não é uma lacuna de classificação.
- Os grupos Choque e DPS continuam com campos de fórmula não encapsulados por um painel-resumo dedicado (ver item 7) — candidato a uma rodada futura, não pendência desta entrega.
- Como já registrado nas rodadas anteriores: sem revisão de toque/mobile nem leitor de tela; sem validação normativa independente além da já descrita nas rodadas anteriores deste documento.


## v1.4 — catálogo de fórmulas

- `tests/test_catalog.py` (11 testes): normalização/expansão de templates exata nas 95.140 fórmulas, ids únicos, trilha de cálculo (substituição e valores), simulação de edição sem alterar o projeto, justificativa obrigatória, preservação do cache do Excel, persistência no `.eletro`, rollback ao baseline, colunas da camada de instalação bloqueadas, honestidade das referências normativas, fluxo HTTP completo com portão de revisor e regressão das chaves de grupo do formulário (imagens dos métodos).
- **Problema anterior à v1.4, não alterado aqui:** na v1.3 três testes de `tests/test_app.py` (`test_reference_main_results`, `test_change_length_recalculates_drop_and_short_circuit`, `test_add_edit_remove_and_roundtrip`) já falhavam, e a conferência com a r42 caiu de 122/140 para 89/140 resultados coincidentes. Causa: os circuitos de exemplo da r42 trazem combinações Método × Tipo de condutor × isolação que as novas restrições da Tabela 33 marcam como incompatíveis (por exemplo, método 2 com "Cabo unipolar"); a instalação fica "pendente" e ampacidade, queda de tensão e Icc viram `#VALUE!`/`#N/A`. É comportamento da camada de restrições da v1.3; precisa de decisão de projeto (migrar os dados de exemplo ou relaxar a validação).

# Roteiro — independência da planilha r42 (itens 1, 2, 3, 4, 13 e 14)

Situação na v1.12.0 e plano de migração por etapas. Este documento não descreve código já entregue, exceto onde indicado.

## Por que não foi feito de uma vez

Hoje o projeto **é** a planilha r42 interpretada: cada projeto salvo contém as 60 abas e cerca de 99,5 mil células de fórmula (1.450 modelos de coluna). Os circuitos ocupam linhas fixas, e daí vêm o limite de 100 circuitos e as posições obrigatórias de entrada e medição. As fórmulas se referem a endereços de célula e a nomes definidos que apontam para intervalos fixos (`$B$2:$B$101`, `INDEX(...;$BK4)`).

Os itens 1, 2, 3 e 13 trocam o motor de cálculo. Traduzir as 1.450 fórmulas de uma só vez, sem comparar com o motor atual a cada passo, mudaria seções e proteções sem aviso. Por isso a migração precisa ser incremental e conferida contra o motor atual, que funciona como referência executável.

## Base já entregue na v1.12 e reaproveitada na migração

| Recurso da v1.12 | Uso na migração |
|---|---|
| `core/integridade.py`: referência das fórmulas por coluna | Inventário das fórmulas a traduzir e prova de que o projeto de origem não tinha alterações |
| `core/historico.py`: revisões por diferenças | Migrar com segurança: a revisão anterior à conversão pode ser restaurada |
| `core/ajustes.py` e `core/topologia.py` | Primeiras regras escritas em Python com variáveis nomeadas, sem endereço de célula; servem de modelo |
| `core/importacao.py` | Cria circuitos a partir de dados, sem depender da posição na planilha; vira a porta de entrada dos projetos nativos |
| Cálculos obrigatórios (`Catalog.mandatory_keys`) | Lista inicial dos resultados que a comparação antes/depois precisa cobrir |

## Etapas propostas

### Etapa A — modelo de dados nativo (itens 3 e parte do 1)

- Entidades com identificador próprio: `Fonte`, `Quadro`, `Circuito`, `Vínculo`, `Dispositivo` e `Condutor`. Topologia em grafo, sem posições obrigatórias.
- Conversor de ida e volta entre o projeto r42 e o modelo nativo, coberto por testes. Na volta, o motor atual continua calculando enquanto o novo motor não cobre tudo.
- Critério de aceite: ida e volta sem nenhuma diferença nos 6 circuitos do exemplo e em projetos gerados (10, 50 e 100 circuitos, cadeias de quadros e todos os tipos de atendimento).

### Etapa B — motor próprio por blocos (item 2)

Ordem sugerida: cada bloco depende só dos anteriores.

1. Cargas e correntes (Carga nos circuitos, Corrente nominal, Levantamento de carga)
2. Ampacidade e fatores (Corrente-Calc_Ampacidade, Cálc_Seç-Ampacidade, Corrente_Max-*). Parte já está em Python (`core/installation.py`).
3. Seções e queda de tensão (Seleção-Seção_Condutor, Queda_Tens-*)
4. Impedâncias e curto-circuito (Cálc_Imp-*, Cálc_Icc-*, IEC 60909)
5. Proteção, choque e seletividade (Cálc-Prot_Cabos, Cálc-Prot_Choque, Seletividade, Dispositivos_Trecho)
6. Motores e partida
7. DPS e auditoria

Cada bloco é uma função com entradas e saídas nomeadas e com unidades. Na transição, o bloco roda **em paralelo** com o motor atual, e um teste compara todos os resultados obrigatórios. Uma diferença só é aceita quando corresponde a uma correção documentada, como a do Icu/Ics na v1.10.

### Etapa C — base técnica própria (item 13)

- Ampacidades, fatores de correção, agrupamento, impedâncias e catálogos (WEG, Siemens, Clamper, NH) saem das abas e vão para arquivos versionados em `data/tabelas/`. Cada tabela registra fonte, edição, revisão e condições de aplicação.
- As 292 relações de `installation_rules.json` já seguem esse formato e servem de padrão.
- Cada modelo de fórmula aponta para as tabelas e as referências normativas que usa, preenchendo as lacunas do catálogo.

### Etapa D — catálogo completo e rastreável (item 4)

- O catálogo passa a listar as funções do motor nativo, inclusive as regras em Python (instalação, seleção, ajustes, topologia, trecho e motores). Para cada uma: expressão, parâmetros, unidades, precedentes, justificativa, versão, autor e histórico.
- A edição controlada passa a valer para os parâmetros e as tabelas. O código Python continua não editável pela interface, mas versionado e citado no relatório.

### Etapa E — coordenação com dados de fabricante (item 14)

- Curvas tempo × corrente digitalizadas (pontos ou equações do fabricante) e tabelas oficiais de seletividade e back-up por par de dispositivos.
- Três níveis no relatório: *pré-verificação* (a regra atual), *aproximado* (curva genérica da classe) e *verificado com dados do dispositivo* (curva ou tabela do fabricante, com a fonte citada).
- Pré-requisito: obter as curvas e tabelas oficiais (WEG, Siemens, Clamper). Elas não estão no pacote e não podem ser inventadas.

### Etapa F — remoção da r42 (fecha o item 1)

Feita só depois de A a E, com todos os blocos validados:

- retirar `data/r42.json.gz`, `referencia/`, a importação de XLSX r42 e a tela *Conferência com r42*;
- trocar as referências a abas e células por nomes de grandezas na interface e nos relatórios;
- converter os projetos existentes ao abrir, guardando a revisão anterior no histórico.

## Validação da migração (item 16)

- Para cada etapa, executar a suíte atual e a comparação bloco a bloco nos cenários de referência, documentando as diferenças decorrentes de correções.
- Adicionar testes de cálculo independentes: casos resolvidos à mão ou em fonte publicada, com tolerância declarada, que não dependam do motor r42.
- Os testes de interface da v1.12 (números brasileiros, navegação, conflitos de abas, importações, edições de fórmula) continuam valendo e entram na suíte de cada etapa.

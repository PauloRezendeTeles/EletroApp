# Validação da versão 1.12.0

Data: 06/10/2026. Ambiente: Linux, Python 3.13 e Chromium em modo headless, com Playwright.

## Resultado

- Suíte completa: **175 testes aprovados**, dos quais 154 já existiam (sem alteração de expectativa) e 21 são novos (`tests/test_v112.py`).
- Os testes HTTP anteriores passaram a enviar o projeto e a revisão, como faz a interface. Nenhuma expectativa de cálculo foi alterada.
- A interface foi exercida no navegador: botões − / + com `1.000,00`, gravação, histórico, comparação, integridade, importação de CSV com revisão, conflito entre duas abas e aviso de ajustes no formulário de proteção. Nenhum erro de JavaScript foi registrado; o único erro de console é o HTTP 409 esperado no teste de conflito.

## Itens implementados e como foram verificados

| Item | Implementação | Teste |
|---|---|---|
| 5 — fórmulas alteradas | `core/integridade.py`: referência = modelo incorporado após as adaptações do aplicativo; situações original, editada, versão inativa, alterada, desconhecida e substituída por valor | `IntegrityTests`: exemplo sem divergências (99.536 fórmulas), circuito novo sem falso positivo, alteração e substituição detectadas, catálogo deixa de mostrar “baseline”, trilha e relatório indicam a divergência, edição registrada reconhecida |
| 6 — bloqueio de novos erros | `Catalog._gate`: novos erros em resultados dos circuitos e na auditoria bloqueiam a confirmação e restaurações para versões editadas | `FormulaGateTests`: `=1/0` em `carga-nos-circuitos-Y` simula (prévia com `bloqueada=True`) e não confirma |
| 7 — ajustes no servidor | `core/ajustes.py`; `Project.update` recusa; `_circuit` sinaliza; formulário mostra o aviso | `SettingsTests`: ACW400H-ETS400-3 com Ir 301 A / Ii 2.000 A recusado e exibido como “✗ Ajustes fora do catálogo”; troca de modelo carrega ajustes válidos; disjuntor de manutenção |
| 8 — seleção sincronizada | `Catalog._reselect` após editar/restaurar; `Project.delete` reaplica a seleção | `test_edit_and_rollback_reselect_devices` |
| 9 — abas desatualizadas | Cabeçalhos `X-Eletro-Project` e `X-Eletro-Revision`; `Store.check` → HTTP 409 | `HttpV112Tests`: revisão antiga e projeto errado recusados sem gravar; teste de navegador com duas abas |
| 10 — textos seguros | `ux.js` monta a navegação com DOM e `textContent`; ids escapados em `app.js`; ids inválidos de projetos importados substituídos | `SanitizeTests` |
| 11 — topologia elétrica | `core/topologia.py`: fases, neutro, PE/PEN, TN-C após TN-S, seção mínima e seccionamento do PEN | `TopologyTests` |
| 12 — números e − / + | `core/numeros.py` e `static/numeros.js` (mesma regra); limites e inteiros por campo | `NumbersTests` + navegador (`1.000,00` + passo 100 = `1100`) |
| 15 — histórico | Tabela `revisions` (cópia completa a cada 25 revisões, diferenças nas demais); comparar, restaurar, cópias de segurança | `HistoryUnitTests`, `HttpV112Tests` |
| 17 — importação | `core/importacao.py`: CSV/XLSX, vários documentos, origem de cada valor, ausências, conflitos, revisão, gravação revalidada; IA opcional para PDF/imagem | `ImportUnitTests` (incluindo XLSX com fórmula: usa o valor salvo, sem executar), `HttpV112Tests` |

## Efeitos nos resultados

- Os cálculos da r42 não mudaram. As 99.536 células de fórmula do exemplo conferem com a referência.
- **Mudança de situação no exemplo r42:** Ramal de entrada, QM-01 e QGBT-01 usam o ACW400H-ETS400-3 com Ii = 1.600 A, mas o catálogo informa Ii fixo = 4.400 A (11 × In). Antes apareciam como “✓ Disjuntor WEG confirmado” (ramal) ou com outra pendência; agora aparecem como **✗ Ajustes fora do catálogo** até o Ii ser corrigido. É a situação descrita no item 7.
- Projetos com vínculos eletricamente incompatíveis (por exemplo, trifásico sob quadro bifásico ou TN-C sob TN-S) passam a mostrar pendência de topologia.

## Desempenho

- Referência de integridade: cerca de 2 s na primeira consulta após iniciar; depois, cerca de 1,7 s por projeto, com cache pela impressão digital das fórmulas. Alterações só de dados não refazem a conferência.
- Cada gravação guarda a diferença em relação à revisão anterior: alguns KB a centenas de KB, contra cerca de 2,3 MB de uma cópia completa.

## Limites conhecidos

- O motor continua sendo a r42 interpretada (limite de 100 circuitos; entrada e medição fixas). Veja `docs/ROTEIRO_INDEPENDENCIA_r42.md`.
- A primeira gravação de um projeto recém-criado registra também a limpeza interna das posições sem circuito. A comparação de revisões omite esses ajustes e informa quantos foram omitidos.
- A extração por IA foi testada com resposta simulada; a chamada real depende de chave e de acesso à internet. As referências à NBR 5410 nas mensagens novas (por exemplo, 5.4.3.6) devem ser conferidas na edição vigente.
- A validação de ajustes usa os dados do catálogo incorporado. Quando o catálogo não traz um eixo (por exemplo, banda magnética “N/D — CONSULTAR WEG”), esse eixo não é reprovado e a pendência continua nas verificações da planilha.

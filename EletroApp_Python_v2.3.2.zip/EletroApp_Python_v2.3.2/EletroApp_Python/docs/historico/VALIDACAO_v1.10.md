# Validação da versão 1.10.0

Data: 04/10/2026. Ambiente: Linux, Python 3.13 e Chromium 141 em modo headless, com Playwright 1.56.

## Escopo

Esta revisão trata de quatro pontos:

- dispositivo de proteção na origem opcional;
- disjuntor de manutenção na extremidade (jusante) do trecho;
- DPS opcional por quadro;
- ajustes de usabilidade.

As alterações foram aplicadas sobre a versão 1.9.0 (agrupamento, paralelos e neutro), sem modificar o que ela introduziu. Não houve certificação integral do aplicativo ou do projeto segundo todas as prescrições da NBR 5410.

## Como o modelo r42 foi adaptado

- **Nova aba `Dispositivos_Trecho`:** tem 70 colunas (A–BR) para as 100 linhas de circuito.
  - 12 colunas de entrada: origem, justificativa, condições da dispensa, tempo e descrição da proteção a montante, uso do disjuntor de manutenção, família, modelo, Ir, Ii, Isd e tsd.
  - 56 colunas calculadas, com as verificações e os dispositivos efetivos.
- **Fórmulas envolvidas:** 35 colunas de fórmulas da r42, em nove abas, foram envolvidas com `TRECHO_SE(condição; variante; fórmula original)`. São 10 em Seletividade, 6 em Cálc-Prot_Choque, 6 em DPS, 4 em Cálc-Prot_Cabos, 3 em Cálc-Condutor_Terra_Sugerido, 3 em Auditoria_Checklist e 1 em cada uma destas: Cálc_Comp_Max-Icc, Identificação dos circuitos e ΔV_Partida_Motores.
- **Colunas novas em abas existentes:** cinco ao todo. Em DPS: BT (DPS neste quadro), BU (observação) e BV (DPS a montante efetivo). Em Seletividade: W e X (dispositivos considerados).
- **Avaliação de `TRECHO_SE`:** funciona como `SE`, calculando somente o ramo escolhido. Com os valores padrão, a condição é falsa em todas as linhas e vale a fórmula original.
- **Catálogo de fórmulas:** reconhece a fórmula original dentro do envoltório. Ao editar ou restaurar, o aplicativo reaplica o envoltório.
- **Aplicação nos projetos:** a adaptação é aplicada na abertura do projeto e é idempotente, controlada por `meta.trecho_version`. O arquivo `data/r42.json.gz` e a planilha em `referencia/` não foram alterados.

## Regressão

Foram montadas duas cópias do exemplo r42, uma com a adaptação e outra sem ela. Em ambas, foram comparadas todas as células de fórmula das linhas ativas de todas as abas, exceto a aba e as colunas novas.

O resultado, sem a correção do Ik descrita abaixo: **5.339 células, nenhuma diferença**, com igualdade exata. O mesmo teste confirma que a adaptação sobrevive a salvar e reabrir o projeto e que não é aplicada duas vezes.

## Correção: Icu/Ics do dispositivo da origem

Na r42, as verificações Icu ≥ Ikmáx e Ics ≥ Ikmáx do dispositivo da origem usavam o Ik do fim do próprio cabo (`Cálc_Icc-Cond_Escolhido!S` da mesma linha). O dispositivo, porém, fica no quadro a montante, onde o Ik é maior. A versão 1.10.0 passa a usar o Ik do quadro de instalação, calculado na coluna `ik_origem` (BS) de `Dispositivos_Trecho`:

- **circuito alimentado por um quadro:** o Ik máximo do quadro de origem, isto é, o Ik do fim do cabo que alimenta esse quadro;
- **circuito ligado ao transformador ou à fonte:** o Ik trifásico nos terminais, com o cmax e a impedância de sequência positiva da fonte já usados pela r42 (`Padrão de entrada` B147, B135, B137 e B138), mais a contribuição dos motores do circuito;
- nunca menos que o valor que a r42 usava; com o Ik do circuito pendente, a verificação continua pendente.

Colunas alteradas em `Cálc-Prot_Cabos`: X, AF, AG, DG e os escores e índices da escolha automática CM–CR. A escolha automática do aplicativo e o assistente de modelos usam o mesmo Ik. O catálogo de fórmulas continua reconhecendo essas entradas e informa a alteração no status. Ficam como estavam, por já usarem o ponto correto: Ii ≤ Ikmín (fim do cabo), disjuntor de manutenção e backup do DPS (no próprio quadro).

No exemplo r42, a correção muda quatro células, todas do QDFL-01:

| Ponto | Ik |
|---|---|
| Verificação anterior, no fim do cabo do QDFL-01 | 2,714 kA |
| Barramento do QGBT-01, onde o disjuntor fica | 8,93 kA |

O MDW-C80-2 (Icu 5 kA) passa a reprovar em Icu (Cálc-Prot_Cabos AF5 e DG5; Auditoria_Checklist J5 e P5). Projetos salvos recebem a correção ao abrir; os resultados podem mudar da mesma forma.

## Testes automatizados

**154 testes aprovados** com `python -B -m unittest discover -s tests -q`: os 127 da versão 1.9.0 e 27 novos.

O arquivo `tests/test_v110.py` reúne os 27 testes novos:

- **Regressão (4):** igualdade com a versão anterior, idempotência e persistência, avaliação de um só ramo de `TRECHO_SE` e edição de fórmulas envolvidas pelo modo revisor.
- **Icu/Ics da origem (3):** Ik do quadro a montante e dos terminais do transformador, células alteradas no exemplo, catálogo e projetos salvos.
- **Trecho sem dispositivo na origem (4):** ramal com disjuntor de manutenção, informações pendentes, condições recusadas com proteção a montante lenta e suspensão da escolha automática do disjuntor da origem.
- **Disjuntor de manutenção (3):**
  - escolha automática, com e sem dispositivo na origem (Ir ≤ Iz só é exigido sem ele);
  - escolha manual, alertas e recarga dos ajustes ao trocar o modelo;
  - projetos antigos, reordenação, circuitos novos e duplicados.
- **DPS opcional (4):** quadro sem DPS e cascata, primeiro DPS com SPDA, DPS imposto a circuito final e entradas inválidas.
- **Cadeia sem derivações (5):** ponto de partida com entrada sem disjuntor, Ir a jusante maior que o Iz, derivação no quadro, carga própria no quadro e fim da cadeia no próximo dispositivo de origem.
- **Dados da interface (1):** formulário, pendências com destino e pré-verificação de seletividade.
- **HTTP (3):** fluxo completo e exportações, ponto de partida e clientes anteriores sem o modo do disjuntor de manutenção.

Em `test_v17.py` e `test_http.py`, só foram atualizadas as contagens: quatro modos de escolha e 60 abas.

## Testes no navegador

Testes feitos no Chromium, nas larguras de 1440 e 390 pixels:

- **Criação de projeto:** com cada ponto de partida e o texto explicativo de cada opção. O exemplo *transformador e medição sem disjuntor na origem* resulta em:
  - Ramal de entrada, QM-01 e QGBT-01 sem dispositivo na origem;
  - disjuntor de manutenção ACW400H-ETS400-3 em modo Manual (Ir 300 A);
  - primeiro DPS no QGBT-01, Tipo 1+2.
- **Dispositivos do trecho:**
  - alternância origem/manutenção e esquema do trecho;
  - situação por verificação, por exemplo *✓ Pelo disjuntor de manutenção de QGBT-01 — Ir 300 A ≤ Iz 346 A*.
- **Disjuntor de manutenção manual:** classe, família, modelo, posições de ajuste do catálogo e recarga dos ajustes ao trocar o modelo.
- **DPS:** dispensa no QM-01, salvamento, tabela da página DPS e fabricante padrão exibido como *Siemens (padrão)*.
- **Verificações:** a pendência do tempo de abertura abre o circuito e posiciona o cursor no campo correspondente.
- **Diagrama unifilar:** trechos sem disjuntor na origem e disjuntor de manutenção desenhado na chegada do QGBT-01, com legenda.
- **Celular:** sem rolagem horizontal da página na visão geral, em Proteções, no formulário do circuito e no diálogo de novo projeto. **Novo projeto** fica acessível pelo menu lateral.
- Nenhum erro de JavaScript no console.

## Referências normativas

As mensagens citam os seguintes itens da NBR 5410:2004:

- 5.3.4.2.2: dispositivo contra sobrecargas deslocado ao longo do percurso, sem derivações;
- 5.3.4.3: omissão da proteção contra sobrecargas;
- 5.3.5.2: localização da proteção contra curtos-circuitos;
- 5.3.5.3: omissão da proteção contra curtos-circuitos, inclusive linhas que ligam transformadores aos quadros correspondentes.

A numeração foi conferida no material didático *Estudo de Proteção Contra Sobrecorrentes — Sobrecarga e Curto-Circuito* (Prof. Marcos Fergütz, UDESC, 2017): https://udesc.br/arquivos/udesc/id_cpmenu/9731/estudo_de_prote__o_v9_17_17218268234974_9731.pdf. Confira o texto na edição vigente da norma.

## Limites desta revisão

- **Cadeia sem derivações:** é aceita quando o quadro alimentado pelo trecho tem uma única saída e nenhuma carga própria, até o primeiro dispositivo, com Ir ≤ Iz do cabo. A condição de curto-circuito que 5.3.4.2.2 também exige fica com a verificação de curto-circuito do próprio trecho, isto é, com a dispensa de 5.3.5.3 confirmada pelo projetista. A alternativa por comprimento de até 3 m não é avaliada automaticamente.
- **Proteção a montante:** o tempo de eliminação da falta (proteção de MT, relé ou dispositivo da concessionária) é informado pelo projetista. O aplicativo não modela curvas de fusíveis ou relés de MT.
- **Tempo do disjuntor de manutenção:**
  - instantâneo: 0,01 s;
  - curto retardo: o tsd adotado, com alerta para somar o tempo de abertura do catálogo;
  - longo retardo: a mesma aproximação genérica da r42, 214·(I/In)^−3,42, com alerta para confirmar na curva WEG.
- **Seletividade:** continua sendo uma pré-verificação pela razão entre os Ir. As tabelas de seletividade do fabricante são necessárias.
- **Windows:** a execução por duplo clique não foi ensaiada nesta revisão.

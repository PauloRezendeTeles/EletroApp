# Validação do agrupamento — v1.9.0

Base consultada: ABNT NBR 5410:2004, versão corrigida em 17/03/2008,
6.2.5.5, 6.2.5.6, 6.2.5.7, 6.2.5.8 e 6.2.6.2; tabelas 42 a 45 e 48.
Complemento identificado: guia Prysmian BT Rev10, tabelas 15–17 e 5.7.4.
Os PDFs não são distribuídos no pacote.

## Comportamento revisado

- Um FCA por trecho. O total soma os conjuntos deste circuito (incluindo
  paralelos) aos conjuntos dos demais circuitos. A opção manual permite informar
  o total físico. O cadastro legado não presume os paralelos de outros circuitos.
- Dutos distintos não desligam o agrupamento. Trechos independentes exigem
  justificativa. Corrente por condutor é dividida por Nc uma única vez.
- Teto: 0,95 para um conjunto e 0,81 para dois, em camada única. Feixe e várias
  camadas permanecem disponíveis quando fisicamente aplicáveis. Para 11B, a
  adoção da linha de teto em camada única é conservadora e fica registrada.
- A tabela 43 substitui a 42. Não há multiplicação entre as duas matrizes.
- Tabelas 44/45: conferir distância, distribuição nos dutos, profundidade de
  0,70 m e resistividade de 2,5 K·m/W. Outras condições de agrupamento enterrado
  exigem fator manual obtido por cálculo específico. Lacunas não são interpoladas.
- Há 292 relações na consulta: 150 posições correspondem à NBR, incluindo
  repetições de faixas, e 142 são extensões do guia. Extensões exigem opção
  explícita. Corrigidos os fatores de unipolares a 0,5 m para 11/17/19/20
  circuitos: 0,70/0,65/0,64/0,63.
- Classes térmicas diferentes: utilizar a menor temperatura informada tanto
  na tabela de ampacidade quanto na correção de temperatura. A condição de
  seções semelhantes é declarada pelo usuário. Mudanças relevantes invalidam
  a confirmação salva.
- 1/√n é restrito à alternativa de grupo não semelhante de 6.2.5.5.5 b, com
  justificativa de inviabilidade do cálculo específico. Não é aplicado por n>8.
- Exclusão por baixa carga verifica a condição com o FCA do grupo completo:
  maior Ib dos excluídos ≤0,30 × menor Iz sem FCA × FCA completo. Os valores
  devem incluir as demais correções, e os conjuntos são identificados pelo usuário.
  Várias camadas com exclusão exigem cálculo manual da geometria remanescente.
- Afastamento horizontal livre >2De é opcional e usa o maior diâmetro externo;
  não é confundido com o afastamento entre fases do método G.
- Método G agrupado sem enquadramento automático: fator manual documentado.

## Neutro e resultados dependentes

- Fases e neutro recebem o mesmo FCA. As capacidades totais incluem Nc.
- O piso legado de corrente do neutro (15%) é opcional e identificado como
  premissa interna. É aplicado por condutor e não autoriza redução de seção.
- A seção mínima do neutro é a da fase por padrão. A tabela 48 só é utilizada
  para trifásico com fase >25 mm², harmônicas ≤15%, com declaração de equilíbrio
  e proteção do neutro. Fora dos valores da tabela, mantém-se a seção da fase.
- Terceira harmônica >15% em trifásico com neutro: fator 0,86 separado do FCA,
  aplicado nas correntes de dimensionamento e nas capacidades admissíveis.
- Temperatura operacional usa corrente física por condutor, sem reaplicar as
  correções usadas na seleção da seção. No exemplo, isso altera a queda de
  tensão dos circuitos agrupados QDFL-01 e QDFL-03.
- Colunas geridas pela instalação exibem a fórmula efetiva no catálogo. A
  matriz legada de paralelos continua como registro histórico, fora dessa rota.

## Verificação

Os testes estão em `tests/test_v19.py`, `tests/test_http.py` e na suíte existente.
Incluem comparação dos 150 valores NBR, identificação das 142 extensões,
contagem combinada, teto, paralelo >8, enterramento, limites, modo manual,
classe térmica, exclusões, neutro, persistência, API, proteção e memorial.

Foram exercitados 127 testes da suíte. Após o ajuste do relatório, os quatro testes HTTP foram reexecutados e aprovados. A sintaxe JavaScript também passou na verificação.

Executar: `python -m unittest discover -s tests -v`.

A planilha de revisão registra casos anteriores e resultados desta versão,
com ampacidade por seção, Iz e a capacidade recebida pela proteção. Os testes
exercitam hipóteses declaradas; não verificam as condições físicas de uma obra.
A conferência visual interativa não foi concluída: o navegador de teste bloqueou
o endereço local. A integração foi verificada por HTTP e a sintaxe JavaScript
foi conferida. A aplicação continua local, sem dependências externas.

# Validação da versão 1.8.0

Data: 04/10/2026. Ambiente: Linux, Python 3.12 e Chrome Headless Shell 154.

## Escopo e precedência das fontes

Correções das relações entre tipo de instalação, montagem, tipo de cabo, isolação e disposição dos condutores. As tabelas de consulta e o formulário agora compartilham a mesma matriz. Não foi realizada uma certificação integral do aplicativo ou do projeto segundo todas as prescrições da NBR 5410.

A NBR 5410:2004, versão corrigida 2008, prevalece sobre o guia e a planilha nos pontos conferidos. Na tabela 33, métodos 22 e 24 (página impressa 92) e método 41 (página impressa 93), B2 se aplica a 1,5De ≤ V < 20De; B1 a V ≥ 20De. O intervalo de 5De indicado para 22/24 na tabela 5 do guia não foi adotado. Não foi identificado um limite superior de 500De nessas entradas da norma.

As distâncias E/F/G seguem 6.2.5.1.2, notas 5 e 6: multipolar em E, distância livre à superfície de pelo menos 0,3De; unipolar em F/G, pelo menos De; G também exige pelo menos De entre cabos. A nota 4 da tabela 33 fixa a área perfurada mínima de 30%. As notas 6 e 7 definem De para os casos de espaço de construção e condutos; o formulário apresenta a definição aplicável.

Fontes consultadas:

- Guia de Dimensionamento de Cabos para Baixa Tensão Prysmian, Rev10, tabelas 1 e 5–17; documento fornecido no chat.
- ABNT NBR 5410:2004, versão corrigida 2008, tabela 33, notas e 6.2.5.1.2. Cópia integral da norma consultada no repositório da PUC Goiás: https://professor.pucgoias.edu.br/SiteDocente/admin/arquivosUpload/18451/material/nbr_5410.pdf

Os PDFs não são distribuídos neste pacote. As ilustrações já existentes provêm da planilha original.

## Alterações verificadas

- 32 condições de instalação e 94 relações; 61 entradas ilustradas derivadas da matriz, sem catálogo paralelo comandando as escolhas.
- Reconhecimento dos sete nomes que tinham espaços finais, normalização consistente no navegador e servidor e bloqueio da galeria para nomes desconhecidos.
- Alternância entre unipolar e multipolar nos métodos 13–17, com E/F calculado a partir do cabo e sem ocultar uma alternativa válida.
- Disposições de F/G montadas dinamicamente, inclusão de 17 e remoção do ajuste oculto incompatível ao retornar a C.
- Faixas geométricas, limites inferior/superior e reconhecimento dos códigos legados com 500De, preservando a identidade dos circuitos e os demais dados do projeto.
- Confirmação manual ou medidas para condições que dependem da instalação real, com revalidação quando a combinação muda. Valores não finitos não são aceitos como medidas válidas.
- Inclusão de LSHF/A (70 °C) e HEPR (90 °C), sem substituir o nome gravado por PVC/EPR. Os aliases atravessam a cadeia térmica e não desabilitam a edição e restauração de fórmulas pelo modo revisor.
- Salvamento e reabertura de projetos com as novas condições.

## Testes

**106 testes automatizados aprovados** com `python -B -m unittest discover -s tests -q` (182,59 s). A suíte percorre todas as 94 relações e verifica limites geométricos, transições, aliases térmicos, persistência, edição/restauração de fórmulas e regressões anteriores de proteções, DPS e motores.

Os testes numéricos do exemplo confirmam explicitamente as condições físicas usadas como premissa. Um teste separado exige que um projeto antigo não receba essa confirmação automaticamente. A potência ativa da origem permanece 76.700 W no exemplo original.

Testes em navegador: as 32 galerias contêm exatamente os métodos previstos; parede isolante restringe a A1/A2; trocas E/F/C e método 17 atualizam as disposições; mudança de cabo reabre a confirmação; V/De igual a 10 é aceito no intervalo B2, 20 é rejeitado nesse intervalo e 900 é aceito no intervalo B1. Salvamento e reabertura de LSHF/A, método 24 e medidas confirmados. A consulta exibiu 32 linhas, busca por 22 com duas condições geométricas e filtro G com uma instalação. Modal e visualização de 390 pixels verificados, sem transbordamento horizontal da página e sem erros JavaScript. Tabelas largas têm rolagem interna.

## Limites desta revisão

As tabelas mostram as combinações suportadas na matriz do aplicativo. Exceções normativas com outras condições de uso exigem verificação específica; por exemplo, a nota 8 da tabela 33 remete a requisitos próprios para condutores isolados em certos condutos enterrados. Não foram liberadas combinações excepcionais sem implementar suas condições.

O arquivo `data/r42.json.gz` e a planilha em `referencia/` permanecem idênticos aos da versão anterior. As adaptações de cálculo são aplicadas à cópia de trabalho em memória e acompanham o projeto salvo. A execução por duplo clique no Windows não foi ensaiada nesta revisão.

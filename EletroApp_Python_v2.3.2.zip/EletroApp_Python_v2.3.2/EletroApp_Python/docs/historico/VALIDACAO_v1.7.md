# Validação da versão 1.7.0

Data: 03/10/2026. Ambiente: Linux, Python 3.12 e Chromium.

## Escopo

Esta revisão atende à seleção guiada de disjuntor, DPS e backup, à separação das cargas de motores e à transferência da partida para a aba Motores. O aplicativo continua local e sem dependências Python externas. Os arquivos de referência da r42 não foram editados.

Os modos Automático e Manual são independentes e acompanham o identificador estável do circuito. Uma mudança de modo é explícita; abrir um projeto antigo não aplica novas escolhas automaticamente. A prévia recalcula uma cópia sem salvar o projeto.

O maior motor usa a potência e os polos para consultar a tabela r42. Entradas opcionais de placa permitem substituir potência mecânica, fp, rendimento, Ip/In, corrente nominal e conjugado. Quando a corrente nominal não é informada e os dados necessários estão disponíveis, ela é obtida da tabela ou calculada a partir das entradas. A soma dos demais motores mantém os critérios da planilha, com fp e rendimento médios informados para o conjunto. Valores insuficientes geram pendências, inclusive na seleção automática das proteções a montante.

Para preservar projetos anteriores, a soma de motores às cargas gerais começa desativada nesses circuitos. Em circuitos novos, fica ativada. O aplicativo explica como evitar dupla contagem. Os fatores e as aproximações de partida da r42 foram mantidos; o método, o percentual aplicável e os limites ficam juntos na aba Motores.

## Verificações executadas

- **93 testes automatizados aprovados** com `python -m unittest discover -s tests -q`: os 76 testes existentes e 17 testes desta revisão.
- Regressão da abertura da r42, incluindo a potência ativa original de 76.700 W.
- Seleção automática de disjuntor com critérios de corrente, ampacidade, partida, curto-circuito, polos e tensão; remoção de escolha automática que deixa de ter candidato compatível.
- Preservação de escolhas manuais, persistência dos modos, duplicação e reordenação de circuitos.
- Seleção de DPS pelos dados do catálogo, tratamento das unidades do catálogo Siemens e indicação de modelo manual ausente.
- Backup automático com limite de corrente e poder de corte, alterações no circuito, manutenção de backup manual e indicação de backup manual vazio.
- Parâmetros de placa, cálculo da corrente do motor, restauração dos parâmetros da tabela ao limpar substituições, motor ausente e validação de entradas inválidas.
- Soma de cargas de motores uma única vez, contribuição nos alimentadores e bloqueio da seleção automática quando faltam dados necessários.
- Teste completo da interface: criação de projeto, troca independente de modos, entrada manual de motor fora da tabela, partida por soft-starter, escolha manual de DPS, escolha rápida de disjuntor e salvamento/reabertura dos valores. Corrente calculada conferida com os dados de placa.
- Revisão visual em navegador nas larguras de 1.365 e 390 pixels, sem erros JavaScript e sem rolagem horizontal da página.

## Critérios e limites da automação

O disjuntor automático exige dados aplicáveis à tensão e à topologia do circuito e usa os ajustes existentes no catálogo. As verificações de seccionamento e de seletividade, e a confirmação do projeto, continuam expostas. A ausência de candidato é uma pendência; o aplicativo não mantém como válida uma escolha automática anterior incompatível.

O backup automático usa fusível gG de catálogo, respeitando o limite disponível do DPS e a capacidade de interrupção necessária. Uma equivalência entre fusível e disjuntor não é presumida. Declarações de Isccr e coordenação dependentes do fabricante não são confirmadas automaticamente. Os limites de tensão disponíveis no catálogo também restringem os candidatos.

Os parâmetros preenchidos pela tabela de motores são referências da r42. Para um motor específico, os dados de placa podem substituí-los. A partida por soft-starter, reator ou inversor depende de informações do equipamento; a interface orienta o preenchimento, sem inventar ajustes desconhecidos.

Os testes não cobrem todas as combinações possíveis de equipamentos, instalações e catálogos. A execução por duplo clique no Windows e a impressão em PDF não foram ensaiadas nesta revisão.

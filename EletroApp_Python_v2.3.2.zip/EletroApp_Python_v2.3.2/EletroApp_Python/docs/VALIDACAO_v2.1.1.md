# EletroApp 2.1.1 — correções e validação

Data: 08/10/2026. Base de trabalho: distribuição 2.1.0. Resposta aos nove achados da análise independente dessa versão.

## Correções por achado

| Achado | Alteração | Evidência de regressão |
|---|---|---|
| A1 — curvas sem faixa comum marcadas como verificadas | O montante precisa documentar tempos mínimos desde o início do envelope máximo do jusante. Dados ausentes não representam não atuação. Faixa comum insuficiente gera dados insuficientes, com motivo na trilha. | Curvas 10–20 kA e 0,1–9 kA, com Ik 8,93 kA, não recebem nível verificado. Testes também cobrem lacuna inferior e montante cujo domínio começa antes do jusante. |
| A2 — coluna I²t descartada | Normalização preserva dígitos e aceita ² como 2. Colunas desconhecidas ou repetidas são recusadas. Ajuste ON/OFF é preservado e confrontado em ambos os dispositivos. Condição ausente impede verificação quando o dispositivo ajustável tem I²t. | ON × OFF, OFF × ON, coluna de jusante, condição ausente, valor inválido e cabeçalhos incorretos. |
| A3 — base antiga usa regras atuais | Retratos de base, formato 2, contêm os arquivos de regras. A instalação recebe regras da instância do modelo. Mudanças de referência, Iz e agrupamento entram na comparação. Cada revisão registra a base calculada, além da base revisada. | Regra B2 → A1: a base antiga recalcula B2 e a nova A1. Histórico compara as bases de cada revisão. Retrato incompleto, base ausente e mudança de código retornam comparação indisponível. |
| A4 — semântica da 2.0 muda ao abrir | Documento recebe identificação de semântica. Em projetos nativos da 2.0, a edição comum com efeito na raiz é copiada para o escopo raiz, com registro de migração e conservação da autoria. | Expressão =0 continua produzindo 0 Ω na raiz, inclusive após salvar/reabrir. Projetos identificados como 2.1 mantêm a semântica nova. Edição externa continua externa. |
| A5 — valor/fórmula da fonte perdido | Valores fixos da fonte/projeto viram expressões preservadas; edição sem registro mantém aviso de integridade. Fórmulas sem equivalente ficam pendentes. Histórico de edição da fonte conserva autor e versão. | B138 =123,456 mantém 123,456. Fórmula não convertível é listada e pode ser conferida pelo revisor. Histórico registrado da fonte mantém autoria. |
| A6 — comparação ignora escopo | Diferenças são produzidas por variável e escopo, com circuito, expressão efetiva e versão anterior/nova. | Alteração local 69,128 →123,456 A mostra a expressão =123.456 no QDFL-01. Edição na raiz compara com a variante da raiz. |
| A7 — catálogo diz “modelo” para edição local | O status considera todos os escopos ativos. Filtro e trilha identificam edições por circuito. | Catálogo retorna status e integridade “editada”; filtro inclui a variável e a trilha mostra 123,456 A. |
| A8 — duplicação perde fórmula particular | Duplica os escopos por circuito, seus históricos e as condições de instalação. Selos válidos são vinculados ao novo ID; alterações externas não são regularizadas. | Cópia calcula os mesmos 123,456 A. Restaurar só a cópia não altera a origem. Histórico adulterado permanece sinalizado. |
| A9 — histórico restaurado ao modelo desaparece | Histórico é migrado mesmo com ativa=0. O registro original da v1.x é conservado. Versões históricas não convertíveis ficam documentadas e pendentes. | Versão de Ana permanece com ativa=0, sem alterar os cálculos. Expressão histórica sem equivalente conserva o original. |

## Controles adicionais

- **Icu:** a coluna importada não substitui silenciosamente um Icu diferente no catálogo para a tensão do circuito. A divergência impede a aplicação da linha e pede reconciliação. A coluna não comprova capacidade reforçada por associação em cascata.
- **Ii:** a coordenação usa o Ii instantâneo do modelo quando disponível; o valor manual fica identificado e sua divergência gera aviso. Uma tabela que declara Ii =1.600 A não valida um dispositivo cujo disparo instantâneo conhecido é 4.400 A.
- **Comparações incompletas:** a interface não apresenta “nenhum resultado muda” quando faltam regras, código antigo ou base arquivada. A adoção da base atual registra a limitação; a contagem de diferenças desconhecida fica nula.
- **Verificações antigas da planilha:** os dois registros documentais padrão sobre varredura de fórmulas e memoriais são reconhecidos por seu conteúdo exato e preservados no registro de migração. Alterações desses registros não são descartadas por uma regra genérica.

## Testes e alterações nos ensaios anteriores

Os 28 testes novos estão em `tests/test_v211.py` e exercitam operações de cálculo, migração, gravação/reabertura, duplicação, comparação e rotas HTTP.

Os ensaios sintéticos de coordenação das versões 2.0/2.1 foram atualizados para declarar I²t OFF e Ii instantâneo de 4.400 A. Os ensaios favoráveis de curvas receberam cobertura inferior explícita. As conclusões de cruzamento, limite superior e região instantânea continuam sendo exigidas. Isso retira dos próprios dados de teste as premissas que os achados A1/A2 demonstraram incorretas.

O teste de comparação de uma revisão v1.x sem identificação de base agora exige comparação indisponível. A comparação de entradas e a preservação das revisões continuam verificadas.

Todos os dados elétricos de fabricante usados nos ensaios são sintéticos e não devem ser utilizados como especificação de equipamento.

## Compatibilidade e limites

- A versão continua funcionando localmente, com Python 3.10 ou superior e navegador, sem Excel e sem bibliotecas externas para execução.
- Arquivos nativos continuam no formato de projeto v2, acrescidos de um identificador de semântica das fórmulas. Retratos de base usam formato v2 para incluir as regras operacionais.
- Para preservar todo o histórico, transfira a pasta `projetos` inteira com o aplicativo fechado. `.eletro` contém o projeto e a identificação das bases, mas não transporta o banco de retratos históricos.
- As regras ou o código que uma versão antiga não arquivou não podem ser reconstruídos com fidelidade. A interface passa a informar essa condição. Código Python de versões antigas não é executado pelo mecanismo de comparação.
- Perdas já consolidadas em importações antigas exigem o original ou um backup anterior à conversão. A correção preserva os dados presentes; não inventa dados ausentes.
- Tabelas importadas pela 2.1.0 podem exigir reimportação para restabelecer I²t perdido. O nome/modelo e a presença de um selo não substituem as condições de validade.
- As tabelas normativas e referências técnicas não foram declaradas verificadas por esta atualização. Seus estados e pendências de conferência continuam visíveis.
- Não foi feita validação visual independente em navegador nesta revisão. A interface foi verificada por sintaxe JavaScript e contratos HTTP; o comportamento do motor foi verificado pelos testes automatizados.

## Resultado da execução

O resultado final da suíte está no arquivo `RESULTADO_TESTES.txt`, incluído na raiz do pacote. Para repetir:

```bash
python -m unittest discover -s tests -v
```

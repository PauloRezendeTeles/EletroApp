# EletroApp 2.3.2 — condutores em paralelo no neutro e no PE

Revisão pedida em 14/10/2026: conferir se o aplicativo considera dois condutores por polo no neutro e no condutor de proteção (PE).

## O que a 2.3.1 fazia

O aplicativo tinha um único campo, **Condutores por polo** (Nc), e o aplicava às fases, ao neutro e ao PE ao mesmo tempo. Ou seja: supunha sempre que cada grupo em paralelo tinha o seu neutro e o seu PE. Não havia como informar um neutro ou um PE com quantidade diferente (por exemplo, um PE único comum aos dois grupos).

Rastreamento grandeza a grandeza, com Nc = 2:

| Grandeza | Neutro | PE |
|---|---|---|
| Corrente por condutor (ampacidade) | ÷ Nc ✓ | não se aplica |
| Iz corrigida | × Nc ✓ | não se aplica |
| Seção pela queda de tensão | ÷ Nc ✓ | não se aplica |
| Impedância R e X (pré-dimensionamento e escolhida) | ÷ Nc ✓ | ÷ Nc ✓ |
| Ik fase-terra, laço de falta, choque, comprimento máximo | via impedância ✓ | via impedância ✓ |
| Seção térmica por curto (pré e final) | Ik ÷ Nc ✓ | **Ik total, sem ÷ Nc** ✗ |
| Tabela 48 / Tabela 58 | por condutor ✓ | por condutor ✓ |
| Verificação integrada (proteção do ramal) | ÷ Nc ✓ | ÷ Nc ✓ |

**Incoerência no PE:** a impedância e a verificação integrada tratavam o PE como Nc condutores em paralelo, mas a seção térmica (S = I·√t/k) usava a corrente total, como se fosse um único condutor. No QGBT-01 com Nc = 2, a seção térmica pedida por condutor era 9,07 mm² quando devia ser 4,53 mm². O erro era a favor da segurança, mas o modelo era internamente contraditório.

**Divisão dupla por Nc (fora do neutro/PE, encontrada no mesmo rastreamento):** as impedâncias do trecho já saem divididas por Nc. Três fórmulas dividiam outra vez:

| Fórmula | Efeito no QGBT-01 com Nc = 2 | 2.3.1 | 2.3.2 |
|---|---|---|---|
| Queda de tensão na partida do motor (5 fórmulas) | subestimada | 1,84 % | 3,68 % |
| Queda do sistema (parcela da fonte ÷ Nc) | subestimada | 2,48 % | 2,98 % |
| Queda no neutro (diagnóstico) | subestimada | 0,13 % | 0,27 % |

A queda de tensão na partida era a mais grave, porque podia aprovar uma partida que não atende. Na partida, toda a impedância da instalação a montante também era dividida pelo Nc do circuito.

## O que mudou

### Entradas novas (aba Condutores do circuito)

- **Condutores em paralelo no neutro/PEN** — vazio = igual ao das fases.
- **Condutores em paralelo no PE** — vazio = igual ao das fases. Use 1 para um PE único comum aos paralelos.

Em TN-C (PEN), o PE adota a quantidade do neutro, porque é o mesmo condutor físico.

Com os campos vazios, os resultados são idênticos aos de informar a mesma quantidade das fases (teste `test_defaults_follow_phase_count`).

### Onde cada quantidade entra

| Cálculo | Fases | Neutro/PEN | PE |
|---|---|---|---|
| Corrente por condutor e Iz | Nc | Nc_N (piso de 15% repartido uma única vez) | — |
| Seção pela queda | Nc | Nc_N | — |
| R e X do trecho | Nc | Nc_N | Nc_PE |
| Seção térmica por curto | Nc | Nc_N | **Nc_PE (corrigido)** |
| Tabela 48 | — | Nc_N ≠ Nc: Nc·S_N,mín ÷ Nc_N, seção superior | — |
| Tabela 58 | — | — | Nc_PE ≠ Nc: Tabela 58 sobre Nc·S_F, ÷ Nc_PE, seção superior |
| Verificação integrada (∫I²dt) | Nc | Nc_N | Nc_PE |

As regras das Tabelas 48 e 58 com quantidades diferentes são **critério interno**: a NBR 5410 não trata explicitamente desses casos. A Tabela 58 aplicada sobre a seção total das fases segue a lógica de 6.4.3.1.5 b (PE comum dimensionado pela maior seção de fase servida). O arredondamento é para a seção superior, a favor da segurança. Quando Nc_PE = Nc ou Nc_N = Nc, nada muda em relação à 2.3.1.

### Alertas

- Neutro com quantidade diferente das fases: **aviso da NBR 5410, 6.2.5.7.2**. A divisão igual de corrente pressupõe cada grupo com todas as fases **e o respectivo neutro**; com quantidades diferentes, é necessário estudo específico (6.2.5.7.1 b).
- PE com quantidade diferente: nota explicando o critério da Tabela 58. Com cabo multipolar, lembra que cada cabo normalmente já tem a sua veia de PE.

### Notação

- `2x{3#240mm²(240mm²)PE120mm²}` — tudo em dois grupos (como antes).
- `2x{3#240mm²(240mm²)} + 1xPE120mm²` — PE único.
- `2x{3#240mm²PE120mm²} + 1x(240mm²)` — neutro único.
- `2x{3#240mm²} + 1x(PEN240mm²)` — TN-C com PEN único.

## Comparação numérica (exemplo, 1.069 variáveis × 6 circuitos por cenário)

| Cenário | Diferenças frente à 2.3.1 |
|---|---|
| Exemplo sem alteração (Nc = 1) | **0** |
| QGBT-01 com Nc = 2 ou 3 | 9 valores por cenário: seção térmica do PE (2), partida de motor (5), queda do sistema (1), queda do neutro (1) |
| QDFL-01 e QDFL-02 com Nc = 2 | 1 valor por cenário: seção térmica do PE |

QGBT-01 (3F+N+PE, 240/120/120 mm², TN-S):

| Grandeza | Nc = 1 | Nc = 2 | Nc = 2, PE único | Nc = 2, neutro único |
|---|---|---|---|---|
| R do PE no trecho (Ω) | 0,00475 | 0,002375 | 0,00475 | 0,002375 |
| Ik fase-terra máx. (kA) | 4,568 | 5,214 | 4,815 | 5,214 |
| Ik do laço de falta (A) | 3.938 | 4.531 | 4.157 | 4.531 |
| Comprimento máx. p/ atuação instantânea (m) | 163,3 | 326,6 | 201,8 | 326,6 |
| S_PE térmica por condutor (mm²) | 7,94 | 4,53 | 8,37 | 4,53 |
| S_PE pela Tabela 58 (mm²) | 120 | 120 | **240** | 120 |
| PE escolhido 120 mm² | ✓ | ✓ | **✗ EXCEDE** | ✓ |
| Corrente por condutor de neutro (A) | 120,2 | 75,1 | 75,1 | 150,2 |
| Iz do neutro corrigida (A) | 206 | 329,6 | 329,6 | 164,8 |
| Neutro mínimo pela fase (mm²) | 240 | 240 | 240 | **500** |

## Compatibilidade

- Projetos existentes abrem com os campos novos vazios, ou seja, com o mesmo comportamento das fases.
- Como as fórmulas e o código das regras mudaram, a base de cálculo muda e os projetos salvos mostram o aviso de base diferente. Em **Integridade → Comparar e decidir**, o revisor confere e adota a nova base. Pela comparação acima, só circuitos com Nc ≥ 2 mudam de resultado.
- As expressões anteriores foram registradas em `data/modelo/variantes_legado.json`, para não serem classificadas como edição particular na conversão de projetos da v1.x.
- Os comentários de revisão da 2.3.1 são mantidos.

## Limites

- Continua valendo a premissa de divisão igual de corrente (6.2.5.7.2). O aplicativo não calcula a divisão desigual de 6.2.5.7.1 b nem o Anexo D.
- A reatância de condutores em paralelo continua dividida por Nc, o que pressupõe grupos completos e simétricos. Arranjos desfavoráveis (cabos da mesma fase agrupados) exigem cálculo específico.
- A contribuição de cada condutor em falta alimentada pelas duas extremidades (5.3.5.4) continua só como alerta.

## Ensaios

- `tests/test_v232.py`: 10 testes. Cobrem quantidades padrão, impedâncias, seção térmica do PE por condutor, Tabela 58 com PE único e com PE em dobro, neutro único (corrente, Iz, Tabela 48, Ik), ausência de divisão dupla (partida, queda do sistema, queda do neutro), PEN em TN-C, notação, formulário, alertas, valores inválidos e verificação integrada (∫I²dt ÷ Nc de cada condutor).
- Suíte completa e navegador: ver `RESULTADO_TESTES.txt`.

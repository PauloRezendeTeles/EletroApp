# Validação — EletroApp 2.0.0 (modelo nativo)

Data: 06/10/2026. Esta versão conclui os itens 1, 2, 3, 4, 13 e 14 da lista de melhorias (os demais foram entregues na 1.12.0).

## 1. Paridade com o motor da v1.12

O modelo nativo foi gerado uma única vez da planilha r42 (`tools/gerar_modelo.py`) e comparado, variável a variável e circuito a circuito, com o motor da v1.12 executando o mesmo cenário (`tools/paridade.py`):

| Cenário | Valores comparados | Diferenças |
|---|---:|---:|
| Exemplo sem alterações | 6.301 | 31 |
| Alteração de cargas e comprimento | 6.301 | 31 |
| Dois circuitos novos (quadro e tomadas) | 8.353 | 31 |
| Ramal, QM e QGBT sem disjuntor na origem | 6.301 | 31 |
| Rede BT direta | 6.301 | 31 |
| Motores somados às cargas | 6.301 | 31 |
| Seções alteradas | 6.301 | 31 |

As 31 diferenças são sempre as mesmas: no grupo *Levantamento de cargas* dos dois primeiros circuitos, a planilha guardava subtítulos (“CARGA GERAL — FASE R”…) nas linhas de dados e deixava os totais vazios; no modelo nativo esses circuitos são comuns e os totais valem 0. Nenhum resultado a jusante muda.

A conversão de um projeto salvo pela v1.x (`tests/fixtures/projeto_v1.json.gz`) reproduz exatamente os resultados do exemplo nativo em todos os mais de 5.000 valores calculados (`test_v110.Regression.test_migrated_legacy_project_reproduces_native_results`).

## 2. Testes automatizados

`python -m unittest discover -s tests` — **188 testes, todos passando** (cerca de 3 min). Os testes das versões 1.x foram adaptados ao modelo nativo; os que verificavam a correção aplicada às fórmulas da planilha passaram a usar o projeto antigo de `tests/fixtures`, que só existe para os testes de conversão.

Novos em `tests/test_v20.py`:

- **Independência:** a planilha, o JSON da r42, o catálogo de fórmulas da r42 e a pasta `referencia` não existem mais; o exemplo guarda só dados de entrada; toda variável tem nome único; a trilha usa nomes e unidades.
- **Regras em Python rastreáveis:** cada regra lista dados usados, resultados, versão e referências.
- **Estrutura dinâmica:** 106 circuitos calculados (o 106º na posição 107), vetores que alcançam todos os circuitos, ramal e medição excluídos com o QGBT ligado direto ao transformador (Ik maior, como esperado), circuito com carga própria ligado à fonte, identidade preservada ao reordenar.
- **Invalidação seletiva:** após cinco alterações aleatórias com reseleção automática, todos os valores conferem com um recálculo completo; o mesmo vale para a cópia transacional (`fork`).
- **Base técnica:** 18 tabelas com fonte, categoria, revisão e situação da fonte; edição exige justificativa e fonte; cabeçalhos e células calculadas são recusados; texto em célula numérica é recusado; apagar a tabela de ampacidade é bloqueado por criar erros obrigatórios (nada é gravado); edição selada, detecção de adulteração e restauração com histórico.
- **Coordenação:** sem dados de fabricante nenhum par é “verificado”; dados sem documento são recusados; tabela de seletividade importada torna os pares verificados (total ou parcial conforme o Ik); curvas tempo × corrente importadas são comparadas ponto a ponto.
- **Conversão no banco:** projeto da v1.x no SQLite é convertido ao abrir, com cópia de segurança, revisão de conversão, comparação entre a revisão antiga e a convertida sem diferenças, diferenças posteriores e restauração da revisão antiga.
- **HTTP:** edição e restauração de tabela e importação/remoção de dados de fabricante exigem o modo revisor; o projeto em branco não tem limite de circuitos; arquivo `.xlsx` em *Importar projeto* é recusado com orientação.
- **Integridade:** expressão sem selo, valor fixo sobre cálculo e tabela sem selo são apontados; edição registrada confere; adulteração da expressão registrada é detectada; o revisor pode assumir a expressão encontrada (tipo `regularizacao`); projeto antigo com fórmula editada no catálogo vira versão registrada com o mesmo autor, e fórmula alterada sem registro vira “alterada fora do aplicativo”.

## 3. Interface

Conferida em navegador (Chromium, 1440 × 950): visão geral, circuitos, catálogo de cálculos (lista, detalhe, regras em Python), trilha de cálculo navegando entre variáveis, base técnica (lista, tabela, edição pelo revisor), coordenação (níveis, importação de tabela de seletividade), integridade, histórico e ajuda — sem erros de JavaScript.

## 4. Desempenho (contêiner de testes)

| Situação | Tempo |
|---|---:|
| Recálculo completo, 6 circuitos | ≈ 1 s |
| Recálculo completo, 50 circuitos | ≈ 4 s |
| Recálculo completo, 126 circuitos | ≈ 9–14 s |
| Alteração + reseleção automática, 126 circuitos | ≈ 2 s |
| Seleção automática inicial, 126 circuitos | ≈ 3,5 s |

O custo dominante é a escolha automática do disjuntor (expressões que percorrem as 567 linhas da biblioteca WEG em cada circuito).

## 5. O que continua sob responsabilidade do usuário

- Conferir as tabelas de norma célula a célula contra a edição vigente (a base técnica indica a situação de cada tabela).
- Importar os dados de seletividade e curvas do fabricante para obter pares “verificados”.
- Verificar as referências normativas embarcadas (todas como “não verificadas”).

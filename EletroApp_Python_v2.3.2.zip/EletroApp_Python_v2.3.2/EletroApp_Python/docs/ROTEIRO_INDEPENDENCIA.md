# Independência da planilha r42 — situação na v2.0.0

| Item | Pedido | Onde está |
|---|---|---|
| 1 | Projetos nativos, sem a planilha, o exemplo embutido, a importação XLSX r42 e a conferência com r42 | Formato `eletroapp-projeto` v2 (`core/project.py`), `data/exemplos/exemplo.json`, conversão de projetos antigos em `core/migracao.py`; arquivos da r42 removidos |
| 2 | Motor próprio com variáveis nomeadas, unidades e dependências explícitas | `core/motor.py`, `data/modelo/*.json`, `docs/MIGRACAO_MODELO.md` (variações unificadas e variante de raiz) |
| 3 | Estrutura dinâmica: sem limite de 100, sem posições fixas, identificadores | Circuitos como entidades com `id`; ordem topológica; vetores com o tamanho do projeto |
| 4 | Catálogo completo e rastreável, incluindo regras em Python | `core/catalog.py` (`rule_view`, trilha por variável), `static/catalogo.js` |
| 13 | Base técnica própria e versionada | `data/tabelas`, `_metadados.json`, `core/tabelas.py`, `static/base.js`, registro normativo ampliado |
| 14 | Coordenação com curvas e tabelas do fabricante, com níveis de evidência | `core/curvas.py`, página Coordenação, relatório |

Pontos que continuam abertos por dependerem de documentos externos: conferência célula a célula das tabelas de norma, verificação das referências normativas por um revisor e importação dos dados de seletividade dos fabricantes usados em cada projeto. O roteiro original da v1.12 está em `docs/historico/`.

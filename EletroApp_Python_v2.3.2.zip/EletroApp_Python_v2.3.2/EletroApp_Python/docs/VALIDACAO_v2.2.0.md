# EletroApp 2.2.0 — base técnica conferida com a NBR 5410 e a NBR 5419

Revisão de 12/10/2026, feita sobre a versão 2.1.2. Implementa a auditoria das tabelas usadas pelo aplicativo, conferida com o exemplar da ABNT NBR 5410:2004 (versão corrigida 2008) e com as quatro partes da ABNT NBR 5419:2026 enviados pelo usuário. As páginas citadas são as impressas no exemplar. A identificação de cada achado (E = erro, I = critério incompleto, C = consistência) é a mesma da auditoria.

## Decisões do usuário

- Implementar todos os achados confirmados.
- Queda de tensão: limite da NBR 5410 (6.2.7) escolhido pelo tipo de atendimento.
- Extensões que não são da NBR (solo, profundidade, agrupamento acima das tabelas): mantidas, marcadas como extensão.
- Método 28 do guia (forro falso e piso elevado): apresentado como método 21 (Tabela 33, nota 5).
- PE pela Tabela 58: seção padronizada mais próxima de S/2, como a norma, com opção de arredondar para cima.
- Extensão da Tabela 45 (cabos multipolares, 1,0 m, 7 a 20 circuitos): limitada a 0,80.

## Valores corrigidos na base técnica

Cada correção está registrada célula a célula em `data/tabelas/_metadados.json` (`correcoes`: células, valor anterior, valor novo, fonte e motivo). Na Base técnica, a célula corrigida aparece marcada, com o valor da 2.1.2 e a justificativa.

| Achado | Tabela e células | 2.1.2 | 2.2.0 | Fonte |
|---|---|---|---|---|
| E1 | `tab_ampacidade_2c!P5` | 1936 A | 1196 A | Tabela 39, Cu EPR/XLPE, método E, 2 carregados, 630 mm² (p. 105) |
| E11 | `tab_ampacidade_2c!N5` | 1112 A | 1122 A | Tabela 37, Cu EPR/XLPE, método C, 2 carregados, 630 mm² (p. 102) |
| E3 | `tab_secao_neutro!E18:E19` | 1,63 | 1,73 | Tabela F.1, trifásico, 3ª harmônica ≥ 66% (p. 196) |
| C2 | `tab_secao_neutro!A22:B25` | 500 a 1000 mm² | removidas | Tabela 48 termina em 400 mm² (p. 115) |
| E10 | `tab_disjuntores_ref!D9:E14` | 1,05/1,35 e 1,05/1,25 (NBR 5361) | 1,13/1,45 | IEC 60898-1 |
| E10 | `tab_disjuntores_ref!D15:E19` | 1,05 a 1,5 / 1,35 a 1,9 (CEE-19) | 1,05/1,30 | IEC 60947-2 |
| E10 | `tab_disjuntores_ref!A20:AB21` | sem linha | gG até 4 A 1,5/2,1; 4 a 16 A 1,5/1,9 | IEC 60269-1 |
| E8 | `tab_dps_siemens!K2:L20` | Uc e Up trocados de coluna | Uc em K, Up em L | catálogo Siemens 5SD7 citado em cada linha |
| E8 | `tab_dps_siemens!Y2:Z24`, `tab_dps_clamper!Y2:Z13` | vazio quando o texto traz total e valor por polo | valor por polo, fase ou modo | texto do catálogo na mesma linha |
| C1 | `tab_fatores_correcao!A1:K10` | bloco de agrupamento que nenhum cálculo lia | removido | Tabelas 42 a 45 geradas da regra do cálculo |
| C3 | `tab_nbr5410_t33` | imagem com `#VALUE!` e 11 rótulos com erro | imagem e rótulos da norma | Tabela 33 (pp. 90–95) |
| C12 | `tab_nbr5410_t33!E1:E60` | sem coluna | resumo das notas 2 a 9 e da nota final | Tabela 33, notas (p. 95) |
| C4 | `tab_ampacidade_2c!AN10`, `tab_ampacidade_3c!AZ10`, `tab_listas!AN10` | 336,6 kcmil | 336,4 kcmil | bitola CA/CAA padronizada |
| C5 | `tab_impedancias` | 2 casas decimais | 4 algarismos significativos em 1057 resistências | R20 da NBR NM 280 × [1 + α(θ − 20)] |
| C10 | `tab_metodos!AE3:AF3` | 28_1,5-5De / 28_5-50De | 21_1,5-5De / 21_5-50De | Tabela 33, nota 5 (p. 95) |

Na tabela de impedâncias, 114 valores ficaram como estavam, com 2 casas: incluem efeito pelicular e de proximidade (seções grandes) ou vêm de outro arredondamento, e precisam ser conferidos no catálogo do cabo. As reatâncias não mudaram. As Tabelas 36 a 39 só mudaram nas duas células acima (E1 e E11).

## Tabelas novas na Base técnica

A base passa de 18 para 35 tabelas. As 17 novas trazem a fonte e, nas da NBR 5410 e da NBR 5419, a página do exemplar. O cálculo lê 15 delas por nome, no lugar das constantes que estavam escritas nas fórmulas. A Tabela 49 e a da NBR NM 280 são de consulta: o fator 1,1·Uo usado no cálculo fica na tabela de critérios de DPS, e a NM 280 serve para conferir as resistências da tabela de impedâncias.

| Tabela | Até a 2.1.2 | Achado |
|---|---|---|
| Tabela 25 — tempos de seccionamento TN | faixas da IEC 60364-4-41 e 5 s acima de 32 A, na fórmula | I1 |
| Tabela 30 — k dos condutores de fase | constantes nas fórmulas, sem a faixa do PVC acima de 300 mm² | E6, E7 |
| Tabela 31 — Uw por tensão e categoria | 2,5 kV fixo | E9 |
| Tabela 35 — temperaturas dos condutores | constantes nas fórmulas | E6 |
| Tabela 46 — condutores carregados | ramos das fórmulas | I11 |
| Tabela 47 — seção mínima | só iluminação e força | I7 |
| Tabela 49 — Uc mínimo do DPS | 1,1·Uo na fórmula | — |
| Tabelas 53 a 57 — k do PE e do condutor nu | valores diferentes em três fórmulas | E6, E7, E15 |
| 6.4.3.1.4 — PE fora do cabo ou do conduto | sem verificação | I12 |
| 6.2.7 e 6.5.1.3.3 — limites de queda | 4% fixo; partida digitada em cada circuito | I6 |
| Critérios de DPS (6.3.5.2.4 d, 6.3.5.2.9, NBR 5419-4 Tabela 1) | um valor por classe; seções 16/4/1,5 mm² | I3, I4 |
| NBR 5419-1, Tabela 3 — corrente de pico por NP | Iimp 12,5 kA fixo | I2 |
| NBR 5419-4, Anexo C — proteção efetiva | constantes nas fórmulas | E14 |
| IEC 60909-0 — fatores de curto-circuito | constantes nas fórmulas | — |
| Constantes de motores (fonte a confirmar) | constantes nas fórmulas | — |
| Resistividade e constante térmica dos condutores | constantes nas fórmulas | — |
| NBR NM 280 — resistência a 20 °C | — | C5 |

As regras de instalação e agrupamento (`data/installation_rules.json`) continuam sendo a fonte do cálculo. A Base técnica mostra as Tabelas 41 a 45 e a matriz de métodos geradas dessas regras, com a origem de cada linha (NBR ou extensão).

## Critérios corrigidos e perguntas novas

| Achado | 2.2.0 | Pergunta nova (sem resposta) |
|---|---|---|
| I1 | Tabela 25 completa; 5 s em distribuição e, nos terminais, só com a confirmação de que alimentam apenas equipamento fixo (5.1.2.2.4.1 c); sem o limite de 32 A | Situação do local (Tabela C.1): situação 1 |
| E9 | Uw de referência e Up máximo pela Tabela 31, conforme a tensão do sistema | — |
| I2 | Iimp por condutor do DPS Classe I = ke·I/(n·n′), pela NBR 5419-1 | NP do SPDA e linhas ligadas à estrutura: sem o NP, Iimp não determinado (12,5 kA, 6.3.5.2.4 d) |
| I3 | Mínimo da norma por modo (In ≥ 5 kA) separado do critério de projeto (20 kA); módulo N–PE do esquema 3+1 | — |
| I4 | Seção do condutor do DPS: com SPDA, NBR 5419-4 Tabela 1 (16/6/2,5 mm²); sem SPDA, NBR 5410 6.3.5.2.9 | usa a resposta “Possui SPDA externo?” |
| E14 | Critério de 10 m com a distância até o DPS que protege; 0,5·Uw em falha crítica | Falha dos sistemas internos é crítica?: não |
| E8 | Fórmulas, seleção automática e fichas leem as mesmas colunas W a Z; valor por modo ou ausente fica “a confirmar” na ficha | — |
| I6 | Limite total pela Tabela 6.2.7 conforme o atendimento, com o acréscimo para linhas principais acima de 100 m; circuito terminal com no máximo 4% (6.2.7.2) na seção pela queda. Partida, quando o circuito não informa: 10% no dispositivo de partida, fp 0,3 e, nos demais pontos, o limite total | Limite de projeto (opcional): só o da norma |
| I7 | Tabela 47 com sinalização e controle, condutores nus, linhas flexíveis e extrabaixa tensão | — |
| I9 | Fator 0,86 dispensado nas condições de F.2 e F.3, com o motivo registrado | — |
| I10 | IB = I1·√(1 + h3²) a partir da taxa de 3ª harmônica informada | — |
| I11 | Circuitos sem neutro com 2 ou 3 condutores carregados pela Tabela 46 | Neutro distribuído?: com neutro, como até a 2.1.2 |
| I12 | Mínimo do PE fora do cabo ou do conduto (2,5/4 mm² Cu; 16 mm² Al) | Condutor de proteção (PE): no mesmo cabo ou conduto |
| E15 | k do PE pela Tabela 55 (veia de cabo ou enfeixado); Tabela 53 só com o PE separado | a mesma pergunta do PE |
| I13 | I2 ≤ Iz quando houver sobrecarga prolongada (5.3.4.1, nota) | Sobrecarga prolongada prevista?: não |
| E6, E7 | k e temperatura do PVC acima de 300 mm²; PE nu pela Tabela 57; para condutor de fase nu, que a Tabela 30 não normaliza, a Tabela 57, com o resultado marcado como fora da Tabela 30 | Condição do condutor nu (Tabela 57): condições normais |
| E12 | IN = fh·IB acima de 33% de 3ª harmônica; retirada a variável que aplicava fh duas vezes | — |
| E16 | fh procurado por faixa da Tabela F.1, e não pelo valor exato da taxa | — |
| E13 | Extensão da Tabela 45 limitada a 0,80 | — |
| C13 | Uma regra para o PE pela Tabela 58 | PE pela Tabela 58: seção padronizada mais próxima (opção: imediatamente superior) |
| C6, C7 | Rótulo “Up máximo admissível”; NBR 5419:2026 citada nas fórmulas e no registro | — |
| C9 | Registro normativo com página do exemplar e conferência da auditoria; IEC 60909-0, IEC 60898-1, IEC 60947-2, IEC 60269-1 e NBR NM 280 sem carimbo, porque não estavam em mãos | — |
| PEN | Regras de topologia citam 6.4.3.4.1, 6.4.3.4.3 e 5.6.2.2 (antes “5.4.3.6 — conferir”) | — |

### Achados retirados ou acrescentados durante a implementação

- **I8 retirado.** O fator KG do gerador já era calculado pela fórmula da IEC 60909-0 (6.6.1); só o cmax = 1,05 estava escrito nela e agora vem da tabela da IEC 60909-0.
- **Tabela 42 (parte do C11) retirada.** Com 9 ou mais circuitos, o valor da camada única é da própria NBR: a célula é mesclada na p. 108. Não é extensão.
- **E15, E16 e a citação do PEN** foram encontrados ao implementar e estão corrigidos acima.

## Vista normativa da Base técnica

- **Mapa:** todas as tabelas que o cálculo usa, inclusive as regras de instalação, agrupadas por norma, com localizador, situação da conferência, o que mudou nesta versão (células corrigidas, tabela nova ou regra alterada) e as edições do projeto.
- **Tabelas 36 a 39 na forma da norma:** cabeçalhos da NBR, marcas por célula (corrigida, editada no projeto, usada por um circuito), uso de cada circuito e gráfico Iz × seção em escala logarítmica.
- **Uso por circuito em qualquer tabela:** as células que o cálculo de um circuito leu, seguindo só os ramos de SE e SEERRO de fato tomados, mais as leituras das regras em Python.
- **Fichas de fabricante:** um cartão por modelo, com o texto do catálogo ao lado do valor que o cálculo lê.
- **Conferência guiada:** o revisor marca cada referência como conferida no projeto, com página e observação. A marcação fica no projeto e não altera a base de cálculo.

A Base técnica (mapa, Tabelas 36 a 39, fichas, conferência guiada, grade das tabelas com uso por circuito) e as Tabelas de instalação foram abertas no Chromium com 1440 e 390 px de largura, sem erros no console.

## Projeto de exemplo antes e depois

O exemplo foi calculado com a 2.1.2 e com a 2.2.0 na abertura e depois da seleção automática. O arquivo `exemplo_antes_depois_v2.2.0.csv` lista as 994 diferenças de cada etapa (1.988 linhas), com o rótulo da variável, os dois valores, o achado e a causa.

Para separar o efeito das impedâncias (C5), o exemplo foi recalculado com a 2.2.0 e a tabela de impedâncias da 2.1.2. Nesse ensaio, 170 das 203 variáveis alteradas voltam ao valor da 2.1.2: mudaram só por causa das impedâncias. As outras 33 mudam por outros achados, e nelas as impedâncias não alteram o valor final (no S_PE térmico do QDFL-01, que depende das duas causas, a diferença some no arredondamento). O resultado é o mesmo na abertura e após a seleção automática; nenhuma variável passou a dar erro, e as 6 imagens do método deixaram de dar `#VALUE!`.

| Achado | Células (abertura) | Principais resultados |
|---|---:|---|
| C5 | 779 em 171 variáveis | Ik até +0,8%; queda do trecho do ramal −2,5%; tempo térmico até −2,6% |
| I6 | 37 em 7 variáveis | limite total de queda 4% → 7% (atendimento por transformador); nenhum circuito muda de situação |
| I1 | 33 em 10 variáveis | QDFL-01 e QDFL-02: 5 s → 0,8 s, seccionamento automático passa a “atende”; QDFL-03: 0,4 s → 0,8 s |
| I2, I3, E7, E12, E14, I9 a I13 | 84 | perguntas e resultados novos; a variável que aplicava fh duas vezes foi retirada |
| E10 | 20 em 5 variáveis | caixa moldada: I2 1,6·In → 1,30·In (QDFL-01: 800 → 650 A); I2 ≤ 1,45·Iz passa a atender na proteção sugerida do QGBT-01 e do QM-01 |
| E15 | 15 em 5 variáveis | QDFL-01: k do PE 176 → 143; S_PE térmico 3,08 → 3,80 mm² |
| E8 | 9 em 7 variáveis | ramal (5SD7 443-1): Uc 1500 V → 350 V, Up 0,35 → 1,5 kV, Iimp 25 kA por polo; QM-01: o Uc deixa de ser o Up lido por engano (1500 V) e fica a confirmar na ficha, e o Up de 1,5 kV passa a ser lido e atende |
| E9 | 6 em 2 variáveis | Uw dos terminais e Up máximo 2,5 → 1,5 kV (127/220 V) |
| C3 | 6 | imagem do método no lugar de `#VALUE!` |
| C13 | 3 | QDFL-01: PE pela Tabela 58 47,5 → 50 mm² (a seção adotada já era 50) |
| I4 | 2 | QM-01 e QGBT-01: condutor do DPS 4 → 6 mm² |

Na seleção automática, o status do DPS do QGBT-01 passou de “modelo Siemens confirmado” para “Uc e Up a confirmar”: o catálogo traz valores por modo de ligação para esse modelo, e a seleção agora lê as mesmas colunas que as fórmulas. Os modelos escolhidos não mudaram.

Comportamento anterior observado e não alterado: no QDFL-01 e no QDFL-03, a instalação está pendente (agrupamento a informar), a queda acumulada fica “N/A — TOPOLOGIA” e a verificação da queda total mostra “excede”, porque compara o texto com o limite. É o mesmo resultado da 2.1.2.

## Matriz de instalação

`python -m tests.installation_matrix --output docs/matriz_instalacoes_v2.2.0.csv`

1.816 cenários: 1.744 cálculos conferidos, 72 bloqueios esperados (método G com dois condutores carregados) e nenhuma falha. Os resultados numéricos são os mesmos da 2.1.2. As 80 linhas de forro falso e piso elevado trazem o método 21 no lugar do 28. Com isso, os códigos de montagem distintos passam de 56 para 54 e as relações incompatíveis rejeitadas, de 5.282 para 5.090 (32 linhas × 54 montagens × 3 tipos de cabo − 94 relações).

## Testes

`python -m unittest discover -s tests -v`: 294 testes, 43 deles novos em `tests/test_v220.py` (um por correção da base, os critérios novos, a vista normativa, a conferência guiada, as rotas HTTP e a conversão de projetos antigos). Registro integral em `testes_v2.2.0.log`.

Cinco testes existentes mudaram de valor esperado por causa de uma correção intencional, com o motivo no próprio teste:

- `test_app`: queda e Ik dos seis circuitos na 3ª casa (C5).
- `test_catalog`: só a auditoria, com data e página, pode carimbar uma referência; IEC 60909-0, IEC 60898-1, IEC 60947-2, IEC 60269-1, NBR NM 280 e NBR 5440 continuam sem carimbo.
- `test_http` e `test_v20`: 35 tabelas na Base técnica; revisão 2 nas tabelas corrigidas.
- `test_v212`: 5.090 relações incompatíveis (método 28 tratado como 21).

Nenhuma outra expectativa foi alterada.

## Projetos existentes

- **Projetos da 2.x:** ao abrir, a integridade mostra que a base de cálculo mudou. Em **Integridade → Comparar e decidir**, o revisor vê os componentes alterados e adota a 2.2.0, com o registro da atualização. Como o código das regras mudou, a comparação de resultados dentro do aplicativo fica incompleta, com aviso explícito (o código antigo não é executado); o CSV de resultados exportado na 2.1.2 serve para comparar. Entradas com o método 28 viram 21 ao abrir, com a conversão registrada no projeto. Edições de tabela feitas no projeto continuam valendo e aparecem como edição.
- **Ensaio de atualização:** projeto criado pela 2.1.2 e aberto pela 2.2.0 com a mesma pasta de projetos. A integridade mostrou um único item (base de cálculo diferente, 35 componentes), a comparação avisou que o código antigo não está disponível, a adoção pelo modo revisor registrou a passagem de 2.1.2 para 2.2.0 e a integridade ficou sem pendências.
- **Projetos da 1.x:** valores e fórmulas anteriores da base são reconhecidos como da base, e não como edição do projeto; a conversão segue a base corrigida.
- **Conferências do revisor:** ficam no projeto e não mudam o cálculo.

## Limites

- A conferência usou o exemplar enviado pelo usuário. IEC 60909-0, IEC 60898-1, IEC 60947-2, IEC 60269-1 e NBR NM 280 não estavam em mãos: os valores dessas normas seguem a fonte declarada e ficam sem carimbo de conferência.
- Os dados de fabricante (Siemens, Clamper, WEG e fusíveis NH) foram conferidos quanto à coerência das colunas e à leitura pelo cálculo, não contra o catálogo vigente de cada fabricante.
- Concessionária, transformadores e constantes de motores continuam com fonte a confirmar (C8).
- As colunas de condutores nus continuam nas tabelas de ampacidade, lidas pelo cálculo por nome. A origem foi declarada nas condições de uso das duas tabelas, mas a fonte dos valores segue a confirmar (C4).
- As extensões fora da NBR continuam no cálculo, marcadas como extensão.
- O aplicativo não certifica projeto: os resultados dependem dos dados de entrada e da conferência do responsável técnico.

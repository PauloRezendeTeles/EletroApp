# Proteções da entrada e dos alimentadores — EletroApp 2.3.0

## 1. Configurar a entrada

Em **Entrada e fontes**, selecione o tipo de atendimento. A proteção em modo automático segue esta relação; nos atendimentos MT, também é possível escolher explicitamente chave fusível ou disjuntor com relé.

| Atendimento | Proteção considerada | Dados necessários |
| --- | --- | --- |
| Rede MT/Trafo sem dados | Subestação aérea: chave fusível MT | Tipo e corrente nominal do elo; referência e pontos de fusão mínima/eliminação máxima |
| Rede MT/Trafo com dados | Subestação abrigada: disjuntor MT com relé | Habilitação, correntes e tempos de 50/51/50N/51N; curva de 51/51N; interrupção do disjuntor |
| Rede BT Direta | Proteção externa desconhecida | Quadro de medição que delimita os circuitos internos |
| Gerador BT | Disjuntor no quadro de transferência | Quadro, modelo/ajustes/tempos do disjuntor e dados temporais do gerador |

O perfil precisa ser compatível com a fonte. Trocar o atendimento conserva os dados dos outros perfis. O aplicativo não preenche ajustes elétricos presumidos.

### Chave fusível

Escolha H, K, T ou Outro e informe a corrente nominal **do elo**. A corrente e a letra não bastam para determinar o tempo: use a curva do fabricante para aquele elo. Informe documento/edição/página e cole os pontos separados por ponto e vírgula:

```text
corrente_a;t_fusao_min_s;t_eliminacao_max_s
```

Acrescente de 2 a 200 linhas numéricas, com correntes de MT crescentes e tempos positivos não crescentes. A fusão mínima deve ser menor ou igual à eliminação máxima. Decimais podem usar vírgula ou ponto. O limite de texto é 5.000 caracteres.

A interpolação é logarítmica e limitada ao intervalo documentado. O cabo é avaliado com a **eliminação máxima**; a fusão mínima serve à comparação preliminar com a proteção de jusante. Não se soma outro tempo de abertura à curva de eliminação do elo. Mudar tipo, corrente nominal ou referência exige conferir e confirmar novamente a curva.

### Disjuntor MT com relé

Declare SIM/NÃO para cada função. Informe as correntes efetivas **em amperes no circuito de MT**. Os ajustes devem estar previamente convertidos quando necessário; não há campos de TC, medição residual ou fabricante/modelo do relé.

- 50/50N: corrente de partida e tempo de atuação em segundos.
- 51/51N: corrente de partida e tempo definido, ou TMS para curva IEC inversa normal, muito inversa ou extremamente inversa.
- Tempo de interrupção do disjuntor MT: milissegundos, do comando do relé até a eliminação da corrente.

O tempo de eliminação é o tempo da primeira função que atua mais a interrupção do disjuntor, somada uma única vez. Exemplo de ensaio: 0,30 s + 60 ms = 0,36 s.

A transferência de corrente BT→MT considera o tipo de falta e o grupo do transformador. Para Dyn, falta monofásica na BT pode sensibilizar a função de fase na MT, mas não gera corrente residual nas linhas primárias do delta. Uma função N habilitada não é considerada proteção dessa falta por si só. Ligações não cobertas ficam não verificadas.

### Rede BT direta

Selecione o quadro de medição. Em branco, o aplicativo tenta identificá-lo pelo nome, somente quando há um candidato único. Os cabos até esse quadro, inclusive seu alimentador, ficam **não verificáveis** pela proteção externa: faltam parâmetros da rede/cabos e da proteção da concessionária. A verificação interna começa na saída da medição, com os dados de fonte disponíveis. Informar a capacidade de um disjuntor de medição não fornece automaticamente a curva da proteção da rede.

## 2. Disjuntor do alimentador no quadro precedente

Abra o circuito e vá a **Proteções → Vínculo e proteção do alimentador**.

**Saída própria no quadro precedente** é o padrão. O disjuntor da origem do alimentador fica fisicamente na saída do quadro precedente. Seu cadastro pode ser acessado pela lista **Disjuntores das saídas deste quadro**. O disjuntor de chegada/manutenção do quadro alimentado é outro equipamento, quando instalado.

**Usar o disjuntor de chegada do quadro precedente** identifica explicitamente o mesmo equipamento. Seus dados são lidos do cadastro do precedente; o formulário oferece um botão para editá-lo ali. As entradas antigas do alimentador ficam preservadas para eventual desvinculação, mas não participam do cálculo enquanto vinculado.

Esse vínculo exige disjuntor de chegada cadastrado no precedente, uma única saída e ausência de carga própria nesse quadro. Quando há derivações, cadastre a saída de cada alimentador. Um vínculo que deixa de ser válido gera pendência; nunca volta silenciosamente a usar o antigo disjuntor do alimentador. Nomear/reordenar quadros mantém os dados associados aos identificadores dos circuitos.

O unifilar representa uma única instância do dispositivo vinculado. A coordenação não compara um disjuntor consigo mesmo. O disjuntor na chegada do próprio cabo não é tratado como proteção de uma falta localizada antes dele.

## 3. Gerador e corrente variável

Selecione o quadro de transferência. Cadastre nele o disjuntor de chegada/manutenção, seu modelo, ajustes e os novos campos de interrupção, tempo da função instantânea e I²t. Esses dados são obrigatórios também quando existem disjuntores próprios nas saídas. O trecho gerador→transferência fica identificado como **a cargo do fabricante do gerador**.

O cálculo do curto inicial permanece. Para calcular sua evolução, escolha um dos métodos:

### Parâmetros — excitação constante

Além dos dados existentes X″d e Xs, informe X′d, T′d e T″d de curto-circuito, na mesma base do gerador. Não use as constantes de circuito aberto T′do/T″do. Exige X″d ≤ X′d ≤ Xs e T″d ≤ T′d.

O modelo usa a soma exponencial das admitâncias subtransitória, transitória e síncrona. Mantém a impedância dos cabos e modifica o equivalente de sequência positiva ao longo do tempo. Não aplica uma razão fixa da curva dos terminais a todos os pontos da instalação.

É uma **estimativa com excitação constante**. Não representa a resposta real do AVR/PMG; Xs, sozinho, não determina a corrente sustentada de um gerador com excitação regulada. Os resultados desse modo permanecem identificados como estimativas, mesmo quando os valores calculados atendem aos limites.

### Curvas I(t) por ponto de falta

No formulário de cada circuito, informe a referência e os pontos da corrente eficaz simétrica que percorre seu alimentador, para faltas no fim dele:

```text
falta;tempo_s;i_min_a;i_max_a
```

Use 3F, 2F, FN e FPE conforme os condutores presentes. Para cada falta, comece em t=0 e informe ao menos dois pontos, com tempos crescentes e 0 ≤ Imin ≤ Imax. A curva deve incluir impedâncias de rede/cabos, condição de excitação e contribuições que efetivamente percorrem o alimentador. Não copie a curva dos terminais do gerador para um circuito distante.

O envelope inicial deve abranger as correntes iniciais calculadas com os dados da fonte (tolerância de arredondamento de 1 A). Essa conferência evita aceitar uma curva incompatível com o curto inicial usado nas demais verificações. Não há extrapolação além do último ponto.

Ao informar pontos e referência, os dados são vinculados à condição atual do projeto. Alterações elétricas, de topologia ou da base de cálculo exigem reconfirmação da aplicabilidade. Renomear quadros não invalida a curva. A cópia de um circuito exige sua própria confirmação.

### Atuação e energia térmica

O motor acompanha I(t). Tempo definido exige permanência acima da partida; corrente que cai antes de completar o retardo não demonstra atuação. Para curvas IEC, integra ∫dt/t(I)=1. O modelo de reset é imediato abaixo da partida; memória/limitação específica do fabricante não é presumida. Após o comando, o disparo permanece retido e o tempo de interrupção é contado mesmo que a corrente decaia.

Nos disjuntores BT, o método temporal cobre a função instantânea com tempo informado e a função S de tempo definido com I²t OFF. Memória térmica L e característica dinâmica S com I²t ON não são deduzidas de uma curva estática. Quando essas características forem necessárias para comprovar a atuação, o resultado permanece **não verificado**.

Para o cabo, integra ∫I²dt e compara com k²S², considerando os condutores em paralelo. Usa o envelope Imax até o maior tempo de eliminação de Imin/Imax. A corrente do motor é incluída como envelope conservador quando não estiver contemplada nas curvas por ponto; a corrente vista pelo relé MT permanece separada dessa contribuição.

A verificação adiabática implementada é limitada a 0,1…5 s. Fora desse intervalo, o resultado exige energia passante/critério térmico aplicável e não recebe aprovação térmica automática. O horizonte de estudo vai até 30 s: ausência de atuação no intervalo não significa que o equipamento nunca atuará.

O painel, as variáveis rastreáveis e o relatório exibem correntes, função, tempo de atuação, interrupção, eliminação, integral térmica, método e pendências. O indicador de atuação/térmica não substitui as verificações separadas de Icu/Ics, sobrecarga, topologia e instalação.

## 4. Atualização e dados ausentes

Preserve a pasta `projetos` inteira ao atualizar. Quando aparecer mudança de base, use **Integridade → Comparar e decidir** para adotar a base atual. Edições particulares de fórmulas e históricos continuam preservadas e devem ser conferidas pelo revisor. O tempo manual de montante de versões antigas continua salvo; ele não substitui os dados da proteção integrada.

Sem curvas/ajustes/constantes suficientes, aparece **não verificada**, sem perder o cálculo do curto inicial. A comparação MT×BT é uma pré-verificação nas faltas calculadas; não declara seletividade total por poucos pontos.

## Referências técnicas consultadas

- Multiquip, *Generator Short-Circuit Current*: https://service.multiquip.com/files/2-20230808-083811.pdf
- STAMFORD | AvK, *AGN 005 — Fault Currents and Short Circuit Decrement Curves*, Issue D: https://www.stamford-avk.com/stamford-avk/stamford-avk/sites/stamfordavk/files/AGNs/AGN-005_D-Fault-Currents-and-Short-Circuit-Decrement-Curves.pdf
- SEL, *PowerSystemProtection Library Extension Manual* — características IEC: https://cdn.selinc.com/assets/Literature/Miscellaneous/RTAC%20Library%20Extension%20Manuals/PowerSystemProtection.pdf
- Eaton, *Consulting Application Guide*, volume 14, seção de fusíveis: https://www.eaton.com/content/dam/eaton/support/poweredge/volume-14/vol14-tab02.pdf
- S&C, curvas de fusão mínima e eliminação total: https://www.sandc.com.br/en/contact-us/time-current-characteristic-curves/

As fontes fundamentam os métodos; não fornecem curvas genéricas válidas para qualquer equipamento. As tabelas normativas existentes do aplicativo não foram substituídas nesta versão.

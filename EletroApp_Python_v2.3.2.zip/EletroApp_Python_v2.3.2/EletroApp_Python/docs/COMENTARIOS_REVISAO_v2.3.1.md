# Comentários de revisão do aplicativo — EletroApp 2.3.1

## Objetivo

Registrar, na própria aba onde o problema aparece, erros, dúvidas e melhorias do aplicativo, para servir de base à próxima revisão. Os comentários são do **aplicativo**, não do projeto elétrico.

## Onde aparece

| Local | Bloco | Chave interna |
|---|---|---|
| Cada aba do menu (Visão geral, Entrada e fontes, Quadros e circuitos, Diagrama unifilar, Proteções, Coordenação, DPS, Verificações, Catálogo de cálculos, Base técnica, Tabelas de instalação, Integridade, Histórico do projeto, Como usar) | No fim da página. O botão **✎ Comentários** no topo da aba leva até ele e mostra quantos estão em aberto. | nome da aba (`overview`, `source`, …) |
| Formulário do circuito | No fim de cada etapa: Informações gerais, Cargas gerais, Motores, Instalação, Condutores, Curto-circuito, Proteções, DPS. | `circuito-<etapa>` |
| Aba **Comentários de revisão** (novo item do menu) | Bloco **Geral — aplicativo como um todo**, filtros, lista completa e exportação. | `geral` |

## Campos

- **Tipo:** Erro de cálculo · Erro de interface · Critério normativo · Melhoria · Dúvida · Texto e termos.
- **Prioridade:** Alta · Média · Baixa.
- **Referência (opcional):** campo, circuito, valor ou item da norma (ex.: "Ik mín. do QDFL-01 = 2,1 kA").
- **Autor (opcional):** lembrado neste navegador; no modo revisor, vem preenchido com o nome do revisor.
- **Comentário:** até 5.000 caracteres. Ctrl+Enter adiciona.

O aplicativo registra junto, automaticamente: data e hora, versão do aplicativo, projeto aberto e sua revisão, sub-aba ativa (por exemplo, *Integridade* ou *Expressões editadas*) e, no formulário do circuito, o circuito aberto. O nome do circuito é lido do projeto, não do navegador.

Cada comentário recebe um código sequencial (**C-001**, **C-002**, …) para ser citado na revisão. Situações: **Aberto**, **Resolvido** (com campo de resolução) e **Descartado**. Excluir é possível, mas *Descartar* mantém o histórico.

## Fluxo de revisão

1. Durante o uso, registre os comentários na aba onde o problema aparece.
2. Em **Comentários de revisão**, filtre pela situação (por padrão, *Aberto*) e clique em **Exportar Markdown**. Também há CSV (Excel, separador `;`) e JSON. O menu **Exportar** do topo tem um atalho para o Markdown com todos os comentários.
3. Envie o arquivo `.md` junto com o pacote do aplicativo para a revisão.
4. Ao receber a versão corrigida, marque cada item como **Resolvido** e anote a resolução (por exemplo, "corrigido na 2.3.2").

## Armazenamento e isolamento

- Tabela `review_comments` no banco local `projetos/eletroapp.sqlite3`, criada automaticamente ao abrir (bancos de versões anteriores são atualizados sem perda).
- Os comentários **não** entram no arquivo `.eletro`, **não** criam revisão no histórico do projeto e **não** alteram cálculos, tabelas ou a base de cálculo. Nenhum arquivo de `core/` foi alterado nesta versão: o identificador da base de cálculo dos projetos continua o mesmo da 2.3.0.
- As cópias de segurança automáticas do banco (pasta `projetos/backups`) incluem os comentários. Ao atualizar o aplicativo copiando a pasta `projetos`, os comentários vêm junto.
- Digitar no bloco de comentários dentro do formulário do circuito não marca o circuito como alterado; Enter nos campos de uma linha não envia o formulário do circuito.

## Correção incluída

Na 2.3.0, o `index.html` carregava `/protecao-integrada.js`, mas o servidor não incluía esse arquivo na lista de arquivos estáticos e respondia 404. Consequências: o formulário do circuito não abria (`integratedGroupHTML` indefinido em `editCircuit`) e o bloco *Proteção a montante do ramal* não aparecia em Entrada e fontes. A 2.3.1 serve o arquivo; o teste `test_every_script_and_style_in_index_is_served` confere todos os scripts e estilos referenciados no `index.html`.

## Interface de programação (local)

| Método | Endereço | Uso |
|---|---|---|
| GET | `/api/review/comments?view=&status=` | Lista (mais recente primeiro) e opções de tipo, prioridade e situação |
| GET | `/api/review/export?format=md\|csv\|json&status=&view=` | Arquivo para download |
| POST | `/api/review/add` | `view`, `view_label`, `subtab`, `kind`, `priority`, `ref`, `author`, `text`, `circuit_id` |
| POST | `/api/review/update` | `id` e qualquer de `text`, `ref`, `author`, `kind`, `priority`, `status`, `resolution`, `subtab` |
| POST | `/api/review/delete` | `id` |

Os POST exigem o token da sessão, como os demais. Não exigem modo revisor nem a revisão do projeto, porque não alteram o projeto.

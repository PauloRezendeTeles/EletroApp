# Migração do modelo r42 para o motor nativo

Variáveis por circuito: 1026 · fonte: 139 · projeto: 6 · tabelas: 18 · nomes definidos: 334.

## Variantes para circuitos ligados diretamente à fonte

Na r42 a linha 2 usava a impedância da fonte como impedância a montante. No motor nativo isso vale para qualquer circuito cujo montante seja a fonte ou o transformador:

- `sug_imp.resistencia_fase_a_montante`
- `sug_imp.reatancia_fase_a_montante`
- `sug_imp.resistencia_neutro_a_montante`
- `sug_imp.reatancia_neutro_a_montante`
- `sug_imp.resistencia_terra_a_montante`
- `sug_imp.reatancia_terra_a_montante`
- `sug_imp.impedancia_fase_a_montante`
- `sug_imp.resistencia_sequencia_zero_r0_rfase`
- `sug_imp.reatancia_sequencia_zero_x0_xfase_3xretorno`
- `sug_imp.resistencia_seq_zero_a_montante`
- `sug_imp.reatancia_seq_zero_a_montante`
- `imp.resistencia_fase_a_montante`
- `imp.reatancia_fase_a_montante`
- `imp.resistencia_neutro_a_montante`
- `imp.reatancia_neutro_a_montante`
- `imp.resistencia_terra_a_montante`
- `imp.reatancia_terra_a_montante`
- `imp.impedancia_fase_a_montante`
- `imp.resistencia_sequencia_zero_r0_rfase`
- `imp.reatancia_sequencia_zero_x0_xfase_3xretorno`
- `imp.resistencia_seq_zero_a_montante`
- `imp.reatancia_seq_zero_a_montante`

## Fórmulas unificadas

A r42 tinha linhas com fórmulas diferentes da coluna (linha 2 = entrada, linha 3 = medição, linhas 2–33 x 34–101 e erros pontuais). O motor nativo usa uma única fórmula por variável — a da linha 4 da r42, primeira linha de circuito comum. Linhas afetadas:

- `motores.pot_maior_motor_w` — linhas 3
- `motores.fp_maior_motor` — linhas 3
- `motores.rend_maior_motor_pct` — linhas 3
- `motores.ip_in` — linhas 3
- `motores.in_maior_motor_local_a` — linhas 3
- `motores.conjugado_nom_kgfm` — linhas 3
- `motores.in_demais_local_a` — linhas 3
- `carga.p_r_w` — linhas 2, 3
- `carga.p_s_w` — linhas 2, 3
- `carga.p_t_w` — linhas 2, 3
- `carga.soma_p_r_filhos_w` — linhas 2
- `carga.soma_p_r_filhos_w` — linhas 101
- `carga.soma_p_s_filhos_w` — linhas 2
- `carga.soma_p_s_filhos_w` — linhas 101
- `carga.soma_p_t_filhos_w` — linhas 2
- `carga.soma_p_t_filhos_w` — linhas 101
- `carga.q_r_propria_var` — linhas 2, 3
- `carga.q_s_propria_var` — linhas 2, 3
- `carga.q_t_propria_var` — linhas 2, 3
- `sug_icc.circuito` — linhas 2
- `sug_pe.isolacao_pe` — linhas 69
- `sug_pe.isolacao_pe` — linhas 89
- `icc.circuito` — linhas 2
- `iz.calc_pagina` — linhas 2
- `protecao.icu_ge_ikmax` — linhas 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45…
- `protecao.ics_ge_ikmax` — linhas 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45…
- `protecao.icu_ics_validos_para_a_tensao` — linhas 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45…
- `protecao.status_real_do_dispositivo` — linhas 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45…
- `seletividade.status_final_da_pre_seletividade` — linhas 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45…
- `dps.distancia_acum_desde_a_origem_m` — linhas 2

## Registro técnico

- carga.soma_p_r_filhos_w: intervalo Carga nos circuitos!B3:B102 tratado como todos os circuitos
- carga.soma_p_r_filhos_w: intervalo Carga nos circuitos!P3:P102 tratado como todos os circuitos
- carga.soma_p_s_filhos_w: intervalo Carga nos circuitos!B3:B102 tratado como todos os circuitos
- carga.soma_p_s_filhos_w: intervalo Carga nos circuitos!Q3:Q102 tratado como todos os circuitos
- carga.soma_p_t_filhos_w: intervalo Carga nos circuitos!B3:B102 tratado como todos os circuitos
- carga.soma_p_t_filhos_w: intervalo Carga nos circuitos!R3:R102 tratado como todos os circuitos
- carga.soma_q_r_filhos_var: intervalo Carga nos circuitos!B3:B102 tratado como todos os circuitos
- carga.soma_q_r_filhos_var: intervalo Carga nos circuitos!V3:V102 tratado como todos os circuitos
- carga.soma_q_s_filhos_var: intervalo Carga nos circuitos!B3:B102 tratado como todos os circuitos
- carga.soma_q_s_filhos_var: intervalo Carga nos circuitos!W3:W102 tratado como todos os circuitos
- carga.soma_q_t_filhos_var: intervalo Carga nos circuitos!B3:B102 tratado como todos os circuitos
- carga.soma_q_t_filhos_var: intervalo Carga nos circuitos!X3:X102 tratado como todos os circuitos
- dps.distancia_real_ao_dps_montante_m: intervalo DPS!G2:G111 tratado como todos os circuitos
- dps.distancia_real_ao_dps_montante_m: intervalo DPS!B2:B111 tratado como todos os circuitos
- dps.distancia_real_ao_dps_montante_m: intervalo DPS!G2:G111 tratado como todos os circuitos
- dps.distancia_real_ao_dps_montante_m: intervalo DPS!B2:B111 tratado como todos os circuitos
- verificacao.topologia_circuitos_com_pendencia: intervalo Identificação dos circuitos!K2:K111 tratado como todos os circuitos
- verificacao.topologia_circuitos_com_pendencia: intervalo Identificação dos circuitos!K2:K111 tratado como todos os circuitos
- verificacao.topologia_circuitos_com_pendencia: intervalo Identificação dos circuitos!K2:K111 tratado como todos os circuitos
- verificacao.topologia_circuitos_com_pendencia: intervalo Identificação dos circuitos!K2:K111 tratado como todos os circuitos
- verificacao.topologia_circuitos_com_pendencia: intervalo Identificação dos circuitos!K2:K111 tratado como todos os circuitos
- verificacao.memoriais_15_sem_erros_de_formula: verificação dos memoriais da r42 substituída (memoriais removidos)
- verificacao.formulas_quebradas_referencias: texto fixo da entrega r38 substituído
- verificacao.biblioteca_dps_clamper_cobertura_do: intervalo Auditoria_Checklist!N2:N111 tratado como todos os circuitos
- verificacao.biblioteca_dps_clamper_cobertura_do: intervalo Auditoria_Checklist!N2:N111 tratado como todos os circuitos
- verificacao.biblioteca_dps_clamper_cobertura_do: intervalo Auditoria_Checklist!N2:N111 tratado como todos os circuitos
- verificacao.biblioteca_dps_clamper_cobertura_do: intervalo Auditoria_Checklist!N2:N111 tratado como todos os circuitos
- verificacao.confiabilidade_do_ik_minimo_fonte: texto fixo da entrega r38 substituído

#!/usr/bin/env python3
"""EletroApp 2.0 — aplicativo local Python (apenas biblioteca padrão), com motor de cálculo nativo."""
from __future__ import annotations
import argparse
import copy
import csv
import gzip
import hashlib
import hmac
import html
import io
import json
import os
from pathlib import Path
import secrets
import sqlite3
import sys
import threading
import time
import traceback
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse, unquote
from core.project import Project, unpack, value_label, IDENT, INSTALL_METHODS, LINHAS_METODO_MAPA
from core.advisor import advise
from core.catalog import Catalog, CatalogError
from core import selection, trecho, protection
from core.installation import consultation
from core import historico, importacao
from core import integridade as integrity
from core import tabelas, curvas, normativa
from core.motor import APP_VERSION as RULES_VERSION

ROOT=Path(__file__).resolve().parent
IMG_EXT={'png':'image/png','jpg':'image/jpeg','jpeg':'image/jpeg','gif':'image/gif'}
# Versão do aplicativo (interface e servidor). v2.3.2: as regras de cálculo mudaram (Nc do neutro e do PE),
# logo core.motor.APP_VERSION acompanha esta versão.
APP_UI_VERSION='2.3.2'
# v2.3.1 — comentários de revisão do aplicativo (um bloco em cada aba; ficam no banco local, fora dos projetos).
REVIEW_KINDS=('Erro de cálculo','Erro de interface','Critério normativo','Melhoria','Dúvida','Texto e termos')
REVIEW_PRIORITIES=('Alta','Média','Baixa')
REVIEW_STATUS=('Aberto','Resolvido','Descartado')
REVIEW_FIELDS=('id','created','updated','view','view_label','subtab','kind','priority','status','text','ref','author',
               'app_version','project_id','project_title','project_revision','circuit_id','circuit_name','resolution')


def example_data():
    """Projeto de exemplo (somente dados de entrada; o cálculo é do modelo nativo)."""
    return json.loads((ROOT/'data/exemplos/exemplo.json').read_text(encoding='utf-8'))


class ClosingConnection(sqlite3.Connection):
    """Confirma/desfaz a transação e FECHA a conexão ao sair do `with` (no Windows o arquivo ficaria travado)."""
    def __exit__(self,*exc):
        try:return super().__exit__(*exc)
        finally:self.close()

class ConflictError(Exception):
    """Pedido baseado em outro projeto ou em uma revisão antiga (HTTP 409)."""
    def __init__(self,message,kind):super().__init__(message);self.kind=kind


class Store:
    BACKUPS_KEPT=10
    def __init__(self,path,backup=True):
        self.path=path; path.parent.mkdir(parents=True,exist_ok=True)
        existed=path.exists()
        with self.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, name TEXT NOT NULL, data BLOB NOT NULL, updated TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)')
            db.execute('CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)')
            # v1.12 — histórico recuperável: uma linha por gravação (cópia completa periódica + diferenças).
            db.execute('CREATE TABLE IF NOT EXISTS revisions (project_id TEXT NOT NULL, revision INTEGER NOT NULL, ts TEXT NOT NULL, '
                       'kind TEXT NOT NULL, summary TEXT, author TEXT, stats TEXT, data BLOB NOT NULL, PRIMARY KEY(project_id,revision))')
            # v2.1 — retrato de cada base de cálculo usada pelos projetos (para recalcular com a base em que foram revisados).
            db.execute('CREATE TABLE IF NOT EXISTS bases (hash TEXT PRIMARY KEY, manifest TEXT NOT NULL, data BLOB NOT NULL, '
                       'created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)')
            # v2.3.1 — comentários de revisão do aplicativo. Não pertencem a um projeto: não entram no .eletro,
            # não geram revisão do projeto e não alteram cálculos. O projeto aberto fica registrado como contexto.
            db.execute('CREATE TABLE IF NOT EXISTS review_comments (id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT NOT NULL, '
                       'updated TEXT NOT NULL, view TEXT NOT NULL, view_label TEXT, subtab TEXT, kind TEXT NOT NULL, priority TEXT NOT NULL, '
                       'status TEXT NOT NULL, text TEXT NOT NULL, ref TEXT, author TEXT, app_version TEXT, project_id TEXT, project_title TEXT, '
                       'project_revision INTEGER, circuit_id TEXT, circuit_name TEXT, resolution TEXT)')
        if backup and existed:self.backup('inicio')
        projects=self.list()
        if not projects:
            self.active_id=uuid.uuid4().hex;self.project=Project(example_data());self.save(summary='Projeto criado (exemplo)')
        else:
            with self.db() as db:row=db.execute("SELECT value FROM settings WHERE key='active'").fetchone()
            self.open(row[0] if row and any(x['id']==row[0] for x in projects) else projects[0]['id'])
    def db(self):return sqlite3.connect(self.path,timeout=20,factory=ClosingConnection)
    def list(self):
        with self.db() as db:
            return [{'id':r[0],'name':r[1],'updated':r[2]} for r in db.execute('SELECT id,name,updated FROM projects ORDER BY updated DESC')]
    @property
    def revision(self):return int(self.project.meta.get('revision',0) or 0)
    def check(self,project_id,revision=None):
        """Recusa gravações destinadas a outro projeto ou baseadas numa revisão antiga (v1.12)."""
        if not project_id:raise ConflictError('Pedido sem identificação do projeto. Atualize a página.','project')
        if project_id!=self.active_id:
            raise ConflictError('Esta janela está com outro projeto aberto do que o aplicativo. Nada foi gravado. '
                                'Atualize a página para continuar no projeto ativo.','project')
        if revision is not None and str(revision)!=str(self.revision):
            raise ConflictError(f'O projeto foi alterado em outra aba ou janela (revisão atual {self.revision}; esta tela partiu da revisão {revision}). '
                                'Nada foi gravado. Atualize a página e refaça a alteração.','revision')
    def archive_base(self,project=None):
        """Guarda o retrato da base em uso (uma vez por base) e devolve o manifesto."""
        m=(project or self.project).model;man=m.manifest()
        with self.db() as db:
            if not db.execute('SELECT 1 FROM bases WHERE hash=?',(man['hash'],)).fetchone():
                db.execute('INSERT INTO bases(hash,manifest,data) VALUES(?,?,?)',(man['hash'],json.dumps(man,ensure_ascii=False),
                           gzip.compress(json.dumps(m.serialize(),ensure_ascii=False,separators=(',',':')).encode(),compresslevel=6)))
        return man
    def base_model(self,hash_):
        from core.motor import Model
        with self.db() as db:row=db.execute('SELECT data FROM bases WHERE hash=?',(hash_,)).fetchone()
        return Model(json.loads(gzip.decompress(row[0]))) if row else None
    def base_status(self):
        """Base registrada no projeto × base em uso, com a comparação dos resultados quando a base registrada está guardada."""
        p=self.project;chk=integrity.base_check(p)
        out={'atual':integrity.base_record(p.model.manifest()),'projeto':p.doc.get('base'),'diferente':bool(chk),
             'historico':p.meta.get('atualizacoes_base',[]),'comparacao_completa':False,'resultados':None}
        if chk:
            out.update(componentes=chk['componentes'],descricao=chk['descricao'])
            old=self.base_model(chk['registrada'])
            out['base_guardada']=old is not None
            out['codigo_diferente']=(p.doc['base'].get('codigo')!=out['atual']['codigo'])
            reasons=[]
            if old is None:
                reasons.append('A base registrada não está guardada nesta instalação.')
            elif old.missing_rules:
                reasons.append('O retrato antigo não contém as regras operacionais: ' + ', '.join(old.missing_rules) + '.')
            if out['codigo_diferente']:
                reasons.append('O código das regras mudou; o código antigo não está disponível para execução.')
            out['comparacao_completa']=not reasons
            out['aviso_comparacao']=' '.join(reasons)
            if out['comparacao_completa']:
                prev=Project(copy.deepcopy(p.doc),base_model=old)
                out['resultados']=historico.compare_results(prev,p)
        return out
    def adopt_base(self,author=None):
        st=self.base_status()
        if not st['diferente']:raise ValueError('O projeto já usa a base de cálculo em vigor.')
        rec=self.project.doc['base']
        def fn(p):
            p.meta.setdefault('atualizacoes_base',[]).append({'ts':time.strftime('%Y-%m-%d %H:%M:%S'),'autor':author,'de':rec.get('hash'),
                'de_app':rec.get('app'),'para':st['atual']['hash'],'para_app':st['atual']['app'],'componentes':st['componentes'],
                'base_anterior_guardada':st.get('base_guardada',False),'codigo_diferente':st.get('codigo_diferente'),
                'comparacao_completa':st['comparacao_completa'],'aviso_comparacao':st.get('aviso_comparacao'),
                'circuitos_com_resultados_diferentes':None if st.get('resultados') is None else len(st['resultados']),
                'resultados':(st.get('resultados') or [])[:60]})
            p.doc['base']=st['atual']
            return {'circuitos':None if st.get('resultados') is None else len(st['resultados'])}
        return self.transactional(fn,summary='Base de cálculo atualizada (migração registrada)',author=author)
    def save(self,prev_data=None,summary='',author=None):
        man=self.archive_base()
        if not isinstance(self.project.doc.get('base'),dict):
            self.project.doc['base']=integrity.base_record(man)  # primeira gravação: fixa a base usada
        meta=self.project.meta
        meta['base_calculada']=integrity.base_record(man)
        meta['revision']=self.revision+1
        rev=meta['revision'];ts=time.strftime('%Y-%m-%d %H:%M:%S')
        with self.db() as db:
            last=db.execute('SELECT MAX(revision) FROM revisions WHERE project_id=?',(self.active_id,)).fetchone()[0]
            kind='full';stats=None;blob=None;packed=self.project.packed()
            if prev_data is not None and historico.is_native(prev_data) and last==rev-1 and rev%historico.FULL_EVERY!=1:
                d=historico.delta(prev_data,self.project.data)
                kind='delta';stats=historico.counts(d);blob=historico.pack(d)
            if blob is None:blob=packed
            db.execute('INSERT INTO projects(id,name,data) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,data=excluded.data,updated=CURRENT_TIMESTAMP',
                       (self.active_id,meta['title'],packed))
            db.execute('INSERT OR REPLACE INTO revisions(project_id,revision,ts,kind,summary,author,stats,data) VALUES(?,?,?,?,?,?,?,?)',
                       (self.active_id,rev,ts,kind,str(summary or 'Alteração')[:300],author,json.dumps(stats,ensure_ascii=False) if stats else None,blob))
            db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('active',?)",(self.active_id,))
    def open(self,uid):
        with self.db() as db:row=db.execute('SELECT data FROM projects WHERE id=?',(uid,)).fetchone()
        if not row:raise ValueError('Projeto não encontrado.')
        raw=unpack(row[0]);legacy=not historico.is_native(raw)
        self.project=Project(raw);self.active_id=uid
        with self.db() as db:db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('active',?)",(uid,))
        self.ensure_history()
        if legacy:
            # v2.0: projeto da v1.x convertido para o modelo nativo; as revisões antigas continuam no histórico.
            self.backup('antes-conversao-v2')
            self.save(summary='Conversão para o modelo nativo (EletroApp 2.0)')
        elif not isinstance(raw.get('base'),dict):
            self.save(summary='Base de cálculo registrada no projeto (projeto sem registro anterior)')
    def ensure_history(self):
        """Projetos de versões anteriores ganham a revisão inicial com o estado atual."""
        with self.db() as db:
            n=db.execute('SELECT COUNT(*) FROM revisions WHERE project_id=?',(self.active_id,)).fetchone()[0]
            if n:return
            rev=self.revision;self.project.meta['revision']=rev
            db.execute('INSERT INTO revisions(project_id,revision,ts,kind,summary,author,stats,data) VALUES(?,?,?,?,?,?,?,?)',
                       (self.active_id,rev,time.strftime('%Y-%m-%d %H:%M:%S'),'full','Estado ao abrir no EletroApp (início do histórico)',None,None,self.project.packed()))
    def add(self,data,name,summary='Projeto criado'):
        project=Project(data);project.meta['title']=str(name).strip()[:160] or 'Novo projeto'
        project.meta['revision']=0
        self.project=project;self.active_id=uuid.uuid4().hex;self.save(summary=summary)
    def reviewer_record(self):
        with self.db() as db:row=db.execute("SELECT value FROM settings WHERE key='reviewer'").fetchone()
        return json.loads(row[0]) if row and row[0] else None
    def reviewer_set(self,password):
        salt=secrets.token_hex(16)
        digest=hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt),240_000).hex()
        with self.db() as db:db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('reviewer',?)",(json.dumps({'salt':salt,'hash':digest}),))
    def reviewer_check(self,password):
        rec=self.reviewer_record()
        if not rec:return False
        digest=hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(rec['salt']),240_000).hex()
        return hmac.compare_digest(digest,rec['hash'])
    def transactional(self,fn,summary='Alteração',author=None):
        candidate=self.project.fork()
        result=fn(candidate)
        before=self.project
        self.project=candidate
        try:self.save(prev_data=before.data,summary=summary(result) if callable(summary) else summary,author=author)
        except Exception:self.project=before;raise
        return result
    # ---- histórico ---------------------------------------------------------
    def history(self,project_id=None):
        pid=project_id or self.active_id
        with self.db() as db:
            rows=db.execute('SELECT revision,ts,kind,summary,author,stats,length(data) FROM revisions WHERE project_id=? ORDER BY revision DESC',(pid,)).fetchall()
        return [{'revisao':r[0],'data':r[1],'tipo':r[2],'resumo':r[3],'autor':r[4],'estatistica':json.loads(r[5]) if r[5] else None,
                 'bytes':r[6],'atual':pid==self.active_id and r[0]==self.revision} for r in rows]
    def reconstruct(self,revision,project_id=None):
        """Dados completos do projeto numa revisão (cópia completa anterior + diferenças)."""
        pid=project_id or self.active_id;revision=int(revision)
        with self.db() as db:
            base=db.execute("SELECT revision,data FROM revisions WHERE project_id=? AND revision<=? AND kind='full' ORDER BY revision DESC LIMIT 1",(pid,revision)).fetchone()
            if not base:raise ValueError('Revisão inexistente ou sem cópia completa anterior.')
            deltas=db.execute("SELECT revision,data FROM revisions WHERE project_id=? AND revision>? AND revision<=? ORDER BY revision",(pid,base[0],revision)).fetchall()
        if not any(r==revision for r,_ in deltas) and base[0]!=revision:raise ValueError('Revisão inexistente.')
        data=unpack(base[1])
        for _,blob in deltas:historico.apply(data,historico.unpack(blob))
        return data
    def compare(self,rev_a,rev_b):
        a=self.reconstruct(rev_a);b=self.reconstruct(rev_b)
        a=historico.native(a);b=historico.native(b)
        out=historico.compare_data(a,b)
        projects=[];reasons=[]
        for label,data in (('A',a),('B',b)):
            rec=data.get('meta',{}).get('base_calculada') or data.get('base')
            if not isinstance(rec,dict) or not rec.get('hash'):
                reasons.append(f'Revisão {label}: não há identificação da base usada no cálculo.')
                continue
            old=self.base_model(rec['hash'])
            if old is None:
                reasons.append(f'Revisão {label}: base arquivada indisponível.')
            elif old.missing_rules:
                reasons.append(f'Revisão {label}: retrato sem as regras operacionais antigas.')
            elif rec.get('codigo')!=self.project.model.manifest()['codigo']:
                reasons.append(f'Revisão {label}: o código antigo não está disponível para execução.')
            else:
                projects.append(Project(copy.deepcopy(data),base_model=old))
        out['comparacao_completa']=not reasons
        out['aviso_comparacao']=' '.join(reasons)
        out['resultados']=historico.compare_results(*projects) if not reasons else None
        out.update(revisao_a=int(rev_a),revisao_b=int(rev_b))
        return out
    def restore(self,revision,author=None):
        data=self.reconstruct(revision)
        restored=Project(data)
        restored.meta['revision']=self.revision
        before=self.project
        self.backup('antes-restauracao')
        self.project=restored
        try:self.save(prev_data=before.data,summary=f'Restauração da revisão {int(revision)}',author=author)
        except Exception:self.project=before;raise
    # ---- comentários de revisão do aplicativo (v2.3.1) ----------------------
    @staticmethod
    def _review_clean(body,partial=False):
        """Valida os campos editáveis de um comentário. Em `partial`, só os campos enviados."""
        import re as _re
        out={}
        def text(key,limit,required=False):
            if key not in body:
                if required and not partial:raise ValueError('Escreva o comentário.' if key=='text' else f'Campo obrigatório: {key}.')
                return
            v=str(body.get(key) or '').replace('\r\n','\n').strip()
            if required and not v:raise ValueError('Escreva o comentário.' if key=='text' else f'Campo obrigatório: {key}.')
            out[key]=v[:limit] or None
        def choice(key,options,default):
            if key not in body:
                if not partial:out[key]=default
                return
            v=str(body.get(key) or '').strip()
            if v not in options:raise ValueError(f'Valor inválido para {key}: escolha entre '+', '.join(options)+'.')
            out[key]=v
        if 'view' in body or not partial:
            view=str(body.get('view') or '').strip()
            if not _re.fullmatch(r'[a-z0-9_-]{1,40}',view):raise ValueError('Aba do comentário inválida.')
            out['view']=view
        text('view_label',80);text('subtab',120);text('text',5000,required=True);text('ref',300);text('author',80);text('resolution',1000)
        choice('kind',REVIEW_KINDS,'Melhoria');choice('priority',REVIEW_PRIORITIES,'Média');choice('status',REVIEW_STATUS,'Aberto')
        return out
    @staticmethod
    def _review_row(r):
        return dict(zip(REVIEW_FIELDS,r))
    def review_list(self,view=None,status=None):
        sql='SELECT '+','.join(REVIEW_FIELDS)+' FROM review_comments';args=[];where=[]
        if view:where.append('view=?');args.append(view)
        if status:where.append('status=?');args.append(status)
        if where:sql+=' WHERE '+' AND '.join(where)
        sql+=' ORDER BY id DESC'
        with self.db() as db:return [self._review_row(r) for r in db.execute(sql,args)]
    def review_get(self,cid):
        with self.db() as db:r=db.execute('SELECT '+','.join(REVIEW_FIELDS)+' FROM review_comments WHERE id=?',(int(cid),)).fetchone()
        if not r:raise ValueError('Comentário não encontrado.')
        return self._review_row(r)
    def review_add(self,body):
        data=self._review_clean(body)
        ts=time.strftime('%Y-%m-%d %H:%M:%S');p=self.project
        circuit_id=str(body.get('circuit_id') or '').strip()[:64] or None;circuit_name=None
        if circuit_id:
            # O nome é lido do projeto aberto (não do navegador); circuito inexistente não é registrado.
            try:circuit_name=p.raw(IDENT,f'B{p.row_for(circuit_id)}')
            except (ValueError,KeyError,TypeError):circuit_id=None
        data.update(created=ts,updated=ts,app_version=APP_UI_VERSION,project_id=self.active_id,
                    project_title=str(p.meta.get('title') or '')[:160],project_revision=self.revision,
                    circuit_id=circuit_id,circuit_name=None if circuit_name is None else str(circuit_name)[:120])
        cols=[k for k in REVIEW_FIELDS if k!='id' and k in data]
        with self.db() as db:
            cur=db.execute(f"INSERT INTO review_comments({','.join(cols)}) VALUES({','.join('?'*len(cols))})",[data[k] for k in cols])
            new_id=cur.lastrowid
        return self.review_get(new_id)
    def review_update(self,cid,body):
        self.review_get(cid)
        data=self._review_clean({k:v for k,v in body.items() if k in ('text','ref','author','kind','priority','status','resolution','subtab')},partial=True)
        if not data:raise ValueError('Nada para alterar.')
        data['updated']=time.strftime('%Y-%m-%d %H:%M:%S')
        with self.db() as db:
            db.execute('UPDATE review_comments SET '+','.join(f'{k}=?' for k in data)+' WHERE id=?',[*data.values(),int(cid)])
        return self.review_get(cid)
    def review_delete(self,cid):
        self.review_get(cid)
        with self.db() as db:db.execute('DELETE FROM review_comments WHERE id=?',(int(cid),))
    def backup(self,reason='manual'):
        """Cópia de segurança do banco inteiro (todos os projetos e revisões); mantém as mais recentes."""
        folder=self.path.parent/'backups';folder.mkdir(parents=True,exist_ok=True)
        target=folder/f"eletroapp-{time.strftime('%Y%m%d-%H%M%S')}-{reason}.sqlite3"
        n=1
        while target.exists():target=folder/f"eletroapp-{time.strftime('%Y%m%d-%H%M%S')}-{reason}-{n}.sqlite3";n+=1
        src=sqlite3.connect(self.path,timeout=20)
        try:
            dst=sqlite3.connect(target)
            try:src.backup(dst)
            finally:dst.close()
        finally:src.close()
        files=sorted(folder.glob('eletroapp-*.sqlite3'),key=lambda f:f.stat().st_mtime,reverse=True)
        for old in files[self.BACKUPS_KEPT:]:
            try:old.unlink()
            except OSError:pass
        return target


def change_summary(project,changes,installation=None):
    """Texto curto da revisão: quantos campos e de quais circuitos."""
    import re as _re
    names=[]
    for c in changes if isinstance(changes,list) else []:
        m=_re.fullmatch(r'[A-Z]{1,3}(\d{1,3})',str(c.get('address','')) if isinstance(c,dict) else '')
        if m:
            n=project.raw(IDENT,'B'+m[1])
            if n and n not in names:names.append(str(n))
        elif isinstance(c,dict) and ':' in str(c.get('address','')):
            uid=str(c['address']).split(':',1)[1]
            try:n=project.raw(IDENT,f'B{project.row_for(uid)}')
            except ValueError:n=None
            if n and n not in names:names.append(str(n))
    txt=f'{len(changes)} campo(s) alterado(s)' if changes else ('Condições de instalação' if installation else 'Gravação sem alterações')
    return txt+(' — '+', '.join(names[:4])+('…' if len(names)>4 else '') if names else '')


def integrity_summary(p):
    try:return integrity.summary(p)
    except Exception:
        traceback.print_exc();return {'situacao':'indisponivel','problemas':None}


def fmt(value,digits=2):
    if isinstance(value,(int,float)):return f'{value:,.{digits}f}'.replace(',','@').replace('.',',').replace('@','.')
    if value is None or value=='':return '—'
    if isinstance(value,dict):return str(value.get('error','—'))
    return str(value)


def calc_base_html(project):
    """Anexo 'Base de cálculo': catálogo efetivamente usado e versões divergentes do baseline."""
    cat=Catalog(project);info=cat.list(limit=1);div=cat.divergences()
    h=html.escape
    out=['<p><b>Catálogo de expressões:</b> '+h(info['baseline'])+' · '+str(info['total_entradas'])+' variáveis calculadas com nome, unidade e dependências explícitas · '
         +str(len(info['regras_python']))+' regras implementadas em Python. '
         'Variáveis com referência normativa atribuída: '+str(info['total_entradas']-info['sem_justificativa'])+' de '+str(info['total_entradas'])+
         '; as demais constam como <i>sem justificativa atribuída</i>.</p>']
    if div['itens']:
        out.append('<h3>Expressões diferentes do modelo do aplicativo</h3><table><thead><tr><th>Variável</th><th>Versão</th><th>Autor</th><th>Data</th><th>Justificativa</th><th>Expressão do modelo</th><th>Expressão em uso</th></tr></thead><tbody>'
            +''.join('<tr><td><code>'+h(i['id'])+'</code> · '+h(i['descricao'])+'</td><td>v'+str(i['versao'])+'</td><td>'+h(str(i['autor']))+'</td><td>'+h(str(i['ts']))+'</td><td>'+h(str(i.get('justificativa') or '—'))+(' <b>(sem registro válido)</b>' if i.get('integridade') in ('alterada','invalida') else '')+'</td><td><code>'+h(str(i['expressao_baseline'])[:400])+'</code></td><td><code>'+h(str(i['expressao'])[:400])+'</code></td></tr>' for i in div['itens'])+'</tbody></table>')
        d=div.get('diff_baseline')
        if d:out.append('<p>Impacto acumulado frente ao modelo: '+str(d['campos_afetados'])+' campo(s), '+str(d['circuitos_afetados'])+' circuito(s) com valores diferentes.</p>')
    else:
        out.append('<p>Nenhuma expressão editada: o projeto usa o modelo do aplicativo. '
                   'As colunas geridas pela instalação usam as regras do aplicativo, descritas no registro de agrupamento e no catálogo.</p>')
    used={}
    for eid,rids in cat.links.items():
        for rid in rids:used.setdefault(rid,[]).append(eid)
    refs=[r for r in (cat.ref_view(rid) for rid in sorted(used)) if r]
    if refs:
        out.append('<h3>Referências normativas atribuídas</h3><table><thead><tr><th>Norma</th><th>Item / tabela</th><th>Situação</th><th>Variáveis e regras</th></tr></thead><tbody>'
            +''.join('<tr><td>'+h(str(r.get('norma')))+'</td><td>'+h(str(r.get('item') or r.get('tabela')))+'</td><td>'+(('verificada por '+h(str(r['verificado_por']))+' em '+h(str(r['verificado_em']))) if r['verificada'] else 'não verificada')+(' · paráfrase' if r.get('trecho') and not r.get('verbatim') else '')+'</td><td>'+str(len(used[r['id']]))+'</td></tr>' for r in refs)+'</tbody></table>')
    out.append(tabelas.report_html(project))
    return ''.join(out)


def integrity_html(project):
    """Integridade das fórmulas frente à referência do aplicativo (v1.12)."""
    r=integrity.report(project);h=html.escape;c=r['contagem']
    if not r['problemas']:
        return ('<p><b>Integridade:</b> as expressões e tabelas conferem com o modelo do aplicativo'
                +(f" ({c['editada']} expressão(ões) e {c['tabela_editada']} tabela(s) editadas pelo revisor, com registro)" if c['editada'] or c['tabela_editada'] else '')+'.</p>')
    rows=''.join('<tr><td>'+h(x.get('variavel') or x.get('tabela') or '')+(' · '+h(x['circuito']) if x.get('circuito') else '')+'</td><td>'+h(x.get('descricao') or '')+'</td><td>'+h(x['rotulo'])+'</td></tr>' for x in r['itens'][:80])
    return ('<p><b>Integridade: '+str(r['problemas'])+' item(ns) diferem do modelo do aplicativo sem registro válido de edição.</b> '
            'Os resultados abaixo usam as expressões e tabelas encontradas no projeto.</p><table><thead><tr><th>Variável / tabela</th><th>Descrição</th><th>Situação</th></tr></thead><tbody>'+rows+'</tbody></table>')


def device_texts(c):
    """Dispositivo na origem, disjuntor de manutenção e DPS em texto curto (relatório e CSV)."""
    if c.get('origem_ausente'):origem='Sem dispositivo na origem — '+str(c.get('justificativa_origem') or 'justificativa pendente')
    else:origem=value_label(c.get('protecao'))
    mb=c.get('manutencao')
    manut=('—' if not mb else ' · '.join(str(x) for x in (mb.get('modelo') or 'modelo pendente',mb.get('ajuste')) if x))
    if c.get('dps_ausente'):dps='Sem DPS neste quadro'
    else:dps=value_label(c.get('dps_modelo'))
    return origem,manut,dps


def report(project):
    s=project.summary(); esc=lambda v:html.escape(fmt(v)); rows=[]; checks=[]; groups=[]; group_details=[]; trechos=[]
    for c in s['circuits']:
        origem,manut,dps=device_texts(c)
        vals=[c['name'],c['parent'],c['phases'],c.get('condutores'),c['p_w'],c['ib'],c['sec_f'],c['sec_n'],c['sec_pe'],c['dv'],c['dv_total'],c['icc_max'],origem,manut,dps]
        rows.append('<tr>'+''.join('<td>'+esc(v)+'</td>' for v in vals)+'</tr>')
        checks.append('<h3>'+esc(c['name'])+'</h3>'+('<ul>'+''.join('<li><b>'+esc(x['label'])+'</b>: '+esc(x['value'])+'</li>' for x in c['issues'])+'</ul>' if c['issues'] else '<p>Sem pendência nos indicadores consultados.</p>'))
        g=c['grouping'];r=c['row'];settings=project.installation.settings(r)
        items=[c['name'],g['physical_count'],g['count'],g['factor'] if c['installation_valid'] else 'Pendente',
               g['temperature'],g.get('source'),g['coordinate']]
        groups.append('<tr>'+''.join('<td>'+esc(v)+'</td>' for v in items)+'</tr>')
        detail=project.installation.group_trace(r)
        if settings.get('independence_basis'):detail+=' | Independência térmica: '+str(settings['independence_basis'])
        if settings.get('low_load_basis'):detail+=' | Conjuntos excluídos: '+str(settings['low_load_basis'])
        detail+=' | Solo × profundidade: '+fmt(c.get('fcr'))+' | Fator de neutro carregado: '+fmt(project.installation.neutral_heating(r))
        detail+=' | Piso interno de 15%: '+('ativo' if settings.get('neutral_floor',True) else 'desativado')
        detail+=' | Redução de seção do neutro: '+str(settings.get('neutral_basis') or 'não comprovada; seção mínima igual à fase quando existe neutro')
        group_details.append('<h3>'+esc(c['name'])+'</h3><p>'+esc(detail)+'</p>')
        if c.get('origem_ausente') or c.get('manutencao') or c.get('dps_ausente'):
            items=[]
            if c.get('origem_ausente'):
                items+=[('Dispositivo na origem',origem),('Proteção contra curtos-circuitos',c.get('trecho_curto')),
                        ('Proteção contra sobrecargas',c.get('trecho_sobrecarga')),('Seccionamento automático',c.get('trecho_choque'))]
            if c.get('manutencao'):items+=[('Disjuntor de manutenção',manut),('Status',c['manutencao'].get('status'))]
            if c.get('dps_ausente'):items.append(('DPS',dps+(' — DPS a montante: '+str(value_label(c.get('dps_montante_circuito'))) if c.get('dps_montante_circuito') else '')))
            trechos.append('<h3>'+esc(c['name'])+'</h3><ul>'+''.join('<li><b>'+esc(k)+'</b>: '+esc(v)+'</li>' for k,v in items)+'</ul>')
    headers=['Circuito','Montante','Ligação','Condutores (por polo)','P (W)','Ib (A)','F (mm²)','N (mm²)','PE (mm²)','ΔV (%)','ΔV acum. (%)','Ik máx. (kA)','Proteção na origem','Disjuntor de manutenção','DPS']
    return ('<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Relatório · '+esc(s['title'])+'</title>'
        '<style>body{font:12px Arial,sans-serif;color:#132838;margin:30px}h1{font-size:26px}h2{margin-top:30px}table{border-collapse:collapse;width:100%;font-size:10px}td,th{border:1px solid #cad6df;padding:7px;text-align:left}th{background:#edf2f6}tr{break-inside:avoid}p{line-height:1.6}li{margin:6px 0}button{padding:10px 20px;border:0;background:#173b50;color:white;border-radius:5px}@page{size:A4 landscape;margin:14mm}@media print{button{display:none}body{margin:0}h3{break-after:avoid}}</style>'
        '<button onclick="window.print()">Imprimir / salvar em PDF</button><h1>'+esc(s['title'])+'</h1><p>EletroApp '+APP_UI_VERSION+' · regras de cálculo '+RULES_VERSION+' · modelo nativo · revisão '+str(int(project.meta.get('revision',0) or 0))+' do projeto · '+time.strftime('%d/%m/%Y %H:%M')+'</p>'
        '<p><b>Potência na origem:</b> '+esc(s['p_w'])+' W · <b>Potência aparente:</b> '+esc(s['s_va'])+' VA · <b>Circuitos:</b> '+str(len(s['circuits']))+'</p>'
        '<table><thead><tr>'+''.join('<th>'+h+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join(rows)+'</tbody></table>'
        '<h2>Agrupamento por trecho</h2><table><thead><tr>'+''.join('<th>'+x+'</th>' for x in ['Circuito','Total físico','Considerados','FCA','Base térmica (°C)','Fonte','Tabela e condição'])+'</tr></thead><tbody>'+''.join(groups)+'</tbody></table>'+''.join(group_details)+
        ('<h2>Dispositivos do trecho</h2><p>Circuitos sem dispositivo na origem, com disjuntor de manutenção na extremidade ou sem DPS no quadro. '
          'Itens da NBR 5410:2004 citados: 5.3.4.2.2, 5.3.4.3, 5.3.5.2 e 5.3.5.3 — conferir na edição vigente.</p>'+''.join(trechos) if trechos else '')+
        '<h2>Coordenação das proteções</h2>'+curvas.coordination_html(project)+
        '<h2>Proteção da entrada e dos alimentadores</h2>'+protection.report_html(project)+
        '<h2>Pendências do projeto</h2>'+''.join(checks)+'<h2>Base de cálculo</h2>'+integrity_html(project)+calc_base_html(project)+'<p>'
        'Resultados calculados pelo motor nativo do EletroApp (variáveis nomeadas, expressões versionadas e base técnica versionada). '
        'O cálculo não constitui validação normativa independente: confira as referências indicadas na edição vigente das normas. '
        'Os catálogos de fabricantes são cópias da base técnica do aplicativo, com a origem indicada; conferir a ficha vigente e as curvas dos dispositivos antes de confirmar a seleção. '
        'O relatório usa apenas as raízes para a potência total e evita somar alimentadores com suas cargas a jusante.</p></html>')


# Ordem das abas no menu lateral (exportação dos comentários de revisão segue a mesma sequência).
REVIEW_VIEW_ORDER=['overview','source','circuits','circuito-geral','circuito-cargas','circuito-motores','circuito-instalacao',
                   'circuito-condutores','circuito-curto','circuito-protecoes','circuito-dps','circuito','diagram','protection',
                   'coordination','dps','audit','sheets','tables','installtables','compare','history','help','geral']


def _review_ts(ts):
    """'2026-10-14 13:20:05' → '14/10/2026 13:20'."""
    try:return time.strftime('%d/%m/%Y %H:%M',time.strptime(str(ts),'%Y-%m-%d %H:%M:%S'))
    except (TypeError,ValueError):return str(ts or '')


def _review_groups(items):
    order={v:i for i,v in enumerate(REVIEW_VIEW_ORDER)}
    groups={}
    for c in items:groups.setdefault(c['view'],[]).append(c)
    keys=sorted(groups,key=lambda v:(order.get(v,len(order)),v))
    return [(k,groups[k][0].get('view_label') or k,sorted(groups[k],key=lambda c:c['id'])) for k in keys]


def review_export(items,fmt='md',filtro=''):
    """Comentários de revisão em Markdown (para enviar à revisão do aplicativo), CSV ou JSON. Devolve (bytes, ctype, extensão)."""
    now=time.strftime('%Y-%m-%d %H:%M:%S');code=lambda c:f"C-{int(c['id']):03d}"
    if fmt=='json':
        body={'formato':'eletroapp-comentarios-revisao','versao':1,'app':APP_UI_VERSION,'gerado':now,'filtro':filtro or None,
              'itens':[{**c,'codigo':code(c)} for c in sorted(items,key=lambda c:c['id'])]}
        return json.dumps(body,ensure_ascii=False,indent=2).encode(),'application/json; charset=utf-8','json'
    if fmt=='csv':
        buf=io.StringIO();w=csv.writer(buf,delimiter=';')
        def safe(v):
            v='' if v is None else str(v)
            return "'"+v if v.startswith(('=','+','-','@','\t','\r')) else v
        w.writerow(['Código','Aba','Sub-aba','Tipo','Prioridade','Situação','Comentário','Referência','Autor','Projeto','Revisão do projeto',
                    'Circuito','Versão do aplicativo','Criado','Atualizado','Resolução'])
        for _,label,cs in _review_groups(items):
            for c in cs:
                w.writerow([safe(x) for x in (code(c),label,c['subtab'],c['kind'],c['priority'],c['status'],c['text'],c['ref'],c['author'],
                            c['project_title'],c['project_revision'],c['circuit_name'],c['app_version'],_review_ts(c['created']),
                            _review_ts(c['updated']),c['resolution'])])
        return b'\xef\xbb\xbf'+buf.getvalue().encode(),'text/csv; charset=utf-8','csv'
    cell=lambda v:str(v).replace('|','\\|').replace('\n',' ')
    count=lambda cs,s:sum(1 for c in cs if c['status']==s)
    out=[f'# Comentários de revisão — EletroApp {APP_UI_VERSION}','',
         f"Gerado em {_review_ts(now)} · {len(items)} comentário(s): {count(items,'Aberto')} aberto(s), "
         f"{count(items,'Resolvido')} resolvido(s), {count(items,'Descartado')} descartado(s)."+(f' Filtro: {filtro}.' if filtro else ''),'']
    if not items:
        out.append('_Nenhum comentário registrado._')
        return ('\n'.join(out)+'\n').encode(),'text/markdown; charset=utf-8','md'
    groups=_review_groups(items)
    out+=['## Resumo por aba','','| Aba | Abertos | Resolvidos | Descartados | Alta prioridade em aberto |','|---|---:|---:|---:|---:|']
    for _,label,cs in groups:
        out.append(f"| {cell(label)} | {count(cs,'Aberto')} | {count(cs,'Resolvido')} | {count(cs,'Descartado')} | "
                   f"{sum(1 for c in cs if c['status']=='Aberto' and c['priority']=='Alta')} |")
    out.append('')
    for _,label,cs in groups:
        out+=[f'## {label} ({len(cs)})','']
        for c in cs:
            out.append(f"### {code(c)} · {c['kind']} · prioridade {c['priority']} · {c['status']}")
            out.append('')
            meta=[f"Registrado em {_review_ts(c['created'])}"+(f" (atualizado em {_review_ts(c['updated'])})" if c['updated']!=c['created'] else ''),
                  f"EletroApp {c['app_version'] or '—'}"]
            if c['author']:meta.append('autor: '+c['author'])
            out.append('- '+' · '.join(meta))
            ctx=[]
            if c['project_title']:ctx.append(f"Projeto: {c['project_title']} (revisão {c['project_revision']})")
            if c['circuit_name']:ctx.append(f"Circuito: {c['circuit_name']}")
            if c['subtab']:ctx.append(f"Sub-aba: {c['subtab']}")
            if ctx:out.append('- '+' · '.join(ctx))
            if c['ref']:out.append(f"- Referência: {c['ref']}")
            out.append('')
            out+=['> '+line if line.strip() else '>' for line in str(c['text']).split('\n')]
            if c['resolution']:out+=['',f"**Resolução:** {c['resolution']}"]
            out.append('')
    return ('\n'.join(out)+'\n').encode(),'text/markdown; charset=utf-8','md'


class Handler(BaseHTTPRequestHandler):
    server_version='EletroApp/'+APP_UI_VERSION
    def log_message(self,format,*args):
        if args and str(args[1] if len(args)>1 else '').startswith(('4','5')):super().log_message(format,*args)
    @property
    def store(self):return self.server.store
    def respond(self,body,status=200,ctype='application/json; charset=utf-8',filename=None):
        if isinstance(body,(dict,list)):body=json.dumps(body,ensure_ascii=False,allow_nan=False).encode()
        elif isinstance(body,str):body=body.encode()
        self.send_response(status);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'")
        if filename:self.send_header('Content-Disposition','attachment; filename="'+filename+'"')
        self.end_headers()
        try:self.wfile.write(body)
        except (BrokenPipeError,ConnectionResetError):pass
    def fail(self,e,status=400):self.respond({'error':str(e)},status)
    def rev_defaults(self):
        for k,v in (('reviewer',None),('reviewer_fails',0),('reviewer_block',0.0)):
            if not hasattr(self.server,k):setattr(self.server,k,v)
    def reviewer_status(self):
        self.rev_defaults()
        rev=self.server.reviewer
        if rev and rev['until']<time.time():self.server.reviewer=rev=None
        return {'configurado':bool(self.store.reviewer_record()),'desbloqueado':bool(rev),'nome':rev['nome'] if rev else None}
    def require_reviewer(self):
        st=self.reviewer_status()
        if not st['desbloqueado']:raise PermissionError('Modo revisor bloqueado. Desbloqueie com a senha de revisor.')
        return self.server.reviewer
    def valid_host(self):
        return self.headers.get('Host','') in (f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}')
    def do_GET(self):
        if not self.valid_host():return self.fail('Host não permitido.',403)
        parsed=urlparse(self.path);path=parsed.path;q={k:v[0] for k,v in parse_qs(parsed.query).items()}
        if path in ('/','/index.html'):
            return self.respond((ROOT/'static/index.html').read_text(encoding='utf-8').replace('__TOKEN__',self.server.token),ctype='text/html; charset=utf-8')
        assets={'/trecho.js':('trecho.js','text/javascript; charset=utf-8'),'/instalacao.js':('instalacao.js','text/javascript; charset=utf-8'),'/app.js':('app.js','text/javascript; charset=utf-8'),'/workflow.js':('workflow.js','text/javascript; charset=utf-8'),'/catalogo.js':('catalogo.js','text/javascript; charset=utf-8'),'/projeto.js':('projeto.js','text/javascript; charset=utf-8'),'/protecao.js':('protecao.js','text/javascript; charset=utf-8'),'/origem.js':('origem.js','text/javascript; charset=utf-8'),'/ux.js':('ux.js','text/javascript; charset=utf-8'),'/style.css':('style.css','text/css; charset=utf-8')}
        assets['/agrupamento.js']=('agrupamento.js','text/javascript; charset=utf-8')
        # v2.3.1: protecao-integrada.js era carregado pelo index.html mas não estava nesta lista (404 na 2.3.0:
        # o formulário do circuito não abria e o bloco de proteção a montante do ramal não aparecia).
        for name in ('numeros.js','historico.js','importacao.js','base.js','normativa.js','protecao-integrada.js','revisao.js'):assets['/'+name]=(name,'text/javascript; charset=utf-8')
        if path in assets:
            filename,ctype=assets[path];return self.respond((ROOT/'static'/filename).read_bytes(),ctype=ctype)
        if path=='/favicon.ico':return self.respond(b'',204,'image/x-icon')
        if path=='/api/metodos':return self.respond(INSTALL_METHODS)
        if path=='/api/installation/catalog':return self.respond(consultation())
        if path=='/api/metodos-linha':return self.respond(LINHAS_METODO_MAPA)
        if path.startswith('/img/metodos/'):
            name=path[len('/img/metodos/'):]
            ext=name.rsplit('.',1)[-1].lower() if '.' in name else ''
            # Sem barras/"..": impede travessia de diretório. Extensão de imagem
            # conhecida: evita servir qualquer outro arquivo do disco por engano.
            if not name or '/' in name or '\\' in name or '..' in name or ext not in IMG_EXT:
                return self.fail('Caminho inválido.',400)
            try:data=(ROOT/'static/img/metodos'/name).read_bytes()
            except OSError:return self.fail('Imagem não encontrada.',404)
            return self.respond(data,ctype=IMG_EXT[ext])
        try:
            with self.server.lock:
                p=self.store.project
                if path=='/api/state':return self.respond({**p.summary(),'project_id':self.store.active_id,'revision':self.store.revision,
                                                           'integridade':integrity_summary(p),'ia_importacao':importacao.ai_available()})
                if path=='/api/history':return self.respond({'revisoes':self.store.history(),'atual':self.store.revision,'project_id':self.store.active_id})
                if path=='/api/history/compare':
                    return self.respond(self.store.compare(int(q['a']),int(q.get('b',self.store.revision))))
                if path=='/api/integrity':return self.respond(integrity.report(p))
                if path=='/api/projects':return self.respond({'projects':self.store.list(),'active':self.store.active_id})
                if path=='/api/form':return self.respond(p.form(q['id']))
                if path=='/api/advisor':return self.respond(advise(p,p.row_for(q['id'])))
                if path=='/api/source':return self.respond(p.source_form())
                if path=='/api/cell':return self.respond(p.field(q['sheet'],q['address']))
                if path=='/api/tables':return self.respond(tabelas.listing(p))
                if path=='/api/table':return self.respond(tabelas.view(p,q['id'],int(q.get('row',1)),int(q.get('count',60)),q.get('q','')))
                # v2.2.0 — vista normativa da Base técnica
                if path=='/api/norm/map':return self.respond(normativa.mapa(p))
                if path=='/api/norm/amp':return self.respond(normativa.ampacidade(p,q.get('tab','36'),q.get('mat','Cu'),q.get('id') or None))
                if path=='/api/norm/uso':return self.respond(normativa.uso(p,q['tabela'],q.get('id') or None))
                if path=='/api/norm/fichas':return self.respond(normativa.fichas(p,q.get('tipo','dps_siemens'),q.get('q',''),q.get('usados')=='1',
                                                                              int(q.get('offset',0)),int(q.get('limit',24))))
                if path=='/api/norm/conferencia':return self.respond(normativa.conferencia(p))
                if path=='/api/coordination':return self.respond(curvas.coordination(p))
                if path=='/api/base':return self.respond(self.store.base_status())
                if path=='/api/rule':return self.respond(Catalog(p).rule_application(q['id'],q['circuito']))
                if path=='/api/curves':return self.respond(curvas.listing(p))
                if path=='/api/protecao-catalogo':
                    # Catálogo real WEG (Biblioteca_Proteções_WEG) já classificado em
                    # fixo/ajustável, igual ao que a aba "Proteção e catálogo" usa para
                    # filtrar AL/AM — igual pattern de /api/metodos, mas por ser lido do
                    # PROJETO carregado (não é constante normativa global), fica dentro
                    # do lock, com o cache por instância de weg_catalog().
                    return self.respond({'catalogo':p.weg_catalog(),'familias_por_classe':p.weg_familias_por_classe(),
                                          'fusivel_opcoes':p.fusivel_opcoes()})
                if path=='/api/catalog':
                    return self.respond(Catalog(p).list(q.get('q',''),q.get('aba',''),q.get('norma',''),q.get('status',''),
                                                         min(int(q.get('limit',60)),200),max(int(q.get('offset',0)),0)))
                if path=='/api/catalog/entry':
                    cat=Catalog(p);return self.respond(cat.entry_view(cat.get(q['id']),detail=True))
                if path=='/api/trace':return self.respond(Catalog(p).trace(q.get('circuito'),q['campo'],q.get('aba','')))
                if path=='/api/normrefs':return self.respond({'refs':Catalog(p).all_refs()})
                if path=='/api/formula/divergences':return self.respond(Catalog(p).divergences())
                if path=='/api/reviewer':return self.respond(self.reviewer_status())
                # v2.3.1 — comentários de revisão do aplicativo
                if path=='/api/review/comments':
                    return self.respond({'itens':self.store.review_list(q.get('view') or None,q.get('status') or None),
                                         'tipos':list(REVIEW_KINDS),'prioridades':list(REVIEW_PRIORITIES),'situacoes':list(REVIEW_STATUS),
                                         'versao':APP_UI_VERSION,'project_id':self.store.active_id})
                if path=='/api/review/export':
                    status=q.get('status') or None
                    if status and status not in REVIEW_STATUS:raise ValueError('Situação inválida.')
                    items=self.store.review_list(q.get('view') or None,status)
                    filtro=' · '.join(x for x in (('situação '+status) if status else '',('aba '+items[0]['view_label']) if q.get('view') and items else '') if x)
                    body,ctype,ext=review_export(items,q.get('format','md'),filtro)
                    return self.respond(body,ctype=ctype,filename=f"comentarios_revisao_EletroApp_v{APP_UI_VERSION}_{time.strftime('%Y%m%d-%H%M')}.{ext}")
                if path=='/report':return self.respond(report(p),ctype='text/html; charset=utf-8')
                if path=='/api/export':
                    if q.get('format')=='csv':
                        buf=io.StringIO();w=csv.writer(buf,delimiter=';')
                        keys=['name','parent','phases','p_w','s_va','ib','sec_f','sec_n','sec_pe','dv','dv_total','icc_max','protecao','prot_status','dps_status']
                        w.writerow(['Circuito','Montante','Ligação','P (W)','S (VA)','Ib (A)','Fase (mm²)','Neutro (mm²)','PE (mm²)','Queda trecho (%)','Queda acumulada (%)','Ik máx (kA)','Disjuntor','Status proteção','Status DPS',
                                    'Dispositivo na origem','Disjuntor de manutenção','Status do disjuntor de manutenção','DPS neste quadro','Condutores (agrupado)'])
                        for c in p.circuits():
                            def safe(v):
                                v=value_label(v)
                                if isinstance(v,(int,float)):return str(v).replace('.',',')
                                v='' if v is None else str(v)
                                return "'"+v if v.startswith(('=','+','-','@','\t','\r')) else v
                            origem,manut,dps=device_texts(c)
                            w.writerow([safe(c[k]) for k in keys]+[safe(origem),safe(manut),safe((c.get('manutencao') or {}).get('status')),safe(dps),safe(c.get('condutores'))])
                        return self.respond(b'\xef\xbb\xbf'+buf.getvalue().encode(),ctype='text/csv; charset=utf-8',filename='resultados_eletricos.csv')
                    return self.respond(p.packed(),ctype='application/gzip',filename='projeto.eletro')
                return self.fail('Endereço não encontrado.',404)
        except (ValueError,KeyError,TypeError) as e:self.fail(e)
        except Exception:
            traceback.print_exc();self.fail('Erro interno ao calcular. Consulte o terminal para o diagnóstico.',500)
    # Pedidos que alteram o projeto ativo: exigem o projeto e a revisão em que a tela se baseou (v1.12).
    MUTATING={'/api/changes','/api/circuit/add','/api/circuit/delete','/api/formula/confirm','/api/formula/rollback',
              '/api/table/edit','/api/table/restore','/api/curves/import','/api/curves/delete','/api/base/adopt','/api/migration/ack',
              '/api/normref/link','/api/normref/save','/api/normref/verify','/api/projects/rename','/api/history/restore','/api/import-loads/confirm','/api/protection/confirm-curve'}
    # Prévias: precisam ao menos ser do mesmo projeto.
    PROJECT_BOUND=MUTATING|{'/api/choices/preview','/api/installation/preview','/api/formula/edit','/api/import-loads/preview'}
    def saved(self,extra=None):
        return self.respond({'ok':True,**(extra or {}),'project_id':self.store.active_id,'revision':self.store.revision})
    def do_POST(self):
        if not self.valid_host():return self.fail('Host não permitido.',403)
        origin=self.headers.get('Origin')
        allowed=(f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}')
        if origin and origin not in allowed:return self.fail('Origem não permitida.',403)
        if self.headers.get('X-Eletro-Token')!=self.server.token:return self.fail('Sessão inválida. Atualize a página.',403)
        try:
            n=int(self.headers.get('Content-Length','0'))
            if n<0 or n>35_000_000:return self.fail('Arquivo excede 35 MB.',413)
            raw=self.rfile.read(n);path=urlparse(self.path).path
            with self.server.lock:
                if path in self.PROJECT_BOUND:
                    self.store.check(self.headers.get('X-Eletro-Project'),self.headers.get('X-Eletro-Revision') if path in self.MUTATING else None)
                if path=='/api/import':
                    filename=unquote(self.headers.get('X-Filename','projeto.eletro'))
                    if not filename.lower().endswith('.eletro'):
                        raise ValueError('Abra um arquivo de projeto .eletro. Quadros de carga (CSV, XLSX, PDF ou imagem) entram pelo botão “Importar quadro de cargas”.')
                    data=unpack(raw)
                    self.store.add(data,Path(filename).stem,summary='Projeto importado de '+Path(filename).name[:120])
                    return self.saved({'id':self.store.active_id})
                if path=='/api/import-loads/preview':
                    filename=unquote(self.headers.get('X-Filename','quadro.csv'))
                    return self.respond(importacao.preview(self.store.project,raw,filename))
                body=json.loads(raw or '{}')
                author=(self.server.reviewer or {}).get('nome') if getattr(self.server,'reviewer',None) else None
                if path=='/api/choices/preview':
                    candidate=self.store.project.fork()
                    candidate.update(body.get('changes',[]),installation=body.get('installation'),validate_installation=False)
                    return self.respond(candidate.form(body['id']))
                if path=='/api/installation/preview':
                    candidate=self.store.project.fork()
                    candidate.update(body.get('changes',[]),validate_installation=False)
                    r=candidate.row_for(body['id'])
                    result=candidate.installation.state(r,reference=body.get('reference'),
                        reconcile=bool(body.get('reconcile')),trigger=body.get('trigger'),settings=body.get('settings'))
                    return self.respond(result)
                if path=='/api/changes':
                    changes=body['changes']
                    summary=lambda _:change_summary(self.store.project,changes,body.get('installation'))
                    self.store.transactional(lambda p:p.update(changes,installation=body.get('installation')),summary=summary,author=author)
                    return self.saved()
                if path=='/api/protection/confirm-curve':
                    self.store.transactional(lambda p:protection.confirm_curve(p,body.get('category'),body.get('id')),
                        summary='Curva de proteção confirmada para os dados atuais.',author=author)
                    return self.saved()
                if path=='/api/circuit/add':
                    uid=self.store.transactional(lambda p:p.add(body['name'],body.get('parent',''),body.get('duplicate')),
                                                 summary=('Circuito duplicado: ' if body.get('duplicate') else 'Circuito incluído: ')+str(body.get('name',''))[:80],author=author)
                    return self.saved({'id':uid})
                if path=='/api/circuit/delete':
                    name=self.store.project.raw(IDENT,f"B{self.store.project.row_for(body['id'])}")
                    self.store.transactional(lambda p:p.delete(body['id']),summary=f'Circuito excluído: {name}',author=author);return self.saved()
                if path=='/api/reviewer/unlock':
                    self.rev_defaults()
                    nome=str(body.get('nome','')).strip()[:80];senha=str(body.get('senha',''))
                    if not nome:raise ValueError('Informe o nome do revisor.')
                    if time.time()<self.server.reviewer_block:raise PermissionError('Muitas tentativas. Aguarde um minuto.')
                    if not self.store.reviewer_record():
                        if len(senha)<6:raise ValueError('Defina uma senha de revisor com ao menos 6 caracteres.')
                        self.store.reviewer_set(senha)
                    elif not self.store.reviewer_check(senha):
                        self.server.reviewer_fails+=1
                        if self.server.reviewer_fails>=5:self.server.reviewer_block=time.time()+60;self.server.reviewer_fails=0
                        raise PermissionError('Senha de revisor incorreta.')
                    self.server.reviewer_fails=0;self.server.reviewer={'nome':nome,'until':time.time()+3600}
                    return self.respond(self.reviewer_status())
                if path=='/api/reviewer/lock':
                    self.rev_defaults();self.server.reviewer=None;return self.respond(self.reviewer_status())
                if path=='/api/formula/edit':
                    rev=self.require_reviewer()
                    return self.respond(Catalog(self.store.project).preview_edit(body['id'],body.get('expressao',''),body.get('escopo','comum')))
                if path=='/api/formula/confirm':
                    rev=self.require_reviewer()
                    if body.get('confirmado') is not True:raise ValueError('Confirme explicitamente a edição.')
                    r=self.store.transactional(lambda p:Catalog(p).commit_edit(p,body['id'],body.get('expressao',''),rev['nome'],body.get('justificativa',''),
                                                                                escopo=body.get('escopo','comum')),
                                               summary=f"Expressão editada: {body['id']} ({body.get('escopo','comum')})",author=rev['nome'])
                    return self.saved(r)
                if path=='/api/formula/rollback':
                    rev=self.require_reviewer()
                    r=self.store.transactional(lambda p:Catalog(p).rollback(p,body['id'],int(body['versao']),rev['nome'],escopo=body.get('escopo','comum')),
                                               summary=f"Expressão restaurada: {body['id']} ({body.get('escopo','comum')}) → versão {int(body['versao'])}",author=rev['nome'])
                    return self.saved(r)
                if path=='/api/normref/link':
                    rev=self.require_reviewer()
                    self.store.transactional(lambda p:Catalog(p).set_links(p,body['id'],list(body.get('refs',[]))),
                                             summary=f"Referências normativas: {body['id']}",author=rev['nome']);return self.saved()
                if path=='/api/normref/save':
                    rev=self.require_reviewer()
                    rid=self.store.transactional(lambda p:Catalog(p).save_ref(p,body.get('ref',{}),rev['nome'],bool(body.get('verificar'))),
                                                 summary='Referência normativa cadastrada',author=rev['nome'])
                    return self.saved({'id':rid})
                if path=='/api/normref/verify':
                    rev=self.require_reviewer()
                    r=self.store.transactional(lambda p:normativa.verificar(p,str(body.get('id','')),rev['nome'],body.get('pagina'),body.get('nota'),
                                                                             bool(body.get('desfazer'))),
                                               summary=('Conferência desfeita: ' if body.get('desfazer') else 'Referência conferida no exemplar: ')+str(body.get('id',''))[:60],
                                               author=rev['nome'])
                    return self.saved(r)
                if path=='/api/table/edit':
                    rev=self.require_reviewer()
                    r=self.store.transactional(lambda p:tabelas.edit(p,body['id'],body.get('celulas',{}),rev['nome'],body.get('justificativa',''),body.get('fonte','')),
                                               summary=f"Tabela técnica editada: {body['id']}",author=rev['nome'])
                    return self.saved(r)
                if path=='/api/table/restore':
                    rev=self.require_reviewer()
                    r=self.store.transactional(lambda p:tabelas.restore(p,body['id'],rev['nome'],body.get('justificativa','')),
                                               summary=f"Tabela técnica restaurada: {body['id']}",author=rev['nome'])
                    return self.saved(r)
                if path=='/api/curves/import':
                    rev=self.require_reviewer()
                    r=self.store.transactional(lambda p:curvas.import_data(p,body,rev['nome']),
                                               summary=lambda r:'Dados do fabricante importados: '+str(r.get('descricao',''))[:100],author=rev['nome'])
                    return self.saved(r)
                if path=='/api/curves/delete':
                    rev=self.require_reviewer()
                    self.store.transactional(lambda p:curvas.delete(p,body['id']),summary='Dados do fabricante removidos',author=rev['nome'])
                    return self.saved()
                if path=='/api/migration/ack':
                    rev=self.require_reviewer()
                    from core import migracao
                    self.store.transactional(lambda p:migracao.acknowledge(p,body.get('variavel'),body.get('circuito_id'),rev['nome'],body.get('justificativa')),
                                             summary=f"Conversão conferida: {body.get('variavel')}",author=rev['nome'])
                    return self.saved()
                if path=='/api/base/adopt':
                    rev=self.require_reviewer()
                    return self.saved(self.store.adopt_base(rev['nome']))
                if path=='/api/history/restore':
                    self.store.restore(int(body['revisao']),author=author);return self.saved()
                # v2.3.1 — comentários de revisão: não alteram o projeto (sem revisão nova nem conferência de revisão).
                if path=='/api/review/add':return self.respond({'ok':True,'comentario':self.store.review_add(body)})
                if path=='/api/review/update':return self.respond({'ok':True,'comentario':self.store.review_update(body['id'],body)})
                if path=='/api/review/delete':self.store.review_delete(body['id']);return self.respond({'ok':True})
                if path=='/api/backup':
                    target=self.store.backup('manual');return self.respond({'ok':True,'arquivo':target.name,'pasta':str(target.parent)})
                if path=='/api/import-loads/confirm':
                    result=self.store.transactional(lambda p:importacao.apply(p,body.get('linhas',[]),body.get('opcoes',{})),
                                                    summary=lambda r:f"Importação de quadro de cargas: {r['incluidos']} incluído(s), {r['atualizados']} atualizado(s)",author=author)
                    return self.saved(result)
                if path=='/api/projects/open':
                    self.store.open(body['id']);return self.saved()
                if path=='/api/projects/new':
                    data=example_data()
                    if body.get('blank'):
                        # Projeto em branco: mantém apenas a entrada de energia (ramal e medição) como ponto de partida.
                        data['circuitos']=data['circuitos'][:2]
                        keep={c['id'] for c in data['circuitos']}
                        data['meta']['installation_settings']={k:v for k,v in data['meta'].get('installation_settings',{}).items() if k in keep}
                    p=Project(data)
                    defaults=body.get('selection_defaults',{k:selection.AUTO for k in selection.KEYS})
                    if not isinstance(defaults,dict) or set(defaults)-set(selection.KEYS) or any(v not in (selection.AUTO,selection.MANUAL) for v in defaults.values()):
                        raise ValueError('Escolha Automático ou Manual para as proteções.')
                    # Clientes anteriores não enviam o modo do disjuntor de manutenção.
                    defaults={k:defaults.get(k,selection.AUTO) for k in selection.KEYS}
                    p.meta['selection_defaults']=defaults
                    for r in p.active_rows():p.meta.setdefault('selection_modes',{})[p.meta['ids'][str(r)]]=dict(defaults)
                    selection.apply(p)
                    if body.get('preset') not in (None,'','entrada_sem_disjuntor'):raise ValueError('Ponto de partida desconhecido.')
                    if body.get('preset')=='entrada_sem_disjuntor' and not body.get('blank'):
                        p.update(trecho.exemplo_entrada(p),validate_installation=False)
                    self.store.add(p.data,body.get('name','Novo projeto'));return self.saved()
                if path=='/api/projects/rename':
                    name=str(body.get('name','')).strip()
                    if not name:raise ValueError('Informe o nome do projeto.')
                    self.store.transactional(lambda p:p.meta.update(title=name[:160]),summary='Projeto renomeado: '+name[:80],author=author);return self.saved()
                return self.fail('Ação não encontrada.',404)
        except ConflictError as e:self.respond({'error':str(e),'conflict':e.kind},409)
        except PermissionError as e:self.fail(e,403)
        except (ValueError,KeyError,TypeError,OSError) as e:self.fail(e)
        except Exception:
            traceback.print_exc();self.fail('Não foi possível concluir. As alterações não foram gravadas.',500)


def main():
    parser=argparse.ArgumentParser(description='EletroApp: dimensionamento de instalações elétricas de baixa tensão')
    parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--no-browser',action='store_true')
    parser.add_argument('--data-dir',type=Path,default=ROOT/'projetos')
    args=parser.parse_args()
    store=Store(args.data_dir/'eletroapp.sqlite3')
    for port in range(args.port,args.port+20):
        try:server=ThreadingHTTPServer(('127.0.0.1',port),Handler);break
        except OSError:
            if port==args.port+19:raise
    server.store=store;server.token=secrets.token_urlsafe(32);server.lock=threading.RLock()
    server.reviewer=None;server.reviewer_fails=0;server.reviewer_block=0.0
    server.daemon_threads=True
    url=f'http://127.0.0.1:{server.server_port}'
    print('\nEletroApp '+APP_UI_VERSION+' — aplicativo Python\n'+url+'\nProjetos: '+str(store.path)+'\nMantenha este terminal aberto. Ctrl+C encerra o aplicativo.\n',flush=True)
    if not args.no_browser:threading.Timer(.7,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:print('\nAplicativo encerrado. Os projetos foram salvos.')
    finally:server.server_close()


if __name__=='__main__':main()
